package android.support.v4.media.session;

import android.content.ComponentName;
import android.content.Context;
import android.media.AudioManager;
import com.android.mms.model.SmilHelper;

/* JADX INFO: loaded from: classes.dex */
public class MediaSessionCompatApi8 {
    public static void registerMediaButtonEventReceiver(Context context, ComponentName mbr) {
        AudioManager am = (AudioManager) context.getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
        am.registerMediaButtonEventReceiver(mbr);
    }

    public static void unregisterMediaButtonEventReceiver(Context context, ComponentName mbr) {
        AudioManager am = (AudioManager) context.getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
        am.unregisterMediaButtonEventReceiver(mbr);
    }
}
