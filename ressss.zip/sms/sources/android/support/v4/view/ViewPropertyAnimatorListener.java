package android.support.v4.view;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public interface ViewPropertyAnimatorListener {
    void onAnimationCancel(View view);

    void onAnimationEnd(View view);

    void onAnimationStart(View view);
}
