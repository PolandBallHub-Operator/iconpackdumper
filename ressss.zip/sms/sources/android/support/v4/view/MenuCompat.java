package android.support.v4.view;

import android.view.MenuItem;

/* JADX INFO: loaded from: classes.dex */
public class MenuCompat {
    @Deprecated
    public static void setShowAsAction(MenuItem item, int actionEnum) {
        MenuItemCompat.setShowAsAction(item, actionEnum);
    }
}
