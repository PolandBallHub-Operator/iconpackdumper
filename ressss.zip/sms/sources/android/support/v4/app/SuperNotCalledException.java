package android.support.v4.app;

import android.util.AndroidRuntimeException;

/* JADX INFO: loaded from: classes.dex */
final class SuperNotCalledException extends AndroidRuntimeException {
    public SuperNotCalledException(String msg) {
        super(msg);
    }
}
