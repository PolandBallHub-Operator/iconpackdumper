package com.android.ex.editstyledtext;

import android.R;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.view.ViewCompat;
import android.text.ClipboardManager;
import android.text.Editable;
import android.text.Html;
import android.text.Layout;
import android.text.NoCopySpan;
import android.text.Selection;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.ArrowKeyMovementMethod;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.AlignmentSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.CharacterStyle;
import android.text.style.DynamicDrawableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.ParagraphStyle;
import android.text.style.QuoteSpan;
import android.text.style.UnderlineSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import com.android.mms.ui.MessageDispActivity;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class EditStyledText extends EditText {
    private static final boolean DBG = true;
    public static final int DEFAULT_FOREGROUND_COLOR = -16777216;
    public static final int DEFAULT_TRANSPARENT_COLOR = 16777215;
    public static final int HINT_MSG_BIG_SIZE_ERROR = 5;
    public static final int HINT_MSG_COPY_BUF_BLANK = 1;
    public static final int HINT_MSG_END_COMPOSE = 7;
    public static final int HINT_MSG_END_PREVIEW = 6;
    public static final int HINT_MSG_NULL = 0;
    public static final int HINT_MSG_PUSH_COMPETE = 4;
    public static final int HINT_MSG_SELECT_END = 3;
    public static final int HINT_MSG_SELECT_START = 2;
    private static final int ID_CLEARSTYLES = 16776962;
    private static final int ID_COPY = 16908321;
    private static final int ID_CUT = 16908320;
    private static final int ID_HIDEEDIT = 16776964;
    private static final int ID_HORIZONTALLINE = 16776961;
    private static final int ID_PASTE = 16908322;
    private static final int ID_SELECT_ALL = 16908319;
    private static final int ID_SHOWEDIT = 16776963;
    private static final int ID_START_SELECTING_TEXT = 16908328;
    private static final int ID_STOP_SELECTING_TEXT = 16908329;
    public static final char IMAGECHAR = 65532;
    private static final int MAXIMAGEWIDTHDIP = 300;
    public static final int MODE_ALIGN = 6;
    public static final int MODE_BGCOLOR = 16;
    public static final int MODE_CANCEL = 18;
    public static final int MODE_CLEARSTYLES = 14;
    public static final int MODE_COLOR = 4;
    public static final int MODE_COPY = 1;
    public static final int MODE_CUT = 7;
    public static final int MODE_END_EDIT = 21;
    public static final int MODE_HORIZONTALLINE = 12;
    public static final int MODE_IMAGE = 15;
    public static final int MODE_MARQUEE = 10;
    public static final int MODE_NOTHING = 0;
    public static final int MODE_PASTE = 2;
    public static final int MODE_PREVIEW = 17;
    public static final int MODE_RESET = 22;
    public static final int MODE_SELECT = 5;
    public static final int MODE_SELECTALL = 11;
    public static final int MODE_SHOW_MENU = 23;
    public static final int MODE_SIZE = 3;
    public static final int MODE_START_EDIT = 20;
    public static final int MODE_STOP_SELECT = 13;
    public static final int MODE_SWING = 9;
    public static final int MODE_TELOP = 8;
    public static final int MODE_TEXTVIEWFUNCTION = 19;
    private static final int PRESSED = 16777233;
    private static final NoCopySpan.Concrete SELECTING = new NoCopySpan.Concrete();
    public static final int STATE_SELECTED = 2;
    public static final int STATE_SELECT_FIX = 3;
    public static final int STATE_SELECT_OFF = 0;
    public static final int STATE_SELECT_ON = 1;
    private static CharSequence STR_CLEARSTYLES = null;
    private static CharSequence STR_HORIZONTALLINE = null;
    private static CharSequence STR_PASTE = null;
    private static final String TAG = "EditStyledText";
    public static final char ZEROWIDTHCHAR = 8288;
    private StyledTextConverter mConverter;
    private Drawable mDefaultBackground;
    private StyledTextDialog mDialog;
    private ArrayList<EditStyledTextNotifier> mESTNotifiers;
    private InputConnection mInputConnection;
    private EditorManager mManager;
    private float mPaddingScale;

    public interface EditStyledTextNotifier {
        void cancelViewManager();

        boolean isButtonsFocused();

        void onStateChanged(int i, int i2);

        void sendHintMsg(int i);

        boolean sendOnTouchEvent(MotionEvent motionEvent);

        boolean showInsertImageSelectAlertDialog();

        boolean showMenuAlertDialog();

        boolean showPreview();
    }

    public interface StyledTextHtmlConverter {
        Spanned fromHtml(String str);

        Spanned fromHtml(String str, Html.ImageGetter imageGetter, Html.TagHandler tagHandler);

        String toHtml(Spanned spanned);

        String toHtml(Spanned spanned, boolean z);

        String toHtml(Spanned spanned, boolean z, int i, float f);
    }

    public EditStyledText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mPaddingScale = 0.0f;
        init();
    }

    public EditStyledText(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mPaddingScale = 0.0f;
        init();
    }

    public EditStyledText(Context context) {
        super(context);
        this.mPaddingScale = 0.0f;
        init();
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        boolean superResult;
        if (event.getAction() == 1) {
            cancelLongPress();
            boolean editting = isEditting();
            if (!editting) {
                onStartEdit();
            }
            int oldSelStart = Selection.getSelectionStart(getText());
            int oldSelEnd = Selection.getSelectionEnd(getText());
            superResult = super.onTouchEvent(event);
            if (isFocused() && getSelectState() == 0) {
                if (editting) {
                    this.mManager.showSoftKey(Selection.getSelectionStart(getText()), Selection.getSelectionEnd(getText()));
                } else {
                    this.mManager.showSoftKey(oldSelStart, oldSelEnd);
                }
            }
            this.mManager.onCursorMoved();
            this.mManager.unsetTextComposingMask();
        } else {
            superResult = super.onTouchEvent(event);
        }
        sendOnTouchEvent(event);
        return superResult;
    }

    @Override // android.widget.TextView, android.view.View
    public Parcelable onSaveInstanceState() {
        Parcelable superState = super.onSaveInstanceState();
        SavedStyledTextState ss = new SavedStyledTextState(superState);
        ss.mBackgroundColor = this.mManager.getBackgroundColor();
        return ss;
    }

    @Override // android.widget.TextView, android.view.View
    public void onRestoreInstanceState(Parcelable state) {
        if (!(state instanceof SavedStyledTextState)) {
            super.onRestoreInstanceState(state);
            return;
        }
        SavedStyledTextState ss = (SavedStyledTextState) state;
        super.onRestoreInstanceState(ss.getSuperState());
        setBackgroundColor(ss.mBackgroundColor);
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.mManager != null) {
            this.mManager.onRefreshStyles();
        }
    }

    @Override // android.widget.EditText, android.widget.TextView
    public boolean onTextContextMenuItem(int id) {
        boolean selection = getSelectionStart() != getSelectionEnd();
        switch (id) {
            case ID_HORIZONTALLINE /* 16776961 */:
                onInsertHorizontalLine();
                return true;
            case ID_CLEARSTYLES /* 16776962 */:
                onClearStyles();
                return true;
            case ID_SHOWEDIT /* 16776963 */:
                onStartEdit();
                return true;
            case ID_HIDEEDIT /* 16776964 */:
                onEndEdit();
                return true;
            case 16908319:
                onStartSelectAll();
                return true;
            case 16908320:
                if (selection) {
                    onStartCut();
                    return true;
                }
                this.mManager.onStartSelectAll(false);
                onStartCut();
                return true;
            case 16908321:
                if (selection) {
                    onStartCopy();
                    return true;
                }
                this.mManager.onStartSelectAll(false);
                onStartCopy();
                return true;
            case 16908322:
                onStartPaste();
                return true;
            case 16908328:
                onStartSelect();
                this.mManager.blockSoftKey();
                break;
            case 16908329:
                onFixSelectedItem();
                break;
        }
        return super.onTextContextMenuItem(id);
    }

    @Override // android.widget.TextView, android.view.View
    protected void onCreateContextMenu(ContextMenu menu) {
        super.onCreateContextMenu(menu);
        MenuHandler handler = new MenuHandler();
        if (STR_HORIZONTALLINE != null) {
            menu.add(0, ID_HORIZONTALLINE, 0, STR_HORIZONTALLINE).setOnMenuItemClickListener(handler);
        }
        if (isStyledText() && STR_CLEARSTYLES != null) {
            menu.add(0, ID_CLEARSTYLES, 0, STR_CLEARSTYLES).setOnMenuItemClickListener(handler);
        }
        if (this.mManager.canPaste()) {
            menu.add(0, 16908322, 0, STR_PASTE).setOnMenuItemClickListener(handler).setAlphabeticShortcut('v');
        }
    }

    @Override // android.widget.TextView
    protected void onTextChanged(CharSequence text, int start, int before, int after) {
        if (this.mManager != null) {
            this.mManager.updateSpanNextToCursor(getText(), start, before, after);
            this.mManager.updateSpanPreviousFromCursor(getText(), start, before, after);
            if (after > before) {
                this.mManager.setTextComposingMask(start, start + after);
            } else if (before < after) {
                this.mManager.unsetTextComposingMask();
            }
            if (this.mManager.isWaitInput()) {
                if (after > before) {
                    this.mManager.onCursorMoved();
                    onFixSelectedItem();
                } else if (after < before) {
                    this.mManager.onAction(22);
                }
            }
        }
        super.onTextChanged(text, start, before, after);
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        this.mInputConnection = new StyledTextInputConnection(super.onCreateInputConnection(outAttrs), this);
        return this.mInputConnection;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onFocusChanged(boolean focused, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(focused, direction, previouslyFocusedRect);
        if (focused) {
            onStartEdit();
        } else if (!isButtonsFocused()) {
            onEndEdit();
        }
    }

    private void init() {
        this.mConverter = new StyledTextConverter(this, new StyledTextHtmlStandard());
        this.mDialog = new StyledTextDialog(this);
        this.mManager = new EditorManager(this, this.mDialog);
        setMovementMethod(new StyledTextArrowKeyMethod(this.mManager));
        this.mDefaultBackground = getBackground();
        requestFocus();
    }

    public void setStyledTextHtmlConverter(StyledTextHtmlConverter html) {
        this.mConverter.setStyledTextHtmlConverter(html);
    }

    public void addEditStyledTextListener(EditStyledTextNotifier estInterface) {
        if (this.mESTNotifiers == null) {
            this.mESTNotifiers = new ArrayList<>();
        }
        this.mESTNotifiers.add(estInterface);
    }

    public void removeEditStyledTextListener(EditStyledTextNotifier estInterface) {
        int i;
        if (this.mESTNotifiers != null && (i = this.mESTNotifiers.indexOf(estInterface)) > 0) {
            this.mESTNotifiers.remove(i);
        }
    }

    private void sendOnTouchEvent(MotionEvent event) {
        if (this.mESTNotifiers != null) {
            for (EditStyledTextNotifier notifier : this.mESTNotifiers) {
                notifier.sendOnTouchEvent(event);
            }
        }
    }

    public boolean isButtonsFocused() {
        boolean retval = false;
        if (this.mESTNotifiers != null) {
            for (EditStyledTextNotifier notifier : this.mESTNotifiers) {
                retval |= notifier.isButtonsFocused();
            }
        }
        return retval;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showPreview() {
        if (this.mESTNotifiers != null) {
            for (EditStyledTextNotifier notifier : this.mESTNotifiers) {
                if (notifier.showPreview()) {
                    return;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void cancelViewManagers() {
        if (this.mESTNotifiers != null) {
            for (EditStyledTextNotifier notifier : this.mESTNotifiers) {
                notifier.cancelViewManager();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showInsertImageSelectAlertDialog() {
        if (this.mESTNotifiers != null) {
            for (EditStyledTextNotifier notifier : this.mESTNotifiers) {
                if (notifier.showInsertImageSelectAlertDialog()) {
                    return;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showMenuAlertDialog() {
        if (this.mESTNotifiers != null) {
            for (EditStyledTextNotifier notifier : this.mESTNotifiers) {
                if (notifier.showMenuAlertDialog()) {
                    return;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendHintMessage(int msgId) {
        if (this.mESTNotifiers != null) {
            for (EditStyledTextNotifier notifier : this.mESTNotifiers) {
                notifier.sendHintMsg(msgId);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notifyStateChanged(int mode, int state) {
        if (this.mESTNotifiers != null) {
            for (EditStyledTextNotifier notifier : this.mESTNotifiers) {
                notifier.onStateChanged(mode, state);
            }
        }
    }

    public void onStartEdit() {
        this.mManager.onAction(20);
    }

    public void onEndEdit() {
        this.mManager.onAction(21);
    }

    public void onResetEdit() {
        this.mManager.onAction(22);
    }

    public void onStartCopy() {
        this.mManager.onAction(1);
    }

    public void onStartCut() {
        this.mManager.onAction(7);
    }

    public void onStartPaste() {
        this.mManager.onAction(2);
    }

    public void onStartSize() {
        this.mManager.onAction(3);
    }

    public void onStartColor() {
        this.mManager.onAction(4);
    }

    public void onStartBackgroundColor() {
        this.mManager.onAction(16);
    }

    public void onStartAlign() {
        this.mManager.onAction(6);
    }

    public void onStartTelop() {
        this.mManager.onAction(8);
    }

    public void onStartSwing() {
        this.mManager.onAction(9);
    }

    public void onStartMarquee() {
        this.mManager.onAction(10);
    }

    public void onStartSelect() {
        this.mManager.onStartSelect(true);
    }

    public void onStartSelectAll() {
        this.mManager.onStartSelectAll(true);
    }

    public void onStartShowPreview() {
        this.mManager.onAction(17);
    }

    public void onStartShowMenuAlertDialog() {
        this.mManager.onStartShowMenuAlertDialog();
    }

    public void onStartAction(int mode, boolean notifyStateChanged) {
        this.mManager.onAction(mode, notifyStateChanged);
    }

    public void onFixSelectedItem() {
        this.mManager.onFixSelectedItem();
    }

    public void onInsertImage() {
        this.mManager.onAction(15);
    }

    public void onInsertImage(Uri uri) {
        this.mManager.onInsertImage(uri);
    }

    public void onInsertImage(int resId) {
        this.mManager.onInsertImage(resId);
    }

    public void onInsertHorizontalLine() {
        this.mManager.onAction(12);
    }

    public void onClearStyles() {
        this.mManager.onClearStyles();
    }

    public void onBlockSoftKey() {
        this.mManager.blockSoftKey();
    }

    public void onUnblockSoftKey() {
        this.mManager.unblockSoftKey();
    }

    public void onCancelViewManagers() {
        this.mManager.onCancelViewManagers();
    }

    private void onRefreshStyles() {
        this.mManager.onRefreshStyles();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onRefreshZeoWidthChar() {
        this.mManager.onRefreshZeoWidthChar();
    }

    public void setItemSize(int size) {
        this.mManager.setItemSize(size, true);
    }

    public void setItemColor(int color) {
        this.mManager.setItemColor(color, true);
    }

    public void setAlignment(Layout.Alignment align) {
        this.mManager.setAlignment(align);
    }

    @Override // android.view.View
    public void setBackgroundColor(int color) {
        if (color != 16777215) {
            super.setBackgroundColor(color);
        } else {
            setBackgroundDrawable(this.mDefaultBackground);
        }
        this.mManager.setBackgroundColor(color);
        onRefreshStyles();
    }

    public void setMarquee(int marquee) {
        this.mManager.setMarquee(marquee);
    }

    public void setHtml(String html) {
        this.mConverter.SetHtml(html);
    }

    public void setBuilder(AlertDialog.Builder builder) {
        this.mDialog.setBuilder(builder);
    }

    public void setColorAlertParams(CharSequence colortitle, CharSequence[] colornames, CharSequence[] colorints, CharSequence transparent) {
        this.mDialog.setColorAlertParams(colortitle, colornames, colorints, transparent);
    }

    public void setSizeAlertParams(CharSequence sizetitle, CharSequence[] sizenames, CharSequence[] sizedisplayints, CharSequence[] sizesendints) {
        this.mDialog.setSizeAlertParams(sizetitle, sizenames, sizedisplayints, sizesendints);
    }

    public void setAlignAlertParams(CharSequence aligntitle, CharSequence[] alignnames) {
        this.mDialog.setAlignAlertParams(aligntitle, alignnames);
    }

    public void setMarqueeAlertParams(CharSequence marqueetitle, CharSequence[] marqueenames) {
        this.mDialog.setMarqueeAlertParams(marqueetitle, marqueenames);
    }

    public void setContextMenuStrings(CharSequence horizontalline, CharSequence clearstyles, CharSequence paste) {
        STR_HORIZONTALLINE = horizontalline;
        STR_CLEARSTYLES = clearstyles;
        STR_PASTE = paste;
    }

    public boolean isEditting() {
        return this.mManager.isEditting();
    }

    public boolean isStyledText() {
        return this.mManager.isStyledText();
    }

    public boolean isSoftKeyBlocked() {
        return this.mManager.isSoftKeyBlocked();
    }

    public int getEditMode() {
        return this.mManager.getEditMode();
    }

    public int getSelectState() {
        return this.mManager.getSelectState();
    }

    public String getHtml() {
        return this.mConverter.getHtml(true);
    }

    public String getHtml(boolean escapeFlag) {
        return this.mConverter.getHtml(escapeFlag);
    }

    public String getHtml(ArrayList<Uri> uris, boolean escapeFlag) {
        this.mConverter.getUriArray(uris, getText());
        return this.mConverter.getHtml(escapeFlag);
    }

    public String getPreviewHtml() {
        return this.mConverter.getPreviewHtml();
    }

    public int getBackgroundColor() {
        return this.mManager.getBackgroundColor();
    }

    public EditorManager getEditStyledTextManager() {
        return this.mManager;
    }

    public int getForegroundColor(int pos) {
        if (pos < 0 || pos > getText().length()) {
            return -16777216;
        }
        ForegroundColorSpan[] spans = (ForegroundColorSpan[]) getText().getSpans(pos, pos, ForegroundColorSpan.class);
        if (spans.length > 0) {
            return spans[0].getForegroundColor();
        }
        return -16777216;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void finishComposingText() {
        if (this.mInputConnection != null && !this.mManager.mTextIsFinishedFlag) {
            this.mInputConnection.finishComposingText();
            this.mManager.mTextIsFinishedFlag = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float getPaddingScale() {
        if (this.mPaddingScale <= 0.0f) {
            this.mPaddingScale = getContext().getResources().getDisplayMetrics().density;
        }
        return this.mPaddingScale;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int dipToPx(int dip) {
        if (this.mPaddingScale <= 0.0f) {
            this.mPaddingScale = getContext().getResources().getDisplayMetrics().density;
        }
        return (int) (((double) (dip * getPaddingScale())) + 0.5d);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getMaxImageWidthDip() {
        return MAXIMAGEWIDTHDIP;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getMaxImageWidthPx() {
        return dipToPx(MAXIMAGEWIDTHDIP);
    }

    public void addAction(int mode, EditModeActions.EditModeActionBase action) {
        this.mManager.addAction(mode, action);
    }

    public void addInputExtra(boolean create, String extra) {
        Bundle bundle = super.getInputExtras(create);
        if (bundle != null) {
            bundle.putBoolean(extra, true);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void startSelecting(View view, Spannable content) {
        content.setSpan(SELECTING, 0, 0, PRESSED);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void stopSelecting(View view, Spannable content) {
        content.removeSpan(SELECTING);
    }

    private class EditorManager {
        private static final String LOG_TAG = "EditStyledText.EditorManager";
        private EditModeActions mActions;
        private BackgroundColorSpan mComposingTextMask;
        private SpannableStringBuilder mCopyBuffer;
        private EditStyledText mEST;
        private SoftKeyReceiver mSkr;
        private boolean mEditFlag = false;
        private boolean mSoftKeyBlockFlag = false;
        private boolean mKeepNonLineSpan = false;
        private boolean mWaitInputFlag = false;
        private boolean mTextIsFinishedFlag = false;
        private int mMode = 0;
        private int mState = 0;
        private int mCurStart = 0;
        private int mCurEnd = 0;
        private int mColorWaitInput = 16777215;
        private int mSizeWaitInput = 0;
        private int mBackgroundColor = 16777215;

        EditorManager(EditStyledText est, StyledTextDialog dialog) {
            this.mEST = est;
            this.mActions = EditStyledText.this.new EditModeActions(this.mEST, this, dialog);
            this.mSkr = new SoftKeyReceiver(this.mEST);
        }

        public void addAction(int mode, EditModeActions.EditModeActionBase action) {
            this.mActions.addAction(mode, action);
        }

        public void onAction(int mode) {
            onAction(mode, true);
        }

        public void onAction(int mode, boolean notifyStateChanged) {
            this.mActions.onAction(mode);
            if (notifyStateChanged) {
                this.mEST.notifyStateChanged(this.mMode, this.mState);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void startEdit() {
            resetEdit();
            showSoftKey();
        }

        public void onStartSelect(boolean notifyStateChanged) {
            Log.d(LOG_TAG, "--- onClickSelect");
            this.mMode = 5;
            if (this.mState == 0) {
                this.mActions.onSelectAction();
            } else {
                unsetSelect();
                this.mActions.onSelectAction();
            }
            if (notifyStateChanged) {
                this.mEST.notifyStateChanged(this.mMode, this.mState);
            }
        }

        public void onCursorMoved() {
            Log.d(LOG_TAG, "--- onClickView");
            if (this.mState == 1 || this.mState == 2) {
                this.mActions.onSelectAction();
                this.mEST.notifyStateChanged(this.mMode, this.mState);
            }
        }

        public void onStartSelectAll(boolean notifyStateChanged) {
            Log.d(LOG_TAG, "--- onClickSelectAll");
            handleSelectAll();
            if (notifyStateChanged) {
                this.mEST.notifyStateChanged(this.mMode, this.mState);
            }
        }

        public void onStartShowMenuAlertDialog() {
            this.mActions.onAction(23);
        }

        public void onFixSelectedItem() {
            Log.d(LOG_TAG, "--- onFixSelectedItem");
            fixSelectionAndDoNextAction();
            this.mEST.notifyStateChanged(this.mMode, this.mState);
        }

        public void onInsertImage(Uri uri) {
            this.mActions.onAction(15, uri);
            this.mEST.notifyStateChanged(this.mMode, this.mState);
        }

        public void onInsertImage(int resId) {
            this.mActions.onAction(15, Integer.valueOf(resId));
            this.mEST.notifyStateChanged(this.mMode, this.mState);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void insertImageFromUri(Uri uri) {
            insertImageSpan(new EditStyledTextSpans.RescalableImageSpan(this.mEST.getContext(), uri, this.mEST.getMaxImageWidthPx()), this.mEST.getSelectionStart());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void insertImageFromResId(int resId) {
            insertImageSpan(new EditStyledTextSpans.RescalableImageSpan(this.mEST.getContext(), resId, this.mEST.getMaxImageWidthDip()), this.mEST.getSelectionStart());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void insertHorizontalLine() {
            Log.d(LOG_TAG, "--- onInsertHorizontalLine:");
            int curpos = this.mEST.getSelectionStart();
            if (curpos > 0 && this.mEST.getText().charAt(curpos - 1) != '\n') {
                this.mEST.getText().insert(curpos, "\n");
                curpos++;
            }
            int curpos2 = curpos + 1;
            insertImageSpan(new EditStyledTextSpans.HorizontalLineSpan(-16777216, this.mEST.getWidth(), this.mEST.getText()), curpos);
            this.mEST.getText().insert(curpos2, "\n");
            this.mEST.setSelection(curpos2 + 1);
            this.mEST.notifyStateChanged(this.mMode, this.mState);
        }

        private void clearStyles(CharSequence txt) {
            Log.d(EditStyledText.TAG, "--- onClearStyles");
            int len = txt.length();
            if (txt instanceof Editable) {
                Editable editable = (Editable) txt;
                Object[] styles = editable.getSpans(0, len, Object.class);
                for (Object style : styles) {
                    if ((style instanceof ParagraphStyle) || (style instanceof QuoteSpan) || ((style instanceof CharacterStyle) && !(style instanceof UnderlineSpan))) {
                        if ((style instanceof ImageSpan) || (style instanceof EditStyledTextSpans.HorizontalLineSpan)) {
                            int start = editable.getSpanStart(style);
                            int end = editable.getSpanEnd(style);
                            editable.replace(start, end, LoggingEvents.EXTRA_CALLING_APP_NAME);
                        }
                        editable.removeSpan(style);
                    }
                }
            }
        }

        public void onClearStyles() {
            this.mActions.onAction(14);
        }

        public void onCancelViewManagers() {
            this.mActions.onAction(18);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearStyles() {
            Log.d(LOG_TAG, "--- onClearStyles");
            clearStyles(this.mEST.getText());
            this.mEST.setBackgroundDrawable(this.mEST.mDefaultBackground);
            this.mBackgroundColor = 16777215;
            onRefreshZeoWidthChar();
        }

        public void onRefreshZeoWidthChar() {
            Editable txt = this.mEST.getText();
            int i = 0;
            while (i < txt.length()) {
                if (txt.charAt(i) == 8288) {
                    txt.replace(i, i + 1, LoggingEvents.EXTRA_CALLING_APP_NAME);
                    i--;
                }
                i++;
            }
        }

        public void onRefreshStyles() {
            Log.d(LOG_TAG, "--- onRefreshStyles");
            Editable txt = this.mEST.getText();
            int len = txt.length();
            int width = this.mEST.getWidth();
            EditStyledTextSpans.HorizontalLineSpan[] lines = (EditStyledTextSpans.HorizontalLineSpan[]) txt.getSpans(0, len, EditStyledTextSpans.HorizontalLineSpan.class);
            for (EditStyledTextSpans.HorizontalLineSpan line : lines) {
                line.resetWidth(width);
            }
            EditStyledTextSpans.MarqueeSpan[] marquees = (EditStyledTextSpans.MarqueeSpan[]) txt.getSpans(0, len, EditStyledTextSpans.MarqueeSpan.class);
            for (EditStyledTextSpans.MarqueeSpan marquee : marquees) {
                marquee.resetColor(this.mEST.getBackgroundColor());
            }
            if (lines.length > 0) {
                txt.replace(0, 1, LoggingEvents.EXTRA_CALLING_APP_NAME + txt.charAt(0));
            }
        }

        public void setBackgroundColor(int color) {
            this.mBackgroundColor = color;
        }

        public void setItemSize(int size, boolean reset) {
            Log.d(LOG_TAG, "--- setItemSize");
            if (isWaitingNextAction()) {
                this.mSizeWaitInput = size;
                return;
            }
            if (this.mState == 2 || this.mState == 3) {
                if (size > 0) {
                    changeSizeSelectedText(size);
                }
                if (reset) {
                    resetEdit();
                }
            }
        }

        public void setItemColor(int color, boolean reset) {
            Log.d(LOG_TAG, "--- setItemColor");
            if (isWaitingNextAction()) {
                this.mColorWaitInput = color;
                return;
            }
            if (this.mState == 2 || this.mState == 3) {
                if (color != 16777215) {
                    changeColorSelectedText(color);
                }
                if (reset) {
                    resetEdit();
                }
            }
        }

        public void setAlignment(Layout.Alignment align) {
            if (this.mState == 2 || this.mState == 3) {
                changeAlign(align);
                resetEdit();
            }
        }

        public void setTelop() {
            if (this.mState == 2 || this.mState == 3) {
                addTelop();
                resetEdit();
            }
        }

        public void setSwing() {
            if (this.mState == 2 || this.mState == 3) {
                addSwing();
                resetEdit();
            }
        }

        public void setMarquee(int marquee) {
            if (this.mState == 2 || this.mState == 3) {
                addMarquee(marquee);
                resetEdit();
            }
        }

        public void setTextComposingMask(int start, int end) {
            int foregroundColor;
            Log.d(EditStyledText.TAG, "--- setTextComposingMask:" + start + MessageDispActivity.string_delimiter + end);
            int min = Math.min(start, end);
            int max = Math.max(start, end);
            if (isWaitInput() && this.mColorWaitInput != 16777215) {
                foregroundColor = this.mColorWaitInput;
            } else {
                foregroundColor = this.mEST.getForegroundColor(min);
            }
            int backgroundColor = this.mEST.getBackgroundColor();
            Log.d(EditStyledText.TAG, "--- fg:" + Integer.toHexString(foregroundColor) + ",bg:" + Integer.toHexString(backgroundColor) + MessageDispActivity.string_delimiter + isWaitInput() + MessageDispActivity.string_delimiter + MessageDispActivity.string_delimiter + this.mMode);
            if (foregroundColor == backgroundColor) {
                int maskColor = Integer.MIN_VALUE | (((-16777216) | backgroundColor) ^ (-1));
                if (this.mComposingTextMask == null || this.mComposingTextMask.getBackgroundColor() != maskColor) {
                    this.mComposingTextMask = new BackgroundColorSpan(maskColor);
                }
                this.mEST.getText().setSpan(this.mComposingTextMask, min, max, 33);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setEditMode(int mode) {
            this.mMode = mode;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setSelectState(int state) {
            this.mState = state;
        }

        public void unsetTextComposingMask() {
            Log.d(EditStyledText.TAG, "--- unsetTextComposingMask");
            if (this.mComposingTextMask != null) {
                this.mEST.getText().removeSpan(this.mComposingTextMask);
                this.mComposingTextMask = null;
            }
        }

        public boolean isEditting() {
            return this.mEditFlag;
        }

        public boolean isStyledText() {
            Editable txt = this.mEST.getText();
            int len = txt.length();
            return ((ParagraphStyle[]) txt.getSpans(0, len, ParagraphStyle.class)).length > 0 || ((QuoteSpan[]) txt.getSpans(0, len, QuoteSpan.class)).length > 0 || ((CharacterStyle[]) txt.getSpans(0, len, CharacterStyle.class)).length > 0 || this.mBackgroundColor != 16777215;
        }

        public boolean isSoftKeyBlocked() {
            return this.mSoftKeyBlockFlag;
        }

        public boolean isWaitInput() {
            return this.mWaitInputFlag;
        }

        public int getBackgroundColor() {
            return this.mBackgroundColor;
        }

        public int getEditMode() {
            return this.mMode;
        }

        public int getSelectState() {
            return this.mState;
        }

        public int getSelectionStart() {
            return this.mCurStart;
        }

        public int getSelectionEnd() {
            return this.mCurEnd;
        }

        public int getSizeWaitInput() {
            return this.mSizeWaitInput;
        }

        public int getColorWaitInput() {
            return this.mColorWaitInput;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setInternalSelection(int curStart, int curEnd) {
            this.mCurStart = curStart;
            this.mCurEnd = curEnd;
        }

        public void updateSpanPreviousFromCursor(Editable txt, int start, int before, int after) {
            Log.d(LOG_TAG, "updateSpanPrevious:" + start + MessageDispActivity.string_delimiter + before + MessageDispActivity.string_delimiter + after);
            int end = start + after;
            int min = Math.min(start, end);
            int max = Math.max(start, end);
            Object[] spansBefore = txt.getSpans(min, min, Object.class);
            for (Object span : spansBefore) {
                if ((span instanceof ForegroundColorSpan) || (span instanceof AbsoluteSizeSpan) || (span instanceof EditStyledTextSpans.MarqueeSpan) || (span instanceof AlignmentSpan)) {
                    int spanstart = txt.getSpanStart(span);
                    int spanend = txt.getSpanEnd(span);
                    Log.d(LOG_TAG, "spantype:" + span.getClass() + MessageDispActivity.string_delimiter + spanstart);
                    int tempmax = max;
                    if ((span instanceof EditStyledTextSpans.MarqueeSpan) || (span instanceof AlignmentSpan)) {
                        tempmax = findLineEnd(this.mEST.getText(), max);
                    } else if (this.mKeepNonLineSpan) {
                        tempmax = spanend;
                    }
                    if (spanend < tempmax) {
                        Log.d(LOG_TAG, "updateSpanPrevious: extend span");
                        txt.setSpan(span, spanstart, tempmax, 33);
                    }
                } else if (span instanceof EditStyledTextSpans.HorizontalLineSpan) {
                    int spanstart2 = txt.getSpanStart(span);
                    int spanend2 = txt.getSpanEnd(span);
                    if (before > after) {
                        txt.replace(spanstart2, spanend2, LoggingEvents.EXTRA_CALLING_APP_NAME);
                        txt.removeSpan(span);
                    } else if (spanend2 == end && end < txt.length() && this.mEST.getText().charAt(end) != '\n') {
                        this.mEST.getText().insert(end, "\n");
                    }
                }
            }
        }

        public void updateSpanNextToCursor(Editable txt, int start, int before, int after) {
            Log.d(LOG_TAG, "updateSpanNext:" + start + MessageDispActivity.string_delimiter + before + MessageDispActivity.string_delimiter + after);
            int end = start + after;
            int min = Math.min(start, end);
            int max = Math.max(start, end);
            Object[] spansAfter = txt.getSpans(max, max, Object.class);
            for (Object span : spansAfter) {
                if ((span instanceof EditStyledTextSpans.MarqueeSpan) || (span instanceof AlignmentSpan)) {
                    int spanstart = txt.getSpanStart(span);
                    int spanend = txt.getSpanEnd(span);
                    Log.d(LOG_TAG, "spantype:" + span.getClass() + MessageDispActivity.string_delimiter + spanend);
                    int tempmin = min;
                    if ((span instanceof EditStyledTextSpans.MarqueeSpan) || (span instanceof AlignmentSpan)) {
                        tempmin = findLineStart(this.mEST.getText(), min);
                    }
                    if (tempmin < spanstart && before > after) {
                        txt.removeSpan(span);
                    } else if (spanstart > min) {
                        txt.setSpan(span, min, spanend, 33);
                    }
                } else if ((span instanceof EditStyledTextSpans.HorizontalLineSpan) && txt.getSpanStart(span) == end && end > 0 && this.mEST.getText().charAt(end - 1) != '\n') {
                    this.mEST.getText().insert(end, "\n");
                    this.mEST.setSelection(end);
                }
            }
        }

        public boolean canPaste() {
            return this.mCopyBuffer != null && this.mCopyBuffer.length() > 0 && removeImageChar(this.mCopyBuffer).length() == 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void endEdit() {
            Log.d(LOG_TAG, "--- handleCancel");
            this.mMode = 0;
            this.mState = 0;
            this.mEditFlag = false;
            this.mColorWaitInput = 16777215;
            this.mSizeWaitInput = 0;
            this.mWaitInputFlag = false;
            this.mSoftKeyBlockFlag = false;
            this.mKeepNonLineSpan = false;
            this.mTextIsFinishedFlag = false;
            unsetSelect();
            this.mEST.setOnClickListener(null);
            unblockSoftKey();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void fixSelectionAndDoNextAction() {
            Log.d(LOG_TAG, "--- handleComplete:" + this.mCurStart + MessageDispActivity.string_delimiter + this.mCurEnd);
            if (this.mEditFlag) {
                if (this.mCurStart == this.mCurEnd) {
                    Log.d(LOG_TAG, "--- cancel handle complete:" + this.mCurStart);
                    resetEdit();
                } else {
                    if (this.mState == 2) {
                        this.mState = 3;
                    }
                    this.mActions.doNext(this.mMode);
                    EditStyledText.stopSelecting(this.mEST, this.mEST.getText());
                }
            }
        }

        private SpannableStringBuilder removeImageChar(SpannableStringBuilder text) {
            SpannableStringBuilder buf = new SpannableStringBuilder(text);
            DynamicDrawableSpan[] styles = (DynamicDrawableSpan[]) buf.getSpans(0, buf.length(), DynamicDrawableSpan.class);
            for (DynamicDrawableSpan style : styles) {
                if ((style instanceof EditStyledTextSpans.HorizontalLineSpan) || (style instanceof EditStyledTextSpans.RescalableImageSpan)) {
                    int start = buf.getSpanStart(style);
                    int end = buf.getSpanEnd(style);
                    buf.replace(start, end, (CharSequence) LoggingEvents.EXTRA_CALLING_APP_NAME);
                }
            }
            return buf;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void copyToClipBoard() {
            int min = Math.min(getSelectionStart(), getSelectionEnd());
            int max = Math.max(getSelectionStart(), getSelectionEnd());
            this.mCopyBuffer = (SpannableStringBuilder) this.mEST.getText().subSequence(min, max);
            SpannableStringBuilder clipboardtxt = removeImageChar(this.mCopyBuffer);
            ClipboardManager clip = (ClipboardManager) EditStyledText.this.getContext().getSystemService("clipboard");
            clip.setText(clipboardtxt);
            dumpSpannableString(clipboardtxt);
            dumpSpannableString(this.mCopyBuffer);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void cutToClipBoard() {
            copyToClipBoard();
            int min = Math.min(getSelectionStart(), getSelectionEnd());
            int max = Math.max(getSelectionStart(), getSelectionEnd());
            this.mEST.getText().delete(min, max);
        }

        private boolean isClipBoardChanged(CharSequence clipboardText) {
            Log.d(EditStyledText.TAG, "--- isClipBoardChanged:" + ((Object) clipboardText));
            if (this.mCopyBuffer == null) {
                return true;
            }
            int len = clipboardText.length();
            CharSequence removedClipBoard = removeImageChar(this.mCopyBuffer);
            Log.d(EditStyledText.TAG, "--- clipBoard:" + len + MessageDispActivity.string_delimiter + ((Object) removedClipBoard) + ((Object) clipboardText));
            if (len != removedClipBoard.length()) {
                return true;
            }
            for (int i = 0; i < len; i++) {
                if (clipboardText.charAt(i) != removedClipBoard.charAt(i)) {
                    return true;
                }
            }
            return false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void pasteFromClipboard() {
            int min = Math.min(this.mEST.getSelectionStart(), this.mEST.getSelectionEnd());
            int max = Math.max(this.mEST.getSelectionStart(), this.mEST.getSelectionEnd());
            Selection.setSelection(this.mEST.getText(), max);
            ClipboardManager clip = (ClipboardManager) EditStyledText.this.getContext().getSystemService("clipboard");
            this.mKeepNonLineSpan = true;
            this.mEST.getText().replace(min, max, clip.getText());
            if (!isClipBoardChanged(clip.getText())) {
                Log.d(EditStyledText.TAG, "--- handlePaste: startPasteImage");
                DynamicDrawableSpan[] styles = (DynamicDrawableSpan[]) this.mCopyBuffer.getSpans(0, this.mCopyBuffer.length(), DynamicDrawableSpan.class);
                for (DynamicDrawableSpan style : styles) {
                    int start = this.mCopyBuffer.getSpanStart(style);
                    if (style instanceof EditStyledTextSpans.HorizontalLineSpan) {
                        insertImageSpan(new EditStyledTextSpans.HorizontalLineSpan(-16777216, this.mEST.getWidth(), this.mEST.getText()), min + start);
                    } else if (style instanceof EditStyledTextSpans.RescalableImageSpan) {
                        insertImageSpan(new EditStyledTextSpans.RescalableImageSpan(this.mEST.getContext(), ((EditStyledTextSpans.RescalableImageSpan) style).getContentUri(), this.mEST.getMaxImageWidthPx()), min + start);
                    }
                }
            }
        }

        private void handleSelectAll() {
            if (this.mEditFlag) {
                this.mActions.onAction(11);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void selectAll() {
            Selection.selectAll(this.mEST.getText());
            this.mCurStart = this.mEST.getSelectionStart();
            this.mCurEnd = this.mEST.getSelectionEnd();
            this.mMode = 5;
            this.mState = 3;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void resetEdit() {
            endEdit();
            this.mEditFlag = true;
            this.mEST.notifyStateChanged(this.mMode, this.mState);
        }

        private void setSelection() {
            Log.d(LOG_TAG, "--- onSelect:" + this.mCurStart + MessageDispActivity.string_delimiter + this.mCurEnd);
            if (this.mCurStart >= 0 && this.mCurStart <= this.mEST.getText().length() && this.mCurEnd >= 0 && this.mCurEnd <= this.mEST.getText().length()) {
                if (this.mCurStart < this.mCurEnd) {
                    this.mEST.setSelection(this.mCurStart, this.mCurEnd);
                    this.mState = 2;
                    return;
                } else if (this.mCurStart > this.mCurEnd) {
                    this.mEST.setSelection(this.mCurEnd, this.mCurStart);
                    this.mState = 2;
                    return;
                } else {
                    this.mState = 1;
                    return;
                }
            }
            Log.e(LOG_TAG, "Select is on, but cursor positions are illigal.:" + this.mEST.getText().length() + MessageDispActivity.string_delimiter + this.mCurStart + MessageDispActivity.string_delimiter + this.mCurEnd);
        }

        private void unsetSelect() {
            Log.d(LOG_TAG, "--- offSelect");
            EditStyledText.stopSelecting(this.mEST, this.mEST.getText());
            int currpos = this.mEST.getSelectionStart();
            this.mEST.setSelection(currpos, currpos);
            this.mState = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setSelectStartPos() {
            Log.d(LOG_TAG, "--- setSelectStartPos");
            this.mCurStart = this.mEST.getSelectionStart();
            this.mState = 1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setSelectEndPos() {
            if (this.mEST.getSelectionEnd() == this.mCurStart) {
                setEndPos(this.mEST.getSelectionStart());
            } else {
                setEndPos(this.mEST.getSelectionEnd());
            }
        }

        public void setEndPos(int pos) {
            Log.d(LOG_TAG, "--- setSelectedEndPos:" + pos);
            this.mCurEnd = pos;
            setSelection();
        }

        private boolean isWaitingNextAction() {
            Log.d(LOG_TAG, "--- waitingNext:" + this.mCurStart + MessageDispActivity.string_delimiter + this.mCurEnd + MessageDispActivity.string_delimiter + this.mState);
            if (this.mCurStart == this.mCurEnd && this.mState == 3) {
                waitSelection();
                return true;
            }
            resumeSelection();
            return false;
        }

        private void waitSelection() {
            Log.d(LOG_TAG, "--- waitSelection");
            this.mWaitInputFlag = true;
            if (this.mCurStart == this.mCurEnd) {
                this.mState = 1;
            } else {
                this.mState = 2;
            }
            EditStyledText.startSelecting(this.mEST, this.mEST.getText());
        }

        private void resumeSelection() {
            Log.d(LOG_TAG, "--- resumeSelection");
            this.mWaitInputFlag = false;
            this.mState = 3;
            EditStyledText.stopSelecting(this.mEST, this.mEST.getText());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean isTextSelected() {
            return this.mState == 2 || this.mState == 3;
        }

        private void setStyledTextSpan(Object span, int start, int end) {
            Log.d(LOG_TAG, "--- setStyledTextSpan:" + this.mMode + MessageDispActivity.string_delimiter + start + MessageDispActivity.string_delimiter + end);
            int min = Math.min(start, end);
            int max = Math.max(start, end);
            this.mEST.getText().setSpan(span, min, max, 33);
            Selection.setSelection(this.mEST.getText(), max);
        }

        private void setLineStyledTextSpan(Object span) {
            int min = Math.min(this.mCurStart, this.mCurEnd);
            int max = Math.max(this.mCurStart, this.mCurEnd);
            int current = this.mEST.getSelectionStart();
            int start = findLineStart(this.mEST.getText(), min);
            int end = findLineEnd(this.mEST.getText(), max);
            if (start == end) {
                this.mEST.getText().insert(end, "\n");
                setStyledTextSpan(span, start, end + 1);
            } else {
                setStyledTextSpan(span, start, end);
            }
            Selection.setSelection(this.mEST.getText(), current);
        }

        private void changeSizeSelectedText(int size) {
            if (this.mCurStart != this.mCurEnd) {
                setStyledTextSpan(new AbsoluteSizeSpan(size), this.mCurStart, this.mCurEnd);
            } else {
                Log.e(LOG_TAG, "---changeSize: Size of the span is zero");
            }
        }

        private void changeColorSelectedText(int color) {
            if (this.mCurStart != this.mCurEnd) {
                setStyledTextSpan(new ForegroundColorSpan(color), this.mCurStart, this.mCurEnd);
            } else {
                Log.e(LOG_TAG, "---changeColor: Size of the span is zero");
            }
        }

        private void changeAlign(Layout.Alignment align) {
            setLineStyledTextSpan(new AlignmentSpan.Standard(align));
        }

        private void addTelop() {
            addMarquee(1);
        }

        private void addSwing() {
            addMarquee(0);
        }

        private void addMarquee(int marquee) {
            Log.d(LOG_TAG, "--- addMarquee:" + marquee);
            setLineStyledTextSpan(new EditStyledTextSpans.MarqueeSpan(marquee, this.mEST.getBackgroundColor()));
        }

        private void insertImageSpan(DynamicDrawableSpan span, int curpos) {
            Log.d(LOG_TAG, "--- insertImageSpan:");
            if (span != null && span.getDrawable() != null) {
                this.mEST.getText().insert(curpos, "￼");
                this.mEST.getText().setSpan(span, curpos, curpos + 1, 33);
                this.mEST.notifyStateChanged(this.mMode, this.mState);
            } else {
                Log.e(LOG_TAG, "--- insertImageSpan: null span was inserted");
                this.mEST.sendHintMessage(5);
            }
        }

        private int findLineStart(Editable text, int current) {
            int pos = current;
            while (pos > 0 && text.charAt(pos - 1) != '\n') {
                pos--;
            }
            Log.d(LOG_TAG, "--- findLineStart:" + current + MessageDispActivity.string_delimiter + text.length() + MessageDispActivity.string_delimiter + pos);
            return pos;
        }

        private int findLineEnd(Editable text, int current) {
            int pos = current;
            while (pos < text.length()) {
                if (text.charAt(pos) != '\n') {
                    pos++;
                } else {
                    pos++;
                    break;
                }
            }
            Log.d(LOG_TAG, "--- findLineEnd:" + current + MessageDispActivity.string_delimiter + text.length() + MessageDispActivity.string_delimiter + pos);
            return pos;
        }

        private void dumpSpannableString(CharSequence txt) {
            if (txt instanceof Spannable) {
                Spannable spannable = (Spannable) txt;
                int len = spannable.length();
                Log.d(EditStyledText.TAG, "--- dumpSpannableString, txt:" + ((Object) spannable) + ", len:" + len);
                Object[] styles = spannable.getSpans(0, len, Object.class);
                for (Object style : styles) {
                    Log.d(EditStyledText.TAG, "--- dumpSpannableString, class:" + style + MessageDispActivity.string_delimiter + spannable.getSpanStart(style) + MessageDispActivity.string_delimiter + spannable.getSpanEnd(style) + MessageDispActivity.string_delimiter + spannable.getSpanFlags(style));
                }
            }
        }

        public void showSoftKey() {
            showSoftKey(this.mEST.getSelectionStart(), this.mEST.getSelectionEnd());
        }

        public void showSoftKey(int oldSelStart, int oldSelEnd) {
            Log.d(LOG_TAG, "--- showsoftkey");
            if (this.mEST.isFocused() && !isSoftKeyBlocked()) {
                this.mSkr.mNewStart = Selection.getSelectionStart(this.mEST.getText());
                this.mSkr.mNewEnd = Selection.getSelectionEnd(this.mEST.getText());
                InputMethodManager imm = (InputMethodManager) EditStyledText.this.getContext().getSystemService("input_method");
                if (imm.showSoftInput(this.mEST, 0, this.mSkr) && this.mSkr != null) {
                    Selection.setSelection(EditStyledText.this.getText(), oldSelStart, oldSelEnd);
                }
            }
        }

        public void hideSoftKey() {
            Log.d(LOG_TAG, "--- hidesoftkey");
            if (this.mEST.isFocused()) {
                this.mSkr.mNewStart = Selection.getSelectionStart(this.mEST.getText());
                this.mSkr.mNewEnd = Selection.getSelectionEnd(this.mEST.getText());
                InputMethodManager imm = (InputMethodManager) this.mEST.getContext().getSystemService("input_method");
                imm.hideSoftInputFromWindow(this.mEST.getWindowToken(), 0, this.mSkr);
            }
        }

        public void blockSoftKey() {
            Log.d(LOG_TAG, "--- blockSoftKey:");
            hideSoftKey();
            this.mSoftKeyBlockFlag = true;
        }

        public void unblockSoftKey() {
            Log.d(LOG_TAG, "--- unblockSoftKey:");
            this.mSoftKeyBlockFlag = false;
        }
    }

    private class StyledTextHtmlStandard implements StyledTextHtmlConverter {
        private StyledTextHtmlStandard() {
        }

        @Override // com.android.ex.editstyledtext.EditStyledText.StyledTextHtmlConverter
        public String toHtml(Spanned text) {
            return Html.toHtml(text);
        }

        @Override // com.android.ex.editstyledtext.EditStyledText.StyledTextHtmlConverter
        public String toHtml(Spanned text, boolean escapeNonAsciiChar) {
            return Html.toHtml(text);
        }

        @Override // com.android.ex.editstyledtext.EditStyledText.StyledTextHtmlConverter
        public String toHtml(Spanned text, boolean escapeNonAsciiChar, int width, float scale) {
            return Html.toHtml(text);
        }

        @Override // com.android.ex.editstyledtext.EditStyledText.StyledTextHtmlConverter
        public Spanned fromHtml(String source) {
            return Html.fromHtml(source);
        }

        @Override // com.android.ex.editstyledtext.EditStyledText.StyledTextHtmlConverter
        public Spanned fromHtml(String source, Html.ImageGetter imageGetter, Html.TagHandler tagHandler) {
            return Html.fromHtml(source, imageGetter, tagHandler);
        }
    }

    private class StyledTextConverter {
        private EditStyledText mEST;
        private StyledTextHtmlConverter mHtml;

        public StyledTextConverter(EditStyledText est, StyledTextHtmlConverter html) {
            this.mEST = est;
            this.mHtml = html;
        }

        public void setStyledTextHtmlConverter(StyledTextHtmlConverter html) {
            this.mHtml = html;
        }

        public String getHtml(boolean escapeFlag) {
            this.mEST.clearComposingText();
            this.mEST.onRefreshZeoWidthChar();
            String htmlBody = this.mHtml.toHtml(this.mEST.getText(), escapeFlag);
            Log.d(EditStyledText.TAG, "--- getHtml:" + htmlBody);
            return htmlBody;
        }

        public String getPreviewHtml() {
            this.mEST.clearComposingText();
            this.mEST.onRefreshZeoWidthChar();
            String html = this.mHtml.toHtml(this.mEST.getText(), true, EditStyledText.this.getMaxImageWidthDip(), EditStyledText.this.getPaddingScale());
            int bgColor = this.mEST.getBackgroundColor();
            String html2 = String.format("<body bgcolor=\"#%02X%02X%02X\">%s</body>", Integer.valueOf(Color.red(bgColor)), Integer.valueOf(Color.green(bgColor)), Integer.valueOf(Color.blue(bgColor)), html);
            Log.d(EditStyledText.TAG, "--- getPreviewHtml:" + html2 + MessageDispActivity.string_delimiter + this.mEST.getWidth());
            return html2;
        }

        public void getUriArray(ArrayList<Uri> uris, Editable text) {
            uris.clear();
            Log.d(EditStyledText.TAG, "--- getUriArray:");
            int len = text.length();
            int i = 0;
            while (i < text.length()) {
                int next = text.nextSpanTransition(i, len, ImageSpan.class);
                ImageSpan[] images = (ImageSpan[]) text.getSpans(i, next, ImageSpan.class);
                for (int j = 0; j < images.length; j++) {
                    Log.d(EditStyledText.TAG, "--- getUriArray: foundArray" + images[j].getSource());
                    uris.add(Uri.parse(images[j].getSource()));
                }
                i = next;
            }
        }

        public void SetHtml(String html) {
            Spanned spanned = this.mHtml.fromHtml(html, new Html.ImageGetter() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextConverter.1
                @Override // android.text.Html.ImageGetter
                public Drawable getDrawable(String src) {
                    Bitmap bitmap;
                    Log.d(EditStyledText.TAG, "--- sethtml: src=" + src);
                    if (!src.startsWith("content://")) {
                        return null;
                    }
                    Uri uri = Uri.parse(src);
                    try {
                        System.gc();
                        InputStream is = StyledTextConverter.this.mEST.getContext().getContentResolver().openInputStream(uri);
                        BitmapFactory.Options opt = new BitmapFactory.Options();
                        opt.inJustDecodeBounds = true;
                        BitmapFactory.decodeStream(is, null, opt);
                        is.close();
                        InputStream is2 = StyledTextConverter.this.mEST.getContext().getContentResolver().openInputStream(uri);
                        int width = opt.outWidth;
                        int height = opt.outHeight;
                        if (opt.outWidth > EditStyledText.this.getMaxImageWidthPx()) {
                            width = EditStyledText.this.getMaxImageWidthPx();
                            height = (EditStyledText.this.getMaxImageWidthPx() * height) / opt.outWidth;
                            Rect padding = new Rect(0, 0, width, height);
                            bitmap = BitmapFactory.decodeStream(is2, padding, null);
                        } else {
                            bitmap = BitmapFactory.decodeStream(is2);
                        }
                        Drawable drawable = new BitmapDrawable(StyledTextConverter.this.mEST.getContext().getResources(), bitmap);
                        try {
                            drawable.setBounds(0, 0, width, height);
                            is2.close();
                            return drawable;
                        } catch (Exception e) {
                            e = e;
                            Log.e(EditStyledText.TAG, "--- set html: Failed to loaded content " + uri, e);
                            return null;
                        } catch (OutOfMemoryError e2) {
                            Log.e(EditStyledText.TAG, "OutOfMemoryError");
                            StyledTextConverter.this.mEST.setHint(5);
                            return null;
                        }
                    } catch (Exception e3) {
                        e = e3;
                    } catch (OutOfMemoryError e4) {
                    }
                }
            }, null);
            this.mEST.setText(spanned);
        }
    }

    private static class SoftKeyReceiver extends ResultReceiver {
        EditStyledText mEST;
        int mNewEnd;
        int mNewStart;

        SoftKeyReceiver(EditStyledText est) {
            super(est.getHandler());
            this.mEST = est;
        }

        @Override // android.os.ResultReceiver
        protected void onReceiveResult(int resultCode, Bundle resultData) {
            if (resultCode != 2) {
                Selection.setSelection(this.mEST.getText(), this.mNewStart, this.mNewEnd);
            }
        }
    }

    public static class SavedStyledTextState extends View.BaseSavedState {
        public int mBackgroundColor;

        SavedStyledTextState(Parcelable superState) {
            super(superState);
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(this.mBackgroundColor);
        }

        public String toString() {
            return "EditStyledText.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " bgcolor=" + this.mBackgroundColor + "}";
        }
    }

    private static class StyledTextDialog {
        private static final int TYPE_BACKGROUND = 1;
        private static final int TYPE_FOREGROUND = 0;
        private AlertDialog mAlertDialog;
        private CharSequence[] mAlignNames;
        private CharSequence mAlignTitle;
        private AlertDialog.Builder mBuilder;
        private CharSequence mColorDefaultMessage;
        private CharSequence[] mColorInts;
        private CharSequence[] mColorNames;
        private CharSequence mColorTitle;
        private EditStyledText mEST;
        private CharSequence[] mMarqueeNames;
        private CharSequence mMarqueeTitle;
        private CharSequence[] mSizeDisplayInts;
        private CharSequence[] mSizeNames;
        private CharSequence[] mSizeSendInts;
        private CharSequence mSizeTitle;

        public StyledTextDialog(EditStyledText est) {
            this.mEST = est;
        }

        public void setBuilder(AlertDialog.Builder builder) {
            this.mBuilder = builder;
        }

        public void setColorAlertParams(CharSequence colortitle, CharSequence[] colornames, CharSequence[] colorInts, CharSequence defaultColorMessage) {
            this.mColorTitle = colortitle;
            this.mColorNames = colornames;
            this.mColorInts = colorInts;
            this.mColorDefaultMessage = defaultColorMessage;
        }

        public void setSizeAlertParams(CharSequence sizetitle, CharSequence[] sizenames, CharSequence[] sizedisplayints, CharSequence[] sizesendints) {
            this.mSizeTitle = sizetitle;
            this.mSizeNames = sizenames;
            this.mSizeDisplayInts = sizedisplayints;
            this.mSizeSendInts = sizesendints;
        }

        public void setAlignAlertParams(CharSequence aligntitle, CharSequence[] alignnames) {
            this.mAlignTitle = aligntitle;
            this.mAlignNames = alignnames;
        }

        public void setMarqueeAlertParams(CharSequence marqueetitle, CharSequence[] marqueenames) {
            this.mMarqueeTitle = marqueetitle;
            this.mMarqueeNames = marqueenames;
        }

        private boolean checkColorAlertParams() {
            Log.d(EditStyledText.TAG, "--- checkParams");
            if (this.mBuilder == null) {
                Log.e(EditStyledText.TAG, "--- builder is null.");
                return false;
            }
            if (this.mColorTitle == null || this.mColorNames == null || this.mColorInts == null) {
                Log.e(EditStyledText.TAG, "--- color alert params are null.");
                return false;
            }
            if (this.mColorNames.length != this.mColorInts.length) {
                Log.e(EditStyledText.TAG, "--- the length of color alert params are different.");
                return false;
            }
            return true;
        }

        private boolean checkSizeAlertParams() {
            Log.d(EditStyledText.TAG, "--- checkParams");
            if (this.mBuilder == null) {
                Log.e(EditStyledText.TAG, "--- builder is null.");
                return false;
            }
            if (this.mSizeTitle == null || this.mSizeNames == null || this.mSizeDisplayInts == null || this.mSizeSendInts == null) {
                Log.e(EditStyledText.TAG, "--- size alert params are null.");
                return false;
            }
            if (this.mSizeNames.length != this.mSizeDisplayInts.length && this.mSizeSendInts.length != this.mSizeDisplayInts.length) {
                Log.e(EditStyledText.TAG, "--- the length of size alert params are different.");
                return false;
            }
            return true;
        }

        private boolean checkAlignAlertParams() {
            Log.d(EditStyledText.TAG, "--- checkAlignAlertParams");
            if (this.mBuilder == null) {
                Log.e(EditStyledText.TAG, "--- builder is null.");
                return false;
            }
            if (this.mAlignTitle == null) {
                Log.e(EditStyledText.TAG, "--- align alert params are null.");
                return false;
            }
            return true;
        }

        private boolean checkMarqueeAlertParams() {
            Log.d(EditStyledText.TAG, "--- checkMarqueeAlertParams");
            if (this.mBuilder == null) {
                Log.e(EditStyledText.TAG, "--- builder is null.");
                return false;
            }
            if (this.mMarqueeTitle == null) {
                Log.e(EditStyledText.TAG, "--- Marquee alert params are null.");
                return false;
            }
            return true;
        }

        private void buildDialogue(CharSequence title, CharSequence[] names, DialogInterface.OnClickListener l) {
            this.mBuilder.setTitle(title);
            this.mBuilder.setIcon(0);
            this.mBuilder.setPositiveButton((CharSequence) null, (DialogInterface.OnClickListener) null);
            this.mBuilder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    StyledTextDialog.this.mEST.onStartEdit();
                }
            });
            this.mBuilder.setItems(names, l);
            this.mBuilder.setView((View) null);
            this.mBuilder.setCancelable(true);
            this.mBuilder.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.2
                @Override // android.content.DialogInterface.OnCancelListener
                public void onCancel(DialogInterface arg0) {
                    Log.d(EditStyledText.TAG, "--- oncancel");
                    StyledTextDialog.this.mEST.onStartEdit();
                }
            });
            this.mBuilder.show();
        }

        private void buildAndShowColorDialogue(int type, CharSequence title, int[] colors) {
            int BUTTON_SIZE = this.mEST.dipToPx(50);
            int BUTTON_MERGIN = this.mEST.dipToPx(2);
            int BUTTON_PADDING = this.mEST.dipToPx(15);
            this.mBuilder.setTitle(title);
            this.mBuilder.setIcon(0);
            this.mBuilder.setPositiveButton((CharSequence) null, (DialogInterface.OnClickListener) null);
            this.mBuilder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.3
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    StyledTextDialog.this.mEST.onStartEdit();
                }
            });
            this.mBuilder.setItems((CharSequence[]) null, (DialogInterface.OnClickListener) null);
            LinearLayout verticalLayout = new LinearLayout(this.mEST.getContext());
            verticalLayout.setOrientation(1);
            verticalLayout.setGravity(1);
            verticalLayout.setPadding(BUTTON_PADDING, BUTTON_PADDING, BUTTON_PADDING, BUTTON_PADDING);
            LinearLayout horizontalLayout = null;
            for (int i = 0; i < colors.length; i++) {
                if (i % 5 == 0) {
                    horizontalLayout = new LinearLayout(this.mEST.getContext());
                    verticalLayout.addView(horizontalLayout);
                }
                Button button = new Button(this.mEST.getContext());
                button.setHeight(BUTTON_SIZE);
                button.setWidth(BUTTON_SIZE);
                ColorPaletteDrawable cp = new ColorPaletteDrawable(colors[i], BUTTON_SIZE, BUTTON_SIZE, BUTTON_MERGIN);
                button.setBackgroundDrawable(cp);
                button.setDrawingCacheBackgroundColor(colors[i]);
                if (type == 0) {
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            StyledTextDialog.this.mEST.setItemColor(view.getDrawingCacheBackgroundColor());
                            if (StyledTextDialog.this.mAlertDialog != null) {
                                StyledTextDialog.this.mAlertDialog.setView(null);
                                StyledTextDialog.this.mAlertDialog.dismiss();
                                StyledTextDialog.this.mAlertDialog = null;
                                return;
                            }
                            Log.e(EditStyledText.TAG, "--- buildAndShowColorDialogue: can't find alertDialog");
                        }
                    });
                } else if (type == 1) {
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            StyledTextDialog.this.mEST.setBackgroundColor(view.getDrawingCacheBackgroundColor());
                            if (StyledTextDialog.this.mAlertDialog != null) {
                                StyledTextDialog.this.mAlertDialog.setView(null);
                                StyledTextDialog.this.mAlertDialog.dismiss();
                                StyledTextDialog.this.mAlertDialog = null;
                                return;
                            }
                            Log.e(EditStyledText.TAG, "--- buildAndShowColorDialogue: can't find alertDialog");
                        }
                    });
                }
                horizontalLayout.addView(button);
            }
            if (type == 1) {
                this.mBuilder.setPositiveButton(this.mColorDefaultMessage, new DialogInterface.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.6
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        StyledTextDialog.this.mEST.setBackgroundColor(16777215);
                    }
                });
            } else if (type == 0) {
                this.mBuilder.setPositiveButton(this.mColorDefaultMessage, new DialogInterface.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.7
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        StyledTextDialog.this.mEST.setItemColor(-16777216);
                    }
                });
            }
            this.mBuilder.setView(verticalLayout);
            this.mBuilder.setCancelable(true);
            this.mBuilder.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.8
                @Override // android.content.DialogInterface.OnCancelListener
                public void onCancel(DialogInterface arg0) {
                    StyledTextDialog.this.mEST.onStartEdit();
                }
            });
            this.mAlertDialog = this.mBuilder.show();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void onShowForegroundColorAlertDialog() {
            Log.d(EditStyledText.TAG, "--- onShowForegroundColorAlertDialog");
            if (checkColorAlertParams()) {
                int[] colorints = new int[this.mColorInts.length];
                for (int i = 0; i < colorints.length; i++) {
                    colorints[i] = Integer.parseInt((String) this.mColorInts[i], 16) - ViewCompat.MEASURED_STATE_TOO_SMALL;
                }
                buildAndShowColorDialogue(0, this.mColorTitle, colorints);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void onShowBackgroundColorAlertDialog() {
            Log.d(EditStyledText.TAG, "--- onShowBackgroundColorAlertDialog");
            if (checkColorAlertParams()) {
                int[] colorInts = new int[this.mColorInts.length];
                for (int i = 0; i < colorInts.length; i++) {
                    colorInts[i] = Integer.parseInt((String) this.mColorInts[i], 16) - ViewCompat.MEASURED_STATE_TOO_SMALL;
                }
                buildAndShowColorDialogue(1, this.mColorTitle, colorInts);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void onShowSizeAlertDialog() {
            Log.d(EditStyledText.TAG, "--- onShowSizeAlertDialog");
            if (checkSizeAlertParams()) {
                buildDialogue(this.mSizeTitle, this.mSizeNames, new DialogInterface.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.9
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Log.d(EditStyledText.TAG, "mBuilder.onclick:" + which);
                        int size = StyledTextDialog.this.mEST.dipToPx(Integer.parseInt((String) StyledTextDialog.this.mSizeDisplayInts[which]));
                        StyledTextDialog.this.mEST.setItemSize(size);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void onShowAlignAlertDialog() {
            Log.d(EditStyledText.TAG, "--- onShowAlignAlertDialog");
            if (checkAlignAlertParams()) {
                buildDialogue(this.mAlignTitle, this.mAlignNames, new DialogInterface.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.10
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Layout.Alignment align = Layout.Alignment.ALIGN_NORMAL;
                        switch (which) {
                            case 0:
                                align = Layout.Alignment.ALIGN_NORMAL;
                                break;
                            case 1:
                                align = Layout.Alignment.ALIGN_CENTER;
                                break;
                            case 2:
                                align = Layout.Alignment.ALIGN_OPPOSITE;
                                break;
                            default:
                                Log.e(EditStyledText.TAG, "--- onShowAlignAlertDialog: got illigal align.");
                                break;
                        }
                        StyledTextDialog.this.mEST.setAlignment(align);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void onShowMarqueeAlertDialog() {
            Log.d(EditStyledText.TAG, "--- onShowMarqueeAlertDialog");
            if (checkMarqueeAlertParams()) {
                buildDialogue(this.mMarqueeTitle, this.mMarqueeNames, new DialogInterface.OnClickListener() { // from class: com.android.ex.editstyledtext.EditStyledText.StyledTextDialog.11
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Log.d(EditStyledText.TAG, "mBuilder.onclick:" + which);
                        StyledTextDialog.this.mEST.setMarquee(which);
                    }
                });
            }
        }
    }

    private class MenuHandler implements MenuItem.OnMenuItemClickListener {
        private MenuHandler() {
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem item) {
            return EditStyledText.this.onTextContextMenuItem(item.getItemId());
        }
    }

    private static class StyledTextArrowKeyMethod extends ArrowKeyMovementMethod {
        String LOG_TAG = "StyledTextArrowKeyMethod";
        EditorManager mManager;

        StyledTextArrowKeyMethod(EditorManager manager) {
            this.mManager = manager;
        }

        @Override // android.text.method.BaseMovementMethod, android.text.method.MovementMethod
        public boolean onKeyDown(TextView widget, Spannable buffer, int keyCode, KeyEvent event) {
            Log.d(this.LOG_TAG, "---onkeydown:" + keyCode);
            this.mManager.unsetTextComposingMask();
            return (this.mManager.getSelectState() == 1 || this.mManager.getSelectState() == 2) ? executeDown(widget, buffer, keyCode) : super.onKeyDown(widget, buffer, keyCode, event);
        }

        private int getEndPos(TextView widget) {
            if (widget.getSelectionStart() == this.mManager.getSelectionStart()) {
                int end = widget.getSelectionEnd();
                return end;
            }
            int end2 = widget.getSelectionStart();
            return end2;
        }

        @Override // android.text.method.ArrowKeyMovementMethod, android.text.method.BaseMovementMethod
        protected boolean up(TextView widget, Spannable buffer) {
            int to;
            Log.d(this.LOG_TAG, "--- up:");
            Layout layout = widget.getLayout();
            int end = getEndPos(widget);
            int line = layout.getLineForOffset(end);
            if (line > 0) {
                if (layout.getParagraphDirection(line) == layout.getParagraphDirection(line - 1)) {
                    float h = layout.getPrimaryHorizontal(end);
                    to = layout.getOffsetForHorizontal(line - 1, h);
                } else {
                    to = layout.getLineStart(line - 1);
                }
                this.mManager.setEndPos(to);
                this.mManager.onCursorMoved();
                return true;
            }
            return true;
        }

        @Override // android.text.method.ArrowKeyMovementMethod, android.text.method.BaseMovementMethod
        protected boolean down(TextView widget, Spannable buffer) {
            int to;
            Log.d(this.LOG_TAG, "--- down:");
            Layout layout = widget.getLayout();
            int end = getEndPos(widget);
            int line = layout.getLineForOffset(end);
            if (line < layout.getLineCount() - 1) {
                if (layout.getParagraphDirection(line) == layout.getParagraphDirection(line + 1)) {
                    float h = layout.getPrimaryHorizontal(end);
                    to = layout.getOffsetForHorizontal(line + 1, h);
                } else {
                    to = layout.getLineStart(line + 1);
                }
                this.mManager.setEndPos(to);
                this.mManager.onCursorMoved();
                return true;
            }
            return true;
        }

        @Override // android.text.method.ArrowKeyMovementMethod, android.text.method.BaseMovementMethod
        protected boolean left(TextView widget, Spannable buffer) {
            Log.d(this.LOG_TAG, "--- left:");
            Layout layout = widget.getLayout();
            int to = layout.getOffsetToLeftOf(getEndPos(widget));
            this.mManager.setEndPos(to);
            this.mManager.onCursorMoved();
            return true;
        }

        @Override // android.text.method.ArrowKeyMovementMethod, android.text.method.BaseMovementMethod
        protected boolean right(TextView widget, Spannable buffer) {
            Log.d(this.LOG_TAG, "--- right:");
            Layout layout = widget.getLayout();
            int to = layout.getOffsetToRightOf(getEndPos(widget));
            this.mManager.setEndPos(to);
            this.mManager.onCursorMoved();
            return true;
        }

        private boolean executeDown(TextView widget, Spannable buffer, int keyCode) {
            Log.d(this.LOG_TAG, "--- executeDown: " + keyCode);
            switch (keyCode) {
                case 19:
                    boolean handled = false | up(widget, buffer);
                    return handled;
                case 20:
                    boolean handled2 = false | down(widget, buffer);
                    return handled2;
                case 21:
                    boolean handled3 = false | left(widget, buffer);
                    return handled3;
                case EditStyledText.MODE_RESET /* 22 */:
                    boolean handled4 = false | right(widget, buffer);
                    return handled4;
                case EditStyledText.MODE_SHOW_MENU /* 23 */:
                    this.mManager.onFixSelectedItem();
                    return true;
                default:
                    return false;
            }
        }
    }

    public static class StyledTextInputConnection extends InputConnectionWrapper {
        EditStyledText mEST;

        public StyledTextInputConnection(InputConnection target, EditStyledText est) {
            super(target, true);
            this.mEST = est;
        }

        @Override // android.view.inputmethod.InputConnectionWrapper, android.view.inputmethod.InputConnection
        public boolean commitText(CharSequence text, int newCursorPosition) {
            Log.d(EditStyledText.TAG, "--- commitText:");
            this.mEST.mManager.unsetTextComposingMask();
            return super.commitText(text, newCursorPosition);
        }

        @Override // android.view.inputmethod.InputConnectionWrapper, android.view.inputmethod.InputConnection
        public boolean finishComposingText() {
            Log.d(EditStyledText.TAG, "--- finishcomposing:");
            if (!this.mEST.isSoftKeyBlocked() && !this.mEST.isButtonsFocused() && !this.mEST.isEditting()) {
                this.mEST.onEndEdit();
            }
            return super.finishComposingText();
        }
    }

    public static class EditStyledTextSpans {
        private static final String LOG_TAG = "EditStyledTextSpan";

        public static class HorizontalLineSpan extends DynamicDrawableSpan {
            HorizontalLineDrawable mDrawable;

            public HorizontalLineSpan(int color, int width, Spannable spannable) {
                super(0);
                this.mDrawable = new HorizontalLineDrawable(color, width, spannable);
            }

            @Override // android.text.style.DynamicDrawableSpan
            public Drawable getDrawable() {
                return this.mDrawable;
            }

            public void resetWidth(int width) {
                this.mDrawable.renewBounds(width);
            }

            public int getColor() {
                return this.mDrawable.getPaint().getColor();
            }
        }

        public static class MarqueeSpan extends CharacterStyle {
            public static final int ALTERNATE = 1;
            public static final int NOTHING = 2;
            public static final int SCROLL = 0;
            private int mMarqueeColor;
            private int mType;

            public MarqueeSpan(int type, int bgc) {
                this.mType = type;
                checkType(type);
                this.mMarqueeColor = getMarqueeColor(type, bgc);
            }

            public MarqueeSpan(int type) {
                this(type, 16777215);
            }

            public int getType() {
                return this.mType;
            }

            public void resetColor(int bgc) {
                this.mMarqueeColor = getMarqueeColor(this.mType, bgc);
            }

            private int getMarqueeColor(int type, int bgc) {
                int a = Color.alpha(bgc);
                int r = Color.red(bgc);
                int g = Color.green(bgc);
                int b = Color.blue(bgc);
                if (a == 0) {
                    a = 128;
                }
                switch (type) {
                    case 0:
                        r = r > 128 ? r / 2 : (255 - r) / 2;
                        break;
                    case 1:
                        g = g > 128 ? g / 2 : (255 - g) / 2;
                        break;
                    case 2:
                        return 16777215;
                    default:
                        Log.e(EditStyledText.TAG, "--- getMarqueeColor: got illigal marquee ID.");
                        return 16777215;
                }
                return Color.argb(a, r, g, b);
            }

            private boolean checkType(int type) {
                if (type == 0 || type == 1) {
                    return true;
                }
                Log.e(EditStyledTextSpans.LOG_TAG, "--- Invalid type of MarqueeSpan");
                return false;
            }

            @Override // android.text.style.CharacterStyle
            public void updateDrawState(TextPaint tp) {
                tp.bgColor = this.mMarqueeColor;
            }
        }

        public static class RescalableImageSpan extends ImageSpan {
            private final int MAXWIDTH;
            Uri mContentUri;
            private Context mContext;
            private Drawable mDrawable;
            public int mIntrinsicHeight;
            public int mIntrinsicWidth;

            public RescalableImageSpan(Context context, Uri uri, int maxwidth) {
                super(context, uri);
                this.mIntrinsicWidth = -1;
                this.mIntrinsicHeight = -1;
                this.mContext = context;
                this.mContentUri = uri;
                this.MAXWIDTH = maxwidth;
            }

            public RescalableImageSpan(Context context, int resourceId, int maxwidth) {
                super(context, resourceId);
                this.mIntrinsicWidth = -1;
                this.mIntrinsicHeight = -1;
                this.mContext = context;
                this.MAXWIDTH = maxwidth;
            }

            @Override // android.text.style.ImageSpan, android.text.style.DynamicDrawableSpan
            public Drawable getDrawable() {
                Bitmap bitmap;
                if (this.mDrawable != null) {
                    return this.mDrawable;
                }
                if (this.mContentUri != null) {
                    System.gc();
                    try {
                        InputStream is = this.mContext.getContentResolver().openInputStream(this.mContentUri);
                        BitmapFactory.Options opt = new BitmapFactory.Options();
                        opt.inJustDecodeBounds = true;
                        BitmapFactory.decodeStream(is, null, opt);
                        is.close();
                        InputStream is2 = this.mContext.getContentResolver().openInputStream(this.mContentUri);
                        int width = opt.outWidth;
                        int height = opt.outHeight;
                        this.mIntrinsicWidth = width;
                        this.mIntrinsicHeight = height;
                        if (opt.outWidth > this.MAXWIDTH) {
                            width = this.MAXWIDTH;
                            height = (this.MAXWIDTH * height) / opt.outWidth;
                            Rect padding = new Rect(0, 0, width, height);
                            bitmap = BitmapFactory.decodeStream(is2, padding, null);
                        } else {
                            bitmap = BitmapFactory.decodeStream(is2);
                        }
                        this.mDrawable = new BitmapDrawable(this.mContext.getResources(), bitmap);
                        this.mDrawable.setBounds(0, 0, width, height);
                        is2.close();
                    } catch (Exception e) {
                        Log.e(EditStyledTextSpans.LOG_TAG, "Failed to loaded content " + this.mContentUri, e);
                        return null;
                    } catch (OutOfMemoryError e2) {
                        Log.e(EditStyledTextSpans.LOG_TAG, "OutOfMemoryError");
                        return null;
                    }
                } else {
                    this.mDrawable = super.getDrawable();
                    rescaleBigImage(this.mDrawable);
                    this.mIntrinsicWidth = this.mDrawable.getIntrinsicWidth();
                    this.mIntrinsicHeight = this.mDrawable.getIntrinsicHeight();
                }
                return this.mDrawable;
            }

            public boolean isOverSize() {
                return getDrawable().getIntrinsicWidth() > this.MAXWIDTH;
            }

            public Uri getContentUri() {
                return this.mContentUri;
            }

            private void rescaleBigImage(Drawable image) {
                Log.d(EditStyledTextSpans.LOG_TAG, "--- rescaleBigImage:");
                if (this.MAXWIDTH >= 0) {
                    int image_width = image.getIntrinsicWidth();
                    int image_height = image.getIntrinsicHeight();
                    Log.d(EditStyledTextSpans.LOG_TAG, "--- rescaleBigImage:" + image_width + MessageDispActivity.string_delimiter + image_height + MessageDispActivity.string_delimiter + this.MAXWIDTH);
                    if (image_width > this.MAXWIDTH) {
                        image_width = this.MAXWIDTH;
                        image_height = (this.MAXWIDTH * image_height) / image_width;
                    }
                    image.setBounds(0, 0, image_width, image_height);
                }
            }
        }

        public static class HorizontalLineDrawable extends ShapeDrawable {
            private static boolean DBG_HL = false;
            private Spannable mSpannable;
            private int mWidth;

            public HorizontalLineDrawable(int color, int width, Spannable spannable) {
                super(new RectShape());
                this.mSpannable = spannable;
                this.mWidth = width;
                renewColor(color);
                renewBounds(width);
            }

            @Override // android.graphics.drawable.ShapeDrawable, android.graphics.drawable.Drawable
            public void draw(Canvas canvas) {
                renewColor();
                Rect rect = new Rect(0, 9, this.mWidth, 11);
                canvas.drawRect(rect, getPaint());
            }

            public void renewBounds(int width) {
                if (DBG_HL) {
                    Log.d(EditStyledTextSpans.LOG_TAG, "--- renewBounds:" + width);
                }
                if (width > 20) {
                    width -= 20;
                }
                this.mWidth = width;
                setBounds(0, 0, width, 20);
            }

            private void renewColor(int color) {
                if (DBG_HL) {
                    Log.d(EditStyledTextSpans.LOG_TAG, "--- renewColor:" + color);
                }
                getPaint().setColor(color);
            }

            private void renewColor() {
                HorizontalLineSpan parent = getParentSpan();
                Spannable text = this.mSpannable;
                int start = text.getSpanStart(parent);
                int end = text.getSpanEnd(parent);
                ForegroundColorSpan[] spans = (ForegroundColorSpan[]) text.getSpans(start, end, ForegroundColorSpan.class);
                if (DBG_HL) {
                    Log.d(EditStyledTextSpans.LOG_TAG, "--- renewColor:" + spans.length);
                }
                if (spans.length > 0) {
                    renewColor(spans[spans.length - 1].getForegroundColor());
                }
            }

            private HorizontalLineSpan getParentSpan() {
                Spannable text = this.mSpannable;
                HorizontalLineSpan[] images = (HorizontalLineSpan[]) text.getSpans(0, text.length(), HorizontalLineSpan.class);
                if (images.length > 0) {
                    for (HorizontalLineSpan image : images) {
                        if (image.getDrawable() == this) {
                            return image;
                        }
                    }
                }
                Log.e(EditStyledTextSpans.LOG_TAG, "---renewBounds: Couldn't find");
                return null;
            }
        }
    }

    public static class ColorPaletteDrawable extends ShapeDrawable {
        private Rect mRect;

        public ColorPaletteDrawable(int color, int width, int height, int mergin) {
            super(new RectShape());
            this.mRect = new Rect(mergin, mergin, width - mergin, height - mergin);
            getPaint().setColor(color);
        }

        @Override // android.graphics.drawable.ShapeDrawable, android.graphics.drawable.Drawable
        public void draw(Canvas canvas) {
            canvas.drawRect(this.mRect, getPaint());
        }
    }

    public class EditModeActions {
        private static final boolean DBG = true;
        private static final String TAG = "EditModeActions";
        private StyledTextDialog mDialog;
        private EditStyledText mEST;
        private EditorManager mManager;
        private int mMode = 0;
        private HashMap<Integer, EditModeActionBase> mActionMap = new HashMap<>();
        private NothingAction mNothingAction = new NothingAction();
        private CopyAction mCopyAction = new CopyAction();
        private PasteAction mPasteAction = new PasteAction();
        private SelectAction mSelectAction = new SelectAction();
        private CutAction mCutAction = new CutAction();
        private SelectAllAction mSelectAllAction = new SelectAllAction();
        private HorizontalLineAction mHorizontalLineAction = new HorizontalLineAction();
        private StopSelectionAction mStopSelectionAction = new StopSelectionAction();
        private ClearStylesAction mClearStylesAction = new ClearStylesAction();
        private ImageAction mImageAction = new ImageAction();
        private BackgroundColorAction mBackgroundColorAction = new BackgroundColorAction();
        private PreviewAction mPreviewAction = new PreviewAction();
        private CancelAction mCancelEditAction = new CancelAction();
        private TextViewAction mTextViewAction = new TextViewAction();
        private StartEditAction mStartEditAction = new StartEditAction();
        private EndEditAction mEndEditAction = new EndEditAction();
        private ResetAction mResetAction = new ResetAction();
        private ShowMenuAction mShowMenuAction = new ShowMenuAction();
        private AlignAction mAlignAction = new AlignAction();
        private TelopAction mTelopAction = new TelopAction();
        private SwingAction mSwingAction = new SwingAction();
        private MarqueeDialogAction mMarqueeDialogAction = new MarqueeDialogAction();
        private ColorAction mColorAction = new ColorAction();
        private SizeAction mSizeAction = new SizeAction();

        EditModeActions(EditStyledText est, EditorManager manager, StyledTextDialog dialog) {
            this.mEST = est;
            this.mManager = manager;
            this.mDialog = dialog;
            this.mActionMap.put(0, this.mNothingAction);
            this.mActionMap.put(1, this.mCopyAction);
            this.mActionMap.put(2, this.mPasteAction);
            this.mActionMap.put(5, this.mSelectAction);
            this.mActionMap.put(7, this.mCutAction);
            this.mActionMap.put(11, this.mSelectAllAction);
            this.mActionMap.put(12, this.mHorizontalLineAction);
            this.mActionMap.put(13, this.mStopSelectionAction);
            this.mActionMap.put(14, this.mClearStylesAction);
            this.mActionMap.put(15, this.mImageAction);
            this.mActionMap.put(16, this.mBackgroundColorAction);
            this.mActionMap.put(17, this.mPreviewAction);
            this.mActionMap.put(18, this.mCancelEditAction);
            this.mActionMap.put(19, this.mTextViewAction);
            this.mActionMap.put(20, this.mStartEditAction);
            this.mActionMap.put(21, this.mEndEditAction);
            this.mActionMap.put(22, this.mResetAction);
            this.mActionMap.put(23, this.mShowMenuAction);
            this.mActionMap.put(6, this.mAlignAction);
            this.mActionMap.put(8, this.mTelopAction);
            this.mActionMap.put(9, this.mSwingAction);
            this.mActionMap.put(10, this.mMarqueeDialogAction);
            this.mActionMap.put(4, this.mColorAction);
            this.mActionMap.put(3, this.mSizeAction);
        }

        public void addAction(int modeId, EditModeActionBase action) {
            this.mActionMap.put(Integer.valueOf(modeId), action);
        }

        public void onAction(int newMode, Object[] params) {
            getAction(newMode).addParams(params);
            this.mMode = newMode;
            doNext(newMode);
        }

        public void onAction(int newMode, Object param) {
            onAction(newMode, new Object[]{param});
        }

        public void onAction(int newMode) {
            onAction(newMode, (Object[]) null);
        }

        public void onSelectAction() {
            doNext(5);
        }

        private EditModeActionBase getAction(int mode) {
            if (this.mActionMap.containsKey(Integer.valueOf(mode))) {
                return this.mActionMap.get(Integer.valueOf(mode));
            }
            return null;
        }

        public boolean doNext() {
            return doNext(this.mMode);
        }

        public boolean doNext(int mode) {
            Log.d(TAG, "--- do the next action: " + mode + MessageDispActivity.string_delimiter + this.mManager.getSelectState());
            EditModeActionBase action = getAction(mode);
            if (action == null) {
                Log.e(TAG, "--- invalid action error.");
                return false;
            }
            switch (this.mManager.getSelectState()) {
                case 0:
                    return action.doNotSelected();
                case 1:
                    return action.doStartPosIsSelected();
                case 2:
                    return action.doEndPosIsSelected();
                case 3:
                    if (this.mManager.isWaitInput()) {
                        return action.doSelectionIsFixedAndWaitingInput();
                    }
                    return action.doSelectionIsFixed();
                default:
                    return false;
            }
        }

        public class EditModeActionBase {
            private Object[] mParams;

            public EditModeActionBase() {
            }

            protected boolean canOverWrap() {
                return false;
            }

            protected boolean canSelect() {
                return false;
            }

            protected boolean canWaitInput() {
                return false;
            }

            protected boolean needSelection() {
                return false;
            }

            protected boolean isLine() {
                return false;
            }

            protected boolean doNotSelected() {
                return false;
            }

            protected boolean doStartPosIsSelected() {
                return doNotSelected();
            }

            protected boolean doEndPosIsSelected() {
                return doStartPosIsSelected();
            }

            protected boolean doSelectionIsFixed() {
                return doEndPosIsSelected();
            }

            protected boolean doSelectionIsFixedAndWaitingInput() {
                return doEndPosIsSelected();
            }

            protected boolean fixSelection() {
                EditModeActions.this.mEST.finishComposingText();
                EditModeActions.this.mManager.setSelectState(3);
                return true;
            }

            protected void addParams(Object[] o) {
                this.mParams = o;
            }

            protected Object getParam(int num) {
                if (this.mParams != null && num <= this.mParams.length) {
                    return this.mParams[num];
                }
                Log.d(EditModeActions.TAG, "--- Number of the parameter is out of bound.");
                return null;
            }
        }

        public class NothingAction extends EditModeActionBase {
            public NothingAction() {
                super();
            }
        }

        public class TextViewActionBase extends EditModeActionBase {
            public TextViewActionBase() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                if (EditModeActions.this.mManager.getEditMode() != 0 && EditModeActions.this.mManager.getEditMode() != 5) {
                    return false;
                }
                EditModeActions.this.mManager.setEditMode(EditModeActions.this.mMode);
                EditModeActions.this.onSelectAction();
                return true;
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doEndPosIsSelected() {
                if (EditModeActions.this.mManager.getEditMode() == 0 || EditModeActions.this.mManager.getEditMode() == 5) {
                    EditModeActions.this.mManager.setEditMode(EditModeActions.this.mMode);
                    fixSelection();
                    EditModeActions.this.doNext();
                    return true;
                }
                if (EditModeActions.this.mManager.getEditMode() != EditModeActions.this.mMode) {
                    EditModeActions.this.mManager.resetEdit();
                    EditModeActions.this.mManager.setEditMode(EditModeActions.this.mMode);
                    EditModeActions.this.doNext();
                    return true;
                }
                return false;
            }
        }

        public class TextViewAction extends TextViewActionBase {
            public TextViewAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.TextViewActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doEndPosIsSelected() {
                if (!super.doEndPosIsSelected()) {
                    Object param = getParam(0);
                    if (param != null && (param instanceof Integer)) {
                        EditModeActions.this.mEST.onTextContextMenuItem(((Integer) param).intValue());
                    }
                    EditModeActions.this.mManager.resetEdit();
                }
                return true;
            }
        }

        public class CopyAction extends TextViewActionBase {
            public CopyAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.TextViewActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doEndPosIsSelected() {
                if (!super.doEndPosIsSelected()) {
                    EditModeActions.this.mManager.copyToClipBoard();
                    EditModeActions.this.mManager.resetEdit();
                }
                return true;
            }
        }

        public class CutAction extends TextViewActionBase {
            public CutAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.TextViewActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doEndPosIsSelected() {
                if (!super.doEndPosIsSelected()) {
                    EditModeActions.this.mManager.cutToClipBoard();
                    EditModeActions.this.mManager.resetEdit();
                }
                return true;
            }
        }

        public class SelectAction extends EditModeActionBase {
            public SelectAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                if (EditModeActions.this.mManager.isTextSelected()) {
                    Log.e(EditModeActions.TAG, "Selection is off, but selected");
                }
                EditModeActions.this.mManager.setSelectStartPos();
                EditModeActions.this.mEST.sendHintMessage(3);
                return true;
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doStartPosIsSelected() {
                if (EditModeActions.this.mManager.isTextSelected()) {
                    Log.e(EditModeActions.TAG, "Selection now start, but selected");
                }
                EditModeActions.this.mManager.setSelectEndPos();
                EditModeActions.this.mEST.sendHintMessage(4);
                if (EditModeActions.this.mManager.getEditMode() != 5) {
                    EditModeActions.this.doNext(EditModeActions.this.mManager.getEditMode());
                    return true;
                }
                return true;
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixed() {
                return false;
            }
        }

        public class PasteAction extends EditModeActionBase {
            public PasteAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mManager.pasteFromClipboard();
                EditModeActions.this.mManager.resetEdit();
                return true;
            }
        }

        public class SelectAllAction extends EditModeActionBase {
            public SelectAllAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mManager.selectAll();
                return true;
            }
        }

        public class HorizontalLineAction extends EditModeActionBase {
            public HorizontalLineAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mManager.insertHorizontalLine();
                return true;
            }
        }

        public class ClearStylesAction extends EditModeActionBase {
            public ClearStylesAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mManager.clearStyles();
                return true;
            }
        }

        public class StopSelectionAction extends EditModeActionBase {
            public StopSelectionAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mManager.fixSelectionAndDoNextAction();
                return true;
            }
        }

        public class CancelAction extends EditModeActionBase {
            public CancelAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mEST.cancelViewManagers();
                return true;
            }
        }

        public class ImageAction extends EditModeActionBase {
            public ImageAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                Object param = getParam(0);
                if (param == null) {
                    EditModeActions.this.mEST.showInsertImageSelectAlertDialog();
                    return true;
                }
                if (param instanceof Uri) {
                    EditModeActions.this.mManager.insertImageFromUri((Uri) param);
                    return true;
                }
                if (param instanceof Integer) {
                    EditModeActions.this.mManager.insertImageFromResId(((Integer) param).intValue());
                    return true;
                }
                return true;
            }
        }

        public class BackgroundColorAction extends EditModeActionBase {
            public BackgroundColorAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mDialog.onShowBackgroundColorAlertDialog();
                return true;
            }
        }

        public class PreviewAction extends EditModeActionBase {
            public PreviewAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mEST.showPreview();
                return true;
            }
        }

        public class StartEditAction extends EditModeActionBase {
            public StartEditAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mManager.startEdit();
                return true;
            }
        }

        public class EndEditAction extends EditModeActionBase {
            public EndEditAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mManager.endEdit();
                return true;
            }
        }

        public class ResetAction extends EditModeActionBase {
            public ResetAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mManager.resetEdit();
                return true;
            }
        }

        public class ShowMenuAction extends EditModeActionBase {
            public ShowMenuAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                EditModeActions.this.mEST.showMenuAlertDialog();
                return true;
            }
        }

        public class SetSpanActionBase extends EditModeActionBase {
            public SetSpanActionBase() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doNotSelected() {
                if (EditModeActions.this.mManager.getEditMode() == 0 || EditModeActions.this.mManager.getEditMode() == 5) {
                    EditModeActions.this.mManager.setEditMode(EditModeActions.this.mMode);
                    EditModeActions.this.mManager.setInternalSelection(EditModeActions.this.mEST.getSelectionStart(), EditModeActions.this.mEST.getSelectionEnd());
                    fixSelection();
                    EditModeActions.this.doNext();
                    return true;
                }
                if (EditModeActions.this.mManager.getEditMode() == EditModeActions.this.mMode) {
                    return false;
                }
                Log.d(EditModeActions.TAG, "--- setspanactionbase" + EditModeActions.this.mManager.getEditMode() + MessageDispActivity.string_delimiter + EditModeActions.this.mMode);
                if (!EditModeActions.this.mManager.isWaitInput()) {
                    EditModeActions.this.mManager.resetEdit();
                    EditModeActions.this.mManager.setEditMode(EditModeActions.this.mMode);
                } else {
                    EditModeActions.this.mManager.setEditMode(0);
                    EditModeActions.this.mManager.setSelectState(0);
                }
                EditModeActions.this.doNext();
                return true;
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doStartPosIsSelected() {
                if (EditModeActions.this.mManager.getEditMode() != 0 && EditModeActions.this.mManager.getEditMode() != 5) {
                    return doNotSelected();
                }
                EditModeActions.this.mManager.setEditMode(EditModeActions.this.mMode);
                EditModeActions.this.onSelectAction();
                return true;
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doEndPosIsSelected() {
                if (EditModeActions.this.mManager.getEditMode() != 0 && EditModeActions.this.mManager.getEditMode() != 5) {
                    return doStartPosIsSelected();
                }
                EditModeActions.this.mManager.setEditMode(EditModeActions.this.mMode);
                fixSelection();
                EditModeActions.this.doNext();
                return true;
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixed() {
                if (!doEndPosIsSelected()) {
                    EditModeActions.this.mEST.sendHintMessage(0);
                    return false;
                }
                return true;
            }
        }

        public class AlignAction extends SetSpanActionBase {
            public AlignAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.SetSpanActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixed() {
                if (!super.doSelectionIsFixed()) {
                    EditModeActions.this.mDialog.onShowAlignAlertDialog();
                }
                return true;
            }
        }

        public class TelopAction extends SetSpanActionBase {
            public TelopAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.SetSpanActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixed() {
                if (!super.doSelectionIsFixed()) {
                    EditModeActions.this.mManager.setTelop();
                }
                return true;
            }
        }

        public class SwingAction extends SetSpanActionBase {
            public SwingAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.SetSpanActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixed() {
                if (!super.doSelectionIsFixed()) {
                    EditModeActions.this.mManager.setSwing();
                }
                return true;
            }
        }

        public class MarqueeDialogAction extends SetSpanActionBase {
            public MarqueeDialogAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.SetSpanActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixed() {
                if (!super.doSelectionIsFixed()) {
                    EditModeActions.this.mDialog.onShowMarqueeAlertDialog();
                }
                return true;
            }
        }

        public class ColorAction extends SetSpanActionBase {
            public ColorAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.SetSpanActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixed() {
                if (!super.doSelectionIsFixed()) {
                    EditModeActions.this.mDialog.onShowForegroundColorAlertDialog();
                }
                return true;
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixedAndWaitingInput() {
                if (!super.doSelectionIsFixedAndWaitingInput()) {
                    int size = EditModeActions.this.mManager.getSizeWaitInput();
                    EditModeActions.this.mManager.setItemColor(EditModeActions.this.mManager.getColorWaitInput(), false);
                    if (!EditModeActions.this.mManager.isWaitInput()) {
                        EditModeActions.this.mManager.setItemSize(size, false);
                        EditModeActions.this.mManager.resetEdit();
                    } else {
                        fixSelection();
                        EditModeActions.this.mDialog.onShowForegroundColorAlertDialog();
                    }
                }
                return true;
            }
        }

        public class SizeAction extends SetSpanActionBase {
            public SizeAction() {
                super();
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.SetSpanActionBase, com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixed() {
                if (!super.doSelectionIsFixed()) {
                    EditModeActions.this.mDialog.onShowSizeAlertDialog();
                }
                return true;
            }

            @Override // com.android.ex.editstyledtext.EditStyledText.EditModeActions.EditModeActionBase
            protected boolean doSelectionIsFixedAndWaitingInput() {
                if (!super.doSelectionIsFixedAndWaitingInput()) {
                    int color = EditModeActions.this.mManager.getColorWaitInput();
                    EditModeActions.this.mManager.setItemSize(EditModeActions.this.mManager.getSizeWaitInput(), false);
                    if (!EditModeActions.this.mManager.isWaitInput()) {
                        EditModeActions.this.mManager.setItemColor(color, false);
                        EditModeActions.this.mManager.resetEdit();
                    } else {
                        fixSelection();
                        EditModeActions.this.mDialog.onShowSizeAlertDialog();
                    }
                }
                return true;
            }
        }
    }
}
