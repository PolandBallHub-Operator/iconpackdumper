package com.android.ex.chips;

/* JADX INFO: loaded from: classes.dex */
public final class Manifest {

    public static final class permission {
        public static final String MMS_SEND_OUTBOX_MSG = "android.permission.MMS_SEND_OUTBOX_MSG";
    }
}
