package com.android.ex.chips.recipientchip;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.style.ReplacementSpan;
import com.android.ex.chips.RecipientEntry;

/* JADX INFO: loaded from: classes.dex */
public class InvisibleRecipientChip extends ReplacementSpan implements DrawableRecipientChip {
    private final SimpleRecipientChip mDelegate;

    public InvisibleRecipientChip(RecipientEntry entry) {
        this.mDelegate = new SimpleRecipientChip(entry);
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public void setSelected(boolean selected) {
        this.mDelegate.setSelected(selected);
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public boolean isSelected() {
        return this.mDelegate.isSelected();
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public CharSequence getDisplay() {
        return this.mDelegate.getDisplay();
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public CharSequence getValue() {
        return this.mDelegate.getValue();
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public long getContactId() {
        return this.mDelegate.getContactId();
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public Long getDirectoryId() {
        return this.mDelegate.getDirectoryId();
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public String getLookupKey() {
        return this.mDelegate.getLookupKey();
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public long getDataId() {
        return this.mDelegate.getDataId();
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public RecipientEntry getEntry() {
        return this.mDelegate.getEntry();
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public void setOriginalText(String text) {
        this.mDelegate.setOriginalText(text);
    }

    @Override // com.android.ex.chips.recipientchip.BaseRecipientChip
    public CharSequence getOriginalText() {
        return this.mDelegate.getOriginalText();
    }

    @Override // android.text.style.ReplacementSpan
    public void draw(Canvas canvas, CharSequence text, int start, int end, float x, int top, int y, int bottom, Paint paint) {
    }

    @Override // android.text.style.ReplacementSpan
    public int getSize(Paint paint, CharSequence text, int start, int end, Paint.FontMetricsInt fm) {
        return 0;
    }

    @Override // com.android.ex.chips.recipientchip.DrawableRecipientChip
    public Rect getBounds() {
        return new Rect(0, 0, 0, 0);
    }

    @Override // com.android.ex.chips.recipientchip.DrawableRecipientChip
    public void draw(Canvas canvas) {
    }
}
