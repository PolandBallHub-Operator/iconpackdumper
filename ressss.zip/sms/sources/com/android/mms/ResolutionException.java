package com.android.mms;

/* JADX INFO: loaded from: classes.dex */
public final class ResolutionException extends ContentRestrictionException {
    private static final long serialVersionUID = 5509925632215500520L;

    public ResolutionException() {
    }

    public ResolutionException(String msg) {
        super(msg);
    }
}
