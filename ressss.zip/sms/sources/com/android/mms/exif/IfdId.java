package com.android.mms.exif;

/* JADX INFO: loaded from: classes.dex */
public interface IfdId {
    public static final int TYPE_IFD_0 = 0;
    public static final int TYPE_IFD_1 = 1;
    public static final int TYPE_IFD_COUNT = 5;
    public static final int TYPE_IFD_EXIF = 2;
    public static final int TYPE_IFD_GPS = 4;
    public static final int TYPE_IFD_INTEROPERABILITY = 3;
}
