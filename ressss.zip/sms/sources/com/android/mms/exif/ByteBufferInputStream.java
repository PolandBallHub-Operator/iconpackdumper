package com.android.mms.exif;

import java.io.InputStream;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
class ByteBufferInputStream extends InputStream {
    private final ByteBuffer mBuf;

    public ByteBufferInputStream(ByteBuffer buf) {
        this.mBuf = buf;
    }

    @Override // java.io.InputStream
    public int read() {
        if (this.mBuf.hasRemaining()) {
            return this.mBuf.get() & 255;
        }
        return -1;
    }

    @Override // java.io.InputStream
    public int read(byte[] bytes, int off, int len) {
        if (!this.mBuf.hasRemaining()) {
            return -1;
        }
        int len2 = Math.min(len, this.mBuf.remaining());
        this.mBuf.get(bytes, off, len2);
        return len2;
    }
}
