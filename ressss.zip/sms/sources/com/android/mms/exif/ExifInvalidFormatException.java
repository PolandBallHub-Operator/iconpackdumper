package com.android.mms.exif;

/* JADX INFO: loaded from: classes.dex */
public class ExifInvalidFormatException extends Exception {
    public ExifInvalidFormatException(String meg) {
        super(meg);
    }
}
