package com.android.mms;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.provider.Telephony;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;

/* JADX INFO: loaded from: classes.dex */
public class QTIBackupSMS {
    BufferedOutputStream buf;
    Cursor cursor;
    Context mContext;
    FileInputStream mFileInputStream;
    FileOutputStream mFileOutputStream;
    String vfile;
    private final boolean DEBUG = false;
    private final String TAG = "QTIBackupSMS";
    SMSBackup smsBackupInbox = new SMSBackup();
    SMSBackup smsBackupSent = new SMSBackup();
    SMSBackup smsBackupDraft = new SMSBackup();

    private enum MsgBox {
        SENT,
        INBOX,
        DRAFT
    }

    public QTIBackupSMS(Context context, String _vfile) {
        this.mContext = context;
        this.vfile = _vfile;
    }

    public void performRestore() {
        try {
            this.mFileInputStream = this.mContext.openFileInput(this.vfile);
            ObjectInputStream ois = new ObjectInputStream(this.mFileInputStream);
            int numOfObjects = ois.readInt();
            if (numOfObjects < 1) {
            }
            SMSBackup smsbk = (SMSBackup) ois.readObject();
            writeSMS(smsbk, MsgBox.INBOX);
            int numOfObjects2 = ois.readInt();
            if (numOfObjects2 < 1) {
            }
            SMSBackup smsbk2 = (SMSBackup) ois.readObject();
            writeSMS(smsbk2, MsgBox.SENT);
            int numOfObjects3 = ois.readInt();
            if (numOfObjects3 < 1) {
            }
            SMSBackup smsbk3 = (SMSBackup) ois.readObject();
            writeSMS(smsbk3, MsgBox.DRAFT);
        } catch (FileNotFoundException e) {
            Log.e("QTIBackupSMS", e.getLocalizedMessage());
        } catch (StreamCorruptedException e2) {
            Log.e("QTIBackupSMS", e2.getLocalizedMessage());
        } catch (IOException e3) {
            Log.e("QTIBackupSMS", e3.getLocalizedMessage());
        } catch (ClassNotFoundException e4) {
            Log.e("QTIBackupSMS", e4.getLocalizedMessage());
        }
    }

    private void writeSMS(SMSBackup smsbk, MsgBox box) {
        ContentResolver cr = this.mContext.getContentResolver();
        ContentValues values = new ContentValues();
        switch (box) {
            case INBOX:
                for (SMSObject smsObj : smsbk.SMSList) {
                    values.put("_id", smsObj.getId());
                    values.put("address", smsObj.getAddr());
                    values.put("body", smsObj.getMsg());
                    values.put("date_sent", smsObj.getTime());
                    values.put("read", smsObj.getReadState());
                    cr.insert(Telephony.Sms.Inbox.CONTENT_URI, values);
                }
                break;
            case SENT:
                for (SMSObject smsObj2 : smsbk.SMSList) {
                    values.put("_id", smsObj2.getId());
                    values.put("address", smsObj2.getAddr());
                    values.put("body", smsObj2.getMsg());
                    values.put("date_sent", smsObj2.getTime());
                    values.put("read", smsObj2.getReadState());
                    cr.insert(Telephony.Sms.Sent.CONTENT_URI, values);
                }
                break;
            case DRAFT:
                for (SMSObject smsObj3 : smsbk.SMSList) {
                    values.put("_id", smsObj3.getId());
                    values.put("address", smsObj3.getAddr());
                    values.put("body", smsObj3.getMsg());
                    values.put("date_sent", smsObj3.getTime());
                    values.put("read", smsObj3.getReadState());
                    cr.insert(Telephony.Sms.Draft.CONTENT_URI, values);
                }
                break;
        }
    }

    public void performBackup() {
        int numOfEntriesInbox = getSMSList(MsgBox.INBOX);
        int numOfEntriesSent = getSMSList(MsgBox.SENT);
        int numOfEntriesDraft = getSMSList(MsgBox.DRAFT);
        writeSMSList(numOfEntriesInbox, numOfEntriesSent, numOfEntriesDraft);
    }

    private int getSMSList(MsgBox box) {
        this.cursor = getSmsCursor(box);
        if (this.cursor == null) {
            return -1;
        }
        if (this.cursor.getCount() < 1) {
            return 0;
        }
        this.cursor.moveToFirst();
        int numOfEntries = 0;
        switch (box) {
            case INBOX:
                int i = 0;
                while (true) {
                    SMSObject smsObj = getSMS(this.cursor);
                    this.smsBackupInbox.SMSList.add(smsObj);
                    numOfEntries++;
                    if (!this.cursor.isLast()) {
                        this.cursor.moveToNext();
                        i++;
                    }
                    break;
                }
                break;
            case SENT:
                int i2 = 0;
                while (true) {
                    SMSObject smsObj2 = getSMS(this.cursor);
                    this.smsBackupSent.SMSList.add(smsObj2);
                    numOfEntries++;
                    if (!this.cursor.isLast()) {
                        this.cursor.moveToNext();
                        i2++;
                    }
                    break;
                }
                break;
            case DRAFT:
                int i3 = 0;
                while (true) {
                    SMSObject smsObj3 = getSMS(this.cursor);
                    this.smsBackupDraft.SMSList.add(smsObj3);
                    numOfEntries++;
                    if (!this.cursor.isLast()) {
                        this.cursor.moveToNext();
                        i3++;
                    }
                    break;
                }
                break;
        }
        this.cursor.close();
        return numOfEntries;
    }

    public void writeSMSList(int numOfEntriesInbox, int numOfEntriesSent, int numOfEntriesDraft) {
        try {
            this.mFileOutputStream = this.mContext.openFileOutput(this.vfile, 0);
            ObjectOutputStream oos = new ObjectOutputStream(this.mFileOutputStream);
            oos.writeInt(numOfEntriesInbox);
            oos.writeObject(this.smsBackupInbox);
            oos.writeInt(numOfEntriesSent);
            oos.writeObject(this.smsBackupSent);
            oos.writeInt(numOfEntriesDraft);
            oos.writeObject(this.smsBackupDraft);
            oos.flush();
            oos.close();
            this.mFileOutputStream.close();
        } catch (IOException e) {
            Log.e("QTIBackupSMS", e.getLocalizedMessage());
        }
    }

    public SMSObject getSMS(Cursor c) {
        SMSObject sms = new SMSObject();
        sms.setId(c.getString(c.getColumnIndexOrThrow("_id")));
        sms.setAddr(c.getString(c.getColumnIndexOrThrow("address")));
        sms.setMsg(c.getString(c.getColumnIndexOrThrow("body")));
        sms.setTime(c.getString(c.getColumnIndexOrThrow("date")));
        sms.setReadState(c.getString(c.getColumnIndexOrThrow("read")));
        return sms;
    }

    private Cursor getSmsCursor(MsgBox box) {
        ContentResolver cr = this.mContext.getContentResolver();
        switch (box) {
            case INBOX:
                Cursor c = cr.query(Telephony.Sms.Inbox.CONTENT_URI, null, null, null, null);
                return c;
            case SENT:
                Cursor c2 = cr.query(Telephony.Sms.Sent.CONTENT_URI, null, null, null, null);
                return c2;
            case DRAFT:
                Cursor c3 = cr.query(Telephony.Sms.Draft.CONTENT_URI, null, null, null, null);
                return c3;
            default:
                return null;
        }
    }
}
