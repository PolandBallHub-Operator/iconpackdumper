package com.android.mms.drm;

import android.drm.DrmManagerClient;
import android.net.Uri;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.android.mms.MmsApp;

/* JADX INFO: loaded from: classes.dex */
public class DrmUtils {
    private static final String EXTENSION_ANDROID_FWDL = ".fl";
    private static final String TAG = "Mms";

    private DrmUtils() {
    }

    public static String getConvertExtension(String mimetype) {
        return EXTENSION_ANDROID_FWDL;
    }

    public static boolean isDrmType(String mimeType) {
        DrmManagerClient drmManagerClient = MmsApp.getApplication().getDrmManagerClient();
        if (drmManagerClient == null) {
            return false;
        }
        try {
            if (!drmManagerClient.canHandle(LoggingEvents.EXTRA_CALLING_APP_NAME, mimeType)) {
                return false;
            }
            return true;
        } catch (IllegalArgumentException e) {
            Log.w("Mms", "canHandle called with wrong parameters");
            return false;
        } catch (IllegalStateException e2) {
            Log.w("Mms", "DrmManagerClient didn't initialize properly");
            return false;
        }
    }

    public static boolean haveRightsForAction(Uri uri, int action) {
        DrmManagerClient drmManagerClient = MmsApp.getApplication().getDrmManagerClient();
        try {
            if (!drmManagerClient.canHandle(uri.toString(), (String) null)) {
                return true;
            }
            int check = drmManagerClient.checkRightsStatus(uri.toString(), action);
            return check == 0;
        } catch (Exception e) {
            return true;
        }
    }
}
