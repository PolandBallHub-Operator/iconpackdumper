package com.android.mms;

/* JADX INFO: loaded from: classes.dex */
public class ContentRestrictionException extends RuntimeException {
    private static final long serialVersionUID = 516136015813043499L;

    public ContentRestrictionException() {
    }

    public ContentRestrictionException(String msg) {
        super(msg);
    }

    public ContentRestrictionException(Exception cause) {
        super(cause);
    }
}
