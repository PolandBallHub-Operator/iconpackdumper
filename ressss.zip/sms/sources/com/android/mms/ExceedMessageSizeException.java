package com.android.mms;

/* JADX INFO: loaded from: classes.dex */
public final class ExceedMessageSizeException extends ContentRestrictionException {
    private static final long serialVersionUID = 6647713416796190850L;

    public ExceedMessageSizeException() {
    }

    public ExceedMessageSizeException(String msg) {
        super(msg);
    }
}
