package com.android.mms.data;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialogFp;
import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteFullException;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.SystemProperties;
import android.provider.Telephony;
import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import com.android.mms.LogTag;
import com.android.mms.MmsApp;
import com.android.mms.R;
import com.android.mms.transaction.MessagingNotification;
import com.android.mms.transaction.MmsMessageSender;
import com.android.mms.ui.ComposeMessageActivity;
import com.android.mms.ui.MessageDispActivity;
import com.android.mms.ui.MessageUtils;
import com.android.mms.util.AddressUtils;
import com.android.mms.util.DraftCache;
import com.android.mms.util.ModeStringUtil;
import com.google.android.mms.util.PduCache;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class Conversation {
    public static final String[] ALL_THREADS_PROJECTION;
    static final int COLUMN_ID = 0;
    static final int COLUMN_SMS_ADDRESS = 2;
    static final int COLUMN_SMS_BODY = 3;
    static final int COLUMN_SMS_DATE = 4;
    static final int COLUMN_SMS_ERROR_CODE = 9;
    static final int COLUMN_SMS_LOCKED = 8;
    static final int COLUMN_SMS_READ = 5;
    static final int COLUMN_SMS_STATUS = 7;
    static final int COLUMN_SMS_TYPE = 6;
    static final int COLUMN_THREAD_ID = 1;
    private static final int DATE = 1;
    private static final boolean DEBUG = true;
    private static final boolean DELETEDEBUG = true;
    private static final int ERROR = 7;
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final int HAS_ATTACHMENT = 8;
    private static final int ID = 0;
    private static final int MESSAGE_COUNT = 2;
    private static final int READ = 6;
    private static final int RECIPIENT_IDS = 3;
    private static final String[] SEEN_PROJECTION;
    static final String[] SMS_PROJECTION;
    private static final int SNIPPET = 4;
    private static final int SNIPPET_CS = 5;
    private static final String TAG = "Mms";
    private static final String UNREAD_FROM_ID_SELECTION = "read=0 AND thread_id=";
    public static final String[] UNREAD_PROJECTION;
    private static final String UNREAD_SELECTION = "(read=0 OR seen=0)";
    public static final Uri sAllThreadsUri;
    private static boolean sDeletingThreads;
    private static Object sDeletingThreadsLock;
    private static boolean sLoadingThreads;
    private static ContentValues sReadContentValues;
    private static Handler sToastHandler;
    private final Context mContext;
    private long mDate;
    private String mForwardRecipientNumber;
    private boolean mHasAttachment;
    private boolean mHasError;
    private boolean mHasMmsForward;
    private boolean mHasUnreadMessages;
    private boolean mIsChecked;
    private Object mMarkAsBlockedSyncer;
    private boolean mMarkAsReadBlocked;
    private boolean mMarkAsReadWaiting;
    private int mMessageCount;
    private ContactList mRecipients;
    private String mSnippet;
    private long mThreadId;
    private int mUnreadMessageCount;

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
        sAllThreadsUri = Telephony.Threads.CONTENT_URI.buildUpon().appendQueryParameter("simple", "true").build();
        ALL_THREADS_PROJECTION = new String[]{"_id", "date", "message_count", "recipient_ids", "snippet", "snippet_cs", "read", "error", "has_attachment"};
        UNREAD_PROJECTION = new String[]{"_id", "read"};
        SEEN_PROJECTION = new String[]{"seen"};
        sDeletingThreadsLock = new Object();
        sToastHandler = new Handler();
        SMS_PROJECTION = new String[]{"_id", ComposeMessageActivity.THREAD_ID, "address", "body", "date", "read", "type", "status", "locked", "error_code"};
    }

    private Conversation(Context context) {
        this.mMarkAsBlockedSyncer = new Object();
        this.mUnreadMessageCount = 0;
        this.mHasMmsForward = false;
        this.mContext = context.getApplicationContext();
        this.mRecipients = new ContactList();
        this.mThreadId = 0L;
    }

    private Conversation(Context context, long threadId, boolean allowQuery) {
        this.mMarkAsBlockedSyncer = new Object();
        this.mUnreadMessageCount = 0;
        this.mHasMmsForward = false;
        Log.v("Mms", "Conversation constructor threadId: " + threadId);
        this.mContext = context.getApplicationContext();
        if (!loadFromThreadId(threadId, allowQuery)) {
            this.mRecipients = new ContactList();
            this.mThreadId = 0L;
        }
    }

    private Conversation(Context context, Cursor cursor, boolean allowQuery) {
        this.mMarkAsBlockedSyncer = new Object();
        this.mUnreadMessageCount = 0;
        this.mHasMmsForward = false;
        Log.v("Mms", "Conversation constructor cursor, allowQuery: " + allowQuery);
        this.mContext = context.getApplicationContext();
        fillFromCursor(context, this, cursor, allowQuery);
    }

    public static Conversation createNew(Context context) {
        return new Conversation(context);
    }

    public static Conversation get(Context context, long threadId, boolean allowQuery) {
        Log.v("Mms", "Conversation get by threadId: " + threadId);
        Conversation conv = Cache.get(threadId);
        if (conv != null) {
            return conv;
        }
        Conversation conv2 = new Conversation(context, threadId, allowQuery);
        try {
            Cache.put(conv2);
        } catch (IllegalStateException e) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.error("Tried to add duplicate Conversation to Cache (from threadId): ***", new Object[0]);
            } else {
                LogTag.error("Tried to add duplicate Conversation to Cache (from threadId): " + conv2, new Object[0]);
            }
            if (!Cache.replace(conv2)) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    LogTag.error("get by threadId cache.replace failed on ***", new Object[0]);
                } else {
                    LogTag.error("get by threadId cache.replace failed on " + conv2, new Object[0]);
                }
            }
        }
        return conv2;
    }

    public static Conversation get(Context context, ContactList recipients) {
        if (recipients.size() < 1) {
            return null;
        }
        return Cache.get(recipients);
    }

    public static Conversation get(Context context, ContactList recipients, boolean allowQuery) {
        if (FJ_TEL_LOG_ACQ_FLG) {
            Log.v("Mms", "Conversation get by recipients: ***");
        } else {
            Log.v("Mms", "Conversation get by recipients: ***");
        }
        if (recipients.size() < 1) {
            return createNew(context);
        }
        Conversation conv = Cache.get(recipients);
        if (conv == null) {
            long threadId = getOrCreateThreadId(context, recipients);
            Conversation conv2 = new Conversation(context, threadId, allowQuery);
            Log.d("Mms", "Conversation.get: created new conversation xxxxxxx");
            if (!conv2.getRecipients().equals(recipients)) {
                LogTag.error("Mms", "Conversation.get: new conv's recipients don't match input recpients xxxxxxx");
            }
            try {
                Cache.put(conv2);
                return conv2;
            } catch (IllegalStateException e) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    LogTag.error("Tried to add duplicate Conversation to Cache (from recipients): ***", new Object[0]);
                } else {
                    LogTag.error("Tried to add duplicate Conversation to Cache (from recipients): " + conv2, new Object[0]);
                }
                if (!Cache.replace(conv2)) {
                    if (FJ_TEL_LOG_ACQ_FLG) {
                        LogTag.error("get by recipients cache.replace failed on ***", new Object[0]);
                        return conv2;
                    }
                    LogTag.error("get by recipients cache.replace failed on " + conv2, new Object[0]);
                    return conv2;
                }
                return conv2;
            }
        }
        return conv;
    }

    public static Conversation get(Context context, Uri uri, boolean allowQuery) {
        Log.v("Mms", "Conversation get by uri: " + uri);
        if (uri == null) {
            return createNew(context);
        }
        Log.v("Mms", "Conversation get URI: " + uri);
        if (uri.getPathSegments().size() >= 2) {
            try {
                long threadId = Long.parseLong(uri.getPathSegments().get(1));
                Log.v("Mms", "Conversation get threadId: " + threadId);
                return get(context, threadId, allowQuery);
            } catch (NumberFormatException e) {
                LogTag.error("Invalid URI: " + uri, new Object[0]);
            }
        }
        String recipients = PhoneNumberUtils.replaceUnicodeDigits(getRecipients(uri)).replace(',', ';');
        return get(context, ContactList.getByNumbers(recipients, allowQuery, true), allowQuery);
    }

    public boolean sameRecipient(Uri uri, Context context) {
        ContactList incomingRecipient;
        int size = this.mRecipients.size();
        if (size > 1) {
            return false;
        }
        if (uri == null) {
            return size == 0;
        }
        if (uri.getPathSegments().size() >= 2) {
            Conversation otherConv = get(context, uri, false);
            if (otherConv == null) {
                return false;
            }
            incomingRecipient = otherConv.mRecipients;
        } else {
            String recipient = getRecipients(uri);
            incomingRecipient = ContactList.getByNumbers(recipient, false, false);
        }
        if (FJ_TEL_LOG_ACQ_FLG) {
            Log.v("Mms", "sameRecipient incomingRecipient: *** mRecipients: ***");
        } else {
            Log.v("Mms", "sameRecipient incomingRecipient: " + incomingRecipient + " mRecipients: " + this.mRecipients);
        }
        return this.mRecipients.equals(incomingRecipient);
    }

    public static Conversation from(Context context, Cursor cursor) {
        Conversation conv;
        long threadId = cursor.getLong(0);
        if (threadId > 0 && (conv = Cache.get(threadId)) != null) {
            fillFromCursor(context, conv, cursor, false);
            return conv;
        }
        Conversation conv2 = new Conversation(context, cursor, false);
        try {
            Cache.put(conv2);
        } catch (IllegalStateException e) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.error("Mms", "Tried to add duplicate Conversation to Cache (from cursor): ***");
            } else {
                LogTag.error("Mms", "Tried to add duplicate Conversation to Cache (from cursor): " + conv2);
            }
            if (!Cache.replace(conv2)) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    LogTag.error("Converations.from cache.replace failed on ***", new Object[0]);
                } else {
                    LogTag.error("Converations.from cache.replace failed on " + conv2, new Object[0]);
                }
            }
        }
        return conv2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void buildReadContentValues() {
        if (sReadContentValues == null) {
            sReadContentValues = new ContentValues(2);
            sReadContentValues.put("read", (Integer) 1);
            sReadContentValues.put("seen", (Integer) 1);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendReadReport(Context context, long threadId, int status) {
        String selection = threadId != -1 ? "m_type = 132 AND read = 0 AND rr = 128 AND " + ComposeMessageActivity.THREAD_ID + " = " + threadId : "m_type = 132 AND read = 0 AND rr = 128";
        Cursor c = SqliteWrapper.query(context, context.getContentResolver(), Telephony.Mms.Inbox.CONTENT_URI, new String[]{"_id", "m_id"}, selection, (String[]) null, (String) null);
        if (c != null) {
            try {
                if (c.getCount() != 0) {
                    while (c.moveToNext()) {
                        Uri uri = ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, c.getLong(0));
                        if (Log.isLoggable("Mms", 2)) {
                            LogTag.debug("sendReadReport: uri = " + uri, new Object[0]);
                        }
                        MmsMessageSender.sendReadRec(context, AddressUtils.getFrom(context, uri), c.getString(1), status);
                    }
                    if (c != null) {
                        return;
                    } else {
                        return;
                    }
                }
            } finally {
                if (c != null) {
                    c.close();
                }
            }
        }
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [com.android.mms.data.Conversation$1] */
    public void markAsRead() {
        Contact.logWithTrace("Mms", "markAsRead mMarkAsReadWaiting: " + this.mMarkAsReadWaiting + " mMarkAsReadBlocked: " + this.mMarkAsReadBlocked, new Object[0]);
        if (!this.mMarkAsReadWaiting) {
            if (this.mMarkAsReadBlocked) {
                this.mMarkAsReadWaiting = true;
            } else {
                final Uri threadUri = getUri();
                new AsyncTask<Void, Void, Void>() { // from class: com.android.mms.data.Conversation.1
                    /* JADX INFO: Access modifiers changed from: protected */
                    @Override // android.os.AsyncTask
                    public Void doInBackground(Void... none) {
                        LogTag.debug("markAsRead.doInBackground", new Object[0]);
                        if (threadUri != null) {
                            Conversation.this.buildReadContentValues();
                            boolean needUpdate = true;
                            Cursor c = Conversation.this.mContext.getContentResolver().query(threadUri, Conversation.UNREAD_PROJECTION, Conversation.UNREAD_SELECTION, null, null);
                            if (c != null) {
                                try {
                                    needUpdate = c.getCount() > 0;
                                    c.close();
                                } catch (Throwable th) {
                                    c.close();
                                    throw th;
                                }
                            }
                            if (needUpdate) {
                                Conversation.this.sendReadReport(Conversation.this.mContext, Conversation.this.mThreadId, 128);
                                LogTag.debug("markAsRead: update read/seen for thread uri: " + threadUri, new Object[0]);
                                try {
                                    Conversation.this.mContext.getContentResolver().update(threadUri, Conversation.sReadContentValues, Conversation.UNREAD_SELECTION, null);
                                } catch (SQLiteFullException e) {
                                    Log.e("Mms", "Database is full");
                                    e.printStackTrace();
                                    Conversation.showStorageFullToast(Conversation.this.mContext);
                                    Conversation.this.setHasUnreadMessages(false);
                                }
                            }
                            Conversation.this.setHasUnreadMessages(false);
                        }
                        MessagingNotification.blockingUpdateAllNotifications(Conversation.this.mContext, -2L);
                        return null;
                    }
                }.execute(new Void[0]);
            }
        }
    }

    public void blockMarkAsRead(boolean block) {
        LogTag.debug("blockMarkAsRead: " + block, new Object[0]);
        if (block != this.mMarkAsReadBlocked) {
            this.mMarkAsReadBlocked = block;
            if (!this.mMarkAsReadBlocked && this.mMarkAsReadWaiting) {
                this.mMarkAsReadWaiting = false;
                markAsRead();
            }
        }
    }

    public synchronized Uri getUri() {
        return this.mThreadId <= 0 ? null : ContentUris.withAppendedId(Telephony.Threads.CONTENT_URI, this.mThreadId);
    }

    public static Uri getUri(long threadId) {
        return ContentUris.withAppendedId(Telephony.Threads.CONTENT_URI, threadId);
    }

    public synchronized long getThreadId() {
        return this.mThreadId;
    }

    public synchronized long ensureThreadId() {
        LogTag.debug("ensureThreadId before: " + this.mThreadId, new Object[0]);
        if (this.mThreadId <= 0) {
            try {
                this.mThreadId = getOrCreateThreadId(this.mContext, this.mRecipients);
            } catch (Exception e) {
                LogTag.error("ensureThreadId Exception e = " + e, new Object[0]);
                this.mThreadId = 0L;
            }
        }
        LogTag.debug("ensureThreadId after: " + this.mThreadId, new Object[0]);
        return this.mThreadId;
    }

    public synchronized void clearThreadId() {
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("clearThreadId old threadId was: " + this.mThreadId + " now zero", new Object[0]);
        }
        Cache.remove(this.mThreadId);
        this.mThreadId = 0L;
    }

    public synchronized void setRecipients(ContactList list) {
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.d("Mms", "setRecipients before: ***");
            } else {
                Log.d("Mms", "setRecipients before: " + toString());
            }
        }
        this.mRecipients = list;
        this.mThreadId = 0L;
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.d("Mms", "setRecipients after: ***");
            } else {
                Log.d("Mms", "setRecipients after: " + toString());
            }
        }
    }

    public synchronized ContactList getRecipients() {
        return this.mRecipients;
    }

    public synchronized boolean hasDraft() {
        return this.mThreadId <= 0 ? false : DraftCache.getInstance().hasDraft(this.mThreadId);
    }

    public synchronized void setDraftState(boolean hasDraft) {
        if (this.mThreadId > 0) {
            DraftCache.getInstance().setDraftState(this.mThreadId, hasDraft);
        }
    }

    public synchronized long getDate() {
        return this.mDate;
    }

    public synchronized int getMessageCount() {
        return this.mMessageCount;
    }

    public synchronized void setMessageCount(int cnt) {
        this.mMessageCount = cnt;
    }

    public synchronized String getSnippet() {
        return this.mSnippet;
    }

    public boolean hasUnreadMessages() {
        boolean z;
        synchronized (this) {
            z = this.mHasUnreadMessages;
        }
        return z;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setHasUnreadMessages(boolean flag) {
        synchronized (this) {
            this.mHasUnreadMessages = flag;
        }
    }

    public synchronized boolean hasAttachment() {
        return this.mHasAttachment;
    }

    public synchronized boolean hasError() {
        return this.mHasError;
    }

    public synchronized boolean isChecked() {
        return this.mIsChecked;
    }

    public synchronized void setIsChecked(boolean isChecked) {
        this.mIsChecked = isChecked;
    }

    private static long getOrCreateThreadId(Context context, ContactList list) {
        long retVal;
        HashSet<String> recipients = new HashSet<>();
        for (Contact c : list) {
            Contact cacheContact = Contact.get(c.getNumber(), false);
            if (cacheContact != null) {
                recipients.add(cacheContact.getNumber());
            } else {
                recipients.add(c.getNumber());
            }
        }
        synchronized (sDeletingThreadsLock) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                ComposeMessageActivity.log("Conversation getOrCreateThreadId for: *** sDeletingThreads: " + sDeletingThreads);
            } else {
                ComposeMessageActivity.log("Conversation getOrCreateThreadId for: " + list.formatNamesAndNumbers(MessageDispActivity.string_delimiter) + " sDeletingThreads: " + sDeletingThreads);
            }
            long now = System.currentTimeMillis();
            while (sDeletingThreads) {
                try {
                    sDeletingThreadsLock.wait(30000L);
                } catch (InterruptedException e) {
                }
                if (System.currentTimeMillis() - now > 29000) {
                    Log.e("Mms", "getOrCreateThreadId timed out waiting for delete to complete", new Exception());
                    sDeletingThreads = false;
                    break;
                }
            }
            retVal = Telephony.Threads.getOrCreateThreadId(context, recipients);
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.debug("[Conversation] getOrCreateThreadId for (%s) returned %d", "***", Long.valueOf(retVal));
            } else {
                LogTag.debug("[Conversation] getOrCreateThreadId for (%s) returned %d", recipients, Long.valueOf(retVal));
            }
        }
        return retVal;
    }

    public static long getOrCreateThreadId(Context context, String address) {
        long retVal;
        synchronized (sDeletingThreadsLock) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                ComposeMessageActivity.log("Conversation getOrCreateThreadId for: *** sDeletingThreads: " + sDeletingThreads);
            } else {
                ComposeMessageActivity.log("Conversation getOrCreateThreadId for: " + address + " sDeletingThreads: " + sDeletingThreads);
            }
            long now = System.currentTimeMillis();
            while (sDeletingThreads) {
                try {
                    sDeletingThreadsLock.wait(30000L);
                } catch (InterruptedException e) {
                }
                if (System.currentTimeMillis() - now > 29000) {
                    Log.e("Mms", "getOrCreateThreadId timed out waiting for delete to complete", new Exception());
                    sDeletingThreads = false;
                    break;
                }
            }
            retVal = Telephony.Threads.getOrCreateThreadId(context, address);
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.debug("[Conversation] getOrCreateThreadId for (%s) returned %d", "***", Long.valueOf(retVal));
            } else {
                LogTag.debug("[Conversation] getOrCreateThreadId for (%s) returned %d", address, Long.valueOf(retVal));
            }
        }
        return retVal;
    }

    public synchronized boolean equals(Object obj) {
        boolean zEquals;
        try {
            Conversation other = (Conversation) obj;
            zEquals = this.mRecipients.equals(other.mRecipients);
        } catch (ClassCastException e) {
            zEquals = false;
        }
        return zEquals;
    }

    public synchronized int hashCode() {
        return this.mRecipients.hashCode();
    }

    public synchronized String toString() {
        return String.format("[%s] (tid %d)", this.mRecipients.serialize(), Long.valueOf(this.mThreadId));
    }

    public static void asyncDeleteObsoleteThreads(AsyncQueryHandler handler, int token) {
        handler.startDelete(token, null, Telephony.Threads.OBSOLETE_THREADS_URI, null, null);
    }

    public static void startQueryForAll(AsyncQueryHandler handler, int token) {
        handler.cancelOperation(token);
        startQuery(handler, token, null);
    }

    public static void startQuery(AsyncQueryHandler handler, int token, String selection) {
        handler.cancelOperation(token);
        handler.startQuery(token, null, sAllThreadsUri, ALL_THREADS_PROJECTION, selection, null, "date DESC");
    }

    public static void startDelete(ConversationQueryHandler handler, int token, boolean deleteAll, long threadId) {
        Uri uri = ContentUris.withAppendedId(Telephony.Threads.CONTENT_URI, threadId);
        String selection = deleteAll ? null : "locked=0";
        PduCache.getInstance().purge(uri);
        handler.startDelete(token, null, uri, selection, null);
    }

    public static void startDelete(ConversationQueryHandler handler, int token, boolean deleteAll, Collection<Long> threadIds) {
        synchronized (sDeletingThreadsLock) {
            Log.v("Mms", "Conversation startDelete sDeletingThreads: " + sDeletingThreads);
            if (sDeletingThreads) {
                Log.e("Mms", "startDeleteAll already in the middle of a delete", new Exception());
            }
            MmsApp.getApplication().getPduLoaderManager().clear();
            sDeletingThreads = true;
            Iterator<Long> it = threadIds.iterator();
            while (it.hasNext()) {
                long threadId = it.next().longValue();
                Uri uri = ContentUris.withAppendedId(Telephony.Threads.CONTENT_URI, threadId);
                String selection = deleteAll ? null : "locked=0";
                handler.setDeleteToken(token);
                handler.startDelete(token, new Long(threadId), uri, selection, null);
                DraftCache.getInstance().setDraftState(threadId, false);
            }
        }
    }

    public static void startDeleteAll(ConversationQueryHandler handler, int token, boolean deleteAll) {
        synchronized (sDeletingThreadsLock) {
            Log.v("Mms", "Conversation startDeleteAll sDeletingThreads: " + sDeletingThreads);
            if (sDeletingThreads) {
                Log.e("Mms", "startDeleteAll already in the middle of a delete", new Exception());
            }
            sDeletingThreads = true;
            String selection = deleteAll ? null : "locked=0";
            MmsApp app = MmsApp.getApplication();
            app.getPduLoaderManager().clear();
            app.getThumbnailManager().clear();
            handler.setDeleteToken(token);
            handler.startDelete(token, new Long(-1L), Telephony.Threads.CONTENT_URI, selection, null);
        }
    }

    public static class ConversationQueryHandler extends AsyncQueryHandler {
        private int mDeleteToken;

        public ConversationQueryHandler(ContentResolver cr) {
            super(cr);
        }

        public void setDeleteToken(int token) {
            this.mDeleteToken = token;
        }

        @Override // android.content.AsyncQueryHandler
        protected void onDeleteComplete(int token, Object cookie, int result) {
            if (token == this.mDeleteToken) {
                synchronized (Conversation.sDeletingThreadsLock) {
                    boolean unused = Conversation.sDeletingThreads = false;
                    Log.v("Mms", "Conversation onDeleteComplete sDeletingThreads: " + Conversation.sDeletingThreads);
                    Conversation.sDeletingThreadsLock.notifyAll();
                }
            }
        }
    }

    public static void startQueryHaveLockedMessages(AsyncQueryHandler handler, Collection<Long> threadIds, int token) {
        handler.cancelOperation(token);
        Uri uri = Telephony.MmsSms.CONTENT_LOCKED_URI;
        String selection = null;
        if (threadIds != null) {
            StringBuilder buf = new StringBuilder();
            int i = 0;
            Iterator<Long> it = threadIds.iterator();
            while (it.hasNext()) {
                long threadId = it.next().longValue();
                int i2 = i + 1;
                if (i > 0) {
                    buf.append(" OR ");
                }
                buf.append(ComposeMessageActivity.THREAD_ID).append("=").append(Long.toString(threadId));
                i = i2;
            }
            selection = buf.toString();
        }
        handler.startQuery(token, threadIds, uri, ALL_THREADS_PROJECTION, selection, null, "date DESC");
    }

    public static void startQueryHaveLockedMessages(AsyncQueryHandler handler, long threadId, int token) {
        ArrayList<Long> threadIds = null;
        if (threadId != -1) {
            threadIds = new ArrayList<>();
            threadIds.add(Long.valueOf(threadId));
        }
        startQueryHaveLockedMessages(handler, threadIds, token);
    }

    private static void fillFromCursor(Context context, Conversation conv, Cursor c, boolean allowQuery) {
        synchronized (conv) {
            conv.mThreadId = c.getLong(0);
            conv.mDate = c.getLong(1);
            conv.mMessageCount = c.getInt(2);
            String snippet = MessageUtils.cleanseMmsSubject(context, MessageUtils.extractEncStrFromCursor(c, 4, 5));
            if (TextUtils.isEmpty(snippet)) {
                snippet = context.getString(R.string.no_subject_view);
            }
            conv.mSnippet = snippet;
            boolean isUnRead = c.getInt(6) == 0;
            if (isUnRead) {
                conv.mUnreadMessageCount = getUnreadSmsMessageCount(context, conv.mThreadId);
            } else {
                conv.mUnreadMessageCount = 0;
            }
            conv.setHasUnreadMessages(isUnRead);
            conv.mHasError = c.getInt(7) != 0;
            conv.mHasAttachment = c.getInt(8) != 0;
        }
        String recipientIds = c.getString(3);
        ContactList recipients = ContactList.getByIds(recipientIds, allowQuery);
        synchronized (conv) {
            conv.mRecipients = recipients;
        }
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.d("Mms", "fillFromCursor: conv=***, recipientIds=***");
            } else {
                Log.d("Mms", "fillFromCursor: conv=" + conv + ", recipientIds=" + recipientIds);
            }
        }
    }

    private static int getUnreadSmsMessageCount(Context context, long threadId) {
        int count = 0;
        Cursor cursor = context.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI, null, UNREAD_FROM_ID_SELECTION + threadId, null, null);
        if (cursor != null) {
            try {
                count = cursor.getCount();
            } finally {
                cursor.close();
            }
        }
        return count;
    }

    public synchronized int getUnreadMessageCount() {
        return this.mUnreadMessageCount;
    }

    private static class Cache {
        private static Cache sInstance = new Cache();
        private final HashSet<Conversation> mCache = new HashSet<>(10);

        static Cache getInstance() {
            return sInstance;
        }

        private Cache() {
        }

        static Conversation get(long threadId) {
            synchronized (sInstance) {
                if (Log.isLoggable("Mms", 2)) {
                    LogTag.debug("Conversation get with threadId: " + threadId, new Object[0]);
                }
                for (Conversation c : sInstance.mCache) {
                    LogTag.debug("Conversation get() threadId: " + threadId + " c.getThreadId(): " + c.getThreadId(), new Object[0]);
                    if (c.getThreadId() == threadId) {
                        return c;
                    }
                }
                return null;
            }
        }

        static Conversation get(ContactList list) {
            synchronized (sInstance) {
                if (Log.isLoggable("Mms", 2)) {
                    if (Conversation.FJ_TEL_LOG_ACQ_FLG) {
                        LogTag.debug("Conversation get with ContactList: ***", new Object[0]);
                    } else {
                        LogTag.debug("Conversation get with ContactList: " + list, new Object[0]);
                    }
                }
                for (Conversation c : sInstance.mCache) {
                    if (c.getRecipients().equals(list)) {
                        return c;
                    }
                }
                return null;
            }
        }

        static void put(Conversation c) {
            synchronized (sInstance) {
                if (Log.isLoggable("Mms", 2)) {
                    if (Conversation.FJ_TEL_LOG_ACQ_FLG) {
                        Log.d("Mms", "Conversation.Cache.put: conv= ***, hash: " + c.hashCode());
                    } else {
                        Log.d("Mms", "Conversation.Cache.put: conv= " + c + ", hash: " + c.hashCode());
                    }
                }
                if (sInstance.mCache.contains(c)) {
                    dumpCache();
                    throw new IllegalStateException("cache already contains " + c + " threadId: " + c.mThreadId);
                }
                sInstance.mCache.add(c);
            }
        }

        static boolean replace(Conversation c) {
            boolean z = false;
            synchronized (sInstance) {
                if (Log.isLoggable("Mms", 2)) {
                    if (Conversation.FJ_TEL_LOG_ACQ_FLG) {
                        LogTag.debug("Conversation.Cache.put: conv= ***, hash: " + c.hashCode(), new Object[0]);
                    } else {
                        LogTag.debug("Conversation.Cache.put: conv= " + c + ", hash: " + c.hashCode(), new Object[0]);
                    }
                }
                if (!sInstance.mCache.contains(c)) {
                    dumpCache();
                } else {
                    sInstance.mCache.remove(c);
                    sInstance.mCache.add(c);
                    z = true;
                }
            }
            return z;
        }

        static void remove(long threadId) {
            synchronized (sInstance) {
                LogTag.debug("remove threadid: " + threadId, new Object[0]);
                dumpCache();
                for (Conversation c : sInstance.mCache) {
                    if (c.getThreadId() == threadId) {
                        sInstance.mCache.remove(c);
                        return;
                    }
                }
            }
        }

        static void dumpCache() {
            synchronized (sInstance) {
                LogTag.debug("Conversation dumpCache: ", new Object[0]);
                for (Conversation c : sInstance.mCache) {
                    if (Conversation.FJ_TEL_LOG_ACQ_FLG) {
                        LogTag.debug("   conv: *** hash: " + c.hashCode(), new Object[0]);
                    } else {
                        LogTag.debug("   conv: " + c.toString() + " hash: " + c.hashCode(), new Object[0]);
                    }
                }
            }
        }

        static void keepOnly(Set<Long> threads) {
            synchronized (sInstance) {
                Iterator<Conversation> iter = sInstance.mCache.iterator();
                while (iter.hasNext()) {
                    Conversation c = iter.next();
                    if (!threads.contains(Long.valueOf(c.getThreadId()))) {
                        iter.remove();
                    }
                }
            }
            LogTag.debug("after keepOnly", new Object[0]);
            dumpCache();
        }
    }

    public static void init(final Context context) {
        Thread thread = new Thread(new Runnable() { // from class: com.android.mms.data.Conversation.2
            @Override // java.lang.Runnable
            public void run() {
                Conversation.cacheAllThreads(context);
            }
        }, "Conversation.init");
        thread.setPriority(1);
        thread.start();
    }

    public static void markAllConversationsAsSeen(final Context context) {
        Contact.logWithTrace("Mms", "Conversation.markAllConversationsAsSeen", new Object[0]);
        Thread thread = new Thread(new Runnable() { // from class: com.android.mms.data.Conversation.3
            @Override // java.lang.Runnable
            public void run() {
                Log.d("Mms", "Conversation.markAllConversationsAsSeen.run");
                Conversation.blockingMarkAllSmsMessagesAsSeen(context);
                Conversation.blockingMarkAllMmsMessagesAsSeen(context);
                MessagingNotification.blockingUpdateAllNotifications(context, -2L);
            }
        }, "Conversation.markAllConversationsAsSeen");
        thread.setPriority(1);
        thread.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void blockingMarkAllSmsMessagesAsSeen(Context context) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = resolver.query(Telephony.Sms.Inbox.CONTENT_URI, SEEN_PROJECTION, "seen=0", null, null);
        int count = 0;
        if (cursor != null) {
            try {
                count = cursor.getCount();
                cursor.close();
            } catch (Throwable th) {
                cursor.close();
                throw th;
            }
        }
        if (count != 0) {
            Log.d("Mms", "mark " + count + " SMS msgs as seen");
            ContentValues values = new ContentValues(1);
            values.put("seen", (Integer) 1);
            try {
                resolver.update(Telephony.Sms.Inbox.CONTENT_URI, values, "seen=0", null);
            } catch (SQLiteFullException e) {
                Log.e("Mms", "Database is full");
                e.printStackTrace();
                showStorageFullToast(context);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void showStorageFullToast(final Context context) {
        sToastHandler.post(new Runnable() { // from class: com.android.mms.data.Conversation.4
            @Override // java.lang.Runnable
            public void run() {
                AlertDialogFp toast = new AlertDialogFp.Builder(context).setMessage(ModeStringUtil.getModeResFromArray(context, R.array.disk_storage_full_error)).create();
                toast.setAutoDismiss(true);
                toast.getWindow().addPrivateFlags(4096);
                toast.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.android.mms.data.Conversation.4.1
                    @Override // android.content.DialogInterface.OnKeyListener
                    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                        if (keyCode != 6) {
                            return false;
                        }
                        ActivityManager mActivityManager = (ActivityManager) context.getSystemService("activity");
                        dialog.dismiss();
                        mActivityManager.goHome();
                        return true;
                    }
                });
                toast.show();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void blockingMarkAllMmsMessagesAsSeen(Context context) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = resolver.query(Telephony.Mms.Inbox.CONTENT_URI, SEEN_PROJECTION, "seen=0", null, null);
        int count = 0;
        if (cursor != null) {
            try {
                count = cursor.getCount();
                cursor.close();
            } catch (Throwable th) {
                cursor.close();
                throw th;
            }
        }
        if (count != 0) {
            Log.d("Mms", "mark " + count + " MMS msgs as seen");
            ContentValues values = new ContentValues(1);
            values.put("seen", (Integer) 1);
            try {
                resolver.update(Telephony.Mms.Inbox.CONTENT_URI, values, "seen=0", null);
            } catch (SQLiteFullException e) {
                Log.e("Mms", "Database is full");
                e.printStackTrace();
                showStorageFullToast(context);
            }
        }
    }

    public static boolean loadingThreads() {
        boolean z;
        synchronized (Cache.getInstance()) {
            z = sLoadingThreads;
        }
        return z;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void cacheAllThreads(Context context) {
        Conversation conv;
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("[Conversation] cacheAllThreads: begin", new Object[0]);
        }
        synchronized (Cache.getInstance()) {
            if (!sLoadingThreads) {
                sLoadingThreads = true;
                HashSet<Long> threadsOnDisk = new HashSet<>();
                Cursor c = context.getContentResolver().query(sAllThreadsUri, ALL_THREADS_PROJECTION, null, null, null);
                if (c != null) {
                    while (c.moveToNext()) {
                        try {
                            long threadId = c.getLong(0);
                            threadsOnDisk.add(Long.valueOf(threadId));
                            synchronized (Cache.getInstance()) {
                                conv = Cache.get(threadId);
                            }
                            if (conv == null) {
                                Conversation conv2 = new Conversation(context, c, true);
                                try {
                                    synchronized (Cache.getInstance()) {
                                        try {
                                            Cache.put(conv2);
                                        } catch (Throwable th) {
                                            throw th;
                                        }
                                    }
                                } catch (IllegalStateException e) {
                                    if (FJ_TEL_LOG_ACQ_FLG) {
                                        LogTag.error("Tried to add duplicate Conversation to Cache for threadId: " + threadId + " new conv: ***", new Object[0]);
                                    } else {
                                        LogTag.error("Tried to add duplicate Conversation to Cache for threadId: " + threadId + " new conv: " + conv2, new Object[0]);
                                    }
                                    if (!Cache.replace(conv2)) {
                                        if (FJ_TEL_LOG_ACQ_FLG) {
                                            LogTag.error("cacheAllThreads cache.replace failed on ***", new Object[0]);
                                        } else {
                                            LogTag.error("cacheAllThreads cache.replace failed on " + conv2, new Object[0]);
                                        }
                                    }
                                }
                            } else {
                                fillFromCursor(context, conv, c, true);
                            }
                        } catch (Throwable th2) {
                            if (c != null) {
                                c.close();
                            }
                            synchronized (Cache.getInstance()) {
                                sLoadingThreads = false;
                                throw th2;
                            }
                        }
                    }
                }
                if (c != null) {
                    c.close();
                }
                synchronized (Cache.getInstance()) {
                    sLoadingThreads = false;
                }
                Cache.keepOnly(threadsOnDisk);
                if (Log.isLoggable("Mms", 2)) {
                    LogTag.debug("[Conversation] cacheAllThreads: finished", new Object[0]);
                    Cache.dumpCache();
                }
            }
        }
    }

    private boolean loadFromThreadId(long threadId, boolean allowQuery) {
        Cursor c = this.mContext.getContentResolver().query(sAllThreadsUri, ALL_THREADS_PROJECTION, "_id=" + Long.toString(threadId), null, null);
        try {
            if (c.moveToFirst()) {
                fillFromCursor(this.mContext, this, c, allowQuery);
                if (threadId != this.mThreadId) {
                    LogTag.error("loadFromThreadId: fillFromCursor returned differnt thread_id! threadId=" + threadId + ", mThreadId=" + this.mThreadId, new Object[0]);
                }
                return true;
            }
            LogTag.error("loadFromThreadId: Can't find thread ID " + threadId, new Object[0]);
            return false;
        } finally {
            c.close();
        }
    }

    public static String getRecipients(Uri uri) {
        String base = uri.getSchemeSpecificPart();
        int pos = base.indexOf(63);
        return pos == -1 ? base : base.substring(0, pos);
    }

    public static void dump() {
        Cache.dumpCache();
    }

    public static void dumpThreadsTable(Context context) {
        LogTag.debug("**** Dump of threads table ****", new Object[0]);
        Cursor c = context.getContentResolver().query(sAllThreadsUri, ALL_THREADS_PROJECTION, null, null, "date ASC");
        try {
            c.moveToPosition(-1);
            while (c.moveToNext()) {
                String snippet = MessageUtils.extractEncStrFromCursor(c, 4, 5);
                Log.d("Mms", "dumpThreadsTable threadId: " + c.getLong(0) + " date : " + c.getLong(1) + " message_count : " + c.getInt(2) + " snippet : " + snippet + " read : " + c.getInt(6) + " error : " + c.getInt(7) + " has_attachment : " + c.getInt(8) + " recipient_ids : " + c.getString(3));
                ContactList recipients = ContactList.getByIds(c.getString(3), false);
                if (FJ_TEL_LOG_ACQ_FLG) {
                    Log.d("Mms", "----recipients: ***");
                } else {
                    Log.d("Mms", "----recipients: " + recipients.serialize());
                }
            }
        } finally {
            c.close();
        }
    }

    public static void dumpSmsTable(Context context) {
        LogTag.debug("**** Dump of sms table ****", new Object[0]);
        Cursor c = context.getContentResolver().query(Telephony.Sms.CONTENT_URI, SMS_PROJECTION, null, null, "_id DESC");
        try {
            c.moveToPosition(-1);
            while (c.moveToNext() && c.getPosition() < 20) {
                String body = c.getString(3);
                if (FJ_TEL_LOG_ACQ_FLG) {
                    LogTag.debug("dumpSmsTable _id: *** thread_id : *** address : *** body : *** date : " + c.getLong(4) + " type : " + c.getInt(6), new Object[0]);
                } else {
                    LogTag.debug("dumpSmsTable _id: " + c.getLong(0) + " " + ComposeMessageActivity.THREAD_ID + " : " + c.getLong(1) + " address : " + c.getString(2) + " body : " + body.substring(0, Math.min(body.length(), 8)) + " date : " + c.getLong(4) + " type : " + c.getInt(6), new Object[0]);
                }
            }
        } finally {
            c.close();
        }
    }

    public static String verifySingleRecipient(Context context, long threadId, String recipientStr) {
        if (threadId <= 0) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.error("verifySingleRecipient threadId is ZERO, recipient: ***", new Object[0]);
            } else {
                LogTag.error("verifySingleRecipient threadId is ZERO, recipient: " + recipientStr, new Object[0]);
            }
            LogTag.dumpInternalTables(context);
            return recipientStr;
        }
        Cursor c = context.getContentResolver().query(sAllThreadsUri, ALL_THREADS_PROJECTION, "_id=" + Long.toString(threadId), null, null);
        if (c == null) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.error("verifySingleRecipient threadId: " + threadId + " resulted in NULL cursor , recipient: ***", new Object[0]);
            } else {
                LogTag.error("verifySingleRecipient threadId: " + threadId + " resulted in NULL cursor , recipient: " + recipientStr, new Object[0]);
            }
            LogTag.dumpInternalTables(context);
            return recipientStr;
        }
        try {
            if (!c.moveToFirst()) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    LogTag.error("verifySingleRecipient threadId: " + threadId + " can't moveToFirst , recipient: ***", new Object[0]);
                } else {
                    LogTag.error("verifySingleRecipient threadId: " + threadId + " can't moveToFirst , recipient: " + recipientStr, new Object[0]);
                }
                LogTag.dumpInternalTables(context);
                c.close();
                return recipientStr;
            }
            String recipientIds = c.getString(3);
            c.close();
            String[] ids = recipientIds.split(" ");
            if (ids.length == 1) {
                String address = RecipientIdCache.getSingleAddressFromCanonicalAddressInDb(context, ids[0]);
                if (TextUtils.isEmpty(address)) {
                    LogTag.error("verifySingleRecipient threadId: " + threadId + " getSingleNumberFromCanonicalAddresses returned empty number for: " + ids[0] + " recipientIds: " + recipientIds, new Object[0]);
                    LogTag.dumpInternalTables(context);
                    return recipientStr;
                }
                if (!PhoneNumberUtils.compareLoosely(recipientStr, address)) {
                    if (context instanceof Activity) {
                        if (FJ_TEL_LOG_ACQ_FLG) {
                            LogTag.warnPossibleRecipientMismatch("verifySingleRecipient for threadId: " + threadId + " original recipient: *** recipient from DB: ***", (Activity) context);
                        } else {
                            LogTag.warnPossibleRecipientMismatch("verifySingleRecipient for threadId: " + threadId + " original recipient: " + recipientStr + " recipient from DB: " + address, (Activity) context);
                        }
                    }
                    LogTag.dumpInternalTables(context);
                    if (Log.isLoggable("Mms", 2)) {
                        if (FJ_TEL_LOG_ACQ_FLG) {
                            LogTag.debug("verifySingleRecipient for threadId: " + threadId + " original recipient: *** recipient from DB: ***", new Object[0]);
                        } else {
                            LogTag.debug("verifySingleRecipient for threadId: " + threadId + " original recipient: " + recipientStr + " recipient from DB: " + address, new Object[0]);
                        }
                    }
                    return address;
                }
                return recipientStr;
            }
            return recipientStr;
        } catch (Throwable th) {
            c.close();
            throw th;
        }
    }

    public boolean getHasMmsForward() {
        return this.mHasMmsForward;
    }

    public void setHasMmsForward(boolean value) {
        this.mHasMmsForward = value;
    }

    public String getForwardRecipientNumber() {
        return this.mForwardRecipientNumber;
    }

    public void setForwardRecipientNumber(String forwardRecipientNumber) {
        this.mForwardRecipientNumber = forwardRecipientNumber;
    }
}
