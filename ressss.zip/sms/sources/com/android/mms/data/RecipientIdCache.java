package com.android.mms.data;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.SystemProperties;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.LogTag;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.concurrent.GuardedBy;
import javax.annotation.concurrent.ThreadSafe;

/* JADX INFO: loaded from: classes.dex */
@ThreadSafe
public class RecipientIdCache {
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final boolean LOCAL_DEBUG = false;
    private static final String TAG = "Mms";
    private static Uri sAllCanonical;
    private static RecipientIdCache sInstance;
    private static Uri sSingleCanonicalAddressUri;

    @GuardedBy("this")
    private final Map<Long, String> mCache = new HashMap();
    private final Context mContext;

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
        sAllCanonical = Uri.parse("content://mms-sms/canonical-addresses");
        sSingleCanonicalAddressUri = Uri.parse("content://mms-sms/canonical-address");
    }

    static RecipientIdCache getInstance() {
        return sInstance;
    }

    public static class Entry {
        public long id;
        public String number;

        public Entry(long id, String number) {
            this.id = id;
            this.number = number;
        }
    }

    static void init(Context context) {
        sInstance = new RecipientIdCache(context);
        new Thread(new Runnable() { // from class: com.android.mms.data.RecipientIdCache.1
            @Override // java.lang.Runnable
            public void run() {
                RecipientIdCache.fill();
            }
        }, "RecipientIdCache.init").start();
    }

    RecipientIdCache(Context context) {
        this.mContext = context;
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x005a */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void fill() {
        /*
            r12 = 2
            r11 = 0
            r3 = 0
            java.lang.String r1 = "Mms"
            boolean r1 = android.util.Log.isLoggable(r1, r12)
            if (r1 == 0) goto L12
            java.lang.String r1 = "[RecipientIdCache] fill: begin"
            java.lang.Object[] r2 = new java.lang.Object[r11]
            com.android.mms.LogTag.debug(r1, r2)
        L12:
            com.android.mms.data.RecipientIdCache r1 = com.android.mms.data.RecipientIdCache.sInstance
            android.content.Context r0 = r1.mContext
            android.content.ContentResolver r1 = r0.getContentResolver()
            android.net.Uri r2 = com.android.mms.data.RecipientIdCache.sAllCanonical
            r4 = r3
            r5 = r3
            r6 = r3
            android.database.Cursor r7 = android.database.sqlite.SqliteWrapper.query(r0, r1, r2, r3, r4, r5, r6)
            if (r7 != 0) goto L2d
            java.lang.String r1 = "Mms"
            java.lang.String r2 = "null Cursor in fill()"
            android.util.Log.w(r1, r2)
        L2c:
            return
        L2d:
            com.android.mms.data.RecipientIdCache r2 = com.android.mms.data.RecipientIdCache.sInstance     // Catch: java.lang.Throwable -> L5a
            monitor-enter(r2)     // Catch: java.lang.Throwable -> L5a
            com.android.mms.data.RecipientIdCache r1 = com.android.mms.data.RecipientIdCache.sInstance     // Catch: java.lang.Throwable -> L57
            java.util.Map<java.lang.Long, java.lang.String> r1 = r1.mCache     // Catch: java.lang.Throwable -> L57
            r1.clear()     // Catch: java.lang.Throwable -> L57
        L37:
            boolean r1 = r7.moveToNext()     // Catch: java.lang.Throwable -> L57
            if (r1 == 0) goto L5f
            r1 = 0
            long r8 = r7.getLong(r1)     // Catch: java.lang.Throwable -> L57
            r1 = 1
            java.lang.String r10 = r7.getString(r1)     // Catch: java.lang.Throwable -> L57
            java.lang.String r10 = android.telephony.SmsMessage.getDispOriginatingAddress(r10)     // Catch: java.lang.Throwable -> L57
            com.android.mms.data.RecipientIdCache r1 = com.android.mms.data.RecipientIdCache.sInstance     // Catch: java.lang.Throwable -> L57
            java.util.Map<java.lang.Long, java.lang.String> r1 = r1.mCache     // Catch: java.lang.Throwable -> L57
            java.lang.Long r3 = java.lang.Long.valueOf(r8)     // Catch: java.lang.Throwable -> L57
            r1.put(r3, r10)     // Catch: java.lang.Throwable -> L57
            goto L37
        L57:
            r1 = move-exception
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L57
            throw r1     // Catch: java.lang.Throwable -> L5a
        L5a:
            r1 = move-exception
            r7.close()
            throw r1
        L5f:
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L57
            r7.close()
            java.lang.String r1 = "Mms"
            boolean r1 = android.util.Log.isLoggable(r1, r12)
            if (r1 == 0) goto L2c
            java.lang.String r1 = "[RecipientIdCache] fill: finished"
            java.lang.Object[] r2 = new java.lang.Object[r11]
            com.android.mms.LogTag.debug(r1, r2)
            dump()
            goto L2c
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.mms.data.RecipientIdCache.fill():void");
    }

    public static List<Entry> getAddresses(String spaceSepIds) {
        List<Entry> numbers;
        synchronized (sInstance) {
            numbers = new ArrayList<>();
            String[] ids = spaceSepIds.split(" ");
            for (String id : ids) {
                try {
                    long longId = Long.parseLong(id);
                    String number = sInstance.mCache.get(Long.valueOf(longId));
                    if (number == null) {
                        Log.w("Mms", "RecipientId " + longId + " not in cache!");
                        if (Log.isLoggable("Mms", 2)) {
                            dump();
                        }
                        fill();
                        number = sInstance.mCache.get(Long.valueOf(longId));
                    }
                    if (TextUtils.isEmpty(number)) {
                        Log.w("Mms", "RecipientId " + longId + " has empty number!");
                    } else {
                        numbers.add(new Entry(longId, number));
                    }
                } catch (NumberFormatException e) {
                }
            }
        }
        return numbers;
    }

    public static void updateNumbers(long threadId, ContactList contacts) {
        for (Contact contact : contacts) {
            if (contact.isNumberModified()) {
                contact.setIsNumberModified(false);
                long recipientId = contact.getRecipientId();
                if (recipientId != 0) {
                    String number1 = contact.getNumber();
                    boolean needsDbUpdate = false;
                    synchronized (sInstance) {
                        String number2 = sInstance.mCache.get(Long.valueOf(recipientId));
                        if (Log.isLoggable("Mms", 2)) {
                            if (FJ_TEL_LOG_ACQ_FLG) {
                                Log.d("Mms", "[RecipientIdCache] updateNumbers: contact=***, wasModified=true, recipientId=***");
                                Log.d("Mms", "   contact.getNumber=***, sInstance.mCache.get(recipientId)=***");
                            } else {
                                Log.d("Mms", "[RecipientIdCache] updateNumbers: contact=" + contact + ", wasModified=true, recipientId=" + recipientId);
                                Log.d("Mms", "   contact.getNumber=" + number1 + ", sInstance.mCache.get(recipientId)=" + number2);
                            }
                        }
                        if (!number1.equalsIgnoreCase(number2)) {
                            sInstance.mCache.put(Long.valueOf(recipientId), number1);
                            needsDbUpdate = true;
                        }
                    }
                    if (needsDbUpdate) {
                        sInstance.updateCanonicalAddressInDb(recipientId, number1);
                    }
                } else {
                    continue;
                }
            }
        }
    }

    /* JADX WARN: Type inference failed for: r0v8, types: [com.android.mms.data.RecipientIdCache$2] */
    private void updateCanonicalAddressInDb(long id, String number) {
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.d("Mms", "[RecipientIdCache] updateCanonicalAddressInDb: id=" + id + ", number=***");
            } else {
                Log.d("Mms", "[RecipientIdCache] updateCanonicalAddressInDb: id=" + id + ", number=" + number);
            }
        }
        final ContentValues values = new ContentValues();
        values.put("address", number);
        final StringBuilder buf = new StringBuilder("_id");
        buf.append('=').append(id);
        final Uri uri = ContentUris.withAppendedId(sSingleCanonicalAddressUri, id);
        final ContentResolver cr = this.mContext.getContentResolver();
        new Thread("updateCanonicalAddressInDb") { // from class: com.android.mms.data.RecipientIdCache.2
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                cr.update(uri, values, buf.toString(), null);
            }
        }.start();
    }

    public static void dump() {
        synchronized (sInstance) {
            Log.d("Mms", "*** Recipient ID cache dump ***");
            for (Long id : sInstance.mCache.keySet()) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    Log.d("Mms", id + ": ***");
                } else {
                    Log.d("Mms", id + ": " + sInstance.mCache.get(id));
                }
            }
        }
    }

    public static void canonicalTableDump() {
        Log.d("Mms", "**** Dump of canoncial_addresses table ****");
        Context context = sInstance.mContext;
        Cursor c = SqliteWrapper.query(context, context.getContentResolver(), sAllCanonical, (String[]) null, (String) null, (String[]) null, (String) null);
        if (c == null) {
            Log.w("Mms", "null Cursor in content://mms-sms/canonical-addresses");
        }
        while (c.moveToNext()) {
            try {
                long id = c.getLong(0);
                String number = c.getString(1);
                if (FJ_TEL_LOG_ACQ_FLG) {
                    Log.d("Mms", "id: " + id + " number: ***");
                } else {
                    Log.d("Mms", "id: " + id + " number: " + number);
                }
            } catch (Throwable th) {
                c.close();
                throw th;
            }
        }
        c.close();
    }

    public static String getSingleAddressFromCanonicalAddressInDb(Context context, String recipientId) {
        Cursor c = SqliteWrapper.query(context, context.getContentResolver(), ContentUris.withAppendedId(sSingleCanonicalAddressUri, Long.parseLong(recipientId)), (String[]) null, (String) null, (String[]) null, (String) null);
        if (c == null) {
            LogTag.warn("Mms", "null Cursor looking up recipient: " + recipientId);
            return null;
        }
        try {
            if (!c.moveToFirst()) {
                return null;
            }
            String number = c.getString(0);
            return number;
        } finally {
            c.close();
        }
    }

    /* JADX WARN: Type inference failed for: r2v3, types: [com.android.mms.data.RecipientIdCache$3] */
    public static void insertCanonicalAddressInDb(Context context, String number) {
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.d("Mms", "[RecipientIdCache] insertCanonicalAddressInDb: number=***");
            } else {
                Log.d("Mms", "[RecipientIdCache] insertCanonicalAddressInDb: number=" + number);
            }
        }
        final ContentValues values = new ContentValues();
        values.put("address", number);
        final ContentResolver cr = context.getContentResolver();
        new Thread("insertCanonicalAddressInDb") { // from class: com.android.mms.data.RecipientIdCache.3
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                cr.insert(RecipientIdCache.sAllCanonical, values);
            }
        }.start();
    }
}
