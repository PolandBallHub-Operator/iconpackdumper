package com.android.mms.data;

import android.content.ContentUris;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.os.SystemProperties;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import com.android.common.speech.LoggingEvents;
import com.android.mms.MmsApp;
import com.android.mms.R;
import com.android.mms.ui.MessageUtils;
import java.io.IOException;
import java.io.InputStream;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;

/* JADX INFO: loaded from: classes.dex */
public class Contact {
    private static final int CONTACT_CHANGED = 0;
    private static final Uri CONTACT_DATA_URI = Uri.parse("content://com.android.contacts/data");
    private static final int CONTACT_METHOD_ID_UNKNOWN = -1;
    public static final int CONTACT_METHOD_TYPE_EMAIL = 2;
    public static final int CONTACT_METHOD_TYPE_PHONE = 1;
    public static final int CONTACT_METHOD_TYPE_SELF = 3;
    public static final int CONTACT_METHOD_TYPE_UNKNOWN = 0;
    public static final String CONTENT_SCHEME = "content";
    private static final int ELAPSE_TIME = 3000;
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    public static final String SELF_ITEM_KEY = "Self_Item_Key";
    private static final String TAG = "Mms";
    public static final String TEL_SCHEME = "tel";
    private static Handler mHandler;
    private static final HashSet<UpdateListener> mListeners;
    private static final ContentObserver sCallLogObserver;
    private static ContactsCache sContactCache;
    private static final ContentObserver sContactsObserver;
    private static final ContentObserver sPresenceObserver;
    private BitmapDrawable mAvatar;
    private byte[] mAvatarData;
    private long mContactMethodId;
    private int mContactMethodType;
    private boolean mIsMe;
    private boolean mIsStale;
    private String mLabel;
    private String mName;
    private String mNameAndNumber;
    private String mNumber;
    private String mNumberE164;
    private boolean mNumberIsModified;
    private Uri mPeopleReferenceUri;
    private long mPersonId;
    private String mPhoneticName;
    private int mPresenceResId;
    private String mPresenceText;
    private boolean mQueryPending;
    private long mRecipientId;
    private boolean mSendToVoicemail;

    public interface UpdateListener {
        void onUpdate(Contact contact);
    }

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
        sPresenceObserver = new ContentObserver(new Handler()) { // from class: com.android.mms.data.Contact.1
            @Override // android.database.ContentObserver
            public void onChange(boolean selfUpdate) {
                if (Log.isLoggable("Mms", 2)) {
                    Contact.log("presence changed, invalidate cache");
                }
                Contact.invalidateCache();
            }
        };
        sCallLogObserver = new ContentObserver(new Handler()) { // from class: com.android.mms.data.Contact.2
            @Override // android.database.ContentObserver
            public void onChange(boolean selfUpdate) {
                Contact.mHandler.removeMessages(0);
            }
        };
        sContactsObserver = new ContentObserver(new Handler()) { // from class: com.android.mms.data.Contact.3
            @Override // android.database.ContentObserver
            public void onChange(boolean selfUpdate) {
                if (Log.isLoggable("Mms", 2)) {
                    Contact.log("contacts changed, invalidate cache");
                }
                Contact.mHandler.removeMessages(0);
                Contact.mHandler.sendEmptyMessageDelayed(0, 3000L);
            }
        };
        mHandler = new Handler() { // from class: com.android.mms.data.Contact.4
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        Contact.invalidateCache();
                        break;
                }
            }
        };
        mListeners = new HashSet<>();
    }

    private Contact(String number, String name) {
        init(number, name);
    }

    private Contact(String number) {
        init(number, LoggingEvents.EXTRA_CALLING_APP_NAME);
    }

    private Contact(boolean isMe) {
        init(SELF_ITEM_KEY, LoggingEvents.EXTRA_CALLING_APP_NAME);
        this.mIsMe = isMe;
    }

    private void init(String number, String name) {
        this.mContactMethodId = -1L;
        this.mName = name;
        this.mPhoneticName = LoggingEvents.EXTRA_CALLING_APP_NAME;
        setNumber(number);
        this.mNumberIsModified = false;
        this.mLabel = LoggingEvents.EXTRA_CALLING_APP_NAME;
        this.mPersonId = 0L;
        this.mPresenceResId = 0;
        this.mIsStale = true;
        this.mSendToVoicemail = false;
    }

    public String toString() {
        Object[] objArr = new Object[7];
        objArr[0] = this.mNumber != null ? this.mNumber : "null";
        objArr[1] = this.mName != null ? this.mName : "null";
        objArr[2] = this.mNameAndNumber != null ? this.mNameAndNumber : "null";
        objArr[3] = this.mLabel != null ? this.mLabel : "null";
        objArr[4] = Long.valueOf(this.mPersonId);
        objArr[5] = Integer.valueOf(hashCode());
        objArr[6] = Long.valueOf(this.mContactMethodId);
        return String.format("{ number=%s, name=%s, nameAndNumber=%s, label=%s, person_id=%d, hash=%d method_id=%d }", objArr);
    }

    public static void logWithTrace(String tag, String msg, Object... format) {
        Thread current = Thread.currentThread();
        StackTraceElement[] stack = current.getStackTrace();
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        sb.append(current.getId());
        sb.append("] ");
        sb.append(String.format(msg, format));
        sb.append(" <- ");
        int stop = stack.length <= 7 ? stack.length : 7;
        for (int i = 3; i < stop; i++) {
            String methodName = stack[i].getMethodName();
            sb.append(methodName);
            if (i + 1 != stop) {
                sb.append(" <- ");
            }
        }
        Log.d(tag, sb.toString());
    }

    public static Contact get(String number, boolean canBlock) {
        return sContactCache.get(number, canBlock);
    }

    public static Contact getMe(boolean canBlock) {
        return sContactCache.getMe(canBlock);
    }

    public void removeFromCache() {
        sContactCache.remove(this);
    }

    public static List<Contact> getByPhoneUris(Parcelable[] uris) {
        return sContactCache.getContactInfoForPhoneUris(uris);
    }

    public static void invalidateCache() {
        if (Log.isLoggable("Mms", 2)) {
            log("invalidateCache");
        }
        sContactCache.invalidate();
    }

    public boolean isMe() {
        return this.mIsMe;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String emptyIfNull(String s) {
        return s != null ? s : LoggingEvents.EXTRA_CALLING_APP_NAME;
    }

    public static String formatNameAndNumber(String name, String number, String numberE164) {
        String formattedNumber = number;
        if (!Telephony.Mms.isEmailAddress(number)) {
            formattedNumber = PhoneNumberUtils.formatNumber(number, numberE164, MmsApp.getApplication().getCurrentCountryIso());
        }
        if (!TextUtils.isEmpty(name) && !name.equals(number)) {
            return name + " <" + formattedNumber + ">";
        }
        return formattedNumber;
    }

    public synchronized void reload() {
        this.mIsStale = true;
        sContactCache.get(this.mNumber, false);
    }

    public synchronized void blockReload() {
        this.mIsStale = true;
        sContactCache.get(this.mNumber, true);
    }

    public synchronized String getNumber() {
        return this.mNumber;
    }

    public synchronized void setNumber(String number) {
        if (!Telephony.Mms.isEmailAddress(number)) {
            this.mNumber = PhoneNumberUtils.formatNumber(number, this.mNumberE164, MmsApp.getApplication().getCurrentCountryIso());
        } else {
            this.mNumber = number;
        }
        notSynchronizedUpdateNameAndNumber();
        this.mNumberIsModified = true;
    }

    public boolean isNumberModified() {
        return this.mNumberIsModified;
    }

    public boolean getSendToVoicemail() {
        return this.mSendToVoicemail;
    }

    public void setIsNumberModified(boolean flag) {
        this.mNumberIsModified = flag;
    }

    public synchronized String getName() {
        return TextUtils.isEmpty(this.mName) ? this.mNumber : this.mName;
    }

    public boolean isNotExistName() {
        if (!TextUtils.isEmpty(this.mName)) {
            return false;
        }
        Matcher match = Patterns.PHONE.matcher(this.mNumber);
        return match.matches();
    }

    public synchronized boolean isName() {
        return !TextUtils.isEmpty(this.mName);
    }

    public synchronized String getPhoneticName() {
        return TextUtils.isEmpty(this.mPhoneticName) ? getName() : this.mPhoneticName;
    }

    public synchronized boolean isPhoneticName() {
        return !TextUtils.isEmpty(this.mPhoneticName);
    }

    public synchronized String getNameAndNumber() {
        return this.mNameAndNumber;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notSynchronizedUpdateNameAndNumber() {
        this.mNameAndNumber = formatNameAndNumber(this.mName, this.mNumber, this.mNumberE164);
    }

    public synchronized long getRecipientId() {
        return this.mRecipientId;
    }

    public synchronized void setRecipientId(long id) {
        this.mRecipientId = id;
    }

    public synchronized String getLabel() {
        return this.mLabel;
    }

    public synchronized Uri getUri() {
        return ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, this.mPersonId);
    }

    public synchronized int getPresenceResId() {
        return this.mPresenceResId;
    }

    public synchronized boolean existsInDatabase() {
        return this.mPersonId > 0;
    }

    public static void addListener(UpdateListener l) {
        synchronized (mListeners) {
            mListeners.add(l);
        }
    }

    public static void removeListener(UpdateListener l) {
        synchronized (mListeners) {
            mListeners.remove(l);
        }
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x005d */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x005e, code lost:
    
        r4 = th;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void dumpListeners() throws java.lang.Throwable {
        /*
            java.util.HashSet<com.android.mms.data.Contact$UpdateListener> r5 = com.android.mms.data.Contact.mListeners
            monitor-enter(r5)
            r0 = 0
            java.lang.String r4 = "Mms"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L5d
            r6.<init>()     // Catch: java.lang.Throwable -> L5d
            java.lang.String r7 = "[Contact] dumpListeners; size="
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> L5d
            java.util.HashSet<com.android.mms.data.Contact$UpdateListener> r7 = com.android.mms.data.Contact.mListeners     // Catch: java.lang.Throwable -> L5d
            int r7 = r7.size()     // Catch: java.lang.Throwable -> L5d
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> L5d
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L5d
            android.util.Log.i(r4, r6)     // Catch: java.lang.Throwable -> L5d
            java.util.HashSet<com.android.mms.data.Contact$UpdateListener> r4 = com.android.mms.data.Contact.mListeners     // Catch: java.lang.Throwable -> L5d
            java.util.Iterator r2 = r4.iterator()     // Catch: java.lang.Throwable -> L5d
            r1 = r0
        L29:
            boolean r4 = r2.hasNext()     // Catch: java.lang.Throwable -> L60
            if (r4 == 0) goto L5b
            java.lang.Object r3 = r2.next()     // Catch: java.lang.Throwable -> L60
            com.android.mms.data.Contact$UpdateListener r3 = (com.android.mms.data.Contact.UpdateListener) r3     // Catch: java.lang.Throwable -> L60
            java.lang.String r4 = "Mms"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L60
            r6.<init>()     // Catch: java.lang.Throwable -> L60
            java.lang.String r7 = "["
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> L60
            int r0 = r1 + 1
            java.lang.StringBuilder r6 = r6.append(r1)     // Catch: java.lang.Throwable -> L5d
            java.lang.String r7 = "]"
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch: java.lang.Throwable -> L5d
            java.lang.StringBuilder r6 = r6.append(r3)     // Catch: java.lang.Throwable -> L5d
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L5d
            android.util.Log.i(r4, r6)     // Catch: java.lang.Throwable -> L5d
            r1 = r0
            goto L29
        L5b:
            monitor-exit(r5)     // Catch: java.lang.Throwable -> L60
            return
        L5d:
            r4 = move-exception
        L5e:
            monitor-exit(r5)     // Catch: java.lang.Throwable -> L5d
            throw r4
        L60:
            r4 = move-exception
            r0 = r1
            goto L5e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.mms.data.Contact.dumpListeners():void");
    }

    public synchronized boolean isEmail() {
        return Telephony.Mms.isEmailAddress(this.mNumber);
    }

    public String getPresenceText() {
        return this.mPresenceText;
    }

    public int getContactMethodType() {
        return this.mContactMethodType;
    }

    public Uri getPeopleReferenceUri() {
        return this.mPeopleReferenceUri;
    }

    public long getContactMethodId() {
        return this.mContactMethodId;
    }

    public synchronized Uri getPhoneUri() {
        Uri uriBuild;
        if (existsInDatabase()) {
            uriBuild = ContentUris.withAppendedId(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, this.mContactMethodId);
        } else {
            Uri.Builder ub = new Uri.Builder();
            ub.scheme(TEL_SCHEME);
            ub.encodedOpaquePart(this.mNumber);
            uriBuild = ub.build();
        }
        return uriBuild;
    }

    public synchronized Drawable getAvatar(Context context, Drawable defaultValue) {
        if (this.mAvatar == null && this.mAvatarData != null) {
            Bitmap b = BitmapFactory.decodeByteArray(this.mAvatarData, 0, this.mAvatarData.length);
            this.mAvatar = new BitmapDrawable(context.getResources(), b);
        }
        if (this.mAvatar != null) {
            defaultValue = this.mAvatar;
        }
        return defaultValue;
    }

    public static void init(Context context) {
        if (sContactCache != null) {
            sContactCache.mTaskQueue.mWorkerThread.interrupt();
        }
        sContactCache = new ContactsCache(context);
        RecipientIdCache.init(context);
        registerDataBasesObserver(context);
    }

    public static void recipientIdCacheInit(Context context) {
        RecipientIdCache.init(context);
    }

    public static void dump() {
        sContactCache.dump();
    }

    private static class ContactsCache {
        private static final String CALLER_ID_SELECTION = " Data._ID IN  (SELECT DISTINCT lookup.data_id  FROM  (SELECT data_id, normalized_number, length(normalized_number) as len  FROM phone_lookup  WHERE min_match = ?) AS lookup  WHERE lookup.normalized_number = ? OR lookup.normalized_number = ? OR  (lookup.len <= ? AND  substr(?, ? - lookup.len + 1) = lookup.normalized_number))";
        private static final String CALLER_ID_SELECTION_WITHOUT_E164 = " Data._ID IN  (SELECT DISTINCT lookup.data_id  FROM  (SELECT data_id, normalized_number, length(normalized_number) as len  FROM phone_lookup  WHERE min_match = ?) AS lookup  WHERE  (lookup.len <= ? AND  substr(?, ? - lookup.len + 1) = lookup.normalized_number))";
        private static final int CONTACT_ID_COLUMN = 4;
        private static final int CONTACT_NAME_COLUMN = 3;
        private static final int CONTACT_PHONETIC_NAME_COLUMN = 9;
        private static final int CONTACT_PRESENCE_COLUMN = 5;
        private static final int CONTACT_STATUS_COLUMN = 6;
        private static final int EMAIL_CONTACT_ID_COLUMN = 3;
        private static final int EMAIL_CONTACT_NAME_COLUMN = 4;
        private static final int EMAIL_ID_COLUMN = 0;
        private static final int EMAIL_NAME_COLUMN = 1;
        private static final int EMAIL_PHONETIC_NAME_COLUMN = 6;
        private static final String EMAIL_SELECTION = "UPPER(data1)=UPPER(?) AND mimetype='vnd.android.cursor.item/email_v2'";
        private static final int EMAIL_SEND_TO_VOICEMAIL_COLUMN = 5;
        private static final int EMAIL_STATUS_COLUMN = 2;
        private static final int PHONE_ID_COLUMN = 0;
        private static final int PHONE_LABEL_COLUMN = 2;
        private static final int PHONE_NORMALIZED_NUMBER = 7;
        private static final int PHONE_NUMBER_COLUMN = 1;
        private static final int SELF_ID_COLUMN = 0;
        private static final int SELF_NAME_COLUMN = 1;
        private static final int SEND_TO_VOICEMAIL = 8;
        private static final String SEPARATOR = ";";
        static final int STATIC_KEY_BUFFER_MAXIMUM_LENGTH = 5;
        private final HashMap<String, ArrayList<Contact>> mContactsHash;
        private final Context mContext;
        private final TaskStack mTaskQueue;
        private static final Uri PHONES_WITH_PRESENCE_URI = ContactsContract.Data.CONTENT_URI;
        private static final String[] CALLER_ID_PROJECTION = {"_id", "data1", "data3", "display_name", "contact_id", "contact_presence", "contact_status", "data4", "send_to_voicemail", "phonetic_name"};
        private static final String[] SELF_PROJECTION = {"_id", "display_name"};
        private static final Uri EMAIL_WITH_PRESENCE_URI = ContactsContract.Data.CONTENT_URI;
        private static final String[] EMAIL_PROJECTION = {"_id", "data4", "contact_presence", "contact_id", "display_name", "send_to_voicemail", "phonetic_name"};
        static CharBuffer sStaticKeyBuffer = CharBuffer.allocate(5);

        private ContactsCache(Context context) {
            this.mTaskQueue = new TaskStack();
            this.mContactsHash = new HashMap<>();
            this.mContext = context;
        }

        void dump() {
            synchronized (this) {
                Log.d("Mms", "**** Contact cache dump ****");
                for (String key : this.mContactsHash.keySet()) {
                    ArrayList<Contact> alc = this.mContactsHash.get(key);
                    for (Contact c : alc) {
                        if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                            Log.d("Mms", key + " ==> ***");
                        } else {
                            Log.d("Mms", key + " ==> " + c.toString());
                        }
                    }
                }
            }
        }

        private static class TaskStack {
            private final ArrayList<Runnable> mThingsToLoad = new ArrayList<>();
            Thread mWorkerThread = new Thread(new Runnable() { // from class: com.android.mms.data.Contact.ContactsCache.TaskStack.1
                @Override // java.lang.Runnable
                public void run() {
                    while (true) {
                        Runnable r = null;
                        synchronized (TaskStack.this.mThingsToLoad) {
                            if (TaskStack.this.mThingsToLoad.size() == 0) {
                                try {
                                    TaskStack.this.mThingsToLoad.wait();
                                } catch (InterruptedException e) {
                                    return;
                                }
                            }
                            if (TaskStack.this.mThingsToLoad.size() > 0) {
                                r = (Runnable) TaskStack.this.mThingsToLoad.remove(0);
                            }
                        }
                        if (r != null) {
                            r.run();
                        }
                    }
                }
            }, "Contact.ContactsCache.TaskStack worker thread");

            public TaskStack() {
                this.mWorkerThread.setPriority(1);
                this.mWorkerThread.start();
            }

            public void push(Runnable r) {
                synchronized (this.mThingsToLoad) {
                    this.mThingsToLoad.add(r);
                    this.mThingsToLoad.notify();
                }
            }
        }

        public void pushTask(Runnable r) {
            this.mTaskQueue.push(r);
        }

        public Contact getMe(boolean canBlock) {
            return get(Contact.SELF_ITEM_KEY, true, canBlock);
        }

        public Contact get(String number, boolean canBlock) {
            return get(number, false, canBlock);
        }

        private Contact get(String number, boolean isMe, boolean canBlock) throws Throwable {
            Throwable th;
            if (Log.isLoggable("Mms", 3)) {
                if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                    Contact.logWithTrace("Mms", "get(%s, %s, %s)", "***", Boolean.valueOf(isMe), Boolean.valueOf(canBlock));
                } else {
                    Contact.logWithTrace("Mms", "get(%s, %s, %s)", number, Boolean.valueOf(isMe), Boolean.valueOf(canBlock));
                }
            }
            if (TextUtils.isEmpty(number)) {
                number = LoggingEvents.EXTRA_CALLING_APP_NAME;
            }
            final Contact contact = internalGet(number, isMe);
            Runnable r = null;
            synchronized (contact) {
                while (canBlock) {
                    try {
                        if (!contact.mQueryPending) {
                            break;
                        }
                        try {
                            contact.wait();
                        } catch (InterruptedException e) {
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        throw th;
                    }
                }
                if (contact.mIsStale && !contact.mQueryPending) {
                    contact.mIsStale = false;
                    if (Log.isLoggable("Mms", 2)) {
                        if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                            Contact.log("async update for *** canBlock: " + canBlock + " isStale: " + contact.mIsStale);
                        } else {
                            Contact.log("async update for " + contact.toString() + " canBlock: " + canBlock + " isStale: " + contact.mIsStale);
                        }
                    }
                    Runnable r2 = new Runnable() { // from class: com.android.mms.data.Contact.ContactsCache.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ContactsCache.this.updateContact(contact);
                        }
                    };
                    try {
                        contact.mQueryPending = true;
                        r = r2;
                    } catch (Throwable th3) {
                        th = th3;
                        throw th;
                    }
                }
                if (r != null) {
                    if (canBlock) {
                        r.run();
                    } else {
                        pushTask(r);
                    }
                }
                return contact;
            }
        }

        public List<Contact> getContactInfoForPhoneUris(Parcelable[] uris) {
            if (uris.length == 0) {
                return null;
            }
            StringBuilder idSetBuilder = new StringBuilder();
            boolean first = true;
            for (Parcelable p : uris) {
                Uri uri = (Uri) p;
                if (Contact.CONTENT_SCHEME.equals(uri.getScheme())) {
                    if (first) {
                        first = false;
                        idSetBuilder.append(uri.getLastPathSegment());
                    } else {
                        idSetBuilder.append(',').append(uri.getLastPathSegment());
                    }
                }
            }
            if (first) {
                return null;
            }
            Cursor cursor = null;
            if (idSetBuilder.length() > 0) {
                String whereClause = "_id IN (" + idSetBuilder.toString() + ")";
                cursor = this.mContext.getContentResolver().query(PHONES_WITH_PRESENCE_URI, CALLER_ID_PROJECTION, whereClause, null, null);
            }
            if (cursor == null) {
                return null;
            }
            List<Contact> entries = new ArrayList<>();
            while (cursor.moveToNext()) {
                try {
                    Contact entry = new Contact(cursor.getString(1), cursor.getString(3));
                    fillPhoneTypeContact(entry, cursor);
                    ArrayList<Contact> value = new ArrayList<>();
                    value.add(entry);
                    this.mContactsHash.put(key(entry.mNumber, sStaticKeyBuffer), value);
                    entries.add(entry);
                } catch (Throwable th) {
                    cursor.close();
                    throw th;
                }
            }
            cursor.close();
            return entries;
        }

        private boolean contactChanged(Contact orig, Contact newContactData) {
            if (orig.mContactMethodType != newContactData.mContactMethodType || orig.mContactMethodId != newContactData.mContactMethodId) {
                return true;
            }
            if (orig.mPersonId == newContactData.mPersonId) {
                if (orig.mPresenceResId == newContactData.mPresenceResId) {
                    if (orig.mSendToVoicemail == newContactData.mSendToVoicemail) {
                        String oldName = Contact.emptyIfNull(orig.mName);
                        String newName = Contact.emptyIfNull(newContactData.mName);
                        if (oldName.equals(newName)) {
                            String oldPhoneticName = Contact.emptyIfNull(orig.mPhoneticName);
                            String newPhoneticName = Contact.emptyIfNull(newContactData.mPhoneticName);
                            if (oldPhoneticName.equals(newPhoneticName)) {
                                String oldLabel = Contact.emptyIfNull(orig.mLabel);
                                String newLabel = Contact.emptyIfNull(newContactData.mLabel);
                                if (oldLabel.equals(newLabel)) {
                                    if (!Arrays.equals(orig.mAvatarData, newContactData.mAvatarData)) {
                                        if (Log.isLoggable("Mms", 3)) {
                                            Log.d("Mms", "avatar changed");
                                        }
                                        return true;
                                    }
                                    return false;
                                }
                                if (Log.isLoggable("Mms", 3)) {
                                    Log.d("Mms", String.format("label changed: %s -> %s", oldLabel, newLabel));
                                }
                                return true;
                            }
                            if (Log.isLoggable("Mms", 3)) {
                                Log.d("Mms", String.format("PhoneticName changed", new Object[0]));
                            }
                            return true;
                        }
                        if (Log.isLoggable("Mms", 3)) {
                            if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                                Log.d("Mms", String.format("name changed: %s -> %s", "***", "***"));
                            } else {
                                Log.d("Mms", String.format("name changed: %s -> %s", oldName, newName));
                            }
                        }
                        return true;
                    }
                    return true;
                }
                if (Log.isLoggable("Mms", 3)) {
                    Log.d("Mms", "presence changed");
                }
                return true;
            }
            if (Log.isLoggable("Mms", 3)) {
                Log.d("Mms", "person id changed");
            }
            return true;
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX WARN: Code duplicated, block: B:34:0x00f8 A[Catch: all -> 0x00d6, TRY_LEAVE, TryCatch #2 {, blocks: (B:6:0x0008, B:8:0x000e, B:10:0x0017, B:12:0x001d, B:29:0x00d9, B:13:0x0022, B:15:0x0091, B:16:0x0095, B:19:0x00a1, B:20:0x00a5, B:22:0x00ab, B:24:0x00ba, B:25:0x00d2, B:33:0x00f7, B:34:0x00f8, B:38:0x0101, B:42:0x0106, B:36:0x00fa, B:37:0x0100, B:17:0x0096, B:18:0x00a0), top: B:47:0x0008, inners: #0, #1 }] */
        /* JADX WARN: Code duplicated, block: B:35:0x00f9  */
        public void updateContact(Contact c) {
            HashSet<UpdateListener> iterator;
            if (c != null) {
                Contact entry = getContactInfo(c);
                synchronized (c) {
                    if (contactChanged(c, entry)) {
                        if (Log.isLoggable("Mms", 2)) {
                            if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                                Contact.log("updateContact: contact changed for ***");
                            } else {
                                Contact.log("updateContact: contact changed for " + entry.mName);
                            }
                        }
                        c.mNumber = entry.mNumber;
                        c.mLabel = entry.mLabel;
                        c.mPersonId = entry.mPersonId;
                        c.mPresenceResId = entry.mPresenceResId;
                        c.mPresenceText = entry.mPresenceText;
                        c.mAvatarData = entry.mAvatarData;
                        c.mAvatar = entry.mAvatar;
                        c.mContactMethodId = entry.mContactMethodId;
                        c.mContactMethodType = entry.mContactMethodType;
                        c.mNumberE164 = entry.mNumberE164;
                        c.mName = entry.mName;
                        c.mPhoneticName = entry.mPhoneticName;
                        c.mSendToVoicemail = entry.mSendToVoicemail;
                        c.mPeopleReferenceUri = entry.mPeopleReferenceUri;
                        c.notSynchronizedUpdateNameAndNumber();
                        if (!TextUtils.isEmpty(c.mNumber)) {
                            synchronized (Contact.mListeners) {
                                iterator = (HashSet) Contact.mListeners.clone();
                            }
                            for (UpdateListener l : iterator) {
                                if (Log.isLoggable("Mms", 3)) {
                                    Log.d("Mms", "updating " + l);
                                }
                                l.onUpdate(c);
                            }
                            synchronized (c) {
                                c.mQueryPending = false;
                                c.notifyAll();
                            }
                        } else {
                            synchronized (c) {
                                c.mQueryPending = false;
                                c.notifyAll();
                            }
                        }
                    } else {
                        synchronized (c) {
                            c.mQueryPending = false;
                            c.notifyAll();
                        }
                    }
                    throw th;
                }
            }
        }

        private Contact getContactInfo(Contact c) {
            if (!c.mIsMe) {
                if (Telephony.Mms.isEmailAddress(c.mNumber)) {
                    return getContactInfoForEmailAddress(c.mNumber);
                }
                if (isAlphaNumber(c.mNumber)) {
                    Contact contact = getContactInfoForEmailAddress(c.mNumber);
                    if (!contact.existsInDatabase()) {
                        return getContactInfoForPhoneNumber(c.mNumber);
                    }
                    return contact;
                }
                String strippedNumber = PhoneNumberUtils.stripSeparators(c.mNumber);
                return getContactInfoForPhoneNumber(strippedNumber);
            }
            return getContactInfoForSelf();
        }

        private boolean isAlphaNumber(String number) {
            if (!PhoneNumberUtils.isWellFormedSmsAddress(number) || MessageUtils.isAlias(number)) {
                return true;
            }
            String number2 = PhoneNumberUtils.extractNetworkPortion(number);
            return TextUtils.isEmpty(number2) || number2.length() < 3;
        }

        private Contact getContactInfoForPhoneNumber(String number) {
            String selection;
            String[] args;
            Contact entry = new Contact(number);
            entry.mContactMethodType = 1;
            entry.mPeopleReferenceUri = Uri.fromParts(Contact.TEL_SCHEME, number, null);
            if (Log.isLoggable("Mms", 3)) {
                if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                    Contact.log("queryContactInfoByNumber: number=***");
                } else {
                    Contact.log("queryContactInfoByNumber: number=" + number);
                }
            }
            String normalizedNumber = PhoneNumberUtils.normalizeNumber(number);
            String minMatch = PhoneNumberUtils.toCallerIDMinMatch(normalizedNumber);
            if (!TextUtils.isEmpty(normalizedNumber) && !TextUtils.isEmpty(minMatch)) {
                String numberLen = String.valueOf(normalizedNumber.length());
                String numberE164 = PhoneNumberUtils.formatNumberToE164(number, MmsApp.getApplication().getCurrentCountryIso());
                String numberE164_JP = LoggingEvents.EXTRA_CALLING_APP_NAME;
                if (numberE164 != null && numberE164.length() > 3) {
                    numberE164_JP = "+81" + numberE164.substring(3, numberE164.length());
                }
                if (TextUtils.isEmpty(numberE164)) {
                    selection = CALLER_ID_SELECTION_WITHOUT_E164;
                    args = new String[]{minMatch, numberLen, normalizedNumber, numberLen};
                } else {
                    selection = CALLER_ID_SELECTION;
                    args = new String[]{minMatch, numberE164, numberE164_JP, numberLen, normalizedNumber, numberLen};
                }
                Cursor cursor = this.mContext.getContentResolver().query(PHONES_WITH_PRESENCE_URI, CALLER_ID_PROJECTION, selection, args, null);
                if (cursor == null) {
                    Log.w("Mms", "queryContactInfoByNumber(" + number + ") returned NULL cursor! contact uri used " + PHONES_WITH_PRESENCE_URI);
                } else {
                    try {
                        if (cursor.moveToFirst()) {
                            fillPhoneTypeContact(entry, cursor);
                        }
                    } finally {
                        cursor.close();
                    }
                }
            }
            return entry;
        }

        private Contact getContactInfoForSelf() {
            Contact entry = new Contact(true);
            entry.mContactMethodType = 3;
            if (Log.isLoggable("Mms", 3)) {
                Contact.log("getContactInfoForSelf");
            }
            Cursor cursor = this.mContext.getContentResolver().query(ContactsContract.Profile.CONTENT_URI, SELF_PROJECTION, null, null, null);
            if (cursor == null) {
                Log.w("Mms", "getContactInfoForSelf() returned NULL cursor! contact uri used " + ContactsContract.Profile.CONTENT_URI);
            } else {
                try {
                    if (cursor.moveToFirst()) {
                        fillSelfContact(entry, cursor);
                    }
                } finally {
                    cursor.close();
                }
            }
            return entry;
        }

        private void fillPhoneTypeContact(Contact contact, Cursor cursor) {
            synchronized (contact) {
                contact.mContactMethodType = 1;
                contact.mContactMethodId = cursor.getLong(0);
                contact.mLabel = cursor.getString(2);
                contact.mName = cursor.getString(3);
                contact.mPhoneticName = cursor.getString(9);
                contact.mPersonId = cursor.getLong(4);
                contact.mPresenceResId = getPresenceIconResourceId(cursor.getInt(5));
                contact.mPresenceText = cursor.getString(6);
                contact.mNumberE164 = cursor.getString(7);
                contact.mSendToVoicemail = cursor.getInt(8) == 1;
                if (Log.isLoggable("Mms", 3)) {
                    if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                        Contact.log("fillPhoneTypeContact: name=***, number=***, presence=" + contact.mPresenceResId + " SendToVoicemail: ***");
                    } else {
                        Contact.log("fillPhoneTypeContact: name=" + contact.mName + ", number=" + contact.mNumber + ", presence=" + contact.mPresenceResId + " SendToVoicemail: " + contact.mSendToVoicemail);
                    }
                }
            }
            byte[] data = loadAvatarData(contact);
            synchronized (contact) {
                contact.mAvatarData = data;
            }
        }

        private void fillSelfContact(Contact contact, Cursor cursor) {
            synchronized (contact) {
                contact.mName = cursor.getString(1);
                if (TextUtils.isEmpty(contact.mName)) {
                    contact.mName = this.mContext.getString(R.string.messagelist_sender_self);
                }
                if (Log.isLoggable("Mms", 3)) {
                    if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                        Contact.log("fillSelfContact: name=***, number=***");
                    } else {
                        Contact.log("fillSelfContact: name=" + contact.mName + ", number=" + contact.mNumber);
                    }
                }
            }
            byte[] data = loadAvatarData(contact);
            synchronized (contact) {
                contact.mAvatarData = data;
            }
        }

        /* JADX WARN: Code duplicated, block: B:42:0x004e A[EXC_TOP_SPLITTER, SYNTHETIC] */
        private byte[] loadAvatarData(Contact entry) {
            byte[] data = null;
            if ((!entry.mIsMe && entry.mPersonId == 0) || entry.mAvatar != null) {
                return null;
            }
            if (Log.isLoggable("Mms", 3)) {
                if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                    Contact.log("loadAvatarData: name=***, number=***");
                } else {
                    Contact.log("loadAvatarData: name=" + entry.mName + ", number=" + entry.mNumber);
                }
            }
            Uri contactUri = entry.mIsMe ? ContactsContract.Profile.CONTENT_URI : ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, entry.mPersonId);
            InputStream avatarDataStream = ContactsContract.Contacts.openContactPhotoInputStream(this.mContext.getContentResolver(), contactUri);
            if (avatarDataStream != null) {
                try {
                    data = new byte[avatarDataStream.available()];
                    avatarDataStream.read(data, 0, data.length);
                    if (avatarDataStream != null) {
                        try {
                            avatarDataStream.close();
                        } catch (IOException e) {
                        }
                    }
                } catch (IOException e2) {
                    if (avatarDataStream != null) {
                        try {
                            avatarDataStream.close();
                        } catch (IOException e3) {
                        }
                    }
                } catch (Throwable th) {
                    if (avatarDataStream != null) {
                        try {
                            avatarDataStream.close();
                        } catch (IOException e4) {
                        }
                    }
                    throw th;
                }
            } else if (avatarDataStream != null) {
                avatarDataStream.close();
            }
            return data;
        }

        private int getPresenceIconResourceId(int presence) {
            if (presence != 0) {
                return ContactsContract.Presence.getPresenceIconResourceId(presence);
            }
            return 0;
        }

        private Contact getContactInfoForEmailAddress(String email) {
            Contact entry = new Contact(email);
            entry.mContactMethodType = 2;
            entry.mPeopleReferenceUri = Uri.fromParts("mailto", email, null);
            Cursor cursor = SqliteWrapper.query(this.mContext, this.mContext.getContentResolver(), EMAIL_WITH_PRESENCE_URI, EMAIL_PROJECTION, EMAIL_SELECTION, new String[]{email}, (String) null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    try {
                        boolean found = false;
                        synchronized (entry) {
                            entry.mContactMethodId = cursor.getLong(0);
                            entry.mPresenceResId = getPresenceIconResourceId(cursor.getInt(2));
                            entry.mPersonId = cursor.getLong(3);
                            entry.mSendToVoicemail = cursor.getInt(5) == 1;
                            String name = cursor.getString(1);
                            if (TextUtils.isEmpty(name)) {
                                name = cursor.getString(4);
                            }
                            if (!TextUtils.isEmpty(name)) {
                                entry.mName = name;
                                String phoneticName = cursor.getString(6);
                                if (!TextUtils.isEmpty(phoneticName)) {
                                    entry.mPhoneticName = phoneticName;
                                } else if (Log.isLoggable("Mms", 3)) {
                                    if (Contact.FJ_TEL_LOG_ACQ_FLG) {
                                        Contact.log("getContactInfoForEmailAddress: name=***, email=***, presence=" + entry.mPresenceResId);
                                    } else {
                                        Contact.log("getContactInfoForEmailAddress: name=" + entry.mName + ", email=" + email + ", presence=" + entry.mPresenceResId);
                                    }
                                }
                                found = true;
                            }
                        }
                        if (found) {
                            byte[] data = loadAvatarData(entry);
                            synchronized (entry) {
                                entry.mAvatarData = data;
                                break;
                            }
                        }
                    } catch (Throwable th) {
                        cursor.close();
                        throw th;
                    }
                }
                cursor.close();
            }
            return entry;
        }

        private String key(String phoneNumber, CharBuffer keyBuffer) {
            keyBuffer.clear();
            keyBuffer.mark();
            int position = phoneNumber.length();
            int resultCount = 0;
            while (true) {
                position--;
                if (position < 0) {
                    break;
                }
                char c = phoneNumber.charAt(position);
                if (Character.isDigit(c)) {
                    keyBuffer.put(c);
                    resultCount++;
                    if (resultCount == 5) {
                        break;
                    }
                }
            }
            keyBuffer.reset();
            if (resultCount > 0) {
                return keyBuffer.toString();
            }
            return phoneNumber;
        }

        /* JADX WARN: Code duplicated, block: B:9:0x0010  */
        private Contact internalGet(String numberOrEmail, boolean isMe) {
            boolean isNotRegularPhoneNumber;
            Contact c;
            synchronized (this) {
                if (isMe) {
                    isNotRegularPhoneNumber = true;
                } else if (Telephony.Mms.isEmailAddress(numberOrEmail) || MessageUtils.isAlias(numberOrEmail)) {
                    isNotRegularPhoneNumber = true;
                } else {
                    isNotRegularPhoneNumber = false;
                }
                String key = isNotRegularPhoneNumber ? numberOrEmail : key(numberOrEmail, sStaticKeyBuffer);
                boolean firstRegistrationFlg = false;
                ArrayList<Contact> candidates = this.mContactsHash.get(key);
                if (candidates != null) {
                    int length = candidates.size();
                    for (int i = 0; i < length; i++) {
                        c = candidates.get(i);
                        if (isNotRegularPhoneNumber) {
                            if (!numberOrEmail.equals(c.mNumber)) {
                            }
                        } else if (!PhoneNumberUtils.compare(numberOrEmail, c.mNumber)) {
                        }
                    }
                } else {
                    candidates = new ArrayList<>();
                    this.mContactsHash.put(key, candidates);
                    firstRegistrationFlg = true;
                }
                c = isMe ? new Contact(true) : new Contact(numberOrEmail);
                if (firstRegistrationFlg) {
                    c.mContactMethodType = isNotRegularPhoneNumber ? 2 : 1;
                }
                candidates.add(c);
            }
            return c;
        }

        void invalidate() {
            synchronized (this) {
                for (ArrayList<Contact> alc : this.mContactsHash.values()) {
                    for (Contact c : alc) {
                        synchronized (c) {
                            c.mIsStale = true;
                        }
                    }
                }
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void remove(Contact contact) {
            synchronized (this) {
                String number = contact.getNumber();
                boolean isNotRegularPhoneNumber = contact.isMe() || Telephony.Mms.isEmailAddress(number) || MessageUtils.isAlias(number);
                String key = isNotRegularPhoneNumber ? number : key(number, sStaticKeyBuffer);
                ArrayList<Contact> candidates = this.mContactsHash.get(key);
                if (candidates != null) {
                    int length = candidates.size();
                    for (int i = 0; i < length; i++) {
                        Contact c = candidates.get(i);
                        if (isNotRegularPhoneNumber) {
                            if (number.equals(c.mNumber)) {
                                candidates.remove(i);
                                break;
                            }
                        } else {
                            if (PhoneNumberUtils.compare(number, c.mNumber)) {
                                candidates.remove(i);
                                break;
                            }
                        }
                    }
                    if (candidates.size() == 0) {
                        this.mContactsHash.remove(key);
                    }
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void log(String msg) {
        Log.d("Mms", msg);
    }

    private static void registerDataBasesObserver(Context context) {
        Log.d("Mms", "Contact | registerDataBasesObserver.");
        context.getContentResolver().registerContentObserver(CONTACT_DATA_URI, true, sContactsObserver);
        context.getContentResolver().registerContentObserver(CallLog.Calls.CONTENT_URI, true, sCallLogObserver);
    }

    public static void unregisterDataBasesObserver(Context context) {
        if (sContactsObserver != null) {
            context.getContentResolver().unregisterContentObserver(sContactsObserver);
            Log.d("Mms", "Contact | unregisterContactsObserver.");
        }
        if (sCallLogObserver != null) {
            context.getContentResolver().unregisterContentObserver(sCallLogObserver);
            Log.d("Mms", "Contact | unregisterCallLogObserver.");
        }
    }
}
