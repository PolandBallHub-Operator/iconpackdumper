package com.android.mms.data;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemProperties;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import com.android.common.contacts.DataUsageStatUpdater;
import com.android.common.speech.LoggingEvents;
import com.android.common.userhappiness.UserHappinessSignals;
import com.android.mms.ContentRestrictionException;
import com.android.mms.ExceedMessageSizeException;
import com.android.mms.LogTag;
import com.android.mms.MmsApp;
import com.android.mms.MmsConfig;
import com.android.mms.ResolutionException;
import com.android.mms.UnsupportContentTypeException;
import com.android.mms.model.ImageModel;
import com.android.mms.model.MediaModel;
import com.android.mms.model.SlideModel;
import com.android.mms.model.SlideshowModel;
import com.android.mms.model.TextModel;
import com.android.mms.transaction.MessageSender;
import com.android.mms.transaction.MmsMessageSender;
import com.android.mms.transaction.SmsMessageSender;
import com.android.mms.ui.ComposeMessageActivity;
import com.android.mms.ui.MessageUtils;
import com.android.mms.ui.MessagingPreferenceActivity;
import com.android.mms.ui.SlideshowEditor;
import com.android.mms.util.DraftCache;
import com.android.mms.util.Recycler;
import com.android.mms.util.ThumbnailManager;
import com.android.mms.widget.MmsWidgetProvider;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.EncodedStringValue;
import com.google.android.mms.pdu.PduBody;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.SendReq;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class WorkingMessage {
    public static final String ACTION_SENDING_SMS = "android.intent.action.SENDING_SMS";
    public static final int AUDIO = 3;
    private static final boolean DEBUG = false;
    public static final String EXTRA_SMS_MESSAGE = "android.mms.extra.MESSAGE";
    public static final String EXTRA_SMS_RECIPIENTS = "android.mms.extra.RECIPIENTS";
    public static final String EXTRA_SMS_THREAD_ID = "android.mms.extra.THREAD_ID";
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final int FORCE_MMS = 16;
    private static final int HAS_ATTACHMENT = 4;
    private static final int HAS_SUBJECT = 2;
    public static final int IMAGE = 1;
    public static final int IMAGE_TOO_LARGE = -4;
    private static final int LENGTH_REQUIRES_MMS = 8;
    public static final int MESSAGE_SIZE_EXCEEDED = -2;
    private static final String[] MMS_DRAFT_PROJECTION;
    private static final int MMS_ID_INDEX = 0;
    private static final int MMS_MESSAGE_SIZE_INDEX = 1;
    private static final String[] MMS_OUTBOX_PROJECTION;
    private static final int MMS_SUBJECT_CS_INDEX = 2;
    private static final int MMS_SUBJECT_INDEX = 1;
    private static final int MULTIPLE_RECIPIENTS = 32;
    public static final int OK = 0;
    private static final int RECIPIENTS_REQUIRE_MMS = 1;
    public static final int SLIDESHOW = 4;
    private static final int SMS_BODY_INDEX = 0;
    private static final String[] SMS_BODY_PROJECTION;
    private static final String SMS_DRAFT_WHERE = "type=3";
    private static final String TAG = "Mms";
    public static final int TEXT = 0;
    public static final int UNKNOWN_ERROR = -1;
    public static final int UNSUPPORTED_TYPE = -3;
    public static final int VIDEO = 2;
    public static int mCurrentConvPhoneId;
    private static boolean sMmsEnabled;
    private final Activity mActivity;
    private final ContentResolver mContentResolver;
    private Conversation mConversation;
    private volatile boolean mHasMmsDraft;
    private volatile boolean mHasSmsDraft;
    private Uri mMessageUri;
    private int mMmsState;
    private SlideshowModel mSlideshow;
    private final MessageStatusListener mStatusListener;
    private CharSequence mSubject;
    private List<String> mWorkingRecipients;
    private boolean mDiscarded = false;
    private int mAttachmentType = 0;
    private CharSequence mText = LoggingEvents.EXTRA_CALLING_APP_NAME;

    public interface MessageStatusListener {
        void onAttachmentChanged();

        void onAttachmentError(int i);

        void onMaxPendingMessagesReached();

        void onMessageSent();

        void onPreMessageSent();

        void onProtocolChanged(boolean z);
    }

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
        sMmsEnabled = MmsConfig.getMmsEnabled();
        MMS_OUTBOX_PROJECTION = new String[]{"_id", "m_size"};
        mCurrentConvPhoneId = 0;
        MMS_DRAFT_PROJECTION = new String[]{"_id", "sub", "sub_cs"};
        SMS_BODY_PROJECTION = new String[]{"body"};
    }

    /* JADX WARN: Multi-variable type inference failed */
    private WorkingMessage(ComposeMessageActivity composeMessageActivity) {
        this.mActivity = composeMessageActivity;
        this.mContentResolver = this.mActivity.getContentResolver();
        this.mStatusListener = composeMessageActivity;
    }

    public static WorkingMessage createEmpty(ComposeMessageActivity activity) {
        WorkingMessage msg = new WorkingMessage(activity);
        return msg;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static WorkingMessage load(ComposeMessageActivity composeMessageActivity, Uri uri) {
        if (!uri.toString().startsWith(Telephony.Mms.Draft.CONTENT_URI.toString())) {
            PduPersister persister = PduPersister.getPduPersister(composeMessageActivity);
            if (Log.isLoggable("Mms", 2)) {
                LogTag.debug("load: moving %s to drafts", uri);
            }
            try {
                uri = persister.move(uri, Telephony.Mms.Draft.CONTENT_URI);
            } catch (MmsException e) {
                LogTag.error("Can't move %s to drafts", uri);
                return null;
            }
        }
        WorkingMessage msg = new WorkingMessage(composeMessageActivity);
        if (!msg.loadFromUri(uri)) {
            return null;
        }
        msg.mHasMmsDraft = true;
        return msg;
    }

    private void correctAttachmentState(boolean showToast) {
        int slideCount = this.mSlideshow.size();
        if (slideCount == 0) {
            removeAttachment(false);
        } else if (slideCount > 1) {
            this.mAttachmentType = 4;
        } else {
            SlideModel slide = this.mSlideshow.get(0);
            if (slide.hasImage()) {
                this.mAttachmentType = 1;
            } else if (slide.hasVideo()) {
                this.mAttachmentType = 2;
            } else if (slide.hasAudio()) {
                this.mAttachmentType = 3;
            }
        }
        updateState(4, hasAttachment(), showToast);
    }

    private boolean loadFromUri(Uri uri) {
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("loadFromUri %s", uri);
        }
        try {
            this.mSlideshow = SlideshowModel.createFromMessageUri(this.mActivity, uri);
            this.mMessageUri = uri;
            syncTextFromSlideshow();
            correctAttachmentState(false);
            return true;
        } catch (MmsException e) {
            LogTag.error("Couldn't load URI %s", uri);
            return false;
        }
    }

    public static WorkingMessage loadDraft(ComposeMessageActivity activity, Conversation conv, Runnable onDraftLoaded) {
        StringBuilder sb;
        Uri uri;
        if (FJ_TEL_LOG_ACQ_FLG) {
            if (Log.isLoggable("Mms", 2)) {
                LogTag.debug("loadDraft %s", "***");
            }
        } else if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("loadDraft %s", conv);
        }
        WorkingMessage msg = createEmpty(activity);
        if (conv.getThreadId() <= 0) {
            if (onDraftLoaded != null) {
                onDraftLoaded.run();
            }
        } else {
            String draftText = msg.readDraftSmsMessage(conv);
            String subject = null;
            if (TextUtils.isEmpty(draftText) && (uri = readDraftMmsMessage(msg.mActivity, conv, (sb = new StringBuilder()))) != null && msg.loadFromUri(uri)) {
                subject = sb.toString();
            }
            Pair<String, String> result = new Pair<>(draftText, subject);
            if (!TextUtils.isEmpty((CharSequence) result.first)) {
                msg.mHasSmsDraft = true;
                msg.setText((CharSequence) result.first);
            }
            if (result.second != null) {
                msg.mHasMmsDraft = true;
                if (!TextUtils.isEmpty((CharSequence) result.second)) {
                    msg.setSubject((CharSequence) result.second, false);
                }
            }
            if (onDraftLoaded != null) {
                onDraftLoaded.run();
            }
        }
        return msg;
    }

    public void setText(CharSequence s) {
        this.mText = s;
    }

    public CharSequence getText() {
        return this.mText;
    }

    public void setWorkingMessageSub(int phoneId) {
        mCurrentConvPhoneId = phoneId;
    }

    public boolean hasText() {
        return this.mText != null && TextUtils.getTrimmedLength(this.mText) > 0;
    }

    public void removeAttachment(boolean notify) {
        removeThumbnailsFromCache(this.mSlideshow);
        this.mAttachmentType = 0;
        this.mSlideshow = null;
        if (this.mMessageUri != null) {
            asyncDelete(this.mMessageUri, null, null);
            this.mMessageUri = null;
        }
        updateState(4, false, notify);
        if (notify) {
            this.mStatusListener.onAttachmentChanged();
        }
    }

    public static void removeThumbnailsFromCache(SlideshowModel slideshow) {
        if (slideshow != null) {
            ThumbnailManager thumbnailManager = MmsApp.getApplication().getThumbnailManager();
            boolean removedSomething = false;
            for (SlideModel slideModel : slideshow) {
                if (slideModel.hasImage()) {
                    thumbnailManager.removeThumbnail(slideModel.getImage().getUri());
                    removedSomething = true;
                } else if (slideModel.hasVideo()) {
                    thumbnailManager.removeThumbnail(slideModel.getVideo().getUri());
                    removedSomething = true;
                }
            }
            if (removedSomething) {
                MmsApp.getApplication().getThumbnailManager().clearBackingStore();
            }
        }
    }

    public int setAttachment(int type, Uri dataUri, boolean append) {
        int numSlides;
        ImageModel imgModel;
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("setAttachment type=%d uri %s", Integer.valueOf(type), dataUri);
        }
        SlideshowEditor slideShowEditor = new SlideshowEditor(this.mActivity, this.mSlideshow);
        if (type == 0 && this.mAttachmentType == 4 && this.mSlideshow != null && dataUri == null && !append) {
            slideShowEditor.removeAllSlides();
        }
        ensureSlideshow();
        slideShowEditor.setSlideshow(this.mSlideshow);
        int result = append ? appendMedia(type, dataUri, slideShowEditor) : changeMedia(type, dataUri, slideShowEditor);
        if (result == 0) {
            this.mAttachmentType = type;
        }
        correctAttachmentState(true);
        if (this.mSlideshow != null && type == 1 && (numSlides = this.mSlideshow.size()) > 0 && (imgModel = this.mSlideshow.get(numSlides - 1).getImage()) != null) {
            cancelThumbnailLoading();
            imgModel.loadThumbnailBitmap(null);
        }
        this.mStatusListener.onAttachmentChanged();
        if (!append && this.mAttachmentType == 0 && type == 0) {
            int[] params = SmsMessage.calculateLength(getText(), false);
            int smsSegmentCount = params[0];
            if (!MmsConfig.getMultipartSmsEnabled()) {
                setLengthRequiresMms(smsSegmentCount > 1, false);
            } else {
                int threshold = MmsConfig.getSmsToMmsTextThreshold();
                setLengthRequiresMms(threshold > 0 && smsSegmentCount > threshold, false);
            }
        }
        return result;
    }

    public boolean isWorthSaving() {
        return hasText() || hasSubject() || hasAttachment() || hasSlideshow() || isFakeMmsForDraft();
    }

    private void cancelThumbnailLoading() {
        ImageModel imgModel;
        int numSlides = this.mSlideshow != null ? this.mSlideshow.size() : 0;
        if (numSlides > 0 && (imgModel = this.mSlideshow.get(numSlides - 1).getImage()) != null) {
            imgModel.cancelThumbnailLoading();
        }
    }

    public boolean isFakeMmsForDraft() {
        return (this.mMmsState & 16) > 0;
    }

    private void ensureSlideshow() {
        if (this.mSlideshow == null) {
            SlideshowModel slideshow = SlideshowModel.createNew(this.mActivity);
            SlideModel slide = new SlideModel(slideshow);
            slideshow.add(slide);
            this.mSlideshow = slideshow;
        }
    }

    private int changeMedia(int type, Uri uri, SlideshowEditor slideShowEditor) {
        SlideModel originalSlide = this.mSlideshow.get(0);
        if (originalSlide != null) {
            slideShowEditor.removeSlide(0);
        }
        slideShowEditor.addNewSlide(0);
        SlideModel slide = this.mSlideshow.get(0);
        if (slide == null) {
            Log.w("Mms", "[WorkingMessage] changeMedia: no slides!");
            return 0;
        }
        this.mAttachmentType = 0;
        if (type == 0) {
            return 0;
        }
        int result = internalChangeMedia(type, uri, 0, slideShowEditor);
        if (result != 0) {
            slideShowEditor.removeSlide(0);
            if (originalSlide != null) {
                slideShowEditor.addSlide(0, originalSlide);
            }
        }
        return result;
    }

    private int appendMedia(int type, Uri uri, SlideshowEditor slideShowEditor) {
        if (type == 0) {
            return 0;
        }
        boolean addNewSlide = true;
        if (this.mSlideshow.size() == 1 && !this.mSlideshow.isSimple()) {
            addNewSlide = false;
        }
        if (addNewSlide && !slideShowEditor.addNewSlide()) {
            return 0;
        }
        int slideNum = this.mSlideshow.size() - 1;
        int result = internalChangeMedia(type, uri, slideNum, slideShowEditor);
        if (result != 0) {
            slideShowEditor.removeSlide(slideNum);
        }
        return result;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private int internalChangeMedia(int type, Uri uri, int slideNum, SlideshowEditor slideShowEditor) {
        try {
            if (type == 1) {
                slideShowEditor.changeImage(slideNum, uri);
            } else if (type == 2) {
                slideShowEditor.changeVideo(slideNum, uri);
            } else if (type == 3) {
                slideShowEditor.changeAudio(slideNum, uri);
            } else {
                return -3;
            }
            return 0;
        } catch (ResolutionException e) {
            Log.e("Mms", "internalChangeMedia:", e);
            return -4;
        } catch (MmsException e2) {
            Log.e("Mms", "internalChangeMedia:", e2);
            return -1;
        } catch (ExceedMessageSizeException e3) {
            Log.e("Mms", "internalChangeMedia:", e3);
            return -2;
        } catch (UnsupportContentTypeException e4) {
            Log.e("Mms", "internalChangeMedia:", e4);
            return -3;
        }
    }

    public boolean hasAttachment() {
        return this.mAttachmentType > 0;
    }

    public SlideshowModel getSlideshow() {
        return this.mSlideshow;
    }

    public boolean hasSlideshow() {
        return this.mAttachmentType == 4;
    }

    public void setSubject(CharSequence s, boolean notify) {
        this.mSubject = s;
        updateState(2, s != null, notify);
    }

    public CharSequence getSubject() {
        return this.mSubject;
    }

    public boolean hasSubject() {
        return this.mSubject != null && TextUtils.getTrimmedLength(this.mSubject) > 0;
    }

    private void syncTextToSlideshow() {
        TextModel text;
        if (this.mSlideshow != null && this.mSlideshow.size() == 1) {
            SlideModel slide = this.mSlideshow.get(0);
            if (!slide.hasText()) {
                text = new TextModel(this.mActivity, "text/plain", "text_0.txt", this.mSlideshow.getLayout().getTextRegion());
                slide.add((MediaModel) text);
            } else {
                text = slide.getText();
            }
            text.setText(this.mText);
        }
    }

    private void syncTextFromSlideshow() {
        SlideModel slide;
        if (this.mSlideshow.size() == 1 && (slide = this.mSlideshow.get(0)) != null && slide.hasText()) {
            this.mText = slide.getText().getText();
        }
    }

    private void removeSubjectIfEmpty(boolean notify) {
        if (!hasSubject()) {
            setSubject(null, notify);
        }
    }

    private void prepareForSave(boolean notify) {
        syncWorkingRecipients();
        if (hasMmsContentToSave()) {
            ensureSlideshow();
            syncTextToSlideshow();
        }
    }

    public void syncWorkingRecipients() {
        if (this.mWorkingRecipients != null) {
            ContactList recipients = ContactList.getByNumbers(this.mWorkingRecipients, false);
            this.mConversation.setRecipients(recipients);
            setHasMultipleRecipients(recipients.size() > 1, true);
            this.mWorkingRecipients = null;
        }
    }

    public String getWorkingRecipients() {
        if (this.mWorkingRecipients == null) {
            return null;
        }
        ContactList recipients = ContactList.getByNumbers(this.mWorkingRecipients, false);
        return recipients.serialize();
    }

    public void removeFakeMmsForDraft() {
        updateState(16, false, false);
    }

    public Uri saveAsMms(boolean notify) {
        if (FJ_TEL_LOG_ACQ_FLG) {
        }
        if (this.mDiscarded) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.warn("saveAsMms mDiscarded: true mConversation: *** returning NULL uri and bailing", new Object[0]);
                return null;
            }
            LogTag.warn("saveAsMms mDiscarded: true mConversation: " + this.mConversation + " returning NULL uri and bailing", new Object[0]);
            return null;
        }
        updateState(16, true, notify);
        prepareForSave(true);
        try {
            DraftCache.getInstance().setSavingDraft(true);
            if (!this.mConversation.getRecipients().isEmpty()) {
                this.mConversation.ensureThreadId();
            }
            this.mConversation.setDraftState(true);
            PduPersister persister = PduPersister.getPduPersister(this.mActivity);
            SendReq sendReq = makeSendReq(this.mConversation, this.mSubject);
            if (this.mMessageUri == null) {
                this.mMessageUri = createDraftMmsMessage(persister, sendReq, this.mSlideshow, null, this.mActivity, null);
            } else {
                updateDraftMmsMessage(this.mMessageUri, persister, this.mSlideshow, sendReq, null);
            }
            this.mHasMmsDraft = true;
            return this.mMessageUri;
        } finally {
            DraftCache.getInstance().setSavingDraft(false);
        }
    }

    public void saveDraft(boolean isStopping) {
        if (this.mDiscarded) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.warn("saveDraft mDiscarded: true mConversation: *** skipping saving draft and bailing", new Object[0]);
                return;
            } else {
                LogTag.warn("saveDraft mDiscarded: true mConversation: " + this.mConversation + " skipping saving draft and bailing", new Object[0]);
                return;
            }
        }
        if (this.mConversation == null) {
            throw new IllegalStateException("saveDraft() called with no conversation");
        }
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.debug("saveDraft for mConversation ***", new Object[0]);
            } else {
                LogTag.debug("saveDraft for mConversation " + this.mConversation, new Object[0]);
            }
        }
        prepareForSave(false);
        if (requiresMms()) {
            if (hasMmsContentToSave()) {
                asyncUpdateDraftMmsMessage(this.mConversation, isStopping);
                this.mHasMmsDraft = true;
                return;
            }
            return;
        }
        String content = this.mText.toString();
        if (!TextUtils.isEmpty(content)) {
            asyncUpdateDraftSmsMessage(this.mConversation, content, isStopping);
            this.mHasSmsDraft = true;
        } else {
            deleteDraftSmsMessage(this.mConversation.getThreadId());
            DraftCache.getInstance().setDraftState(this.mConversation.getThreadId(), false);
            this.mMessageUri = null;
        }
    }

    public synchronized void discard() {
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("[WorkingMessage] discard", new Object[0]);
        }
        if (!this.mDiscarded) {
            this.mDiscarded = true;
            cancelThumbnailLoading();
            if (this.mHasMmsDraft) {
                asyncDeleteDraftMmsMessage(this.mConversation);
            }
            if (this.mHasSmsDraft) {
                asyncDeleteDraftSmsMessage(this.mConversation);
            }
            clearConversation(this.mConversation, true);
        }
    }

    public void unDiscard() {
        this.mDiscarded = false;
    }

    public boolean isDiscarded() {
        return this.mDiscarded;
    }

    public void writeStateToBundle(Bundle bundle) {
        if (hasSubject()) {
            bundle.putString("subject", this.mSubject.toString());
        }
        if (this.mMessageUri != null) {
            bundle.putParcelable("msg_uri", this.mMessageUri);
        } else if (hasText()) {
            bundle.putString("sms_body", this.mText.toString());
        }
    }

    public void readStateFromBundle(Bundle bundle) {
        if (bundle != null) {
            String subject = bundle.getString("subject");
            setSubject(subject, false);
            Uri uri = (Uri) bundle.getParcelable("msg_uri");
            if (uri != null) {
                loadFromUri(uri);
            } else {
                String body = bundle.getString("sms_body");
                this.mText = body;
            }
        }
    }

    public void setWorkingRecipients(List<String> numbers) {
        this.mWorkingRecipients = numbers;
        if (numbers != null) {
            int size = numbers.size();
            switch (size) {
                case 0:
                    break;
                case 1:
                    numbers.get(0);
                    break;
                default:
                    String str = "{...} len=" + size;
                    break;
            }
        }
    }

    private void dumpWorkingRecipients() {
        Log.i("Mms", "-- mWorkingRecipients:");
        if (this.mWorkingRecipients != null) {
            int count = this.mWorkingRecipients.size();
            for (int i = 0; i < count; i++) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    Log.i("Mms", "   [" + i + "] ***");
                } else {
                    Log.i("Mms", "   [" + i + "] " + this.mWorkingRecipients.get(i));
                }
            }
            Log.i("Mms", LoggingEvents.EXTRA_CALLING_APP_NAME);
        }
    }

    public void dump() {
        Log.i("Mms", "WorkingMessage:");
        dumpWorkingRecipients();
        if (this.mConversation != null) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.i("Mms", "mConversation: ***");
            } else {
                Log.i("Mms", "mConversation: " + this.mConversation.toString());
            }
        }
    }

    public void setConversation(Conversation conv) {
        if (FJ_TEL_LOG_ACQ_FLG) {
        }
        this.mConversation = conv;
        ContactList contactList = conv.getRecipients();
        setHasEmail(contactList.containsEmail(), false);
        setHasMultipleRecipients(contactList.size() > 1, false);
    }

    public Conversation getConversation() {
        return this.mConversation;
    }

    public void setHasEmail(boolean hasEmail, boolean notify) {
        if (MmsConfig.getEmailGateway() != null) {
            updateState(1, false, notify);
        } else {
            updateState(1, hasEmail, notify);
        }
    }

    public void setHasMultipleRecipients(boolean hasMultipleRecipients, boolean notify) {
        updateState(32, hasMultipleRecipients && MessagingPreferenceActivity.getIsGroupMmsEnabled(this.mActivity), notify);
    }

    public boolean requiresMms() {
        return this.mMmsState > 0;
    }

    private boolean hasMmsContentToSave() {
        if (this.mMmsState == 0) {
            return false;
        }
        return this.mMmsState != 32 || hasText();
    }

    public void setLengthRequiresMms(boolean mmsRequired, boolean notify) {
        updateState(8, mmsRequired, notify);
    }

    private static String stateString(int state) {
        if (state == 0) {
            return "<none>";
        }
        StringBuilder sb = new StringBuilder();
        if ((state & 1) > 0) {
            sb.append("RECIPIENTS_REQUIRE_MMS | ");
        }
        if ((state & 2) > 0) {
            sb.append("HAS_SUBJECT | ");
        }
        if ((state & 4) > 0) {
            sb.append("HAS_ATTACHMENT | ");
        }
        if ((state & 8) > 0) {
            sb.append("LENGTH_REQUIRES_MMS | ");
        }
        if ((state & 16) > 0) {
            sb.append("FORCE_MMS | ");
        }
        if ((state & 32) > 0) {
            sb.append("MULTIPLE_RECIPIENTS | ");
        }
        sb.delete(sb.length() - 3, sb.length());
        return sb.toString();
    }

    private void updateState(int state, boolean on, boolean notify) {
        if (sMmsEnabled) {
            int oldState = this.mMmsState;
            if (on) {
                this.mMmsState |= state;
            } else {
                this.mMmsState &= state ^ (-1);
            }
            if (this.mMmsState == 16 && (oldState & (-17)) > 0) {
                this.mMmsState = 0;
            }
            if (notify) {
                if (oldState == 0 && this.mMmsState != 0) {
                    this.mStatusListener.onProtocolChanged(true);
                } else if (oldState != 0 && this.mMmsState == 0) {
                    this.mStatusListener.onProtocolChanged(false);
                }
            }
            if (oldState != this.mMmsState && Log.isLoggable("Mms", 2)) {
                Object[] objArr = new Object[3];
                objArr[0] = on ? "+" : "-";
                objArr[1] = stateString(state);
                objArr[2] = stateString(this.mMmsState);
                LogTag.debug("updateState: %s%s = %s", objArr);
            }
        }
    }

    public void send(final String recipientsInUI) {
        long origThreadId = this.mConversation.getThreadId();
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("send origThreadId: " + origThreadId, new Object[0]);
        }
        removeSubjectIfEmpty(true);
        prepareForSave(true);
        final Conversation conv = this.mConversation;
        String msgTxt = this.mText.toString();
        if (requiresMms() || addressContainsEmailToMms(conv, msgTxt)) {
            if (MmsConfig.getUaProfUrl() == null) {
                RuntimeException ex = new NullPointerException("WorkingMessage.send MMS sending failure. mms_config.xml is missing uaProfUrl setting.  uaProfUrl is required for MMS service, but can be absent for SMS.");
                Log.e("Mms", "WorkingMessage.send MMS sending failure. mms_config.xml is missing uaProfUrl setting.  uaProfUrl is required for MMS service, but can be absent for SMS.", ex);
                throw ex;
            }
            final Uri mmsUri = this.mMessageUri;
            final PduPersister persister = PduPersister.getPduPersister(this.mActivity);
            final SlideshowModel slideshow = this.mSlideshow;
            final CharSequence subject = this.mSubject;
            final boolean textOnly = this.mAttachmentType == 0;
            if (Log.isLoggable("Mms", 2)) {
                LogTag.debug("Send mmsUri: " + mmsUri, new Object[0]);
            }
            new Thread(new Runnable() { // from class: com.android.mms.data.WorkingMessage.1
                @Override // java.lang.Runnable
                public void run() {
                    SendReq sendReq = WorkingMessage.makeSendReq(conv, subject);
                    slideshow.prepareForSend();
                    WorkingMessage.this.sendMmsWorker(conv, mmsUri, persister, slideshow, sendReq, textOnly);
                    WorkingMessage.this.updateSendStats(conv);
                }
            }, "WorkingMessage.send MMS").start();
        } else {
            final String msgText = this.mText.toString();
            new Thread(new Runnable() { // from class: com.android.mms.data.WorkingMessage.2
                /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
                @Override // java.lang.Runnable
                public void run() throws MmsException {
                    WorkingMessage.this.preSendSmsWorker(conv, msgText, recipientsInUI);
                    WorkingMessage.this.updateSendStats(conv);
                }
            }, "WorkingMessage.send SMS").start();
        }
        RecipientIdCache.updateNumbers(conv.getThreadId(), conv.getRecipients());
        this.mDiscarded = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateSendStats(Conversation conv) {
        String[] dests = conv.getRecipients().getNumbers();
        ArrayList<String> phoneNumbers = new ArrayList<>(Arrays.asList(dests));
        DataUsageStatUpdater updater = new DataUsageStatUpdater(this.mActivity);
        updater.updateWithPhoneNumber(phoneNumbers);
    }

    private boolean addressContainsEmailToMms(Conversation conv, String text) {
        if (MmsConfig.getEmailGateway() != null) {
            String[] dests = conv.getRecipients().getNumbers();
            int length = dests.length;
            for (int i = 0; i < length; i++) {
                if (Telephony.Mms.isEmailAddress(dests[i]) || MessageUtils.isAlias(dests[i])) {
                    String mtext = dests[i] + " " + text;
                    int[] params = SmsMessage.calculateLength(mtext, false);
                    if (params[0] > 1) {
                        updateState(1, true, true);
                        ensureSlideshow();
                        syncTextToSlideshow();
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public void preSendSmsWorker(Conversation conv, String msgText, String recipientsInUI) throws MmsException {
        UserHappinessSignals.userAcceptedImeText(this.mActivity);
        this.mStatusListener.onPreMessageSent();
        long origThreadId = conv.getThreadId();
        long threadId = conv.ensureThreadId();
        String semiSepRecipients = conv.getRecipients().serialize();
        if ((origThreadId != 0 && origThreadId != threadId) || (!semiSepRecipients.equals(recipientsInUI) && !TextUtils.isEmpty(recipientsInUI))) {
            String msg = (origThreadId == 0 || origThreadId == threadId) ? "Recipients in window: \"" + recipientsInUI + "\" differ from recipients from conv: \"" + semiSepRecipients + "\"" : "WorkingMessage.preSendSmsWorker threadId changed or recipients changed. origThreadId: " + origThreadId + " new threadId: " + threadId + " also mConversation.getThreadId(): " + this.mConversation.getThreadId();
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.warnPossibleRecipientMismatch("***", this.mActivity);
            } else {
                LogTag.warnPossibleRecipientMismatch(msg, this.mActivity);
            }
        }
        sendSmsWorker(msgText, semiSepRecipients, threadId);
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private void sendSmsWorker(String msgText, String semiSepRecipients, long threadId) throws MmsException {
        Log.d("Mms", "WorkingMessage sendSmsWorker start");
        String[] dests = TextUtils.split(semiSepRecipients, MessageSender.RECIPIENTS_SEPARATOR);
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.d("Mms", "sendSmsWorker sending message: recipients=***, threadId=" + threadId);
            } else {
                Log.d("Mms", "sendSmsWorker sending message: recipients=" + semiSepRecipients + ", threadId=" + threadId);
            }
        }
        MessageSender sender = new SmsMessageSender((Context) this.mActivity, dests, msgText, threadId, mCurrentConvPhoneId);
        try {
            sender.sendMessage(threadId);
            Recycler.getSmsRecycler().deleteOldMessagesByThreadId(this.mActivity, threadId);
        } catch (Exception e) {
            Log.e("Mms", "Failed to send SMS message, threadId=" + threadId, e);
        }
        this.mStatusListener.onMessageSent();
        MmsWidgetProvider.notifyDatasetChanged(this.mActivity);
        Log.d("Mms", "WorkingMessage sendSmsWorker end");
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public void sendMmsWorker(Conversation conv, Uri mmsUri, PduPersister persister, SlideshowModel slideshow, SendReq sendReq, boolean textOnly) {
        String[] numbers;
        Cursor cursor = null;
        boolean forwardMessage = conv.getHasMmsForward();
        boolean sameRecipient = false;
        ContactList contactList = conv.getRecipients();
        if (contactList != null && (numbers = contactList.getNumbers()) != null && numbers.length == 1 && numbers[0].equals(conv.getForwardRecipientNumber())) {
            sameRecipient = true;
        }
        try {
            DraftCache.getInstance().setSavingDraft(true);
            this.mStatusListener.onPreMessageSent();
            long threadId = conv.ensureThreadId();
            if (forwardMessage && sameRecipient) {
                MessageUtils.sSameRecipientList.add(Long.valueOf(threadId));
            }
            if (Log.isLoggable("Mms", 2)) {
                LogTag.debug("sendMmsWorker: update draft MMS message " + mmsUri + " threadId: " + threadId, new Object[0]);
            }
            String[] dests = conv.getRecipients().getNumbers(true);
            if (dests.length == 1) {
                String newAddress = Conversation.verifySingleRecipient(this.mActivity, conv.getThreadId(), dests[0]);
                if (Log.isLoggable("Mms", 2)) {
                    if (FJ_TEL_LOG_ACQ_FLG) {
                        LogTag.debug("sendMmsWorker: newAddress *** dests[0]: ***", new Object[0]);
                    } else {
                        LogTag.debug("sendMmsWorker: newAddress " + newAddress + " dests[0]: " + dests[0], new Object[0]);
                    }
                }
                if (!newAddress.equals(dests[0])) {
                    dests[0] = newAddress;
                    EncodedStringValue[] encodedNumbers = EncodedStringValue.encodeStrings(dests);
                    if (encodedNumbers != null) {
                        if (Log.isLoggable("Mms", 2)) {
                            LogTag.debug("sendMmsWorker: REPLACING number!!!", new Object[0]);
                        }
                        sendReq.setTo(encodedNumbers);
                    }
                }
            }
            boolean newMessage = mmsUri == null;
            if (newMessage) {
                ContentValues values = new ContentValues();
                values.put("msg_box", (Integer) 4);
                values.put(ComposeMessageActivity.THREAD_ID, Long.valueOf(threadId));
                values.put("m_type", (Integer) 128);
                if (textOnly) {
                    values.put("text_only", (Integer) 1);
                }
                mmsUri = SqliteWrapper.insert(this.mActivity, this.mContentResolver, Telephony.Mms.Outbox.CONTENT_URI, values);
            }
            this.mStatusListener.onMessageSent();
            UserHappinessSignals.userAcceptedImeText(this.mActivity);
            cursor = SqliteWrapper.query(this.mActivity, this.mContentResolver, Telephony.Mms.Outbox.CONTENT_URI, MMS_OUTBOX_PROJECTION, (String) null, (String[]) null, (String) null);
            if (cursor != null) {
                long maxMessageSize = MmsConfig.getMaxSizeScaleForPendingMmsAllowed() * MmsConfig.getMaxMessageSize();
                long totalPendingSize = 0;
                while (cursor.moveToNext()) {
                    totalPendingSize += cursor.getLong(1);
                }
                if (totalPendingSize >= maxMessageSize) {
                    unDiscard();
                    this.mStatusListener.onMaxPendingMessagesReached();
                    markMmsMessageWithError(mmsUri);
                    if (cursor != null) {
                        cursor.close();
                        return;
                    }
                    return;
                }
            }
            if (cursor != null) {
                cursor.close();
            }
            try {
                if (newMessage) {
                    mmsUri = createDraftMmsMessage(persister, sendReq, slideshow, mmsUri, this.mActivity, null);
                } else {
                    updateDraftMmsMessage(mmsUri, persister, slideshow, sendReq, null);
                }
                deleteDraftSmsMessage(threadId);
                DraftCache.getInstance().setSavingDraft(false);
                int error = 0;
                try {
                    slideshow.finalResize(mmsUri);
                } catch (ExceedMessageSizeException e) {
                    error = -2;
                } catch (MmsException e2) {
                    error = -1;
                }
                if (error != 0) {
                    markMmsMessageWithError(mmsUri);
                    this.mStatusListener.onAttachmentError(error);
                    return;
                }
                ContentValues values2 = new ContentValues(1);
                if (TelephonyManager.getDefault().getPhoneCount() > 1) {
                    values2.put("phone_id", Integer.valueOf(mCurrentConvPhoneId));
                } else {
                    values2.put("phone_id", Integer.valueOf(SubscriptionManager.getPhoneId(SubscriptionManager.getDefaultDataSubId())));
                }
                SqliteWrapper.update(this.mActivity, this.mContentResolver, mmsUri, values2, (String) null, (String[]) null);
                MessageSender sender = new MmsMessageSender(this.mActivity, mmsUri, slideshow.getCurrentMessageSize(), mCurrentConvPhoneId);
                try {
                    if (!sender.sendMessage(threadId)) {
                        SqliteWrapper.delete(this.mActivity, this.mContentResolver, mmsUri, (String) null, (String[]) null);
                    }
                    Recycler.getMmsRecycler().deleteOldMessagesByThreadId(this.mActivity, threadId);
                } catch (Exception e3) {
                    Log.e("Mms", "Failed to send message: " + mmsUri + ", threadId=" + threadId, e3);
                }
                if (forwardMessage && sameRecipient) {
                    MessageUtils.sSameRecipientList.remove(Long.valueOf(threadId));
                }
                MmsWidgetProvider.notifyDatasetChanged(this.mActivity);
            } catch (Throwable th) {
                DraftCache.getInstance().setSavingDraft(false);
                throw th;
            }
        } catch (Throwable th2) {
            if (cursor != null) {
                cursor.close();
            }
            throw th2;
        }
    }

    private void markMmsMessageWithError(Uri mmsUri) {
        try {
            PduPersister p = PduPersister.getPduPersister(this.mActivity);
            p.move(mmsUri, Telephony.Mms.Outbox.CONTENT_URI);
            ContentValues values = new ContentValues(1);
            values.put("err_type", (Integer) 10);
            long msgId = ContentUris.parseId(mmsUri);
            SqliteWrapper.update(this.mActivity, this.mContentResolver, Telephony.MmsSms.PendingMessages.CONTENT_URI, values, "msg_id=" + msgId, (String[]) null);
        } catch (MmsException e) {
            Log.e("Mms", "Failed to move message to outbox and mark as error: " + mmsUri, e);
        }
    }

    private static Uri readDraftMmsMessage(Context context, Conversation conv, StringBuilder sb) {
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.debug("readDraftMmsMessage conv: ***", new Object[0]);
            } else {
                LogTag.debug("readDraftMmsMessage conv: " + conv, new Object[0]);
            }
        }
        ContentResolver cr = context.getContentResolver();
        String selection = "thread_id = " + conv.getThreadId();
        Cursor cursor = SqliteWrapper.query(context, cr, Telephony.Mms.Draft.CONTENT_URI, MMS_DRAFT_PROJECTION, selection, (String[]) null, (String) null);
        if (cursor == null) {
            return null;
        }
        try {
            if (!cursor.moveToFirst()) {
                return null;
            }
            Uri uri = ContentUris.withAppendedId(Telephony.Mms.Draft.CONTENT_URI, cursor.getLong(0));
            String subject = MessageUtils.extractEncStrFromCursor(cursor, 1, 2);
            if (subject != null) {
                sb.append(subject);
            }
            if (Log.isLoggable("Mms", 2)) {
                LogTag.debug("readDraftMmsMessage uri: ", uri);
            }
            return uri;
        } finally {
            cursor.close();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static SendReq makeSendReq(Conversation conv, CharSequence subject) {
        String[] dests = conv.getRecipients().getNumbers(true);
        SendReq req = new SendReq();
        EncodedStringValue[] encodedNumbers = EncodedStringValue.encodeStrings(dests);
        if (encodedNumbers != null) {
            req.setTo(encodedNumbers);
        }
        if (!TextUtils.isEmpty(subject)) {
            req.setSubject(new EncodedStringValue(subject.toString()));
        }
        req.setDate(System.currentTimeMillis() / 1000);
        return req;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Uri createDraftMmsMessage(PduPersister persister, SendReq sendReq, SlideshowModel slideshow, Uri preUri, Context context, HashMap<Uri, InputStream> preOpenedFiles) {
        if (slideshow == null) {
            return null;
        }
        try {
            PduBody pb = slideshow.toPduBody();
            sendReq.setBody(pb);
            Uri uriPersist = persister.persist(sendReq, preUri == null ? Telephony.Mms.Draft.CONTENT_URI : preUri, true, MessagingPreferenceActivity.getIsGroupMmsEnabled(context), preOpenedFiles);
            slideshow.sync(pb);
            return uriPersist;
        } catch (IllegalStateException e) {
            Log.e("Mms", "failed to create draft mms " + e);
            return null;
        } catch (MmsException e2) {
            return null;
        }
    }

    private void asyncUpdateDraftMmsMessage(final Conversation conv, final boolean isStopping) {
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.debug("asyncUpdateDraftMmsMessage conv=%s mMessageUri=%s", "***", "***");
            } else {
                LogTag.debug("asyncUpdateDraftMmsMessage conv=%s mMessageUri=%s", conv, this.mMessageUri);
            }
        }
        final HashMap<Uri, InputStream> preOpenedFiles = this.mSlideshow.openPartFiles(this.mContentResolver);
        new Thread(new Runnable() { // from class: com.android.mms.data.WorkingMessage.3
            @Override // java.lang.Runnable
            public void run() {
                try {
                    DraftCache.getInstance().setSavingDraft(true);
                    PduPersister persister = PduPersister.getPduPersister(WorkingMessage.this.mActivity);
                    SendReq sendReq = WorkingMessage.makeSendReq(conv, WorkingMessage.this.mSubject);
                    if (WorkingMessage.this.mMessageUri != null) {
                        WorkingMessage.updateDraftMmsMessage(WorkingMessage.this.mMessageUri, persister, WorkingMessage.this.mSlideshow, sendReq, preOpenedFiles);
                    } else {
                        WorkingMessage.this.mMessageUri = WorkingMessage.createDraftMmsMessage(persister, sendReq, WorkingMessage.this.mSlideshow, null, WorkingMessage.this.mActivity, preOpenedFiles);
                    }
                    WorkingMessage.this.ensureThreadIdIfNeeded(conv, isStopping);
                    conv.setDraftState(true);
                    if (Log.isLoggable("Mms", 2)) {
                        if (!WorkingMessage.FJ_TEL_LOG_ACQ_FLG) {
                            LogTag.debug("asyncUpdateDraftMmsMessage conv: " + conv + " uri: " + WorkingMessage.this.mMessageUri, new Object[0]);
                        } else {
                            LogTag.debug("asyncUpdateDraftMmsMessage conv: *** uri: ***", new Object[0]);
                        }
                    }
                    WorkingMessage.this.asyncDeleteDraftSmsMessage(conv);
                } finally {
                    DraftCache.getInstance().setSavingDraft(false);
                    WorkingMessage.closePreOpenedFiles(preOpenedFiles);
                }
            }
        }, "WorkingMessage.asyncUpdateDraftMmsMessage").start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void updateDraftMmsMessage(Uri uri, PduPersister persister, SlideshowModel slideshow, SendReq sendReq, HashMap<Uri, InputStream> preOpenedFiles) {
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("updateDraftMmsMessage uri=%s", uri);
        }
        if (uri == null) {
            Log.e("Mms", "updateDraftMmsMessage null uri");
            return;
        }
        persister.updateHeaders(uri, sendReq);
        PduBody pb = slideshow.toPduBody();
        try {
            persister.updateParts(uri, pb, preOpenedFiles);
        } catch (MmsException e) {
            Log.e("Mms", "updateDraftMmsMessage: cannot update message " + uri);
        }
        slideshow.sync(pb);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void closePreOpenedFiles(HashMap<Uri, InputStream> preOpenedFiles) {
        if (preOpenedFiles != null) {
            Set<Uri> uris = preOpenedFiles.keySet();
            for (Uri uri : uris) {
                InputStream is = preOpenedFiles.get(uri);
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                    }
                }
            }
        }
    }

    private String readDraftSmsMessage(Conversation conv) {
        long thread_id = conv.getThreadId();
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.d("Mms", "readDraftSmsMessage conv: ***");
            } else {
                Log.d("Mms", "readDraftSmsMessage conv: " + conv);
            }
        }
        if (thread_id <= 0 || !conv.hasDraft()) {
            return LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        Uri thread_uri = ContentUris.withAppendedId(Telephony.Sms.Conversations.CONTENT_URI, thread_id);
        String body = LoggingEvents.EXTRA_CALLING_APP_NAME;
        Cursor c = SqliteWrapper.query(this.mActivity, this.mContentResolver, thread_uri, SMS_BODY_PROJECTION, SMS_DRAFT_WHERE, (String[]) null, (String) null);
        boolean haveDraft = false;
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    body = c.getString(0);
                    haveDraft = true;
                }
                c.close();
            } catch (Throwable th) {
                c.close();
                throw th;
            }
        }
        if (haveDraft && conv.getMessageCount() == 0) {
            asyncDeleteDraftSmsMessage(conv);
            clearConversation(conv, true);
        }
        if (Log.isLoggable("Mms", 2)) {
            Object[] objArr = new Object[1];
            objArr[0] = Boolean.valueOf(!TextUtils.isEmpty(body));
            LogTag.debug("readDraftSmsMessage haveDraft: ", objArr);
            return body;
        }
        return body;
    }

    public void clearConversation(Conversation conv, boolean resetThreadId) {
        if (resetThreadId && conv.getMessageCount() == 0) {
            conv.clearThreadId();
        }
        conv.setDraftState(false);
    }

    public void clearConversation(Conversation conv, boolean resetThreadId, boolean changeDraftState) {
        if (resetThreadId && conv.getMessageCount() == 0) {
            conv.clearThreadId();
        }
        Log.d("Mms", "WorkingMessage | clearConversation changeDraftState:" + changeDraftState);
        if (changeDraftState) {
            conv.setDraftState(false);
        }
    }

    private void asyncUpdateDraftSmsMessage(final Conversation conv, final String contents, final boolean isStopping) {
        new Thread(new Runnable() { // from class: com.android.mms.data.WorkingMessage.4
            @Override // java.lang.Runnable
            public void run() {
                try {
                    DraftCache.getInstance().setSavingDraft(true);
                    if (!conv.getRecipients().isEmpty()) {
                        WorkingMessage.this.ensureThreadIdIfNeeded(conv, isStopping);
                        conv.setDraftState(true);
                        WorkingMessage.this.updateDraftSmsMessage(conv, contents);
                    } else {
                        if (Log.isLoggable("Mms", 2)) {
                            LogTag.debug("asyncUpdateDraftSmsMessage no recipients, not saving", new Object[0]);
                        }
                    }
                } finally {
                    DraftCache.getInstance().setSavingDraft(false);
                }
            }
        }, "WorkingMessage.asyncUpdateDraftSmsMessage").start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateDraftSmsMessage(Conversation conv, String contents) {
        long threadId = conv.getThreadId();
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.debug("updateDraftSmsMessage tid=%d, contents=\"%s\"", Long.valueOf(threadId), "***");
            } else {
                LogTag.debug("updateDraftSmsMessage tid=%d, contents=\"%s\"", Long.valueOf(threadId), contents);
            }
        }
        if (threadId > 0) {
            ContentValues values = new ContentValues(3);
            values.put(ComposeMessageActivity.THREAD_ID, Long.valueOf(threadId));
            values.put("body", contents);
            values.put("type", (Integer) 3);
            SqliteWrapper.insert(this.mActivity, this.mContentResolver, Telephony.Sms.CONTENT_URI, values);
            this.mMessageUri = null;
        }
    }

    private void asyncDelete(final Uri uri, final String selection, final String[] selectionArgs) {
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("asyncDelete %s where %s", uri, selection);
        }
        new Thread(new Runnable() { // from class: com.android.mms.data.WorkingMessage.5
            @Override // java.lang.Runnable
            public void run() {
                SqliteWrapper.delete(WorkingMessage.this.mActivity, WorkingMessage.this.mContentResolver, uri, selection, selectionArgs);
            }
        }, "WorkingMessage.asyncDelete").start();
    }

    public void asyncDeleteDraftSmsMessage(Conversation conv) {
        this.mHasSmsDraft = false;
        long threadId = conv.getThreadId();
        if (threadId > 0) {
            asyncDelete(ContentUris.withAppendedId(Telephony.Sms.Conversations.CONTENT_URI, threadId), SMS_DRAFT_WHERE, null);
        }
    }

    private void deleteDraftSmsMessage(long threadId) {
        SqliteWrapper.delete(this.mActivity, this.mContentResolver, ContentUris.withAppendedId(Telephony.Sms.Conversations.CONTENT_URI, threadId), SMS_DRAFT_WHERE, (String[]) null);
    }

    private void asyncDeleteDraftMmsMessage(Conversation conv) {
        this.mHasMmsDraft = false;
        long threadId = conv.getThreadId();
        String where = ComposeMessageActivity.THREAD_ID + (threadId > 0 ? " = " + threadId : " IS NULL");
        asyncDelete(Telephony.Mms.Draft.CONTENT_URI, where, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void ensureThreadIdIfNeeded(Conversation conv, boolean isStopping) {
        if (isStopping && conv.getMessageCount() == 0) {
            conv.clearThreadId();
        }
        if (!conv.getRecipients().isEmpty()) {
            conv.ensureThreadId();
        }
    }

    public void sendFailedMessage(final String recipientsInUI, final long timeStamp) {
        this.mConversation.getThreadId();
        removeSubjectIfEmpty(true);
        prepareForSave(true);
        final Conversation conv = this.mConversation;
        String msgTxt = this.mText.toString();
        if (requiresMms() || addressContainsEmailToMms(conv, msgTxt)) {
            if (MmsConfig.getUaProfUrl() == null) {
                RuntimeException ex = new ContentRestrictionException("WorkingMessage.send MMS sending failure. mms_config.xml is missing uaProfUrl setting.  uaProfUrl is required for MMS service, but can be absent for SMS.");
                Log.e("Mms", "WorkingMessage.send MMS sending failure. mms_config.xml is missing uaProfUrl setting.  uaProfUrl is required for MMS service, but can be absent for SMS.", ex);
                throw ex;
            }
            Uri uri = this.mMessageUri;
            PduPersister.getPduPersister(this.mActivity);
            final SlideshowModel slideshow = this.mSlideshow;
            final CharSequence subject = this.mSubject;
            new Thread(new Runnable() { // from class: com.android.mms.data.WorkingMessage.6
                @Override // java.lang.Runnable
                public void run() {
                    WorkingMessage.makeSendReq(conv, subject, timeStamp);
                    slideshow.prepareForSend();
                    WorkingMessage.this.updateSendStats(conv);
                }
            }).start();
        } else {
            final String msgText = this.mText.toString();
            new Thread(new Runnable() { // from class: com.android.mms.data.WorkingMessage.7
                /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
                @Override // java.lang.Runnable
                public void run() throws MmsException {
                    WorkingMessage.this.preSendSmsWorker(conv, msgText, recipientsInUI, timeStamp);
                    WorkingMessage.this.updateSendStats(conv);
                }
            }).start();
        }
        RecipientIdCache.updateNumbers(conv.getThreadId(), conv.getRecipients());
        this.mDiscarded = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public void preSendSmsWorker(Conversation conv, String msgText, String recipientsInUI, long timeStamp) throws MmsException {
        UserHappinessSignals.userAcceptedImeText(this.mActivity);
        this.mStatusListener.onPreMessageSent();
        long threadId = conv.ensureThreadId();
        sendSmsWorker(msgText, recipientsInUI, threadId, timeStamp);
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private void sendSmsWorker(String msgText, String semiSepRecipients, long threadId, long timeStamp) throws MmsException {
        String[] dests = TextUtils.split(semiSepRecipients, MessageSender.RECIPIENTS_SEPARATOR);
        if (Log.isLoggable("Mms", 2)) {
            Log.d("Mms", "sendSmsWorker sending message: recipients=" + semiSepRecipients + ", threadId=" + threadId);
        }
        MessageSender sender = new SmsMessageSender(this.mActivity, dests, msgText, threadId, timeStamp);
        try {
            sender.sendMessage(threadId);
            Recycler.getSmsRecycler().deleteOldMessagesByThreadId(this.mActivity, threadId);
        } catch (Exception e) {
            Log.e("Mms", "Failed to send SMS message, threadId=" + threadId, e);
        }
        this.mStatusListener.onMessageSent();
    }

    public void changeFailedMessageToDraft(long msgId) {
        ContentValues values = new ContentValues(1);
        values.put("type", (Integer) 3);
        SqliteWrapper.update(this.mActivity, this.mContentResolver, Telephony.Sms.CONTENT_URI, values, "_id=" + msgId, (String[]) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static SendReq makeSendReq(Conversation conv, CharSequence subject, long time) {
        String[] dests = conv.getRecipients().getNumbers(true);
        SendReq req = new SendReq();
        EncodedStringValue[] encodedNumbers = EncodedStringValue.encodeStrings(dests);
        if (encodedNumbers != null) {
            req.setTo(encodedNumbers);
        }
        if (!TextUtils.isEmpty(subject)) {
            req.setSubject(new EncodedStringValue(subject.toString()));
        }
        req.setDate(time / 1000);
        return req;
    }
}
