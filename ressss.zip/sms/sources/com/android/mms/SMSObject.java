package com.android.mms;

import java.io.Serializable;

/* JADX INFO: compiled from: QTIBackupSMS.java */
/* JADX INFO: loaded from: classes.dex */
class SMSObject implements Serializable {
    private String addr;
    private String id;
    private String msg;
    private String readState;
    private String time;

    SMSObject() {
    }

    String getId() {
        return this.id;
    }

    String getAddr() {
        return this.addr;
    }

    String getMsg() {
        return this.msg;
    }

    String getReadState() {
        return this.readState;
    }

    String getTime() {
        return this.time;
    }

    void setId(String id) {
        this.id = id;
    }

    void setAddr(String addr) {
        this.addr = addr;
    }

    void setMsg(String msg) {
        this.msg = msg;
    }

    void setReadState(String readState) {
        this.readState = readState;
    }

    void setTime(String time) {
        this.time = time;
    }
}
