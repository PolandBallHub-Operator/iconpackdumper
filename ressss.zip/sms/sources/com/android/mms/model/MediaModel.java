package com.android.mms.model;

import android.content.ContentResolver;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.util.Log;
import com.android.mms.MmsConfig;
import com.google.android.mms.MmsException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import org.w3c.dom.events.EventListener;

/* JADX INFO: loaded from: classes.dex */
public abstract class MediaModel extends Model implements EventListener {
    protected static final String TAG = "Mms";
    protected int mBegin;
    protected String mContentType;
    protected Context mContext;
    private byte[] mData;
    protected int mDuration;
    protected short mFill;
    private final ArrayList<MediaAction> mMediaActions;
    protected boolean mMediaResizeable;
    protected int mSeekTo;
    protected int mSize;
    protected String mSrc;
    protected String mTag;
    private Uri mUri;

    public enum MediaAction {
        NO_ACTIVE_ACTION,
        START,
        STOP,
        PAUSE,
        SEEK
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public MediaModel(Context context, String tag, String contentType, String src, Uri uri) throws MmsException {
        this.mContext = context;
        this.mTag = tag;
        this.mContentType = contentType;
        this.mSrc = src;
        this.mUri = uri;
        initMediaSize();
        this.mMediaActions = new ArrayList<>();
    }

    public MediaModel(Context context, String tag, String contentType, String src, byte[] data) {
        if (data == null) {
            throw new IllegalArgumentException("data may not be null.");
        }
        this.mContext = context;
        this.mTag = tag;
        this.mContentType = contentType;
        this.mSrc = src;
        this.mData = data;
        this.mSize = data.length;
        this.mMediaActions = new ArrayList<>();
    }

    public int getBegin() {
        return this.mBegin;
    }

    public void setBegin(int begin) {
        this.mBegin = begin;
        notifyModelChanged(true);
    }

    public int getDuration() {
        return this.mDuration;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public void setDuration(int duration) throws IOException {
        if (isPlayable() && duration < 0) {
            try {
                initMediaDuration();
            } catch (MmsException e) {
                Log.e("Mms", e.getMessage(), e);
                return;
            }
        } else {
            this.mDuration = duration;
        }
        notifyModelChanged(true);
    }

    public String getTag() {
        return this.mTag;
    }

    public String getContentType() {
        return this.mContentType;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public byte[] getData() {
        if (this.mData == null) {
            return null;
        }
        byte[] data = new byte[this.mData.length];
        System.arraycopy(this.mData, 0, data, 0, this.mData.length);
        return data;
    }

    void setUri(Uri uri) {
        this.mUri = uri;
    }

    public String getSrc() {
        return this.mSrc;
    }

    public short getFill() {
        return this.mFill;
    }

    public void setFill(short fill) {
        this.mFill = fill;
        notifyModelChanged(true);
    }

    public boolean getMediaResizable() {
        return this.mMediaResizeable;
    }

    public int getMediaSize() {
        return this.mSize;
    }

    public boolean isText() {
        return this.mTag.equals(SmilHelper.ELEMENT_TAG_TEXT);
    }

    public boolean isImage() {
        return this.mTag.equals(SmilHelper.ELEMENT_TAG_IMAGE);
    }

    public boolean isVideo() {
        return this.mTag.equals(SmilHelper.ELEMENT_TAG_VIDEO);
    }

    public boolean isAudio() {
        return this.mTag.equals(SmilHelper.ELEMENT_TAG_AUDIO);
    }

    protected void initMediaDuration() throws MmsException, IOException {
        if (this.mUri == null) {
            throw new IllegalArgumentException("Uri may not be null.");
        }
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        int duration = 0;
        try {
            try {
                retriever.setDataSource(this.mContext, this.mUri);
                String dur = retriever.extractMetadata(9);
                if (dur != null) {
                    duration = Integer.parseInt(dur);
                }
                this.mDuration = duration;
                retriever.release();
            } catch (Exception ex) {
                Log.e("Mms", "MediaMetadataRetriever failed to get duration for " + this.mUri.getPath(), ex);
                throw new MmsException(ex);
            }
        } catch (Throwable th) {
            retriever.release();
            throw th;
        }
    }

    private void initMediaSize() throws MmsException {
        ContentResolver cr = this.mContext.getContentResolver();
        InputStream input = null;
        try {
            try {
                InputStream input2 = cr.openInputStream(this.mUri);
                if (input2 instanceof FileInputStream) {
                    FileInputStream f = (FileInputStream) input2;
                    this.mSize = (int) f.getChannel().size();
                    if (isVideo() && this.mSize > MmsConfig.getMaxMessageSize()) {
                        Log.w("Mms", "initMediaSize: Video size: f.getChannel().size(): " + this.mSize + " larger than max message size: " + MmsConfig.getMaxMessageSize());
                    }
                } else {
                    while (-1 != input2.read()) {
                        this.mSize++;
                    }
                }
                if (input2 != null) {
                    try {
                        input2.close();
                    } catch (IOException e) {
                        Log.e("Mms", "IOException caught while closing stream", e);
                    }
                }
            } catch (IOException e2) {
                Log.e("Mms", "IOException caught while opening or reading stream", e2);
                if (e2 instanceof FileNotFoundException) {
                    throw new MmsException(e2.getMessage());
                }
                if (0 != 0) {
                    try {
                        input.close();
                    } catch (IOException e3) {
                        Log.e("Mms", "IOException caught while closing stream", e3);
                    }
                }
            }
        } catch (Throwable th) {
            if (0 != 0) {
                try {
                    input.close();
                } catch (IOException e4) {
                    Log.e("Mms", "IOException caught while closing stream", e4);
                }
            }
            throw th;
        }
    }

    public static boolean isMmsUri(Uri uri) {
        return uri.getAuthority().startsWith("mms");
    }

    public int getSeekTo() {
        return this.mSeekTo;
    }

    public void appendAction(MediaAction action) {
        this.mMediaActions.add(action);
    }

    public MediaAction getCurrentAction() {
        return this.mMediaActions.size() == 0 ? MediaAction.NO_ACTIVE_ACTION : this.mMediaActions.remove(0);
    }

    protected boolean isPlayable() {
        return false;
    }

    protected void pauseMusicPlayer() {
        if (Log.isLoggable("Mms", 2)) {
            Log.d("Mms", "pauseMusicPlayer");
        }
        AudioManager am = (AudioManager) this.mContext.getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
        am.requestAudioFocus(null, 3, 1);
    }

    protected void resizeMedia(int byteLimit, long messageId) throws MmsException {
    }
}
