package com.android.mms.model;

import android.drm.DrmManagerClient;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.MmsApp;
import com.android.mms.dom.smil.SmilDocumentImpl;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.dom.smil.SmilParElementImpl;
import com.android.mms.dom.smil.parser.SmilXmlParser;
import com.google.android.mms.ContentType;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.PduBody;
import com.google.android.mms.pdu.PduPart;
import com.nextfp.android.util.NfpSharedResources;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import org.w3c.dom.Node;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.SMILLayoutElement;
import org.w3c.dom.smil.SMILMediaElement;
import org.w3c.dom.smil.SMILParElement;
import org.w3c.dom.smil.SMILRegionElement;
import org.w3c.dom.smil.SMILRegionMediaElement;
import org.w3c.dom.smil.SMILRootLayoutElement;
import org.xml.sax.SAXException;

/* JADX INFO: loaded from: classes.dex */
public class SmilHelper {
    private static final boolean DEBUG = false;
    public static final String ELEMENT_TAG_AUDIO = "audio";
    public static final String ELEMENT_TAG_IMAGE = "img";
    public static final String ELEMENT_TAG_REF = "ref";
    public static final String ELEMENT_TAG_TEXT = "text";
    public static final String ELEMENT_TAG_VIDEO = "video";
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";

    private SmilHelper() {
    }

    public static SMILDocument getDocument(PduBody pb) {
        PduPart smilPart = findSmilPart(pb);
        SMILDocument document = null;
        if (smilPart != null) {
            document = getSmilDocument(smilPart);
        }
        if (document == null) {
            SMILDocument document2 = createSmilDocument(pb);
            return document2;
        }
        return document;
    }

    public static SMILDocument getDocument(SlideshowModel model) {
        return createSmilDocument(model);
    }

    private static PduPart findSmilPart(PduBody body) {
        int partNum = body.getPartsNum();
        for (int i = 0; i < partNum; i++) {
            PduPart part = body.getPart(i);
            if (Arrays.equals(part.getContentType(), "application/smil".getBytes())) {
                return part;
            }
        }
        return null;
    }

    private static SMILDocument validate(SMILDocument in) {
        return in;
    }

    private static SMILDocument getSmilDocument(PduPart smilPart) {
        try {
            byte[] data = smilPart.getData();
            if (data != null) {
                ByteArrayInputStream bais = new ByteArrayInputStream(data);
                SMILDocument document = new SmilXmlParser().parse(bais);
                return validate(document);
            }
        } catch (MmsException e) {
            Log.e("Mms", "Failed to parse SMIL document.", e);
        } catch (IOException e2) {
            Log.e("Mms", "Failed to parse SMIL document.", e2);
        } catch (SAXException e3) {
            Log.e("Mms", "Failed to parse SMIL document.", e3);
        }
        return null;
    }

    public static SMILParElement addPar(SMILDocument document) {
        SMILParElement par = (SMILParElement) document.createElement("par");
        par.setDur(8.0f);
        document.getBody().appendChild(par);
        return par;
    }

    public static SMILMediaElement createMediaElement(String tag, SMILDocument document, String src) {
        SMILMediaElement mediaElement = (SMILMediaElement) document.createElement(tag);
        mediaElement.setSrc(escapeXML(src));
        return mediaElement;
    }

    public static String escapeXML(String str) {
        return str.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&apos;");
    }

    private static SMILDocument createSmilDocument(PduBody pb) {
        SmilDocumentImpl smilDocumentImpl = new SmilDocumentImpl();
        SMILElement smil = (SMILElement) smilDocumentImpl.createElement("smil");
        smil.setAttribute("xmlns", "http://www.w3.org/2001/SMIL20/Language");
        smilDocumentImpl.appendChild(smil);
        SMILElement head = (SMILElement) smilDocumentImpl.createElement("head");
        smil.appendChild(head);
        SMILLayoutElement layout = (SMILLayoutElement) smilDocumentImpl.createElement(NfpSharedResources.DEFTYPE_LAYOUT);
        head.appendChild(layout);
        SMILElement body = (SMILElement) smilDocumentImpl.createElement("body");
        smil.appendChild(body);
        SMILParElement par = addPar(smilDocumentImpl);
        int partsNum = pb.getPartsNum();
        if (partsNum != 0) {
            DrmManagerClient drmManagerClient = MmsApp.getApplication().getDrmManagerClient();
            boolean hasText = false;
            boolean hasMedia = false;
            for (int i = 0; i < partsNum; i++) {
                if (par == null || (hasMedia && hasText)) {
                    par = addPar(smilDocumentImpl);
                    hasText = false;
                    hasMedia = false;
                }
                PduPart part = pb.getPart(i);
                String contentType = new String(part.getContentType());
                if (ContentType.isDrmType(contentType)) {
                    contentType = drmManagerClient.getOriginalMimeType(part.getDataUri());
                }
                if (contentType.equals("text/plain") || contentType.equalsIgnoreCase("application/vnd.wap.xhtml+xml") || contentType.equals("text/html")) {
                    SMILMediaElement textElement = createMediaElement(ELEMENT_TAG_TEXT, smilDocumentImpl, part.generateLocation());
                    par.appendChild(textElement);
                    hasText = true;
                } else if (ContentType.isImageType(contentType)) {
                    SMILMediaElement imageElement = createMediaElement(ELEMENT_TAG_IMAGE, smilDocumentImpl, part.generateLocation());
                    par.appendChild(imageElement);
                    hasMedia = true;
                } else if (ContentType.isVideoType(contentType)) {
                    SMILMediaElement videoElement = createMediaElement(ELEMENT_TAG_VIDEO, smilDocumentImpl, part.generateLocation());
                    par.appendChild(videoElement);
                    hasMedia = true;
                } else if (ContentType.isAudioType(contentType)) {
                    SMILMediaElement audioElement = createMediaElement(ELEMENT_TAG_AUDIO, smilDocumentImpl, part.generateLocation());
                    par.appendChild(audioElement);
                    hasMedia = true;
                } else {
                    Log.w("Mms", "unsupport media type");
                }
            }
        }
        return smilDocumentImpl;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0166  */
    /* JADX WARN: Code duplicated, block: B:25:0x017f  */
    private static SMILDocument createSmilDocument(SlideshowModel slideshow) {
        SMILMediaElement sme;
        int begin;
        int duration;
        SmilDocumentImpl smilDocumentImpl = new SmilDocumentImpl();
        SMILElement sMILElement = (SMILElement) smilDocumentImpl.createElement("smil");
        smilDocumentImpl.appendChild(sMILElement);
        SMILElement sMILElement2 = (SMILElement) smilDocumentImpl.createElement("head");
        sMILElement.appendChild(sMILElement2);
        SMILLayoutElement layoutElement = (SMILLayoutElement) smilDocumentImpl.createElement(NfpSharedResources.DEFTYPE_LAYOUT);
        sMILElement2.appendChild(layoutElement);
        SMILRootLayoutElement rootLayoutElement = (SMILRootLayoutElement) smilDocumentImpl.createElement("root-layout");
        LayoutModel layouts = slideshow.getLayout();
        rootLayoutElement.setWidth(layouts.getLayoutWidth());
        rootLayoutElement.setHeight(layouts.getLayoutHeight());
        String bgColor = layouts.getBackgroundColor();
        if (!TextUtils.isEmpty(bgColor)) {
            rootLayoutElement.setBackgroundColor(bgColor);
        }
        layoutElement.appendChild(rootLayoutElement);
        ArrayList<RegionModel> regions = layouts.getRegions();
        ArrayList<SMILRegionElement> smilRegions = new ArrayList<>();
        for (RegionModel r : regions) {
            SMILRegionElement smilRegion = (SMILRegionElement) smilDocumentImpl.createElement("region");
            smilRegion.setId(r.getRegionId());
            smilRegion.setLeft(r.getLeft());
            smilRegion.setTop(r.getTop());
            smilRegion.setWidth(r.getWidth());
            smilRegion.setHeight(r.getHeight());
            smilRegion.setFit(r.getFit());
            smilRegions.add(smilRegion);
        }
        Node bodyElement = (SMILElement) smilDocumentImpl.createElement("body");
        sMILElement.appendChild(bodyElement);
        for (SlideModel slide : slideshow) {
            boolean txtRegionPresentInLayout = false;
            boolean imgRegionPresentInLayout = false;
            SMILParElement par = addPar(smilDocumentImpl);
            par.setDur(slide.getDuration() / 1000.0f);
            addParElementEventListeners((EventTarget) par, slide);
            for (MediaModel media : slide) {
                String src = media.getSrc();
                if (media instanceof TextModel) {
                    TextModel text = (TextModel) media;
                    if (!TextUtils.isEmpty(text.getText())) {
                        sme = createMediaElement(ELEMENT_TAG_TEXT, smilDocumentImpl, src);
                        txtRegionPresentInLayout = setRegion((SMILRegionMediaElement) sme, smilRegions, layoutElement, LayoutModel.TEXT_REGION_ID, txtRegionPresentInLayout);
                        begin = media.getBegin();
                        if (begin != 0) {
                            sme.setAttribute("begin", String.valueOf(begin / 1000));
                        }
                        duration = media.getDuration();
                        if (duration != 0) {
                            sme.setDur(duration / 1000.0f);
                        }
                        par.appendChild(sme);
                        addMediaElementEventListeners((EventTarget) sme, media);
                    }
                } else {
                    if (media instanceof ImageModel) {
                        sme = createMediaElement(ELEMENT_TAG_IMAGE, smilDocumentImpl, src);
                        imgRegionPresentInLayout = setRegion((SMILRegionMediaElement) sme, smilRegions, layoutElement, LayoutModel.IMAGE_REGION_ID, imgRegionPresentInLayout);
                    } else if (media instanceof VideoModel) {
                        sme = createMediaElement(ELEMENT_TAG_VIDEO, smilDocumentImpl, src);
                        imgRegionPresentInLayout = setRegion((SMILRegionMediaElement) sme, smilRegions, layoutElement, LayoutModel.IMAGE_REGION_ID, imgRegionPresentInLayout);
                    } else if (media instanceof AudioModel) {
                        sme = createMediaElement(ELEMENT_TAG_AUDIO, smilDocumentImpl, src);
                    } else {
                        Log.w("Mms", "Unsupport media: " + media);
                    }
                    begin = media.getBegin();
                    if (begin != 0) {
                        sme.setAttribute("begin", String.valueOf(begin / 1000));
                    }
                    duration = media.getDuration();
                    if (duration != 0) {
                        sme.setDur(duration / 1000.0f);
                    }
                    par.appendChild(sme);
                    addMediaElementEventListeners((EventTarget) sme, media);
                }
            }
        }
        return smilDocumentImpl;
    }

    private static SMILRegionElement findRegionElementById(ArrayList<SMILRegionElement> smilRegions, String rId) {
        for (SMILRegionElement smilRegion : smilRegions) {
            if (smilRegion.getId().equals(rId)) {
                return smilRegion;
            }
        }
        return null;
    }

    private static boolean setRegion(SMILRegionMediaElement srme, ArrayList<SMILRegionElement> smilRegions, SMILLayoutElement smilLayout, String regionId, boolean regionPresentInLayout) {
        SMILRegionElement smilRegion = findRegionElementById(smilRegions, regionId);
        if (regionPresentInLayout || smilRegion == null) {
            return false;
        }
        srme.setRegion(smilRegion);
        smilLayout.appendChild(smilRegion);
        return true;
    }

    static void addMediaElementEventListeners(EventTarget target, MediaModel media) {
        target.addEventListener(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT, media, false);
        target.addEventListener(SmilMediaElementImpl.SMIL_MEDIA_END_EVENT, media, false);
        target.addEventListener(SmilMediaElementImpl.SMIL_MEDIA_PAUSE_EVENT, media, false);
        target.addEventListener(SmilMediaElementImpl.SMIL_MEDIA_SEEK_EVENT, media, false);
    }

    static void addParElementEventListeners(EventTarget target, SlideModel slide) {
        target.addEventListener(SmilParElementImpl.SMIL_SLIDE_START_EVENT, slide, false);
        target.addEventListener(SmilParElementImpl.SMIL_SLIDE_END_EVENT, slide, false);
    }
}
