package com.android.mms.model;

/* JADX INFO: loaded from: classes.dex */
public interface IModelChangedObserver {
    void onModelChanged(Model model, boolean z);
}
