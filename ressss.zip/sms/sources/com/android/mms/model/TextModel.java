package com.android.mms.model;

import android.content.Context;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.ui.ComposeMessageActivity;
import com.google.android.mms.pdu.CharacterSets;
import java.io.UnsupportedEncodingException;
import org.w3c.dom.events.Event;

/* JADX INFO: loaded from: classes.dex */
public class TextModel extends RegionMediaModel {
    private static final String TAG = "Mms";
    private final int mCharset;
    private CharSequence mText;

    public TextModel(Context context, String contentType, String src, RegionModel region) {
        this(context, contentType, src, ComposeMessageActivity.REQUEST_CODE_CREATE_SLIDESHOW, new byte[0], region);
    }

    public TextModel(Context context, String contentType, String src, int charset, byte[] data, RegionModel region) {
        super(context, SmilHelper.ELEMENT_TAG_TEXT, contentType, src, data != null ? data : new byte[0], region);
        this.mCharset = charset == 0 ? 4 : charset;
        this.mText = extractTextFromData(data);
    }

    private CharSequence extractTextFromData(byte[] data) {
        String str;
        if (data != null) {
            try {
                if (this.mCharset == 0) {
                    str = new String(data);
                } else {
                    String name = CharacterSets.getMimeName(this.mCharset);
                    str = new String(data, name);
                }
                return str;
            } catch (UnsupportedEncodingException e) {
                Log.e("Mms", "Unsupported encoding: " + this.mCharset, e);
                return new String(data);
            }
        }
        return LoggingEvents.EXTRA_CALLING_APP_NAME;
    }

    public String getText() {
        if (this.mText == null) {
            this.mText = extractTextFromData(getData());
        }
        if (!(this.mText instanceof String)) {
            this.mText = this.mText.toString();
        }
        return this.mText.toString();
    }

    public void setText(CharSequence text) {
        this.mText = text;
        notifyModelChanged(true);
    }

    public void cloneText() {
        this.mText = new String(this.mText != null ? this.mText.toString() : LoggingEvents.EXTRA_CALLING_APP_NAME);
    }

    public int getCharset() {
        return this.mCharset;
    }

    @Override // org.w3c.dom.events.EventListener
    public void handleEvent(Event evt) {
        if (evt.getType().equals(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT)) {
            this.mVisible = true;
        } else if (this.mFill != 1) {
            this.mVisible = false;
        }
        notifyModelChanged(false);
    }
}
