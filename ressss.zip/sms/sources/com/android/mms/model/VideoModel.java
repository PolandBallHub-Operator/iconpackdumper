package com.android.mms.model;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.MimeTypeMap;
import com.android.mms.ContentRestrictionException;
import com.android.mms.MmsApp;
import com.android.mms.data.Contact;
import com.android.mms.dom.events.EventImpl;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.util.ItemLoadedCallback;
import com.android.mms.util.ItemLoadedFuture;
import com.android.mms.util.ThumbnailManager;
import com.google.android.mms.MmsException;
import org.w3c.dom.events.Event;

/* JADX INFO: loaded from: classes.dex */
public class VideoModel extends RegionMediaModel {
    private static final boolean DEBUG = true;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private ItemLoadedFuture mItemLoadedFuture;

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public VideoModel(Context context, Uri uri, RegionModel region) throws MmsException {
        this(context, null, null, uri, region);
        initModelFromUri(uri);
        checkContentRestriction();
    }

    public VideoModel(Context context, String contentType, String src, Uri uri, RegionModel region) throws MmsException {
        super(context, SmilHelper.ELEMENT_TAG_VIDEO, contentType, src, uri, region);
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private void initModelFromUri(Uri uri) throws MmsException {
        String scheme = uri.getScheme();
        if (scheme.equals(Contact.CONTENT_SCHEME)) {
            initFromContentUri(uri);
        } else if (uri.getScheme().equals("file")) {
            initFromFile(uri);
        }
        initMediaDuration();
    }

    private void initFromFile(Uri uri) {
        int dotPos;
        String path = uri.getPath();
        this.mSrc = path.substring(path.lastIndexOf(47) + 1);
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        String extension = MimeTypeMap.getFileExtensionFromUrl(this.mSrc);
        if (TextUtils.isEmpty(extension) && (dotPos = this.mSrc.lastIndexOf(46)) >= 0) {
            extension = this.mSrc.substring(dotPos + 1);
        }
        this.mContentType = mimeTypeMap.getMimeTypeFromExtension(extension);
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "New VideoModel initFromFile created: mSrc=" + this.mSrc + " mContentType=" + this.mContentType + " mUri=" + uri);
        }
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private void initFromContentUri(Uri uri) throws MmsException {
        String path;
        ContentResolver cr = this.mContext.getContentResolver();
        Cursor c = SqliteWrapper.query(this.mContext, cr, uri, (String[]) null, (String) null, (String[]) null, (String) null);
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    try {
                        path = c.getString(c.getColumnIndexOrThrow("_data"));
                    } catch (IllegalArgumentException e) {
                        path = uri.toString();
                    }
                    this.mSrc = path.substring(path.lastIndexOf(47) + 1);
                    if (isMmsUri(uri)) {
                        this.mContentType = c.getString(c.getColumnIndexOrThrow("ct"));
                    } else {
                        this.mContentType = c.getString(c.getColumnIndexOrThrow("mime_type"));
                    }
                    if (TextUtils.isEmpty(this.mContentType)) {
                        throw new MmsException("Type of media is unknown.");
                    }
                    if (this.mContentType.equals("video/mp4") && !TextUtils.isEmpty(this.mSrc)) {
                        int index = this.mSrc.lastIndexOf(".");
                        if (index != -1) {
                            try {
                                String extension = this.mSrc.substring(index + 1);
                                if (!TextUtils.isEmpty(extension) && (extension.equalsIgnoreCase("3gp") || extension.equalsIgnoreCase("3gpp") || extension.equalsIgnoreCase("3g2"))) {
                                    this.mContentType = "video/3gpp";
                                }
                            } catch (IndexOutOfBoundsException e2) {
                            }
                        }
                    }
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "New VideoModel initFromContentUri created: mSrc=" + this.mSrc + " mContentType=" + this.mContentType + " mUri=" + uri);
                    }
                    c.close();
                    return;
                }
                throw new MmsException("Nothing found: " + uri);
            } catch (Throwable th) {
                c.close();
                throw th;
            }
        }
        throw new MmsException("Bad URI: " + uri);
    }

    @Override // org.w3c.dom.events.EventListener
    public void handleEvent(Event evt) {
        String evtType = evt.getType();
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "[VideoModel] handleEvent " + evt.getType() + " on " + this);
        }
        MediaModel.MediaAction action = MediaModel.MediaAction.NO_ACTIVE_ACTION;
        if (evtType.equals(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT)) {
            action = MediaModel.MediaAction.START;
            pauseMusicPlayer();
            this.mVisible = true;
        } else if (evtType.equals(SmilMediaElementImpl.SMIL_MEDIA_END_EVENT)) {
            action = MediaModel.MediaAction.STOP;
            if (this.mFill != 1) {
                this.mVisible = false;
            }
        } else if (evtType.equals(SmilMediaElementImpl.SMIL_MEDIA_PAUSE_EVENT)) {
            action = MediaModel.MediaAction.PAUSE;
            this.mVisible = true;
        } else if (evtType.equals(SmilMediaElementImpl.SMIL_MEDIA_SEEK_EVENT)) {
            action = MediaModel.MediaAction.SEEK;
            this.mSeekTo = ((EventImpl) evt).getSeekTo();
            this.mVisible = true;
        }
        appendAction(action);
        notifyModelChanged(false);
    }

    protected void checkContentRestriction() throws ContentRestrictionException {
        ContentRestriction cr = ContentRestrictionFactory.getContentRestriction();
        cr.checkVideoContentType(this.mContentType);
    }

    @Override // com.android.mms.model.MediaModel
    protected boolean isPlayable() {
        return true;
    }

    public ItemLoadedFuture loadThumbnailBitmap(ItemLoadedCallback callback) {
        ThumbnailManager thumbnailManager = MmsApp.getApplication().getThumbnailManager();
        this.mItemLoadedFuture = thumbnailManager.getVideoThumbnail(getUri(), callback);
        return this.mItemLoadedFuture;
    }

    public void cancelThumbnailLoading() {
        if (this.mItemLoadedFuture != null && !this.mItemLoadedFuture.isDone()) {
            if (Log.isLoggable("Mms", 3)) {
                Log.v("Mms", "cancelThumbnailLoading for: " + this);
            }
            this.mItemLoadedFuture.cancel(getUri());
            this.mItemLoadedFuture = null;
        }
    }
}
