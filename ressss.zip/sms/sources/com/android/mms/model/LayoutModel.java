package com.android.mms.model;

import android.util.Log;
import com.android.mms.layout.LayoutManager;
import com.android.mms.layout.LayoutParameters;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class LayoutModel extends Model {
    private static final boolean DEBUG = false;
    public static final int DEFAULT_LAYOUT_TYPE = 0;
    public static final String IMAGE_REGION_ID = "Image";
    public static final int LAYOUT_BOTTOM_TEXT = 0;
    public static final int LAYOUT_TOP_TEXT = 1;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    public static final String TEXT_REGION_ID = "Text";
    private RegionModel mImageRegion;
    private LayoutParameters mLayoutParams;
    private int mLayoutType;
    private ArrayList<RegionModel> mNonStdRegions;
    private RegionModel mRootLayout;
    private RegionModel mTextRegion;

    public LayoutModel() {
        this.mLayoutType = 0;
        this.mLayoutParams = LayoutManager.getInstance().getLayoutParameters();
        createDefaultRootLayout();
        createDefaultImageRegion();
        createDefaultTextRegion();
    }

    public LayoutModel(RegionModel rootLayout, ArrayList<RegionModel> regions) {
        this.mLayoutType = 0;
        this.mLayoutParams = LayoutManager.getInstance().getLayoutParameters();
        this.mRootLayout = rootLayout;
        this.mNonStdRegions = new ArrayList<>();
        for (RegionModel r : regions) {
            String rId = r.getRegionId();
            if (rId.equals(IMAGE_REGION_ID)) {
                this.mImageRegion = r;
            } else if (rId.equals(TEXT_REGION_ID)) {
                this.mTextRegion = r;
            } else {
                this.mNonStdRegions.add(r);
            }
        }
        validateLayouts();
    }

    private void createDefaultRootLayout() {
        this.mRootLayout = new RegionModel(null, 0, 0, this.mLayoutParams.getWidth(), this.mLayoutParams.getHeight());
    }

    private void createDefaultImageRegion() {
        if (this.mRootLayout == null) {
            throw new IllegalStateException("Root-Layout uninitialized.");
        }
        this.mImageRegion = new RegionModel(IMAGE_REGION_ID, 0, 0, this.mRootLayout.getWidth(), this.mLayoutParams.getImageHeight());
    }

    private void createDefaultTextRegion() {
        if (this.mRootLayout == null) {
            throw new IllegalStateException("Root-Layout uninitialized.");
        }
        this.mTextRegion = new RegionModel(TEXT_REGION_ID, 0, this.mLayoutParams.getImageHeight(), this.mRootLayout.getWidth(), this.mLayoutParams.getTextHeight());
    }

    private void validateLayouts() {
        if (this.mRootLayout == null) {
            createDefaultRootLayout();
        }
        if (this.mImageRegion == null) {
            createDefaultImageRegion();
        }
        if (this.mTextRegion == null) {
            createDefaultTextRegion();
        }
        this.mLayoutType = this.mImageRegion.getTop() == 0 ? 0 : 1;
    }

    public RegionModel getRootLayout() {
        return this.mRootLayout;
    }

    public void setRootLayout(RegionModel rootLayout) {
        this.mRootLayout = rootLayout;
    }

    public RegionModel getImageRegion() {
        return this.mImageRegion;
    }

    public void setImageRegion(RegionModel imageRegion) {
        this.mImageRegion = imageRegion;
    }

    public RegionModel getTextRegion() {
        return this.mTextRegion;
    }

    public void setTextRegion(RegionModel textRegion) {
        this.mTextRegion = textRegion;
    }

    public ArrayList<RegionModel> getRegions() {
        ArrayList<RegionModel> regions = new ArrayList<>();
        if (this.mImageRegion != null) {
            regions.add(this.mImageRegion);
        }
        if (this.mTextRegion != null) {
            regions.add(this.mTextRegion);
        }
        return regions;
    }

    public RegionModel findRegionById(String rId) {
        if (IMAGE_REGION_ID.equals(rId)) {
            return this.mImageRegion;
        }
        if (TEXT_REGION_ID.equals(rId)) {
            return this.mTextRegion;
        }
        for (RegionModel r : this.mNonStdRegions) {
            if (r.getRegionId().equals(rId)) {
                return r;
            }
        }
        return null;
    }

    public int getLayoutWidth() {
        return this.mRootLayout.getWidth();
    }

    public int getLayoutHeight() {
        return this.mRootLayout.getHeight();
    }

    public String getBackgroundColor() {
        return this.mRootLayout.getBackgroundColor();
    }

    public void changeTo(int layout) {
        if (this.mRootLayout == null) {
            throw new IllegalStateException("Root-Layout uninitialized.");
        }
        if (this.mLayoutParams == null) {
            this.mLayoutParams = LayoutManager.getInstance().getLayoutParameters();
        }
        if (this.mLayoutType != layout) {
            switch (layout) {
                case 0:
                    this.mImageRegion.setTop(0);
                    this.mTextRegion.setTop(this.mLayoutParams.getImageHeight());
                    this.mLayoutType = layout;
                    notifyModelChanged(true);
                    return;
                case 1:
                    this.mImageRegion.setTop(this.mLayoutParams.getTextHeight());
                    this.mTextRegion.setTop(0);
                    this.mLayoutType = layout;
                    notifyModelChanged(true);
                    return;
                default:
                    Log.w("Mms", "Unknown layout type: " + layout);
                    return;
            }
        }
    }

    public int getLayoutType() {
        return this.mLayoutType;
    }

    @Override // com.android.mms.model.Model
    protected void registerModelChangedObserverInDescendants(IModelChangedObserver observer) {
        if (this.mRootLayout != null) {
            this.mRootLayout.registerModelChangedObserver(observer);
        }
        if (this.mImageRegion != null) {
            this.mImageRegion.registerModelChangedObserver(observer);
        }
        if (this.mTextRegion != null) {
            this.mTextRegion.registerModelChangedObserver(observer);
        }
    }

    @Override // com.android.mms.model.Model
    protected void unregisterModelChangedObserverInDescendants(IModelChangedObserver observer) {
        if (this.mRootLayout != null) {
            this.mRootLayout.unregisterModelChangedObserver(observer);
        }
        if (this.mImageRegion != null) {
            this.mImageRegion.unregisterModelChangedObserver(observer);
        }
        if (this.mTextRegion != null) {
            this.mTextRegion.unregisterModelChangedObserver(observer);
        }
    }

    @Override // com.android.mms.model.Model
    protected void unregisterAllModelChangedObserversInDescendants() {
        if (this.mRootLayout != null) {
            this.mRootLayout.unregisterAllModelChangedObservers();
        }
        if (this.mImageRegion != null) {
            this.mImageRegion.unregisterAllModelChangedObservers();
        }
        if (this.mTextRegion != null) {
            this.mTextRegion.unregisterAllModelChangedObservers();
        }
    }
}
