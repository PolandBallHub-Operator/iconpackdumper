package com.android.mms.model;

import android.content.Context;
import android.util.Log;
import com.android.mms.MmsConfig;
import com.google.android.mms.ContentType;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.PduBody;
import com.google.android.mms.pdu.PduPart;
import java.io.IOException;
import org.w3c.dom.smil.SMILMediaElement;
import org.w3c.dom.smil.SMILRegionElement;
import org.w3c.dom.smil.SMILRegionMediaElement;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

/* JADX INFO: loaded from: classes.dex */
public class MediaModelFactory {
    private static final String TAG = "Mms";

    public static MediaModel getMediaModel(Context context, SMILMediaElement sme, LayoutModel layouts, PduBody pb) throws MmsException, IOException, IllegalArgumentException {
        String tag = sme.getTagName();
        String src = sme.getSrc();
        PduPart part = findPart(pb, src);
        return sme instanceof SMILRegionMediaElement ? getRegionMediaModel(context, tag, src, (SMILRegionMediaElement) sme, layouts, part) : getGenericMediaModel(context, tag, src, sme, part, null);
    }

    private static PduPart findPart(PduBody pb, String src) {
        PduPart part = null;
        if (src != null) {
            String src2 = unescapeXML(src);
            if (src2.startsWith("cid:")) {
                part = pb.getPartByContentId("<" + src2.substring("cid:".length()) + ">");
            } else {
                part = pb.getPartByName(src2);
                if (part == null && (part = pb.getPartByFileName(src2)) == null) {
                    part = pb.getPartByContentLocation(src2);
                }
            }
        }
        if (part != null) {
            return part;
        }
        throw new IllegalArgumentException("No part found for the model.");
    }

    private static String unescapeXML(String str) {
        return str.replaceAll("&lt;", "<").replaceAll("&gt;", ">").replaceAll("&quot;", "\"").replaceAll("&apos;", "'").replaceAll("&amp;", "&");
    }

    private static MediaModel getRegionMediaModel(Context context, String tag, String src, SMILRegionMediaElement srme, LayoutModel layouts, PduPart part) throws MmsException, IOException {
        String rId;
        SMILRegionElement sre = srme.getRegion();
        if (sre != null) {
            RegionModel region = layouts.findRegionById(sre.getId());
            if (region != null) {
                return getGenericMediaModel(context, tag, src, srme, part, region);
            }
        } else {
            if (tag.equals(SmilHelper.ELEMENT_TAG_TEXT)) {
                rId = LayoutModel.TEXT_REGION_ID;
            } else {
                rId = LayoutModel.IMAGE_REGION_ID;
            }
            RegionModel region2 = layouts.findRegionById(rId);
            if (region2 != null) {
                return getGenericMediaModel(context, tag, src, srme, part, region2);
            }
        }
        throw new IllegalArgumentException("Region not found or bad region ID.");
    }

    private static MediaModel createEmptyTextModel(Context context, RegionModel regionModel) throws IOException {
        return new TextModel(context, "text/plain", null, regionModel);
    }

    private static MediaModel getGenericMediaModel(Context context, String tag, String src, SMILMediaElement sme, PduPart part, RegionModel regionModel) throws MmsException, IOException {
        MediaModel media;
        TimeList tl;
        byte[] bytes = part.getContentType();
        if (bytes == null) {
            throw new IllegalArgumentException("Content-Type of the part may not be null.");
        }
        String contentType = new String(bytes);
        if (tag.equals(SmilHelper.ELEMENT_TAG_TEXT)) {
            media = new TextModel(context, contentType, src, part.getCharset(), part.getData(), regionModel);
        } else if (tag.equals(SmilHelper.ELEMENT_TAG_IMAGE)) {
            media = new ImageModel(context, contentType, src, part.getDataUri(), regionModel);
        } else if (tag.equals(SmilHelper.ELEMENT_TAG_VIDEO)) {
            media = new VideoModel(context, contentType, src, part.getDataUri(), regionModel);
        } else if (tag.equals(SmilHelper.ELEMENT_TAG_AUDIO)) {
            media = new AudioModel(context, contentType, src, part.getDataUri());
        } else if (tag.equals(SmilHelper.ELEMENT_TAG_REF)) {
            if (ContentType.isTextType(contentType)) {
                media = new TextModel(context, contentType, src, part.getCharset(), part.getData(), regionModel);
            } else if (ContentType.isImageType(contentType)) {
                media = new ImageModel(context, contentType, src, part.getDataUri(), regionModel);
            } else if (ContentType.isVideoType(contentType)) {
                media = new VideoModel(context, contentType, src, part.getDataUri(), regionModel);
            } else if (ContentType.isAudioType(contentType)) {
                media = new AudioModel(context, contentType, src, part.getDataUri());
            } else {
                Log.d("Mms", "[MediaModelFactory] getGenericMediaModel Unsupported Content-Type: " + contentType);
                media = createEmptyTextModel(context, regionModel);
            }
        } else {
            throw new IllegalArgumentException("Unsupported TAG: " + tag);
        }
        int begin = 0;
        TimeList tl2 = sme.getBegin();
        if (tl2 != null && tl2.getLength() > 0) {
            begin = (int) (tl2.item(0).getResolvedOffset() * 1000.0d);
        }
        media.setBegin(begin);
        int duration = (int) (sme.getDur() * 1000.0f);
        if (duration <= 0 && (tl = sme.getEnd()) != null && tl.getLength() > 0) {
            Time t = tl.item(0);
            if (t.getTimeType() != 0 && (duration = ((int) (t.getResolvedOffset() * 1000.0d)) - begin) == 0 && ((media instanceof AudioModel) || (media instanceof VideoModel))) {
                duration = MmsConfig.getMinimumSlideElementDuration();
                if (Log.isLoggable("Mms", 2)) {
                    Log.d("Mms", "[MediaModelFactory] compute new duration for " + tag + ", duration=" + duration);
                }
            }
        }
        media.setDuration(duration);
        if (!MmsConfig.getSlideDurationEnabled()) {
            media.setFill((short) 1);
        } else {
            media.setFill(sme.getFill());
        }
        return media;
    }
}
