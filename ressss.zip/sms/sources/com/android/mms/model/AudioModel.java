package com.android.mms.model;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.text.TextUtils;
import com.android.mms.ContentRestrictionException;
import com.android.mms.dom.events.EventImpl;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.google.android.mms.MmsException;
import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.events.Event;

/* JADX INFO: loaded from: classes.dex */
public class AudioModel extends MediaModel {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private final HashMap<String, String> mExtras;

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public AudioModel(Context context, Uri uri) throws MmsException {
        this(context, null, null, uri);
        initModelFromUri(uri);
        checkContentRestriction();
    }

    public AudioModel(Context context, String contentType, String src, Uri uri) throws MmsException {
        super(context, SmilHelper.ELEMENT_TAG_AUDIO, contentType, src, uri);
        this.mExtras = new HashMap<>();
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private void initModelFromUri(Uri uri) throws MmsException {
        String path;
        ContentResolver cr = this.mContext.getContentResolver();
        Cursor c = SqliteWrapper.query(this.mContext, cr, uri, (String[]) null, (String) null, (String[]) null, (String) null);
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    boolean isFromMms = isMmsUri(uri);
                    if (isFromMms) {
                        path = c.getString(c.getColumnIndexOrThrow("_data"));
                        this.mContentType = c.getString(c.getColumnIndexOrThrow("ct"));
                    } else {
                        path = c.getString(c.getColumnIndexOrThrow("_data"));
                        this.mContentType = c.getString(c.getColumnIndexOrThrow("mime_type"));
                        String album = c.getString(c.getColumnIndexOrThrow("album"));
                        if (!TextUtils.isEmpty(album)) {
                            this.mExtras.put("album", album);
                        }
                        String artist = c.getString(c.getColumnIndexOrThrow("artist"));
                        if (!TextUtils.isEmpty(artist)) {
                            this.mExtras.put("artist", artist);
                        }
                    }
                    this.mSrc = path.substring(path.lastIndexOf(47) + 1);
                    if (TextUtils.isEmpty(this.mContentType)) {
                        throw new MmsException("Type of media is unknown.");
                    }
                    c.close();
                    initMediaDuration();
                    return;
                }
                throw new MmsException("Nothing found: " + uri);
            } catch (Throwable th) {
                c.close();
                throw th;
            }
        }
        throw new MmsException("Bad URI: " + uri);
    }

    public void stop() {
        appendAction(MediaModel.MediaAction.STOP);
        notifyModelChanged(false);
    }

    @Override // org.w3c.dom.events.EventListener
    public void handleEvent(Event evt) {
        String evtType = evt.getType();
        MediaModel.MediaAction action = MediaModel.MediaAction.NO_ACTIVE_ACTION;
        if (evtType.equals(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT)) {
            action = MediaModel.MediaAction.START;
            pauseMusicPlayer();
        } else if (evtType.equals(SmilMediaElementImpl.SMIL_MEDIA_END_EVENT)) {
            action = MediaModel.MediaAction.STOP;
        } else if (evtType.equals(SmilMediaElementImpl.SMIL_MEDIA_PAUSE_EVENT)) {
            action = MediaModel.MediaAction.PAUSE;
        } else if (evtType.equals(SmilMediaElementImpl.SMIL_MEDIA_SEEK_EVENT)) {
            action = MediaModel.MediaAction.SEEK;
            this.mSeekTo = ((EventImpl) evt).getSeekTo();
        }
        appendAction(action);
        notifyModelChanged(false);
    }

    public Map<String, ?> getExtras() {
        return this.mExtras;
    }

    protected void checkContentRestriction() throws ContentRestrictionException {
        ContentRestriction cr = ContentRestrictionFactory.getContentRestriction();
        cr.checkAudioContentType(this.mContentType);
    }

    @Override // com.android.mms.model.MediaModel
    protected boolean isPlayable() {
        return true;
    }
}
