package com.android.mms.model;

import android.text.TextUtils;
import android.util.Log;
import com.android.mms.dom.smil.SmilParElementImpl;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventListener;

/* JADX INFO: loaded from: classes.dex */
public class SlideModel extends Model implements List<MediaModel>, EventListener {
    private static final boolean DEBUG = false;
    private static final int DEFAULT_SLIDE_DURATION = 5000;
    private static final boolean LOCAL_LOGV = false;
    public static final String TAG = "Mms";
    private MediaModel mAudio;
    private boolean mCanAddAudio;
    private boolean mCanAddImage;
    private boolean mCanAddVideo;
    private int mDuration;
    private short mFill;
    private MediaModel mImage;
    private final ArrayList<MediaModel> mMedia;
    private SlideshowModel mParent;
    private int mSlideSize;
    private MediaModel mText;
    private MediaModel mVideo;
    private boolean mVisible;

    public SlideModel(SlideshowModel slideshow) {
        this(5000, slideshow);
    }

    public SlideModel(int duration, SlideshowModel slideshow) {
        this.mMedia = new ArrayList<>();
        this.mCanAddImage = true;
        this.mCanAddAudio = true;
        this.mCanAddVideo = true;
        this.mVisible = true;
        this.mDuration = duration;
        this.mParent = slideshow;
    }

    public SlideModel(int duration, ArrayList<MediaModel> mediaList) {
        this.mMedia = new ArrayList<>();
        this.mCanAddImage = true;
        this.mCanAddAudio = true;
        this.mCanAddVideo = true;
        this.mVisible = true;
        this.mDuration = duration;
        int maxDur = 0;
        for (MediaModel media : mediaList) {
            internalAdd(media);
            int mediaDur = media.getDuration();
            if (mediaDur > maxDur) {
                maxDur = mediaDur;
            }
        }
        updateDuration(maxDur);
    }

    private void internalAdd(MediaModel media) throws IllegalStateException {
        if (media != null) {
            if (media.isText()) {
                String contentType = media.getContentType();
                if (TextUtils.isEmpty(contentType) || "text/plain".equals(contentType) || "text/html".equals(contentType)) {
                    internalAddOrReplace(this.mText, media);
                    this.mText = media;
                    return;
                } else {
                    Log.w("Mms", "[SlideModel] content type " + media.getContentType() + " isn't supported (as text)");
                    return;
                }
            }
            if (media.isImage()) {
                if (this.mCanAddImage) {
                    internalAddOrReplace(this.mImage, media);
                    this.mImage = media;
                    this.mCanAddVideo = false;
                    return;
                }
                Log.w("Mms", "[SlideModel] content type " + media.getContentType() + " - can't add image in this state");
                return;
            }
            if (media.isAudio()) {
                if (this.mCanAddAudio) {
                    internalAddOrReplace(this.mAudio, media);
                    this.mAudio = media;
                    this.mCanAddVideo = false;
                    return;
                }
                Log.w("Mms", "[SlideModel] content type " + media.getContentType() + " - can't add audio in this state");
                return;
            }
            if (media.isVideo()) {
                if (this.mCanAddVideo) {
                    internalAddOrReplace(this.mVideo, media);
                    this.mVideo = media;
                    this.mCanAddImage = false;
                    this.mCanAddAudio = false;
                    return;
                }
                Log.w("Mms", "[SlideModel] content type " + media.getContentType() + " - can't add video in this state");
            }
        }
    }

    private void internalAddOrReplace(MediaModel old, MediaModel media) {
        int addSize = media.getMediaResizable() ? 0 : media.getMediaSize();
        if (old == null) {
            if (this.mParent != null) {
                this.mParent.checkMessageSize(addSize);
            }
            this.mMedia.add(media);
            increaseSlideSize(addSize);
            increaseMessageSize(addSize);
        } else {
            int removeSize = old.getMediaResizable() ? 0 : old.getMediaSize();
            if (addSize > removeSize) {
                if (this.mParent != null) {
                    this.mParent.checkMessageSize(addSize - removeSize);
                }
                increaseSlideSize(addSize - removeSize);
                increaseMessageSize(addSize - removeSize);
            } else {
                decreaseSlideSize(removeSize - addSize);
                decreaseMessageSize(removeSize - addSize);
            }
            this.mMedia.set(this.mMedia.indexOf(old), media);
            old.unregisterAllModelChangedObservers();
        }
        for (IModelChangedObserver observer : this.mModelChangedObservers) {
            media.registerModelChangedObserver(observer);
        }
    }

    private boolean internalRemove(Object object) {
        if (!this.mMedia.remove(object)) {
            return false;
        }
        if (object instanceof TextModel) {
            this.mText = null;
        } else if (object instanceof ImageModel) {
            this.mImage = null;
            this.mCanAddVideo = true;
        } else if (object instanceof AudioModel) {
            this.mAudio = null;
            this.mCanAddVideo = true;
        } else if (object instanceof VideoModel) {
            this.mVideo = null;
            this.mCanAddImage = true;
            this.mCanAddAudio = true;
        }
        int decreaseSize = ((MediaModel) object).getMediaResizable() ? 0 : ((MediaModel) object).getMediaSize();
        decreaseSlideSize(decreaseSize);
        decreaseMessageSize(decreaseSize);
        ((Model) object).unregisterAllModelChangedObservers();
        return true;
    }

    public int getDuration() {
        return this.mDuration;
    }

    public void setDuration(int duration) {
        this.mDuration = duration;
        notifyModelChanged(true);
    }

    public int getSlideSize() {
        return this.mSlideSize;
    }

    public void increaseSlideSize(int increaseSize) {
        if (increaseSize > 0) {
            this.mSlideSize += increaseSize;
        }
    }

    public void decreaseSlideSize(int decreaseSize) {
        if (decreaseSize > 0) {
            this.mSlideSize -= decreaseSize;
            if (this.mSlideSize < 0) {
                this.mSlideSize = 0;
            }
        }
    }

    public void setParent(SlideshowModel parent) {
        this.mParent = parent;
    }

    public void increaseMessageSize(int increaseSize) {
        if (increaseSize > 0 && this.mParent != null) {
            int size = this.mParent.getCurrentMessageSize();
            this.mParent.setCurrentMessageSize(size + increaseSize);
        }
    }

    public void decreaseMessageSize(int decreaseSize) {
        if (decreaseSize > 0 && this.mParent != null) {
            int size = this.mParent.getCurrentMessageSize() - decreaseSize;
            if (size < 0) {
                size = 0;
            }
            this.mParent.setCurrentMessageSize(size);
        }
    }

    @Override // java.util.List, java.util.Collection
    public boolean add(MediaModel object) {
        internalAdd(object);
        notifyModelChanged(true);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public boolean addAll(Collection<? extends MediaModel> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    @Override // java.util.List, java.util.Collection
    public void clear() {
        if (this.mMedia.size() > 0) {
            for (MediaModel media : this.mMedia) {
                media.unregisterAllModelChangedObservers();
                int decreaseSize = media.getMediaSize();
                decreaseSlideSize(decreaseSize);
                decreaseMessageSize(decreaseSize);
            }
            this.mMedia.clear();
            this.mText = null;
            this.mImage = null;
            this.mAudio = null;
            this.mVideo = null;
            this.mCanAddImage = true;
            this.mCanAddAudio = true;
            this.mCanAddVideo = true;
            notifyModelChanged(true);
        }
    }

    @Override // java.util.List, java.util.Collection
    public boolean contains(Object object) {
        return this.mMedia.contains(object);
    }

    @Override // java.util.List, java.util.Collection
    public boolean containsAll(Collection<?> collection) {
        return this.mMedia.containsAll(collection);
    }

    @Override // java.util.List, java.util.Collection
    public boolean isEmpty() {
        return this.mMedia.isEmpty();
    }

    @Override // java.util.List, java.util.Collection, java.lang.Iterable
    public Iterator<MediaModel> iterator() {
        return this.mMedia.iterator();
    }

    @Override // java.util.List, java.util.Collection
    public boolean remove(Object object) {
        if (object == null || !(object instanceof MediaModel) || !internalRemove(object)) {
            return false;
        }
        notifyModelChanged(true);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public boolean removeAll(Collection<?> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    @Override // java.util.List, java.util.Collection
    public boolean retainAll(Collection<?> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    @Override // java.util.List, java.util.Collection
    public int size() {
        return this.mMedia.size();
    }

    @Override // java.util.List, java.util.Collection
    public Object[] toArray() {
        return this.mMedia.toArray();
    }

    @Override // java.util.List, java.util.Collection
    public <T> T[] toArray(T[] tArr) {
        return (T[]) this.mMedia.toArray(tArr);
    }

    @Override // java.util.List
    public void add(int location, MediaModel object) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    @Override // java.util.List
    public boolean addAll(int location, Collection<? extends MediaModel> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.List
    public MediaModel get(int location) {
        if (this.mMedia.size() == 0) {
            return null;
        }
        return this.mMedia.get(location);
    }

    @Override // java.util.List
    public int indexOf(Object object) {
        return this.mMedia.indexOf(object);
    }

    @Override // java.util.List
    public int lastIndexOf(Object object) {
        return this.mMedia.lastIndexOf(object);
    }

    @Override // java.util.List
    public ListIterator<MediaModel> listIterator() {
        return this.mMedia.listIterator();
    }

    @Override // java.util.List
    public ListIterator<MediaModel> listIterator(int location) {
        return this.mMedia.listIterator(location);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.List
    public MediaModel remove(int location) {
        MediaModel media = this.mMedia.get(location);
        if (media != null && internalRemove(media)) {
            notifyModelChanged(true);
        }
        return media;
    }

    @Override // java.util.List
    public MediaModel set(int location, MediaModel object) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    @Override // java.util.List
    public List<MediaModel> subList(int start, int end) {
        return this.mMedia.subList(start, end);
    }

    public boolean isVisible() {
        return this.mVisible;
    }

    public void setVisible(boolean visible) {
        this.mVisible = visible;
        notifyModelChanged(true);
    }

    public short getFill() {
        return this.mFill;
    }

    public void setFill(short fill) {
        this.mFill = fill;
        notifyModelChanged(true);
    }

    @Override // com.android.mms.model.Model
    protected void registerModelChangedObserverInDescendants(IModelChangedObserver observer) {
        for (MediaModel media : this.mMedia) {
            media.registerModelChangedObserver(observer);
        }
    }

    @Override // com.android.mms.model.Model
    protected void unregisterModelChangedObserverInDescendants(IModelChangedObserver observer) {
        for (MediaModel media : this.mMedia) {
            media.unregisterModelChangedObserver(observer);
        }
    }

    @Override // com.android.mms.model.Model
    protected void unregisterAllModelChangedObserversInDescendants() {
        for (MediaModel media : this.mMedia) {
            media.unregisterAllModelChangedObservers();
        }
    }

    @Override // org.w3c.dom.events.EventListener
    public void handleEvent(Event evt) {
        if (evt.getType().equals(SmilParElementImpl.SMIL_SLIDE_START_EVENT)) {
            this.mVisible = true;
        } else if (this.mFill != 1) {
            this.mVisible = false;
        }
        notifyModelChanged(false);
    }

    public boolean hasText() {
        return this.mText != null;
    }

    public boolean hasImage() {
        return this.mImage != null;
    }

    public boolean hasAudio() {
        return this.mAudio != null;
    }

    public boolean hasVideo() {
        return this.mVideo != null;
    }

    public boolean removeText() {
        return remove(this.mText);
    }

    public boolean removeImage() {
        return remove(this.mImage);
    }

    public boolean removeAudio() {
        boolean result = remove(this.mAudio);
        resetDuration();
        return result;
    }

    public boolean removeVideo() {
        boolean result = remove(this.mVideo);
        resetDuration();
        return result;
    }

    public TextModel getText() {
        return (TextModel) this.mText;
    }

    public ImageModel getImage() {
        return (ImageModel) this.mImage;
    }

    public AudioModel getAudio() {
        return (AudioModel) this.mAudio;
    }

    public VideoModel getVideo() {
        return (VideoModel) this.mVideo;
    }

    public void resetDuration() {
        if (!hasAudio() && !hasVideo()) {
            this.mDuration = 5000;
        }
    }

    public void updateDuration(int duration) {
        if (duration > 0) {
            if (duration > this.mDuration || this.mDuration == 5000) {
                this.mDuration = duration;
            }
        }
    }
}
