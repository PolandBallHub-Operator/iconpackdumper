package com.android.mms.model;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.ContentRestrictionException;
import com.android.mms.ExceedMessageSizeException;
import com.android.mms.MmsApp;
import com.android.mms.MmsConfig;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.ui.UriImage;
import com.android.mms.util.ItemLoadedCallback;
import com.android.mms.util.ItemLoadedFuture;
import com.android.mms.util.ThumbnailManager;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.PduPart;
import com.google.android.mms.pdu.PduPersister;
import java.lang.ref.SoftReference;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import org.w3c.dom.events.Event;

/* JADX INFO: loaded from: classes.dex */
public class ImageModel extends RegionMediaModel {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final int PICTURE_SIZE_LIMIT = 102400;
    private static final Set<String> SUPPORTED_MMS_IMAGE_CONTENT_TYPES = new HashSet(Arrays.asList("image/jpeg"));
    private static final String TAG = "Mms";
    private SoftReference<Bitmap> mFullSizeBitmapCache;
    private int mHeight;
    private ItemLoadedFuture mItemLoadedFuture;
    private int mWidth;

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public ImageModel(Context context, Uri uri, RegionModel region) throws MmsException {
        super(context, SmilHelper.ELEMENT_TAG_IMAGE, uri, region);
        this.mFullSizeBitmapCache = new SoftReference<>(null);
        initModelFromUri(uri);
        checkContentRestriction();
    }

    public ImageModel(Context context, String contentType, String src, Uri uri, RegionModel region) throws MmsException {
        super(context, SmilHelper.ELEMENT_TAG_IMAGE, contentType, src, uri, region);
        this.mFullSizeBitmapCache = new SoftReference<>(null);
        decodeImageBounds(uri);
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private void initModelFromUri(Uri uri) throws MmsException {
        UriImage uriImage = new UriImage(this.mContext, uri);
        this.mContentType = uriImage.getContentType();
        if (TextUtils.isEmpty(this.mContentType)) {
            throw new MmsException("Type of media is unknown.");
        }
        this.mSrc = uriImage.getSrc();
        this.mWidth = uriImage.getWidth();
        this.mHeight = uriImage.getHeight();
    }

    private void decodeImageBounds(Uri uri) {
        UriImage uriImage = new UriImage(this.mContext, uri);
        this.mWidth = uriImage.getWidth();
        this.mHeight = uriImage.getHeight();
    }

    @Override // org.w3c.dom.events.EventListener
    public void handleEvent(Event evt) {
        if (evt.getType().equals(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT)) {
            this.mVisible = true;
        } else if (this.mFill != 1) {
            this.mVisible = false;
        }
        notifyModelChanged(false);
    }

    public int getWidth() {
        return this.mWidth;
    }

    public int getHeight() {
        return this.mHeight;
    }

    protected void checkContentRestriction() throws ContentRestrictionException {
        ContentRestriction cr = ContentRestrictionFactory.getContentRestriction();
        cr.checkImageContentType(this.mContentType);
    }

    public ItemLoadedFuture loadThumbnailBitmap(ItemLoadedCallback callback) {
        ThumbnailManager thumbnailManager = MmsApp.getApplication().getThumbnailManager();
        this.mItemLoadedFuture = thumbnailManager.getThumbnail(getUri(), callback);
        return this.mItemLoadedFuture;
    }

    public void cancelThumbnailLoading() {
        if (this.mItemLoadedFuture != null && !this.mItemLoadedFuture.isDone()) {
            if (Log.isLoggable("Mms", 3)) {
                Log.v("Mms", "cancelThumbnailLoading for: " + this);
            }
            this.mItemLoadedFuture.cancel(getUri());
            this.mItemLoadedFuture = null;
        }
    }

    private Bitmap createBitmap(int thumbnailBoundsLimit, Uri uri) throws Throwable {
        byte[] data = UriImage.getResizedImageData(this.mWidth, this.mHeight, thumbnailBoundsLimit, thumbnailBoundsLimit, PICTURE_SIZE_LIMIT, uri, this.mContext);
        if (data == null) {
            return null;
        }
        return BitmapFactory.decodeByteArray(data, 0, data.length);
    }

    public Bitmap getBitmap(int width, int height) throws Throwable {
        Bitmap bm = this.mFullSizeBitmapCache.get();
        if (bm == null) {
            try {
                bm = createBitmap(Math.max(width, height), getUri());
                if (bm != null) {
                    this.mFullSizeBitmapCache = new SoftReference<>(bm);
                }
            } catch (OutOfMemoryError e) {
            }
        }
        return bm;
    }

    @Override // com.android.mms.model.MediaModel
    public boolean getMediaResizable() {
        return true;
    }

    @Override // com.android.mms.model.MediaModel
    protected void resizeMedia(int byteLimit, long messageId) throws Throwable {
        UriImage image = new UriImage(this.mContext, getUri());
        int widthLimit = MmsConfig.getMaxImageWidth();
        int heightLimit = MmsConfig.getMaxImageHeight();
        int size = getMediaSize();
        if (image.getHeight() > image.getWidth()) {
            widthLimit = heightLimit;
            heightLimit = widthLimit;
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "resizeMedia size: " + size + " image.getWidth(): " + image.getWidth() + " widthLimit: " + widthLimit + " image.getHeight(): " + image.getHeight() + " heightLimit: " + heightLimit + " image.getContentType(): " + image.getContentType());
        }
        if (size != 0 && size <= byteLimit && image.getWidth() <= widthLimit && image.getHeight() <= heightLimit && SUPPORTED_MMS_IMAGE_CONTENT_TYPES.contains(image.getContentType())) {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "resizeMedia - already sized");
                return;
            }
            return;
        }
        PduPart part = image.getResizedImageAsPart(widthLimit, heightLimit, byteLimit);
        if (part == null) {
            throw new ExceedMessageSizeException("Not enough memory to turn image into part: " + getUri());
        }
        this.mContentType = new String(part.getContentType());
        String src = getSrc();
        byte[] srcBytes = src.getBytes();
        part.setContentLocation(srcBytes);
        int period = src.lastIndexOf(".");
        byte[] contentId = period != -1 ? src.substring(0, period).getBytes() : srcBytes;
        part.setContentId(contentId);
        PduPersister persister = PduPersister.getPduPersister(this.mContext);
        this.mSize = part.getData().length;
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "resizeMedia mSize: " + this.mSize);
        }
        Uri newUri = persister.persistPart(part, messageId, (HashMap) null);
        setUri(newUri);
    }
}
