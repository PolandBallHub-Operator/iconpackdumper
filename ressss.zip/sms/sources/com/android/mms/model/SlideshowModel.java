package com.android.mms.model;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.ContentRestrictionException;
import com.android.mms.ExceedMessageSizeException;
import com.android.mms.MmsConfig;
import com.android.mms.UnsupportContentTypeException;
import com.android.mms.dom.smil.parser.SmilXmlSerializer;
import com.android.mms.layout.LayoutManager;
import com.google.android.mms.ContentType;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.MultimediaMessagePdu;
import com.google.android.mms.pdu.PduBody;
import com.google.android.mms.pdu.PduPart;
import com.google.android.mms.pdu.PduPersister;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.w3c.dom.NodeList;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.SMILLayoutElement;
import org.w3c.dom.smil.SMILMediaElement;
import org.w3c.dom.smil.SMILParElement;
import org.w3c.dom.smil.SMILRegionElement;
import org.w3c.dom.smil.SMILRootLayoutElement;

/* JADX INFO: loaded from: classes.dex */
public class SlideshowModel extends Model implements List<SlideModel>, IModelChangedObserver {
    public static final int SLIDESHOW_SLOP = 1024;
    private static final String TAG = "Mms";
    private Context mContext;
    private int mCurrentMessageSize;
    private SMILDocument mDocumentCache;
    private final LayoutModel mLayout;
    private PduBody mPduBodyCache;
    private final ArrayList<SlideModel> mSlides;
    private int mTotalMessageSize;

    private SlideshowModel(Context context) {
        this.mLayout = new LayoutModel();
        this.mSlides = new ArrayList<>();
        this.mContext = context;
    }

    private SlideshowModel(LayoutModel layouts, ArrayList<SlideModel> slides, SMILDocument documentCache, PduBody pbCache, Context context) {
        this.mLayout = layouts;
        this.mSlides = slides;
        this.mContext = context;
        this.mDocumentCache = documentCache;
        this.mPduBodyCache = pbCache;
        for (SlideModel slide : this.mSlides) {
            increaseMessageSize(slide.getSlideSize());
            slide.setParent(this);
        }
    }

    public static SlideshowModel createNew(Context context) {
        return new SlideshowModel(context);
    }

    public static SlideshowModel createFromMessageUri(Context context, Uri uri) throws MmsException {
        return createFromPduBody(context, getPduBody(context, uri));
    }

    public static SlideshowModel createFromPduBody(Context context, PduBody pb) throws MmsException {
        SMILDocument document = SmilHelper.getDocument(pb);
        SMILLayoutElement sle = document.getLayout();
        SMILRootLayoutElement srle = sle.getRootLayout();
        int w = srle.getWidth();
        int h = srle.getHeight();
        if (w == 0 || h == 0) {
            w = LayoutManager.getInstance().getLayoutParameters().getWidth();
            h = LayoutManager.getInstance().getLayoutParameters().getHeight();
            srle.setWidth(w);
            srle.setHeight(h);
        }
        RegionModel rootLayout = new RegionModel(null, 0, 0, w, h);
        ArrayList<RegionModel> regions = new ArrayList<>();
        NodeList nlRegions = sle.getRegions();
        int regionsNum = nlRegions.getLength();
        for (int i = 0; i < regionsNum; i++) {
            SMILRegionElement sre = (SMILRegionElement) nlRegions.item(i);
            RegionModel r = new RegionModel(sre.getId(), sre.getFit(), sre.getLeft(), sre.getTop(), sre.getWidth(), sre.getHeight(), sre.getBackgroundColor());
            regions.add(r);
        }
        LayoutModel layouts = new LayoutModel(rootLayout, regions);
        SMILElement docBody = document.getBody();
        NodeList slideNodes = docBody.getChildNodes();
        int slidesNum = slideNodes.getLength();
        ArrayList<SlideModel> slides = new ArrayList<>(slidesNum);
        int totalMessageSize = 0;
        for (int i2 = 0; i2 < slidesNum; i2++) {
            SMILParElement par = (SMILParElement) slideNodes.item(i2);
            NodeList mediaNodes = par.getChildNodes();
            int mediaNum = mediaNodes.getLength();
            ArrayList<MediaModel> mediaSet = new ArrayList<>(mediaNum);
            for (int j = 0; j < mediaNum; j++) {
                SMILMediaElement sme = (SMILMediaElement) mediaNodes.item(j);
                try {
                    MediaModel media = MediaModelFactory.getMediaModel(context, sme, layouts, pb);
                    if (!MmsConfig.getSlideDurationEnabled()) {
                        int mediadur = media.getDuration();
                        float dur = par.getDur();
                        if (dur == 0.0f) {
                            mediadur = MmsConfig.getMinimumSlideElementDuration() * 1000;
                            media.setDuration(mediadur);
                        }
                        if (mediadur / 1000 != dur) {
                            String tag = sme.getTagName();
                            if (ContentType.isVideoType(media.mContentType) || tag.equals(SmilHelper.ELEMENT_TAG_VIDEO) || ContentType.isAudioType(media.mContentType) || tag.equals(SmilHelper.ELEMENT_TAG_AUDIO)) {
                                par.setDur((mediadur / 1000.0f) + 1.0f);
                            } else if (mediadur / 1000 < dur) {
                                media.setDuration(((int) dur) * 1000);
                            } else if (((int) dur) != 0) {
                                media.setDuration(((int) dur) * 1000);
                            } else {
                                par.setDur(mediadur / 1000.0f);
                            }
                        }
                    }
                    SmilHelper.addMediaElementEventListeners((EventTarget) sme, media);
                    mediaSet.add(media);
                    totalMessageSize += media.getMediaSize();
                } catch (UnsupportContentTypeException e) {
                    Log.e("Mms", e.getMessage(), e);
                } catch (IOException e2) {
                    Log.e("Mms", e2.getMessage(), e2);
                } catch (IllegalArgumentException e3) {
                    Log.e("Mms", e3.getMessage(), e3);
                }
            }
            SlideModel slide = new SlideModel((int) (par.getDur() * 1000.0f), mediaSet);
            slide.setFill(par.getFill());
            SmilHelper.addParElementEventListeners((EventTarget) par, slide);
            slides.add(slide);
        }
        SlideshowModel slideshowModel = new SlideshowModel(layouts, slides, document, pb, context);
        slideshowModel.mTotalMessageSize = totalMessageSize;
        slideshowModel.registerModelChangedObserver(slideshowModel);
        return slideshowModel;
    }

    public PduBody toPduBody() {
        if (this.mPduBodyCache == null) {
            this.mDocumentCache = SmilHelper.getDocument(this);
            this.mPduBodyCache = makePduBody(this.mDocumentCache);
        }
        return this.mPduBodyCache;
    }

    private PduBody makePduBody(SMILDocument document) {
        String location;
        PduBody pb = new PduBody();
        for (SlideModel slide : this.mSlides) {
            for (MediaModel media : slide) {
                PduPart part = new PduPart();
                if (media.isText()) {
                    TextModel text = (TextModel) media;
                    if (!TextUtils.isEmpty(text.getText())) {
                        part.setCharset(text.getCharset());
                    }
                }
                part.setContentType(media.getContentType().getBytes());
                String src = media.getSrc();
                boolean startWithContentId = src.startsWith("cid:");
                if (startWithContentId) {
                    location = src.substring("cid:".length());
                } else {
                    location = src;
                }
                part.setContentLocation(location.getBytes());
                if (startWithContentId) {
                    part.setContentId(location.getBytes());
                } else {
                    int index = location.lastIndexOf(".");
                    String contentId = index == -1 ? location : location.substring(0, index);
                    part.setContentId(contentId.getBytes());
                }
                if (media.isText()) {
                    part.setData(((TextModel) media).getText().getBytes());
                } else if (media.isImage() || media.isVideo() || media.isAudio()) {
                    part.setDataUri(media.getUri());
                } else {
                    Log.w("Mms", "Unsupport media: " + media);
                }
                pb.addPart(part);
            }
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        SmilXmlSerializer.serialize(document, out);
        PduPart smilPart = new PduPart();
        smilPart.setContentId("smil".getBytes());
        smilPart.setContentLocation("smil.xml".getBytes());
        smilPart.setContentType("application/smil".getBytes());
        smilPart.setData(out.toByteArray());
        pb.addPart(0, smilPart);
        return pb;
    }

    public HashMap<Uri, InputStream> openPartFiles(ContentResolver cr) {
        HashMap<Uri, InputStream> openedFiles = null;
        for (SlideModel slide : this.mSlides) {
            for (MediaModel media : slide) {
                if (!media.isText()) {
                    Uri uri = media.getUri();
                    try {
                        InputStream is = cr.openInputStream(uri);
                        if (is != null) {
                            if (openedFiles == null) {
                                HashMap<Uri, InputStream> openedFiles2 = new HashMap<>();
                                openedFiles = openedFiles2;
                            }
                            openedFiles.put(uri, is);
                        }
                    } catch (FileNotFoundException e) {
                        Log.e("Mms", "openPartFiles couldn't open: " + uri, e);
                    }
                }
            }
        }
        return openedFiles;
    }

    public PduBody makeCopy() {
        return makePduBody(SmilHelper.getDocument(this));
    }

    public SMILDocument toSmilDocument() {
        if (this.mDocumentCache == null) {
            this.mDocumentCache = SmilHelper.getDocument(this);
        }
        return this.mDocumentCache;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public static PduBody getPduBody(Context context, Uri msg) throws MmsException {
        PduPersister p = PduPersister.getPduPersister(context);
        MultimediaMessagePdu multimediaMessagePduLoad = p.load(msg);
        int msgType = multimediaMessagePduLoad.getMessageType();
        if (msgType == 128 || msgType == 132) {
            return multimediaMessagePduLoad.getBody();
        }
        throw new MmsException();
    }

    public void setCurrentMessageSize(int size) {
        this.mCurrentMessageSize = size;
    }

    public int getCurrentMessageSize() {
        return this.mCurrentMessageSize;
    }

    public int getTotalMessageSize() {
        return this.mTotalMessageSize;
    }

    public void increaseMessageSize(int increaseSize) {
        if (increaseSize > 0) {
            this.mCurrentMessageSize += increaseSize;
        }
    }

    public void decreaseMessageSize(int decreaseSize) {
        if (decreaseSize > 0) {
            this.mCurrentMessageSize -= decreaseSize;
        }
    }

    public LayoutModel getLayout() {
        return this.mLayout;
    }

    @Override // java.util.List, java.util.Collection
    public boolean add(SlideModel object) {
        int increaseSize = object.getSlideSize();
        checkMessageSize(increaseSize);
        if (object == null || !this.mSlides.add(object)) {
            return false;
        }
        increaseMessageSize(increaseSize);
        object.registerModelChangedObserver(this);
        for (IModelChangedObserver observer : this.mModelChangedObservers) {
            object.registerModelChangedObserver(observer);
        }
        notifyModelChanged(true);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public boolean addAll(Collection<? extends SlideModel> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    @Override // java.util.List, java.util.Collection
    public void clear() {
        if (this.mSlides.size() > 0) {
            for (SlideModel slide : this.mSlides) {
                slide.unregisterModelChangedObserver(this);
                for (IModelChangedObserver observer : this.mModelChangedObservers) {
                    slide.unregisterModelChangedObserver(observer);
                }
            }
            this.mCurrentMessageSize = 0;
            this.mSlides.clear();
            notifyModelChanged(true);
        }
    }

    @Override // java.util.List, java.util.Collection
    public boolean contains(Object object) {
        return this.mSlides.contains(object);
    }

    @Override // java.util.List, java.util.Collection
    public boolean containsAll(Collection<?> collection) {
        return this.mSlides.containsAll(collection);
    }

    @Override // java.util.List, java.util.Collection
    public boolean isEmpty() {
        return this.mSlides.isEmpty();
    }

    @Override // java.util.List, java.util.Collection, java.lang.Iterable
    public Iterator<SlideModel> iterator() {
        return this.mSlides.iterator();
    }

    @Override // java.util.List, java.util.Collection
    public boolean remove(Object object) {
        if (object == null || !this.mSlides.remove(object)) {
            return false;
        }
        SlideModel slide = (SlideModel) object;
        decreaseMessageSize(slide.getSlideSize());
        slide.unregisterAllModelChangedObservers();
        notifyModelChanged(true);
        return true;
    }

    @Override // java.util.List, java.util.Collection
    public boolean removeAll(Collection<?> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    @Override // java.util.List, java.util.Collection
    public boolean retainAll(Collection<?> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    @Override // java.util.List, java.util.Collection
    public int size() {
        return this.mSlides.size();
    }

    @Override // java.util.List, java.util.Collection
    public Object[] toArray() {
        return this.mSlides.toArray();
    }

    @Override // java.util.List, java.util.Collection
    public <T> T[] toArray(T[] tArr) {
        return (T[]) this.mSlides.toArray(tArr);
    }

    @Override // java.util.List
    public void add(int location, SlideModel object) {
        if (object != null) {
            int increaseSize = object.getSlideSize();
            checkMessageSize(increaseSize);
            this.mSlides.add(location, object);
            increaseMessageSize(increaseSize);
            object.registerModelChangedObserver(this);
            for (IModelChangedObserver observer : this.mModelChangedObservers) {
                object.registerModelChangedObserver(observer);
            }
            notifyModelChanged(true);
        }
    }

    @Override // java.util.List
    public boolean addAll(int location, Collection<? extends SlideModel> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.List
    public SlideModel get(int location) {
        if (location < 0 || location >= this.mSlides.size()) {
            return null;
        }
        return this.mSlides.get(location);
    }

    @Override // java.util.List
    public int indexOf(Object object) {
        return this.mSlides.indexOf(object);
    }

    @Override // java.util.List
    public int lastIndexOf(Object object) {
        return this.mSlides.lastIndexOf(object);
    }

    @Override // java.util.List
    public ListIterator<SlideModel> listIterator() {
        return this.mSlides.listIterator();
    }

    @Override // java.util.List
    public ListIterator<SlideModel> listIterator(int location) {
        return this.mSlides.listIterator(location);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.List
    public SlideModel remove(int location) {
        SlideModel slide = this.mSlides.remove(location);
        if (slide != null) {
            decreaseMessageSize(slide.getSlideSize());
            slide.unregisterAllModelChangedObservers();
            notifyModelChanged(true);
        }
        return slide;
    }

    @Override // java.util.List
    public SlideModel set(int location, SlideModel object) {
        SlideModel slide = this.mSlides.get(location);
        if (object != null) {
            int removeSize = 0;
            int addSize = object.getSlideSize();
            if (slide != null) {
                removeSize = slide.getSlideSize();
            }
            if (addSize > removeSize) {
                checkMessageSize(addSize - removeSize);
                increaseMessageSize(addSize - removeSize);
            } else {
                decreaseMessageSize(removeSize - addSize);
            }
        }
        SlideModel slide2 = this.mSlides.set(location, object);
        if (slide2 != null) {
            slide2.unregisterAllModelChangedObservers();
        }
        if (object != null) {
            object.registerModelChangedObserver(this);
            for (IModelChangedObserver observer : this.mModelChangedObservers) {
                object.registerModelChangedObserver(observer);
            }
        }
        notifyModelChanged(true);
        return slide2;
    }

    @Override // java.util.List
    public List<SlideModel> subList(int start, int end) {
        return this.mSlides.subList(start, end);
    }

    @Override // com.android.mms.model.Model
    protected void registerModelChangedObserverInDescendants(IModelChangedObserver observer) {
        this.mLayout.registerModelChangedObserver(observer);
        for (SlideModel slide : this.mSlides) {
            slide.registerModelChangedObserver(observer);
        }
    }

    @Override // com.android.mms.model.Model
    protected void unregisterModelChangedObserverInDescendants(IModelChangedObserver observer) {
        this.mLayout.unregisterModelChangedObserver(observer);
        for (SlideModel slide : this.mSlides) {
            slide.unregisterModelChangedObserver(observer);
        }
    }

    @Override // com.android.mms.model.Model
    protected void unregisterAllModelChangedObserversInDescendants() {
        this.mLayout.unregisterAllModelChangedObservers();
        for (SlideModel slide : this.mSlides) {
            slide.unregisterAllModelChangedObservers();
        }
    }

    @Override // com.android.mms.model.IModelChangedObserver
    public void onModelChanged(Model model, boolean dataChanged) {
        if (dataChanged) {
            this.mDocumentCache = null;
            this.mPduBodyCache = null;
        }
    }

    public void sync(PduBody pb) {
        for (SlideModel slide : this.mSlides) {
            for (MediaModel media : slide) {
                PduPart part = pb.getPartByContentLocation(media.getSrc());
                if (part != null) {
                    media.setUri(part.getDataUri());
                }
            }
        }
    }

    public void checkMessageSize(int increaseSize) throws ContentRestrictionException {
        ContentRestriction cr = ContentRestrictionFactory.getContentRestriction();
        cr.checkMessageSize(this.mCurrentMessageSize, increaseSize, this.mContext.getContentResolver());
    }

    public boolean isSimple() {
        if (size() != 1) {
            return false;
        }
        SlideModel slide = get(0);
        return (slide.hasImage() ^ slide.hasVideo()) && !slide.hasAudio();
    }

    public void prepareForSend() {
        TextModel text;
        if (size() == 1 && (text = get(0).getText()) != null) {
            text.cloneText();
        }
    }

    public void finalResize(Uri messageUri) throws ExceedMessageSizeException, MmsException {
        int resizableCnt = 0;
        int fixedSizeTotal = 0;
        for (SlideModel slide : this.mSlides) {
            for (MediaModel media : slide) {
                if (media.getMediaResizable()) {
                    resizableCnt++;
                } else {
                    fixedSizeTotal += media.getMediaSize();
                }
            }
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "finalResize: original message size: " + getCurrentMessageSize() + " getMaxMessageSize: " + MmsConfig.getMaxMessageSize() + " fixedSizeTotal: " + fixedSizeTotal);
        }
        if (resizableCnt > 0) {
            int remainingSize = (MmsConfig.getMaxMessageSize() - fixedSizeTotal) - 1024;
            if (remainingSize <= 0) {
                throw new ExceedMessageSizeException("No room for pictures");
            }
            long messageId = ContentUris.parseId(messageUri);
            int bytesPerMediaItem = remainingSize / resizableCnt;
            for (SlideModel slide2 : this.mSlides) {
                for (MediaModel media2 : slide2) {
                    if (media2.getMediaResizable()) {
                        media2.resizeMedia(bytesPerMediaItem, messageId);
                    }
                }
            }
            int totalSize = 0;
            for (SlideModel slide3 : this.mSlides) {
                Iterator<MediaModel> it = slide3.iterator();
                while (it.hasNext()) {
                    totalSize += it.next().getMediaSize();
                }
            }
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "finalResize: new message size: " + totalSize);
            }
            if (totalSize > MmsConfig.getMaxMessageSize()) {
                throw new ExceedMessageSizeException("After compressing pictures, message too big");
            }
            setCurrentMessageSize(totalSize);
            onModelChanged(this, true);
            PduBody pb = toPduBody();
            PduPersister.getPduPersister(this.mContext).updateParts(messageUri, pb, (HashMap) null);
        }
    }
}
