package com.android.mms;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.util.Log;

/* JADX INFO: loaded from: classes.dex */
public class MmsNewsPreferences {
    private static final int DEFALT_VALUE = 0;
    private static final String FIELD_KEY_NEWS_COUNT = "NewsCount";
    private static final String INTENT_KEY_APP_LINK_NEW_MESSAGE = "com.android.mms.APP_LINK_NEW_MESSAGE";
    private static final boolean LOCAL_LOGV = true;
    private static final String LOG_TAG = "MmsNewsPreferences";
    private static final String PACKAGE_NAME = "com.android.mms";
    private static final String PREFERENCES_FILE = "MmsNewsPreferences";
    private static SharedPreferences mSharedPreferences = null;

    private MmsNewsPreferences() {
    }

    private static void initPreferences(Context context) {
        if (mSharedPreferences == null) {
            try {
                Context mmsContext = context.createPackageContext(PACKAGE_NAME, 0);
                mSharedPreferences = mmsContext.getSharedPreferences("MmsNewsPreferences", 3);
            } catch (PackageManager.NameNotFoundException e) {
                Log.e("MmsNewsPreferences", "create mms context error com.android.mms.APP_LINK_NEW_MESSAGE");
            }
        }
    }

    public static void setNewsCount(Context context, int value) {
        Log.d("MmsNewsPreferences", "setNewsCount mms : news flag=" + value);
        initPreferences(context);
        if (mSharedPreferences != null) {
            SharedPreferences.Editor e = mSharedPreferences.edit();
            e.putInt(FIELD_KEY_NEWS_COUNT, value);
            e.commit();
            Intent intent = new Intent(INTENT_KEY_APP_LINK_NEW_MESSAGE);
            intent.putExtra(FIELD_KEY_NEWS_COUNT, value);
            context.sendBroadcast(intent);
        }
    }
}
