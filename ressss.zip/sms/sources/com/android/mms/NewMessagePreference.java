package com.android.mms;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;

/* JADX INFO: loaded from: classes.dex */
public class NewMessagePreference {
    private static final String FIELD_KEY_NEWS_COUNT = "NewsCount";
    private static final String FIELD_KEY_NEWS_URI = "NewsUri";
    private static final String FIELD_KEY_UNREAD_COUNT = "UnreadCount";
    private static final String INTENT_KEY_NEW_MESSAGE = "com.android.mms.NEW_MESSAGE";
    private static final String INTENT_KEY_NEW_MESSAGE_GONE = "com.android.mms.NEW_MESSAGE_GONE";
    private static final String INTENT_KEY_UNREAD_MESSAGE = "com.android.mms.UNREAD_MESSAGE";
    private static final String PACKAGE_NAME = "com.android.mms";
    private static final String PREFERENCES_FILE = "NewMessagePreference";
    private static SharedPreferences mSharedPreferences = null;

    private NewMessagePreference() {
    }

    private static void initPreferences(Context context) {
        if (mSharedPreferences == null) {
            try {
                Context mmsContext = context.createPackageContext(PACKAGE_NAME, 0);
                mSharedPreferences = mmsContext.getSharedPreferences(PREFERENCES_FILE, 1);
            } catch (PackageManager.NameNotFoundException e) {
            }
        }
    }

    public static void setNewsCountToBroadcast(Context context, int value, Uri uri) {
        if (value != -1) {
            initPreferences(context);
            if (mSharedPreferences != null && mSharedPreferences.getInt(FIELD_KEY_NEWS_COUNT, -1) != value) {
                SharedPreferences.Editor e = mSharedPreferences.edit();
                e.putInt(FIELD_KEY_NEWS_COUNT, value);
                if (uri == null) {
                    e.remove(FIELD_KEY_NEWS_URI);
                } else {
                    e.putString(FIELD_KEY_NEWS_URI, uri.toString());
                }
                e.commit();
                Intent intent = new Intent(value == 0 ? INTENT_KEY_NEW_MESSAGE_GONE : INTENT_KEY_NEW_MESSAGE);
                intent.putExtra(FIELD_KEY_NEWS_COUNT, value);
                if (uri != null) {
                    intent.putExtra(FIELD_KEY_NEWS_URI, uri.toString());
                }
                context.sendBroadcast(intent);
            }
        }
    }

    public static int getNewsCount(Context context) {
        initPreferences(context);
        if (mSharedPreferences == null) {
            return 0;
        }
        return mSharedPreferences.getInt(FIELD_KEY_NEWS_COUNT, 0);
    }

    public static void setUnreadCountToBroadcast(Context context, int value) {
        if (value != -1) {
            initPreferences(context);
            if (mSharedPreferences != null && mSharedPreferences.getInt(FIELD_KEY_UNREAD_COUNT, -1) != value) {
                SharedPreferences.Editor e = mSharedPreferences.edit();
                e.putInt(FIELD_KEY_UNREAD_COUNT, value);
                e.commit();
                Intent intent = new Intent(INTENT_KEY_UNREAD_MESSAGE);
                intent.putExtra(FIELD_KEY_UNREAD_COUNT, value);
                context.sendBroadcast(intent);
            }
        }
    }

    public static int getUnreadCount(Context context) {
        initPreferences(context);
        if (mSharedPreferences == null) {
            return 0;
        }
        return mSharedPreferences.getInt(FIELD_KEY_UNREAD_COUNT, 0);
    }

    public static void setNewsUri(Context context, Uri value) {
        initPreferences(context);
        if (mSharedPreferences != null) {
            SharedPreferences.Editor e = mSharedPreferences.edit();
            if (value == null) {
                e.remove(FIELD_KEY_NEWS_URI);
            } else {
                e.putString(FIELD_KEY_NEWS_URI, value.toString());
            }
            e.commit();
        }
    }

    public static Uri getNewsUri(Context context) {
        String str;
        initPreferences(context);
        if (mSharedPreferences == null || (str = mSharedPreferences.getString(FIELD_KEY_NEWS_URI, null)) == null) {
            return null;
        }
        return Uri.parse(str);
    }
}
