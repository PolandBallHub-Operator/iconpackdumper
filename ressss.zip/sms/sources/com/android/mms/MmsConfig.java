package com.android.mms;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.XmlResourceParser;
import android.os.SystemProperties;
import android.preference.PreferenceManager;
import android.provider.Telephony;
import android.util.Log;
import com.android.mms.ui.MessageUtils;
import com.nextfp.android.util.NfpSharedResources;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: classes.dex */
public class MmsConfig {
    private static final boolean DEBUG = true;
    private static final boolean LOCAL_LOGV = false;
    private static final int MAX_IMAGE_HEIGHT = 480;
    private static final int MAX_IMAGE_WIDTH = 640;
    private static final int MAX_TEXT_LENGTH = 2000;
    private static final String MMS_APP_PACKAGE = "com.android.mms";
    private static final String SMS_PROMO_DISMISSED_KEY = "sms_promo_dismissed_key";
    private static final String TAG = "Mms";
    private static ArrayList<String> mSmscAddress;
    private static boolean mTransIdEnabled = false;
    private static int mMmsEnabled = 1;
    private static int mMaxMessageSize = 307200;
    private static final String DEFAULT_USER_AGENT = "Android-Mms/2.0";
    private static String mUserAgent = DEFAULT_USER_AGENT;
    private static final String DEFAULT_HTTP_KEY_X_WAP_PROFILE = "x-wap-profile";
    private static String mUaProfTagName = DEFAULT_HTTP_KEY_X_WAP_PROFILE;
    private static String mUaProfUrl = null;
    private static String mHttpParams = null;
    private static String mHttpParamsLine1Key = null;
    private static String mEmailGateway = null;
    private static int mMaxImageHeight = 480;
    private static int mMaxImageWidth = 640;
    private static int mRecipientLimit = Integer.MAX_VALUE;
    private static int mDefaultSMSMessagesPerThread = 500;
    private static int mDefaultMMSMessagesPerThread = 50;
    private static int mMinMessageCountPerThread = 2;
    private static int mMaxMessageCountPerThread = MessageUtils.MESSAGE_OVERHEAD;
    private static int mHttpSocketTimeout = 60000;
    private static int mMinimumSlideElementDuration = 7;
    private static boolean mNotifyWapMMSC = false;
    private static boolean mAllowAttachAudio = true;
    private static boolean mEnableMultipartSMS = true;
    private static int mSmsToMmsTextThreshold = -1;
    private static boolean mEnableSlideDuration = true;
    private static boolean mEnableMMSReadReports = true;
    private static boolean mEnableSMSDeliveryReports = true;
    private static boolean mEnableMMSDeliveryReports = true;
    private static int mMaxTextLength = -1;
    private static int mMaxSizeScaleForPendingMmsAllowed = 4;
    private static boolean mAliasEnabled = false;
    private static int mAliasRuleMinChars = 2;
    private static int mAliasRuleMaxChars = 48;
    private static int mMaxSubjectLength = 40;
    private static boolean mEnableGroupMms = true;

    public static void init(Context context) {
        Log.v("Mms", "mnc/mcc: " + SystemProperties.get("gsm.sim.operator.numeric"));
        loadMmsSettings(context);
    }

    public static boolean isSmsEnabled(Context context) {
        String defaultSmsApplication = Telephony.Sms.getDefaultSmsPackage(context);
        return defaultSmsApplication != null && defaultSmsApplication.equals(MMS_APP_PACKAGE);
    }

    public static boolean isSmsPromoDismissed(Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getBoolean(SMS_PROMO_DISMISSED_KEY, false);
    }

    public static void setSmsPromoDismissed(Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(SMS_PROMO_DISMISSED_KEY, true);
        editor.apply();
    }

    public static Intent getRequestDefaultSmsAppActivity() {
        Intent intent = new Intent("android.provider.Telephony.ACTION_CHANGE_DEFAULT");
        intent.putExtra("package", MMS_APP_PACKAGE);
        return intent;
    }

    public static int getSmsToMmsTextThreshold() {
        return mSmsToMmsTextThreshold;
    }

    public static boolean getMmsEnabled() {
        return mMmsEnabled == 1;
    }

    public static int getMaxMessageSize() {
        return mMaxMessageSize;
    }

    public static boolean getTransIdEnabled() {
        return mTransIdEnabled;
    }

    public static String getUserAgent() {
        return mUserAgent;
    }

    public static String getUaProfTagName() {
        return mUaProfTagName;
    }

    public static ArrayList<String> getDefaultSmscAddress() {
        return mSmscAddress;
    }

    public static String getUaProfUrl() {
        return mUaProfUrl;
    }

    public static String getHttpParams() {
        return mHttpParams;
    }

    public static String getHttpParamsLine1Key() {
        return mHttpParamsLine1Key;
    }

    public static String getEmailGateway() {
        return mEmailGateway;
    }

    public static int getMaxImageHeight() {
        return mMaxImageHeight;
    }

    public static int getMaxImageWidth() {
        return mMaxImageWidth;
    }

    public static int getRecipientLimit() {
        return mRecipientLimit;
    }

    public static int getMaxTextLimit() {
        return mMaxTextLength > -1 ? mMaxTextLength : MAX_TEXT_LENGTH;
    }

    public static int getDefaultSMSMessagesPerThread() {
        return mDefaultSMSMessagesPerThread;
    }

    public static int getDefaultMMSMessagesPerThread() {
        return mDefaultMMSMessagesPerThread;
    }

    public static int getMinMessageCountPerThread() {
        return mMinMessageCountPerThread;
    }

    public static int getMaxMessageCountPerThread() {
        return mMaxMessageCountPerThread;
    }

    public static int getHttpSocketTimeout() {
        return mHttpSocketTimeout;
    }

    public static int getMinimumSlideElementDuration() {
        return mMinimumSlideElementDuration;
    }

    public static boolean getMultipartSmsEnabled() {
        return mEnableMultipartSMS;
    }

    public static boolean getSlideDurationEnabled() {
        return mEnableSlideDuration;
    }

    public static boolean getMMSReadReportsEnabled() {
        return mEnableMMSReadReports;
    }

    public static boolean getSMSDeliveryReportsEnabled() {
        return mEnableSMSDeliveryReports;
    }

    public static boolean getMMSDeliveryReportsEnabled() {
        return mEnableMMSDeliveryReports;
    }

    public static boolean getNotifyWapMMSC() {
        return mNotifyWapMMSC;
    }

    public static int getMaxSizeScaleForPendingMmsAllowed() {
        return mMaxSizeScaleForPendingMmsAllowed;
    }

    public static boolean isAliasEnabled() {
        return mAliasEnabled;
    }

    public static int getAliasMinChars() {
        return mAliasRuleMinChars;
    }

    public static int getAliasMaxChars() {
        return mAliasRuleMaxChars;
    }

    public static boolean getAllowAttachAudio() {
        return mAllowAttachAudio;
    }

    public static int getMaxSubjectLength() {
        return mMaxSubjectLength;
    }

    public static boolean getGroupMmsEnabled() {
        return mEnableGroupMms;
    }

    public static final void beginDocument(XmlPullParser parser, String firstElementName) throws XmlPullParserException, IOException {
        int type;
        do {
            type = parser.next();
            if (type == 2) {
                break;
            }
        } while (type != 1);
        if (type != 2) {
            throw new XmlPullParserException("No start tag found");
        }
        if (!parser.getName().equals(firstElementName)) {
            throw new XmlPullParserException("Unexpected start tag: found " + parser.getName() + ", expected " + firstElementName);
        }
    }

    public static final void nextElement(XmlPullParser parser) throws XmlPullParserException, IOException {
        int type;
        do {
            type = parser.next();
            if (type == 2) {
                return;
            }
        } while (type != 1);
    }

    private static void loadMmsSettings(Context context) {
        XmlResourceParser parser = context.getResources().getXml(R.xml.mms_config);
        try {
            try {
                try {
                    try {
                        beginDocument(parser, "mms_config");
                        while (true) {
                            nextElement(parser);
                            String tag = parser.getName();
                            if (tag == null) {
                                break;
                            }
                            String name = parser.getAttributeName(0);
                            String value = parser.getAttributeValue(0);
                            String text = parser.next() == 4 ? parser.getText() : null;
                            Log.v("Mms", "tag: " + tag + " value: " + value + " - " + text);
                            if ("name".equalsIgnoreCase(name)) {
                                if (NfpSharedResources.DEFTYPE_BOOL.equals(tag)) {
                                    if ("enabledMMS".equalsIgnoreCase(value)) {
                                        mMmsEnabled = "true".equalsIgnoreCase(text) ? 1 : 0;
                                    } else if ("enabledTransID".equalsIgnoreCase(value)) {
                                        mTransIdEnabled = "true".equalsIgnoreCase(text);
                                    } else if ("enabledNotifyWapMMSC".equalsIgnoreCase(value)) {
                                        mNotifyWapMMSC = "true".equalsIgnoreCase(text);
                                    } else if ("aliasEnabled".equalsIgnoreCase(value)) {
                                        mAliasEnabled = "true".equalsIgnoreCase(text);
                                    } else if ("allowAttachAudio".equalsIgnoreCase(value)) {
                                        mAllowAttachAudio = "true".equalsIgnoreCase(text);
                                    } else if ("enableMultipartSMS".equalsIgnoreCase(value)) {
                                        mEnableMultipartSMS = "true".equalsIgnoreCase(text);
                                    } else if ("enableSlideDuration".equalsIgnoreCase(value)) {
                                        mEnableSlideDuration = "true".equalsIgnoreCase(text);
                                    } else if ("enableMMSReadReports".equalsIgnoreCase(value)) {
                                        mEnableMMSReadReports = "true".equalsIgnoreCase(text);
                                    } else if ("enableSMSDeliveryReports".equalsIgnoreCase(value)) {
                                        mEnableSMSDeliveryReports = "true".equalsIgnoreCase(text);
                                    } else if ("enableMMSDeliveryReports".equalsIgnoreCase(value)) {
                                        mEnableMMSDeliveryReports = "true".equalsIgnoreCase(text);
                                    } else if ("enableGroupMms".equalsIgnoreCase(value)) {
                                        mEnableGroupMms = "true".equalsIgnoreCase(text);
                                    }
                                } else if ("int".equals(tag)) {
                                    if ("maxMessageSize".equalsIgnoreCase(value)) {
                                        mMaxMessageSize = Integer.parseInt(text);
                                    } else if ("maxImageHeight".equalsIgnoreCase(value)) {
                                        mMaxImageHeight = Integer.parseInt(text);
                                    } else if ("maxImageWidth".equalsIgnoreCase(value)) {
                                        mMaxImageWidth = Integer.parseInt(text);
                                    } else if ("defaultSMSMessagesPerThread".equalsIgnoreCase(value)) {
                                        mDefaultSMSMessagesPerThread = Integer.parseInt(text);
                                    } else if ("defaultMMSMessagesPerThread".equalsIgnoreCase(value)) {
                                        mDefaultMMSMessagesPerThread = Integer.parseInt(text);
                                    } else if ("minMessageCountPerThread".equalsIgnoreCase(value)) {
                                        mMinMessageCountPerThread = Integer.parseInt(text);
                                    } else if ("maxMessageCountPerThread".equalsIgnoreCase(value)) {
                                        mMaxMessageCountPerThread = Integer.parseInt(text);
                                    } else if ("recipientLimit".equalsIgnoreCase(value)) {
                                        mRecipientLimit = Integer.parseInt(text);
                                        if (mRecipientLimit < 0) {
                                            mRecipientLimit = Integer.MAX_VALUE;
                                        }
                                    } else if ("httpSocketTimeout".equalsIgnoreCase(value)) {
                                        mHttpSocketTimeout = Integer.parseInt(text);
                                    } else if ("minimumSlideElementDuration".equalsIgnoreCase(value)) {
                                        mMinimumSlideElementDuration = Integer.parseInt(text);
                                    } else if ("maxSizeScaleForPendingMmsAllowed".equalsIgnoreCase(value)) {
                                        mMaxSizeScaleForPendingMmsAllowed = Integer.parseInt(text);
                                    } else if ("aliasMinChars".equalsIgnoreCase(value)) {
                                        mAliasRuleMinChars = Integer.parseInt(text);
                                    } else if ("aliasMaxChars".equalsIgnoreCase(value)) {
                                        mAliasRuleMaxChars = Integer.parseInt(text);
                                    } else if ("smsToMmsTextThreshold".equalsIgnoreCase(value)) {
                                        mSmsToMmsTextThreshold = Integer.parseInt(text);
                                    } else if ("maxMessageTextSize".equalsIgnoreCase(value)) {
                                        mMaxTextLength = Integer.parseInt(text);
                                    } else if ("maxSubjectLength".equalsIgnoreCase(value)) {
                                        mMaxSubjectLength = Integer.parseInt(text);
                                    }
                                } else if (NfpSharedResources.DEFTYPE_STRING.equals(tag)) {
                                    if ("userAgent".equalsIgnoreCase(value)) {
                                        mUserAgent = text;
                                    } else if ("uaProfTagName".equalsIgnoreCase(value)) {
                                        mUaProfTagName = text;
                                    } else if ("uaProfUrl".equalsIgnoreCase(value)) {
                                        mUaProfUrl = text;
                                    } else if ("httpParams".equalsIgnoreCase(value)) {
                                        mHttpParams = text;
                                    } else if ("httpParamsLine1Key".equalsIgnoreCase(value)) {
                                        mHttpParamsLine1Key = text;
                                    } else if ("emailGatewayNumber".equalsIgnoreCase(value)) {
                                        mEmailGateway = text;
                                    }
                                } else if ("string-array".equals(tag)) {
                                    ArrayList<String> al = new ArrayList<>();
                                    while ("item".equals(itemTag)) {
                                        if (parser.next() == 4) {
                                            al.add(parser.getText());
                                            parser.next();
                                            parser.next();
                                        }
                                    }
                                    Log.v("Mms", "tag: " + tag + " value: " + value + " - " + al);
                                    if ("smscAddress".equalsIgnoreCase(value)) {
                                        mSmscAddress = al;
                                    }
                                }
                            }
                        }
                        parser.close();
                    } catch (XmlPullParserException e) {
                        Log.e("Mms", "loadMmsSettings caught ", e);
                        parser.close();
                    }
                } catch (NumberFormatException e2) {
                    Log.e("Mms", "loadMmsSettings caught ", e2);
                    parser.close();
                }
            } catch (IOException e3) {
                Log.e("Mms", "loadMmsSettings caught ", e3);
                parser.close();
            }
            String errorStr = null;
            if (getMmsEnabled() && mUaProfUrl == null) {
                errorStr = "uaProfUrl";
            }
            if (errorStr != null) {
                String err = String.format("MmsConfig.loadMmsSettings mms_config.xml missing %s setting", errorStr);
                Log.e("Mms", err);
            }
        } catch (Throwable th) {
            parser.close();
            throw th;
        }
    }
}
