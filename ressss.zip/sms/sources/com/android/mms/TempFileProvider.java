package com.android.mms;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import java.io.File;
import java.io.FileNotFoundException;

/* JADX INFO: loaded from: classes.dex */
public class TempFileProvider extends ContentProvider {
    private static final int MMS_SCRAP_SPACE = 1;
    private static String TAG = "Mms";
    public static final Uri SCRAP_CONTENT_URI = Uri.parse("content://mms_temp_file/scrapSpace");
    private static final UriMatcher sURLMatcher = new UriMatcher(-1);

    static {
        sURLMatcher.addURI("mms_temp_file", "scrapSpace", 1);
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        return true;
    }

    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

    private ParcelFileDescriptor getTempStoreFd(String mode) {
        int modeFlags;
        String fileName = getScrapPath(getContext());
        ParcelFileDescriptor pfd = null;
        try {
            File file = new File(fileName);
            File parentFile = file.getParentFile();
            if (!parentFile.exists() && !parentFile.mkdirs()) {
                Log.e(TAG, "[TempFileProvider] tempStoreFd: " + parentFile.getPath() + "does not exist!");
                return null;
            }
            if (mode.equals("r")) {
                modeFlags = 268435456;
            } else {
                modeFlags = 1006632960;
            }
            pfd = ParcelFileDescriptor.open(file, modeFlags);
            return pfd;
        } catch (Exception ex) {
            Log.e(TAG, "getTempStoreFd: error creating pfd for " + fileName, ex);
        }
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        return "*/*";
    }

    @Override // android.content.ContentProvider
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        int match = sURLMatcher.match(uri);
        if (Log.isLoggable(TAG, 2)) {
            Log.d(TAG, "openFile: uri=" + uri + ", mode=" + mode);
        }
        switch (match) {
            case 1:
                ParcelFileDescriptor fd = getTempStoreFd(mode);
                return fd;
            default:
                return null;
        }
    }

    public static String getScrapPath(Context context, String fileName) {
        return context.getExternalCacheDir().getAbsolutePath() + "/" + fileName;
    }

    public static String getScrapPath(Context context) {
        return getScrapPath(context, ".temp.jpg");
    }

    public static Uri renameScrapFile(String fileExtension, String uniqueIdentifier, Context context) {
        String filePath = getScrapPath(context);
        if (uniqueIdentifier == null) {
            uniqueIdentifier = LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        File newTempFile = new File(getScrapPath(context, ".temp" + uniqueIdentifier + fileExtension));
        File oldTempFile = new File(filePath);
        newTempFile.delete();
        if (oldTempFile.renameTo(newTempFile)) {
            return Uri.fromFile(newTempFile);
        }
        return null;
    }

    public static boolean isTempFile(String path) {
        return path.contains(".temp");
    }
}
