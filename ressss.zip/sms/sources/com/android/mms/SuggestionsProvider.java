package com.android.mms;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.CrossProcessCursor;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.DataSetObserver;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class SuggestionsProvider extends ContentProvider {
    static final String AUTHORITY = "com.android.mms.SuggestionsProvider";

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        return null;
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        return true;
    }

    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Uri u = Uri.parse(String.format("content://mms-sms/searchSuggest?pattern=%s", selectionArgs[0]));
        Cursor c = getContext().getContentResolver().query(u, null, null, null, null);
        return new SuggestionsCursor(c, selectionArgs[0]);
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

    private class SuggestionsCursor implements CrossProcessCursor {
        int mColumnCount;
        int mCurrentRow;
        Cursor mDatabaseCursor;
        String mQuery;
        ArrayList<Row> mRows = new ArrayList<>();
        private String[] mVirtualColumns = {"suggest_intent_data", "suggest_intent_action", "suggest_intent_extra_data", "suggest_text_1"};
        private final int INTENT_DATA_COLUMN = 0;
        private final int INTENT_ACTION_COLUMN = 1;
        private final int INTENT_EXTRA_DATA_COLUMN = 2;
        private final int INTENT_TEXT_COLUMN = 3;

        public SuggestionsCursor(Cursor cursor, String query) {
            this.mDatabaseCursor = cursor;
            this.mQuery = query;
            this.mColumnCount = cursor.getColumnCount();
            try {
                computeRows();
            } catch (SQLiteException e) {
                this.mRows.clear();
            }
        }

        @Override // android.database.Cursor
        public int getCount() {
            return this.mRows.size();
        }

        private class Row {
            private int mRowNumber;
            private String mSnippet;

            public Row(int row, String snippet) {
                this.mSnippet = snippet.trim();
                this.mRowNumber = row;
            }

            public String getSnippet() {
                return this.mSnippet;
            }
        }

        private void computeRows() {
            int snippetColumn = this.mDatabaseCursor.getColumnIndex("snippet");
            int count = this.mDatabaseCursor.getCount();
            String previousSnippet = null;
            for (int i = 0; i < count; i++) {
                this.mDatabaseCursor.moveToPosition(i);
                String snippet = this.mDatabaseCursor.getString(snippetColumn);
                if (!TextUtils.equals(previousSnippet, snippet)) {
                    this.mRows.add(new Row(i, snippet));
                    previousSnippet = snippet;
                }
            }
        }

        private int[] computeOffsets(String offsetsString) {
            String[] vals = offsetsString.split(" ");
            int[] retvals = new int[vals.length];
            for (int i = retvals.length - 1; i >= 0; i--) {
                retvals[i] = Integer.parseInt(vals[i]);
            }
            return retvals;
        }

        @Override // android.database.CrossProcessCursor
        public void fillWindow(int position, CursorWindow window) {
            int count = getCount();
            if (position >= 0 && position <= count + 1) {
                window.acquireReference();
                try {
                    int oldpos = getPosition();
                    window.clear();
                    window.setStartPosition(position);
                    int columnNum = getColumnCount();
                    window.setNumColumns(columnNum);
                    for (int pos = position; moveToPosition(pos) && window.allocRow(); pos++) {
                        for (int i = 0; i < columnNum; i++) {
                            String field = getString(i);
                            if (field != null) {
                                if (!window.putString(field, pos, i)) {
                                    window.freeLastRow();
                                    break;
                                }
                            } else {
                                if (!window.putNull(pos, i)) {
                                    window.freeLastRow();
                                    break;
                                }
                            }
                        }
                    }
                    moveToPosition(oldpos);
                } catch (IllegalStateException e) {
                } finally {
                    window.releaseReference();
                }
            }
        }

        @Override // android.database.CrossProcessCursor
        public CursorWindow getWindow() {
            return null;
        }

        @Override // android.database.CrossProcessCursor
        public boolean onMove(int oldPosition, int newPosition) {
            return ((CrossProcessCursor) this.mDatabaseCursor).onMove(oldPosition, newPosition);
        }

        @Override // android.database.Cursor
        public int getColumnCount() {
            return this.mColumnCount + this.mVirtualColumns.length;
        }

        @Override // android.database.Cursor
        public int getColumnIndex(String columnName) {
            for (int i = 0; i < this.mVirtualColumns.length; i++) {
                if (this.mVirtualColumns[i].equals(columnName)) {
                    return this.mColumnCount + i;
                }
            }
            return this.mDatabaseCursor.getColumnIndex(columnName);
        }

        @Override // android.database.Cursor
        public String[] getColumnNames() {
            String[] x = this.mDatabaseCursor.getColumnNames();
            String[] y = new String[x.length + this.mVirtualColumns.length];
            for (int i = 0; i < x.length; i++) {
                y[i] = x[i];
            }
            for (int i2 = 0; i2 < this.mVirtualColumns.length; i2++) {
                y[x.length + i2] = this.mVirtualColumns[i2];
            }
            return y;
        }

        @Override // android.database.Cursor
        public boolean moveToPosition(int position) {
            if (position < 0 || position >= this.mRows.size()) {
                return false;
            }
            this.mCurrentRow = position;
            this.mDatabaseCursor.moveToPosition(this.mRows.get(position).mRowNumber);
            return true;
        }

        @Override // android.database.Cursor
        public boolean move(int offset) {
            return moveToPosition(this.mCurrentRow + offset);
        }

        @Override // android.database.Cursor
        public boolean moveToFirst() {
            return moveToPosition(0);
        }

        @Override // android.database.Cursor
        public boolean moveToLast() {
            return moveToPosition(this.mRows.size() - 1);
        }

        @Override // android.database.Cursor
        public boolean moveToNext() {
            return moveToPosition(this.mCurrentRow + 1);
        }

        @Override // android.database.Cursor
        public boolean moveToPrevious() {
            return moveToPosition(this.mCurrentRow - 1);
        }

        @Override // android.database.Cursor
        public String getString(int column) {
            if (column < this.mColumnCount) {
                return this.mDatabaseCursor.getString(column);
            }
            Row row = this.mRows.get(this.mCurrentRow);
            switch (column - this.mColumnCount) {
                case 0:
                    Uri.Builder b = Uri.parse("content://mms-sms/search").buildUpon();
                    Uri u = b.appendQueryParameter("pattern", row.getSnippet()).build();
                    return u.toString();
                case 1:
                    return "android.intent.action.SEARCH";
                case 2:
                    return row.getSnippet();
                case 3:
                    return row.getSnippet();
                default:
                    return null;
            }
        }

        @Override // android.database.Cursor, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            this.mDatabaseCursor.close();
        }

        @Override // android.database.Cursor
        public void copyStringToBuffer(int columnIndex, CharArrayBuffer buffer) {
            this.mDatabaseCursor.copyStringToBuffer(columnIndex, buffer);
        }

        @Override // android.database.Cursor
        public void deactivate() {
            this.mDatabaseCursor.deactivate();
        }

        @Override // android.database.Cursor
        public byte[] getBlob(int columnIndex) {
            return null;
        }

        @Override // android.database.Cursor
        public int getColumnIndexOrThrow(String columnName) throws IllegalArgumentException {
            return 0;
        }

        @Override // android.database.Cursor
        public String getColumnName(int columnIndex) {
            return null;
        }

        @Override // android.database.Cursor
        public double getDouble(int columnIndex) {
            return 0.0d;
        }

        @Override // android.database.Cursor
        public Bundle getExtras() {
            return Bundle.EMPTY;
        }

        @Override // android.database.Cursor
        public float getFloat(int columnIndex) {
            return 0.0f;
        }

        @Override // android.database.Cursor
        public int getInt(int columnIndex) {
            return 0;
        }

        @Override // android.database.Cursor
        public long getLong(int columnIndex) {
            return 0L;
        }

        @Override // android.database.Cursor
        public int getPosition() {
            return this.mCurrentRow;
        }

        @Override // android.database.Cursor
        public short getShort(int columnIndex) {
            return (short) 0;
        }

        @Override // android.database.Cursor
        public boolean getWantsAllOnMoveCalls() {
            return false;
        }

        @Override // android.database.Cursor
        public boolean isAfterLast() {
            return this.mCurrentRow >= this.mRows.size();
        }

        @Override // android.database.Cursor
        public boolean isBeforeFirst() {
            return this.mCurrentRow < 0;
        }

        @Override // android.database.Cursor
        public boolean isClosed() {
            return this.mDatabaseCursor.isClosed();
        }

        @Override // android.database.Cursor
        public boolean isFirst() {
            return this.mCurrentRow == 0;
        }

        @Override // android.database.Cursor
        public boolean isLast() {
            return this.mCurrentRow == this.mRows.size() + (-1);
        }

        @Override // android.database.Cursor
        public int getType(int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override // android.database.Cursor
        public boolean isNull(int columnIndex) {
            return false;
        }

        @Override // android.database.Cursor
        public void registerContentObserver(ContentObserver observer) {
            this.mDatabaseCursor.registerContentObserver(observer);
        }

        @Override // android.database.Cursor
        public void registerDataSetObserver(DataSetObserver observer) {
            this.mDatabaseCursor.registerDataSetObserver(observer);
        }

        @Override // android.database.Cursor
        public boolean requery() {
            return false;
        }

        @Override // android.database.Cursor
        public Bundle respond(Bundle extras) {
            return this.mDatabaseCursor.respond(extras);
        }

        @Override // android.database.Cursor
        public void setNotificationUri(ContentResolver cr, Uri uri) {
            this.mDatabaseCursor.setNotificationUri(cr, uri);
        }

        @Override // android.database.Cursor
        public Uri getNotificationUri() {
            return this.mDatabaseCursor.getNotificationUri();
        }

        @Override // android.database.Cursor
        public void unregisterContentObserver(ContentObserver observer) {
            this.mDatabaseCursor.unregisterContentObserver(observer);
        }

        @Override // android.database.Cursor
        public void unregisterDataSetObserver(DataSetObserver observer) {
            this.mDatabaseCursor.unregisterDataSetObserver(observer);
        }
    }
}
