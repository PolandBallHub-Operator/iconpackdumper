package com.android.mms.layout;

import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public class HVGALayoutParameters implements LayoutParameters {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private static int mImageHeightLandscape;
    private static int mImageHeightPortrait;
    private static int mMaxHeight;
    private static int mMaxWidth;
    private static int mTextHeightLandscape;
    private static int mTextHeightPortrait;
    private int mType;

    public HVGALayoutParameters(Context context, int type) {
        this.mType = -1;
        if (type != 10 && type != 11) {
            throw new IllegalArgumentException("Bad layout type detected: " + type);
        }
        this.mType = type;
        float scale = context.getResources().getDisplayMetrics().density;
        mMaxWidth = (int) ((context.getResources().getConfiguration().screenWidthDp * scale) + 0.5f);
        mMaxHeight = (int) ((context.getResources().getConfiguration().screenHeightDp * scale) + 0.5f);
        mImageHeightLandscape = (int) (mMaxHeight * 0.9f);
        mTextHeightLandscape = (int) (mMaxHeight * 0.1f);
        mImageHeightPortrait = (int) (mMaxWidth * 0.9f);
        mTextHeightPortrait = (int) (mMaxWidth * 0.1f);
    }

    @Override // com.android.mms.layout.LayoutParameters
    public int getWidth() {
        return this.mType == 10 ? mMaxWidth : mMaxHeight;
    }

    @Override // com.android.mms.layout.LayoutParameters
    public int getHeight() {
        return this.mType == 10 ? mMaxHeight : mMaxWidth;
    }

    @Override // com.android.mms.layout.LayoutParameters
    public int getImageHeight() {
        return this.mType == 10 ? mImageHeightLandscape : mImageHeightPortrait;
    }

    @Override // com.android.mms.layout.LayoutParameters
    public int getTextHeight() {
        return this.mType == 10 ? mTextHeightLandscape : mTextHeightPortrait;
    }

    @Override // com.android.mms.layout.LayoutParameters
    public int getType() {
        return this.mType;
    }

    @Override // com.android.mms.layout.LayoutParameters
    public String getTypeDescription() {
        return this.mType == 10 ? "HVGA-L" : "HVGA-P";
    }
}
