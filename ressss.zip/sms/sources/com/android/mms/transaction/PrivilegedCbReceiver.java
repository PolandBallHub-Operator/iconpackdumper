package com.android.mms.transaction;

import android.content.Context;
import android.content.Intent;

/* JADX INFO: loaded from: classes.dex */
public class PrivilegedCbReceiver extends SmsReceiver {
    @Override // com.android.mms.transaction.SmsReceiver, android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        onReceiveWithPrivilege(context, intent, true);
    }
}
