package com.android.mms.transaction;

import android.app.Service;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SqliteWrapper;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemProperties;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import com.android.mms.MmsConfig;
import com.android.mms.R;
import com.android.mms.util.DownloadManager;
import com.android.mms.util.ModeStringUtil;
import com.android.mms.util.RateController;
import com.google.android.mms.pdu.NotificationInd;
import com.google.android.mms.pdu.PduParser;
import com.google.android.mms.pdu.PduPersister;
import java.io.IOException;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class TransactionService extends Service implements Observer {
    public static final String ACTION_ENABLE_AUTO_RETRIEVE = "android.intent.action.ACTION_ENABLE_AUTO_RETRIEVE";
    public static final String ACTION_ONALARM = "android.intent.action.ACTION_ONALARM";
    private static final int APN_EXTENSION_WAIT = 30000;
    private static final int EVENT_CONTINUE_MMS_CONNECTIVITY = 3;
    private static final int EVENT_HANDLE_NEXT_PENDING_TRANSACTION = 4;
    private static final int EVENT_MMS_PDP_ACTIVATION_TIMEOUT = 6;
    private static final int EVENT_NEW_INTENT = 5;
    private static final int EVENT_QUIT = 100;
    private static final int EVENT_TRANSACTION_REQUEST = 1;
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final int PDP_ACTIVATION_TIMEOUT = 60000;
    public static final String STATE = "state";
    public static final String STATE_URI = "uri";
    private static final String TAG = "Mms";
    private static final int TOAST_DOWNLOAD_LATER = 2;
    private static final int TOAST_MSG_QUEUED = 1;
    private static final int TOAST_NONE = -1;
    private static final int TOAST_NO_APN = 3;
    public static final String TRANSACTION_COMPLETED_ACTION = "android.intent.action.TRANSACTION_COMPLETED_ACTION";
    private ConnectivityManager mConnMgr;
    private ServiceHandler mServiceHandler;
    private Looper mServiceLooper;
    private PowerManager.WakeLock mWakeLock;
    private final ArrayList<Transaction> mProcessing = new ArrayList<>();
    private final ArrayList<Transaction> mPending = new ArrayList<>();
    public Handler mToastHandler = new Handler() { // from class: com.android.mms.transaction.TransactionService.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            String str = null;
            if (msg.what == 1) {
                str = TransactionService.this.getString(ModeStringUtil.getModeResFromArray(TransactionService.this, R.array.message_queued));
            } else if (msg.what == 2) {
                str = TransactionService.this.getString(R.string.download_later);
            } else if (msg.what == 3) {
                str = TransactionService.this.getString(R.string.no_apn);
            }
            if (str != null) {
                Toast.makeText(TransactionService.this, str, 1).show();
            }
        }
    };
    private ConnectivityManager.NetworkCallback mMmsNetworkCallback = null;
    private NetworkRequest mMmsNetworkRequest = null;

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
    }

    @Override // android.app.Service
    public void onCreate() {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "Creating TransactionService");
        }
        HandlerThread thread = new HandlerThread("TransactionService");
        thread.start();
        this.mServiceLooper = thread.getLooper();
        this.mServiceHandler = new ServiceHandler(this.mServiceLooper);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            Message msg = this.mServiceHandler.obtainMessage(5);
            msg.arg1 = startId;
            msg.obj = intent;
            this.mServiceHandler.sendMessage(msg);
            return 2;
        }
        return 2;
    }

    private int[] getSubIdFromDb(Uri uri) {
        int phoneId = 0;
        Cursor c = getApplicationContext().getContentResolver().query(uri, null, null, null, null);
        Log.d("Mms", "Cursor= " + DatabaseUtils.dumpCursorToString(c));
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    phoneId = c.getInt(c.getColumnIndex("phone_id"));
                    Log.d("Mms", "phoneId in db = " + phoneId);
                    c.close();
                    c = null;
                }
                if (c != null) {
                    c.close();
                }
            } catch (Throwable th) {
                if (c != null) {
                    c.close();
                }
                throw th;
            }
        }
        if (!SubscriptionManager.isValidSlotId(phoneId)) {
            phoneId = SubscriptionManager.from(getApplicationContext()).getDefaultSmsPhoneId();
        }
        Log.d("Mms", "Destination Phone Id = " + phoneId);
        return SubscriptionManager.getSubId(phoneId);
    }

    private boolean isMmsAllowed() {
        boolean flag = true;
        if (isAirplaneModeActive()) {
            Log.d("Mms", "Airplane mode is ON, MMS may not be allowed.");
            flag = false;
        }
        if (isCurrentRatIwlan()) {
            Log.d("Mms", "Current RAT is IWLAN, MMS allowed");
            return true;
        }
        return flag;
    }

    private boolean isAirplaneModeActive() {
        return Settings.Global.getInt(getContentResolver(), "airplane_mode_on", 0) != 0;
    }

    private boolean isCurrentRatIwlan() {
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService("phone");
        return telephonyManager != null && telephonyManager.getNetworkType() == 18;
    }

    private boolean isMmsDataConnectivityPossible(int subId) {
        boolean flag = false;
        TelephonyManager telephonyManager = (TelephonyManager) getApplicationContext().getSystemService("phone");
        if (telephonyManager != null) {
            flag = telephonyManager.isDataPossibleForSubscription(subId, "mms");
        }
        Log.d("Mms", "isMmsDataConnectivityPossible = " + flag + "subId = " + subId);
        return flag;
    }

    /* JADX WARN: Code duplicated, block: B:125:0x032b A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:128:0x0268 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:130:0x037d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:137:0x01f7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:85:0x0331 A[Catch: all -> 0x0270, TryCatch #0 {all -> 0x0270, blocks: (B:32:0x011b, B:34:0x0129, B:36:0x0151, B:38:0x015b, B:39:0x0162, B:44:0x01cd, B:46:0x01df, B:48:0x01e9, B:49:0x01f0, B:50:0x01f7, B:52:0x01fd, B:54:0x0213, B:56:0x023f, B:59:0x0250, B:61:0x0268, B:83:0x032b, B:85:0x0331, B:86:0x035a, B:88:0x0368, B:93:0x0388, B:95:0x03a5, B:96:0x03c1, B:90:0x036e, B:92:0x037d, B:66:0x0275, B:68:0x0291, B:70:0x02d3, B:72:0x02dd, B:73:0x02e4, B:75:0x02ff, B:77:0x0305, B:79:0x030f, B:80:0x0318, B:82:0x0322), top: B:118:0x011b }] */
    public void onNewIntent(Intent intent, int serviceId) {
        Uri uri;
        int[] subId;
        if (!MmsConfig.isSmsEnabled(getApplicationContext())) {
            Log.d("Mms", "TransactionService: is not the default sms app");
            stopSelf(serviceId);
            return;
        }
        this.mConnMgr = (ConnectivityManager) getSystemService("connectivity");
        if (this.mConnMgr == null || !MmsConfig.isSmsEnabled(getApplicationContext())) {
            endMmsConnectivity();
            stopSelf(serviceId);
            return;
        }
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.v("Mms", "onNewIntent: serviceId: " + serviceId + ": *** intent=***");
            } else {
                Log.v("Mms", "onNewIntent: serviceId: " + serviceId + ": " + intent.getExtras() + " intent=" + intent);
            }
            Log.v("Mms", "    networkAvailable=" + (0 == 0));
        }
        Bundle extras = intent.getExtras();
        String action = intent.getAction();
        DownloadManager downloadManager = DownloadManager.getInstance();
        if (!ACTION_ONALARM.equals(action) && !ACTION_ENABLE_AUTO_RETRIEVE.equals(action) && extras != null && (extras == null || extras.containsKey("uri"))) {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "onNewIntent: launch transaction...");
            }
            String uriStr = intent.getStringExtra("uri");
            Uri uri2 = Uri.parse(uriStr);
            int[] subId2 = getSubIdFromDb(uri2);
            if (subId2 == null) {
                Log.e("Mms", "SMS subId is null. Bail out");
                return;
            }
            Log.d("Mms", "destination Sub Id = " + subId2[0]);
            if (subId2[0] < 0) {
                int defSmsSubId = getDefaultSmsSubId();
                Log.d("Mms", "Override with default Sms subId = " + defSmsSubId);
                subId2[0] = defSmsSubId;
            }
            if (!isMmsDataConnectivityPossible(subId2[0]) || !isMmsAllowed()) {
                Log.d("Mms", "Either mobile data is off or apn not present, Abort");
                downloadManager.markState(uri2, DownloadManager.STATE_SKIP_RETRYING);
                return;
            } else {
                Bundle bundle = intent.getExtras();
                bundle.putInt("subscription", subId2[0]);
                TransactionBundle args = new TransactionBundle(bundle);
                launchTransaction(serviceId, args, false);
                return;
            }
        }
        Cursor cursor = PduPersister.getPduPersister(this).getPendingMessages(System.currentTimeMillis());
        Log.d("Mms", "Cursor= " + DatabaseUtils.dumpCursorToString(cursor));
        if (FJ_TEL_LOG_ACQ_FLG) {
            Log.d("Mms", "Cursor= ***");
        } else {
            Log.d("Mms", "Cursor= " + DatabaseUtils.dumpCursorToString(cursor));
        }
        if (cursor == null) {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "onNewIntent: no pending messages. Stopping service.");
            }
            RetryScheduler.setRetryAlarm(this);
            stopSelfIfIdle(serviceId);
            return;
        }
        try {
            int count = cursor.getCount();
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "onNewIntent: cursor.count=" + count + " action=" + action);
            }
            if (count == 0) {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "onNewIntent: no pending messages. Stopping service.");
                }
                RetryScheduler.setRetryAlarm(this);
                stopSelfIfIdle(serviceId);
                cursor.close();
                return;
            }
            int columnIndexOfMsgId = cursor.getColumnIndexOrThrow("msg_id");
            int columnIndexOfMsgType = cursor.getColumnIndexOrThrow("msg_type");
            if (0 != 0) {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "onNewIntent: registerForConnectionStateChanges");
                }
                MmsSystemEventReceiver.registerForConnectionStateChanges(getApplicationContext());
            }
            while (cursor.moveToNext()) {
                int msgType = cursor.getInt(columnIndexOfMsgType);
                int transactionType = getTransactionType(msgType);
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "onNewIntent: msgType=" + msgType + " transactionType=" + transactionType);
                }
                if (0 == 0) {
                    switch (transactionType) {
                        case -1:
                            break;
                        case 0:
                        default:
                            uri = ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, cursor.getLong(columnIndexOfMsgId));
                            subId = getSubIdFromDb(uri);
                            if (subId == null) {
                                Log.e("Mms", "SMS subId is null. Bail out");
                            } else {
                                if (subId[0] < 0) {
                                    Log.d("Mms", "Subscriptions are not yet ready.");
                                    int defSmsSubId2 = getDefaultSmsSubId();
                                    Log.d("Mms", "Override with default Sms subId = " + defSmsSubId2);
                                    subId[0] = defSmsSubId2;
                                }
                                if (isMmsDataConnectivityPossible(subId[0]) || !isMmsAllowed()) {
                                    Log.d("Mms", "mobileData off or no mms apn or APM, Abort");
                                    if (transactionType == 1) {
                                        downloadManager.markState(uri, DownloadManager.STATE_SKIP_RETRYING);
                                    }
                                } else {
                                    TransactionBundle args2 = new TransactionBundle(transactionType, uri.toString(), subId[0]);
                                    if (Log.isLoggable("Mms", 2)) {
                                        Log.v("Mms", "onNewIntent: launchTransaction uri=" + uri);
                                    }
                                    launchTransaction(serviceId, args2, false);
                                }
                            }
                            break;
                        case 1:
                            int failureType = cursor.getInt(cursor.getColumnIndexOrThrow("err_type"));
                            boolean autoDownload = downloadManager.isAuto();
                            if (Log.isLoggable("Mms", 2)) {
                                Log.v("Mms", "onNewIntent: failureType=" + failureType + " action=" + action + " isTransientFailure:" + isTransientFailure(failureType) + " autoDownload=" + autoDownload);
                            }
                            if (!autoDownload) {
                                if (Log.isLoggable("Mms", 2)) {
                                    Log.v("Mms", "onNewIntent: skipping - autodownload off");
                                }
                                downloadManager.markState(ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, cursor.getLong(columnIndexOfMsgId)), DownloadManager.STATE_SKIP_RETRYING);
                            } else if (failureType == 0 || isTransientFailure(failureType)) {
                                if (Log.isLoggable("Mms", 2)) {
                                    Log.v("Mms", "onNewIntent: falling through and processing");
                                }
                                uri = ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, cursor.getLong(columnIndexOfMsgId));
                                subId = getSubIdFromDb(uri);
                                if (subId == null) {
                                    Log.e("Mms", "SMS subId is null. Bail out");
                                } else {
                                    if (subId[0] < 0) {
                                        Log.d("Mms", "Subscriptions are not yet ready.");
                                        int defSmsSubId3 = getDefaultSmsSubId();
                                        Log.d("Mms", "Override with default Sms subId = " + defSmsSubId3);
                                        subId[0] = defSmsSubId3;
                                    }
                                    if (isMmsDataConnectivityPossible(subId[0])) {
                                    }
                                    Log.d("Mms", "mobileData off or no mms apn or APM, Abort");
                                    if (transactionType == 1) {
                                        downloadManager.markState(uri, DownloadManager.STATE_SKIP_RETRYING);
                                    }
                                }
                            } else if (Log.isLoggable("Mms", 2)) {
                                Log.v("Mms", "onNewIntent: skipping - permanent error");
                            }
                            break;
                    }
                } else {
                    onNetworkUnavailable(serviceId, transactionType);
                    cursor.close();
                    return;
                }
            }
            cursor.close();
        } catch (Throwable th) {
            cursor.close();
            throw th;
        }
    }

    private int getDefaultSmsSubId() {
        return SubscriptionManager.getDefaultSmsSubId();
    }

    private void stopSelfIfIdle(int startId) {
        synchronized (this.mProcessing) {
            if (this.mProcessing.isEmpty() && this.mPending.isEmpty()) {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "stopSelfIfIdle: STOP!");
                }
                stopSelf(startId);
            }
        }
    }

    private static boolean isTransientFailure(int type) {
        return type >= 0 && type < 10;
    }

    private int getTransactionType(int msgType) {
        switch (msgType) {
            case 128:
                return 2;
            case 130:
                return 1;
            case DownloadManager.STATE_PERMANENT_FAILURE /* 135 */:
                return 3;
            default:
                Log.w("Mms", "Unrecognized MESSAGE_TYPE: " + msgType);
                return -1;
        }
    }

    private void launchTransaction(int serviceId, TransactionBundle txnBundle, boolean noNetwork) {
        if (noNetwork) {
            Log.w("Mms", "launchTransaction: no network error!");
            onNetworkUnavailable(serviceId, txnBundle.getTransactionType());
            return;
        }
        Message msg = this.mServiceHandler.obtainMessage(1);
        msg.arg1 = serviceId;
        msg.obj = txnBundle;
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.v("Mms", "launchTransaction: sending message ***");
            } else {
                Log.v("Mms", "launchTransaction: sending message " + msg);
            }
        }
        this.mServiceHandler.sendMessage(msg);
    }

    private void onNetworkUnavailable(int serviceId, int transactionType) {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "onNetworkUnavailable: sid=" + serviceId + ", type=" + transactionType);
        }
        int toastType = -1;
        if (transactionType == 1) {
            toastType = 2;
        } else if (transactionType == 2) {
            toastType = 1;
        }
        if (toastType != -1) {
            this.mToastHandler.sendEmptyMessage(toastType);
        }
        stopSelf(serviceId);
    }

    @Override // android.app.Service
    public void onDestroy() {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "Destroying TransactionService");
        }
        if (!this.mPending.isEmpty()) {
            Log.w("Mms", "TransactionService exiting with transaction still pending");
        }
        releaseWakeLock();
        this.mServiceHandler.sendEmptyMessage(100);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // com.android.mms.transaction.Observer
    public void update(Observable observable) {
        Transaction transaction = (Transaction) observable;
        int serviceId = transaction.getServiceId();
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "update transaction " + serviceId);
        }
        releaseNetworkRequest();
        try {
            synchronized (this.mProcessing) {
                this.mProcessing.remove(transaction);
                if (this.mPending.size() > 0) {
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "update: handle next pending transaction...");
                    }
                    Transaction nextTxn = this.mPending.get(0);
                    Log.d("Mms", "update: currentTxn = " + transaction + ", nextTxn = " + nextTxn);
                    if (nextTxn.getSubId() != transaction.getSubId()) {
                        Log.d("Mms", "update: Next pending txn is on different sub. Finish for current sub.");
                        endMmsConnectivity();
                    }
                    Message msg = this.mServiceHandler.obtainMessage(4, transaction.getConnectionSettings());
                    this.mServiceHandler.sendMessage(msg);
                } else if (this.mProcessing.isEmpty()) {
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "update: endMmsConnectivity");
                    }
                    endMmsConnectivity();
                } else if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "update: mProcessing is not empty");
                }
            }
            Intent intent = new Intent(TRANSACTION_COMPLETED_ACTION);
            TransactionState state = transaction.getState();
            int result = state.getState();
            intent.putExtra(STATE, result);
            switch (result) {
                case 1:
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "Transaction complete: " + serviceId);
                    }
                    intent.putExtra("uri", state.getContentUri());
                    switch (transaction.getType()) {
                        case 0:
                        case 1:
                            MessagingNotification.getThreadId(this, state.getContentUri());
                            MessagingNotification.updateDownloadFailedNotification(this);
                            break;
                        case 2:
                            RateController.getInstance().update();
                            break;
                    }
                    break;
                case 2:
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "Transaction failed: " + serviceId);
                    }
                    break;
                default:
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "Transaction state unknown: " + serviceId + " " + result);
                    }
                    break;
            }
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "update: broadcast transaction result " + result);
            }
            sendBroadcast(intent);
            transaction.detach(this);
            stopSelfIfIdle(serviceId);
        } catch (Throwable th) {
            transaction.detach(this);
            stopSelfIfIdle(serviceId);
            throw th;
        }
    }

    private synchronized void createWakeLock() {
        if (this.mWakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService("power");
            this.mWakeLock = pm.newWakeLock(1, "MMS Connectivity");
            this.mWakeLock.setReferenceCounted(false);
        }
    }

    private void acquireWakeLock() {
        Log.v("Mms", "mms acquireWakeLock");
        this.mWakeLock.acquire();
    }

    private void releaseWakeLock() {
        if (this.mWakeLock != null && this.mWakeLock.isHeld()) {
            Log.v("Mms", "mms releaseWakeLock");
            this.mWakeLock.release();
        }
    }

    protected int beginMmsConnectivity(String subId) throws IOException {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "beginMmsConnectivity for subId = " + subId);
        }
        createWakeLock();
        int result = this.mConnMgr.startUsingNetworkFeatureForSubscription(0, "enableMMS", subId);
        if (this.mMmsNetworkRequest == null) {
            this.mMmsNetworkRequest = buildNetworkRequest(subId);
            this.mMmsNetworkCallback = getNetworkCallback(subId);
            this.mConnMgr.registerNetworkCallback(this.mMmsNetworkRequest, this.mMmsNetworkCallback);
            this.mServiceHandler.sendMessageDelayed(this.mServiceHandler.obtainMessage(6), 60000L);
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "beginMmsConnectivity: result=" + result);
        }
        switch (result) {
            case 0:
            case 1:
                acquireWakeLock();
                return result;
            default:
                throw new IOException("Cannot establish MMS connectivity");
        }
    }

    private void releaseNetworkRequest() {
        if (this.mMmsNetworkCallback != null) {
            Log.d("Mms", "releaseNetworkRequest");
            this.mConnMgr.unregisterNetworkCallback(this.mMmsNetworkCallback);
            this.mMmsNetworkRequest = null;
            this.mMmsNetworkCallback = null;
        }
    }

    protected void endMmsConnectivity() {
        int subId = SubscriptionManager.getOnDemandDataSubId();
        endMmsConnectivity(Integer.toString(subId));
    }

    protected void endMmsConnectivity(String subId) {
        try {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "endMmsConnectivity for subId = " + subId);
            }
            this.mServiceHandler.removeMessages(3);
            if (this.mConnMgr != null) {
                releaseNetworkRequest();
                this.mConnMgr.stopUsingNetworkFeatureForSubscription(0, "enableMMS", subId);
            }
        } finally {
            releaseWakeLock();
        }
    }

    private final class ServiceHandler extends Handler {
        public ServiceHandler(Looper looper) {
            super(looper);
        }

        private String decodeMessage(Message msg) {
            if (msg.what == 100) {
                return "EVENT_QUIT";
            }
            if (msg.what == 3) {
                return "EVENT_CONTINUE_MMS_CONNECTIVITY";
            }
            if (msg.what == 1) {
                return "EVENT_TRANSACTION_REQUEST";
            }
            if (msg.what == 4) {
                return "EVENT_HANDLE_NEXT_PENDING_TRANSACTION";
            }
            if (msg.what == 5) {
                return "EVENT_NEW_INTENT";
            }
            if (msg.what == 6) {
                return "EVENT_MMS_PDP_ACTIVATION_TIMEOUT";
            }
            return "unknown message.what";
        }

        private String decodeTransactionType(int transactionType) {
            if (transactionType == 0) {
                return "NOTIFICATION_TRANSACTION";
            }
            if (transactionType == 1) {
                return "RETRIEVE_TRANSACTION";
            }
            if (transactionType == 2) {
                return "SEND_TRANSACTION";
            }
            if (transactionType == 3) {
                return "READREC_TRANSACTION";
            }
            return "invalid transaction type";
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            Transaction transaction;
            if (Log.isLoggable("Mms", 2)) {
                if (TransactionService.FJ_TEL_LOG_ACQ_FLG) {
                    Log.v("Mms", "Handling incoming message: *** = ***");
                } else {
                    Log.v("Mms", "Handling incoming message: " + msg + " = " + decodeMessage(msg));
                }
            }
            Transaction transaction2 = null;
            switch (msg.what) {
                case 1:
                    int serviceId = msg.arg1;
                    try {
                        try {
                            TransactionBundle args = (TransactionBundle) msg.obj;
                            if (Log.isLoggable("Mms", 2)) {
                                Log.v("Mms", "EVENT_TRANSACTION_REQUEST MmscUrl=" + args.getMmscUrl() + " proxy port: " + args.getProxyAddress());
                            }
                            String mmsc = args.getMmscUrl();
                            TransactionSettings transactionSettings = mmsc != null ? new TransactionSettings(mmsc, args.getProxyAddress(), args.getProxyPort()) : new TransactionSettings(TransactionService.this, (String) null, args.getSubId());
                            int transactionType = args.getTransactionType();
                            if (Log.isLoggable("Mms", 2)) {
                                Log.v("Mms", "handle EVENT_TRANSACTION_REQUEST: transactionType=" + transactionType + " " + decodeTransactionType(transactionType));
                            }
                            switch (transactionType) {
                                case 0:
                                    String uri = args.getUri();
                                    if (uri == null) {
                                        byte[] pushData = args.getPushData();
                                        PduParser parser = new PduParser(pushData, PduParserUtil.shouldParseContentDisposition());
                                        NotificationInd notificationInd = parser.parse();
                                        if (notificationInd == null || notificationInd.getMessageType() != 130) {
                                            Log.e("Mms", "Invalid PUSH data.");
                                            if (0 == 0) {
                                                if (Log.isLoggable("Mms", 2)) {
                                                    Log.v("Mms", "Transaction was null. Stopping self: " + serviceId);
                                                }
                                                TransactionService.this.endMmsConnectivity();
                                                TransactionService.this.stopSelf(serviceId);
                                                return;
                                            }
                                            return;
                                        }
                                        transaction = new NotificationTransaction(TransactionService.this, serviceId, transactionSettings, notificationInd);
                                    } else {
                                        transaction = new NotificationTransaction(TransactionService.this, serviceId, transactionSettings, uri);
                                    }
                                    break;
                                case 1:
                                    transaction = new RetrieveTransaction(TransactionService.this, serviceId, transactionSettings, args.getUri());
                                    break;
                                case 2:
                                    transaction = new SendTransaction(TransactionService.this, serviceId, transactionSettings, args.getUri());
                                    break;
                                case 3:
                                    transaction = new ReadRecTransaction(TransactionService.this, serviceId, transactionSettings, args.getUri());
                                    break;
                                default:
                                    Log.w("Mms", "Invalid transaction type: " + serviceId);
                                    if (0 == 0) {
                                        if (Log.isLoggable("Mms", 2)) {
                                            Log.v("Mms", "Transaction was null. Stopping self: " + serviceId);
                                        }
                                        TransactionService.this.endMmsConnectivity();
                                        TransactionService.this.stopSelf(serviceId);
                                        return;
                                    }
                                    return;
                            }
                            transaction.setSubId(args.getSubId());
                            if (!processTransaction(transaction)) {
                                if (0 == 0) {
                                    if (Log.isLoggable("Mms", 2)) {
                                        Log.v("Mms", "Transaction was null. Stopping self: " + serviceId);
                                    }
                                    TransactionService.this.endMmsConnectivity();
                                    TransactionService.this.stopSelf(serviceId);
                                    return;
                                }
                                return;
                            }
                            if (Log.isLoggable("Mms", 2)) {
                                if (TransactionService.FJ_TEL_LOG_ACQ_FLG) {
                                    Log.v("Mms", "Started processing of incoming message: ***");
                                } else {
                                    Log.v("Mms", "Started processing of incoming message: " + msg);
                                }
                            }
                            if (transaction == null) {
                                if (Log.isLoggable("Mms", 2)) {
                                    Log.v("Mms", "Transaction was null. Stopping self: " + serviceId);
                                }
                                TransactionService.this.endMmsConnectivity();
                                TransactionService.this.stopSelf(serviceId);
                                return;
                            }
                            return;
                        } catch (Exception ex) {
                            if (TransactionService.FJ_TEL_LOG_ACQ_FLG) {
                                Log.w("Mms", "Exception occurred while handling message: ***", ex);
                            } else {
                                Log.w("Mms", "Exception occurred while handling message: " + msg, ex);
                            }
                            if (0 != 0) {
                                try {
                                    try {
                                        transaction2.detach(TransactionService.this);
                                        if (TransactionService.this.mProcessing.contains(null)) {
                                            synchronized (TransactionService.this.mProcessing) {
                                                try {
                                                    TransactionService.this.mProcessing.remove((Object) null);
                                                } catch (Throwable th) {
                                                    throw th;
                                                }
                                            }
                                        }
                                        transaction2 = null;
                                    } catch (Throwable th2) {
                                        throw th2;
                                    }
                                } catch (Throwable t) {
                                    Log.e("Mms", "Unexpected Throwable.", t);
                                    transaction2 = null;
                                }
                                break;
                            }
                            if (transaction2 == null) {
                                if (Log.isLoggable("Mms", 2)) {
                                    Log.v("Mms", "Transaction was null. Stopping self: " + serviceId);
                                }
                                TransactionService.this.endMmsConnectivity();
                                TransactionService.this.stopSelf(serviceId);
                                return;
                            }
                            return;
                        }
                    } catch (Throwable th3) {
                        if (0 == 0) {
                            if (Log.isLoggable("Mms", 2)) {
                                Log.v("Mms", "Transaction was null. Stopping self: " + serviceId);
                            }
                            TransactionService.this.endMmsConnectivity();
                            TransactionService.this.stopSelf(serviceId);
                        }
                        throw th3;
                    }
                case 3:
                    synchronized (TransactionService.this.mProcessing) {
                        if (!TransactionService.this.mProcessing.isEmpty()) {
                            if (Log.isLoggable("Mms", 2)) {
                                Log.v("Mms", "handle EVENT_CONTINUE_MMS_CONNECTIVITY event...");
                            }
                            try {
                                int subId = SubscriptionManager.getOnDemandDataSubId();
                                if (Log.isLoggable("Mms", 2)) {
                                    Log.v("Mms", "renew PDP connection for subscription: " + subId);
                                }
                                int result = TransactionService.this.beginMmsConnectivity(Integer.toString(subId));
                                if (result != 0) {
                                    Log.v("Mms", "Extending MMS connectivity returned " + result + " instead of APN_ALREADY_ACTIVE");
                                } else {
                                    TransactionService.this.renewMmsConnectivity();
                                }
                            } catch (IOException e) {
                                Log.w("Mms", "Attempt to extend use of MMS connectivity failed");
                            }
                            break;
                        }
                    }
                    return;
                case 4:
                    processPendingTransaction(null, (TransactionSettings) msg.obj);
                    return;
                case 5:
                    TransactionService.this.onNewIntent((Intent) msg.obj, msg.arg1);
                    return;
                case 6:
                    synchronized (TransactionService.this.mProcessing) {
                        Transaction txn = TransactionService.this.mPending.isEmpty() ? null : (Transaction) TransactionService.this.mPending.remove(0);
                        if (txn != null) {
                            Log.d("Mms", "PDP activation timer expired, declare failure");
                            txn.attach(TransactionService.this);
                            markFailed(txn);
                        } else {
                            Log.d("Mms", "PDP activation timer expired, no pending txn found");
                        }
                        break;
                    }
                    return;
                case 100:
                    getLooper().quit();
                    return;
                default:
                    Log.w("Mms", "what=" + msg.what);
                    return;
            }
        }

        private void markFailed(Transaction transaction) {
            transaction.abort();
        }

        public void markAllPendingTransactionsAsFailed() {
            Log.d("Mms", "markAllPendingTransactionAsFailed");
            synchronized (TransactionService.this.mProcessing) {
                while (TransactionService.this.mPending.size() != 0) {
                    Transaction transaction = (Transaction) TransactionService.this.mPending.remove(0);
                    transaction.mTransactionState.setState(2);
                    if (transaction instanceof SendTransaction) {
                        Uri uri = ((SendTransaction) transaction).mSendReqURI;
                        transaction.mTransactionState.setContentUri(uri);
                        ContentValues values = new ContentValues(1);
                        values.put("resp_st", (Integer) 134);
                        SqliteWrapper.update(TransactionService.this, TransactionService.this.getContentResolver(), uri, values, (String) null, (String[]) null);
                    }
                    transaction.notifyObservers();
                }
            }
        }

        public void processPendingTransaction(Transaction transaction, TransactionSettings settings) {
            int numProcessTransaction;
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "processPendingTxn: transaction=" + transaction);
            }
            synchronized (TransactionService.this.mProcessing) {
                if (TransactionService.this.mPending.size() != 0) {
                    transaction = (Transaction) TransactionService.this.mPending.remove(0);
                }
                numProcessTransaction = TransactionService.this.mProcessing.size();
            }
            if (transaction != null) {
                if (settings != null) {
                    transaction.setConnectionSettings(settings);
                }
                try {
                    int serviceId = transaction.getServiceId();
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "processPendingTxn: process " + serviceId);
                    }
                    if (processTransaction(transaction)) {
                        if (Log.isLoggable("Mms", 2)) {
                            Log.v("Mms", "Started deferred processing of transaction  " + transaction);
                            return;
                        }
                        return;
                    }
                    TransactionService.this.stopSelf(serviceId);
                    return;
                } catch (IOException e) {
                    Log.w("Mms", e.getMessage(), e);
                    return;
                }
            }
            if (numProcessTransaction == 0) {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "processPendingTxn: no more transaction, endMmsConnectivity");
                }
                TransactionService.this.endMmsConnectivity();
            }
        }

        private boolean processTransaction(Transaction transaction) throws IOException {
            synchronized (TransactionService.this.mProcessing) {
                for (Transaction t : TransactionService.this.mPending) {
                    if (t.isEquivalent(transaction)) {
                        if (Log.isLoggable("Mms", 2)) {
                            Log.v("Mms", "Transaction already pending: " + transaction.getServiceId());
                        }
                    }
                }
                for (Transaction t2 : TransactionService.this.mProcessing) {
                    if (t2.isEquivalent(transaction)) {
                        if (Log.isLoggable("Mms", 2)) {
                            Log.v("Mms", "Duplicated transaction: " + transaction.getServiceId());
                        }
                    }
                }
                int subId = transaction.getSubId();
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "processTransaction: call beginMmsConnectivity on subId = " + subId);
                }
                int connectivityResult = TransactionService.this.beginMmsConnectivity(Integer.toString(subId));
                if (connectivityResult == 1) {
                    TransactionService.this.mPending.add(transaction);
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "processTransaction: connResult=APN_REQUEST_STARTED, defer transaction pending MMS connectivity");
                    }
                } else if (TransactionService.this.mProcessing.size() > 0) {
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "Adding transaction to 'mPending' list: " + transaction);
                    }
                    TransactionService.this.mPending.add(transaction);
                } else {
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "Adding transaction to 'mProcessing' list: " + transaction);
                    }
                    TransactionService.this.mProcessing.add(transaction);
                    sendMessageDelayed(obtainMessage(3), 30000L);
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "processTransaction: starting transaction " + transaction);
                    }
                    transaction.attach(TransactionService.this);
                    transaction.process();
                }
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void renewMmsConnectivity() {
        this.mServiceHandler.sendMessageDelayed(this.mServiceHandler.obtainMessage(3), 30000L);
    }

    private ConnectivityManager.NetworkCallback getNetworkCallback(final String subId) {
        return new ConnectivityManager.NetworkCallback() { // from class: com.android.mms.transaction.TransactionService.2
            public void onPreCheck(Network network) {
                Log.d("Mms", "sub:" + subId + "NetworkCallback.onPrecheck: network=" + network);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onAvailable(Network network) {
                Log.d("Mms", "sub:" + subId + "NetworkCallback.onAvailable: network=" + network);
                TransactionService.this.mServiceHandler.removeMessages(6);
                TransactionService.this.onMmsPdpConnected(subId, network);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onLosing(Network network, int timeToLive) {
                Log.d("Mms", "sub:" + subId + "NetworkCallback.onLosing: network=" + network + ", maxTimeToLive= " + timeToLive);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onLost(Network network) {
                Log.d("Mms", "sub:" + subId + "NetworkCallback.onLost: network=" + network);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onUnavailable() {
                Log.d("Mms", "sub:" + subId + "NetworkCallback.onUnavailable");
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onCapabilitiesChanged(Network network, NetworkCapabilities nc) {
                Log.d("Mms", "sub:" + subId + "NetworkCallback.onCapabilitiesChanged: network=" + network + ", Cap = " + nc);
            }

            @Override // android.net.ConnectivityManager.NetworkCallback
            public void onLinkPropertiesChanged(Network network, LinkProperties lp) {
                Log.d("Mms", "sub:" + subId + "NetworkCallback.onLinkPropertiesChanged: network=" + network + ", LP = " + lp);
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onMmsPdpConnected(String subId, Network network) {
        Log.d("Mms", "onMmsPdpConnected subId = " + subId);
        NetworkInfo mmsNetworkInfo = this.mConnMgr.getNetworkInfo(network);
        if (mmsNetworkInfo == null) {
            Log.e("Mms", "mms type is null or mobile data is turned off, bail");
            return;
        }
        if ("2GVoiceCallEnded".equals(mmsNetworkInfo.getReason())) {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "   reason is 2GVoiceCallEnded, retrying mms connectivity");
            }
            renewMmsConnectivity();
            return;
        }
        if (mmsNetworkInfo.isConnected()) {
            TransactionSettings settings = new TransactionSettings(this, mmsNetworkInfo.getExtraInfo(), Integer.parseInt(subId));
            if (TextUtils.isEmpty(settings.getMmscUrl())) {
                Log.v("Mms", "   empty MMSC url, bail");
                this.mToastHandler.sendEmptyMessage(3);
                this.mServiceHandler.markAllPendingTransactionsAsFailed();
                endMmsConnectivity();
                return;
            }
            this.mServiceHandler.processPendingTransaction(null, settings);
            return;
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "   TYPE_MOBILE_MMS not connected, bail");
        }
        if (mmsNetworkInfo.isAvailable()) {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "   retrying mms connectivity for it's available");
            }
            renewMmsConnectivity();
        }
    }

    private NetworkRequest buildNetworkRequest(String subId) {
        NetworkRequest networkRequest = new NetworkRequest.Builder().addTransportType(0).addCapability(0).build();
        networkRequest.networkCapabilities.setNetworkSpecifier(subId);
        return networkRequest;
    }
}
