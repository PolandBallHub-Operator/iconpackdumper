package com.android.mms.transaction;

import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public abstract class Observable {
    private Iterator<Observer> mIterator;
    private final ArrayList<Observer> mObservers = new ArrayList<>();

    public abstract TransactionState getState();

    public void attach(Observer observer) {
        detach(observer);
        this.mObservers.add(observer);
    }

    public void detach(Observer observer) {
        if (this.mIterator != null) {
            this.mIterator.remove();
        } else {
            this.mObservers.remove(observer);
        }
    }

    public void notifyObservers() {
        this.mIterator = this.mObservers.iterator();
        while (this.mIterator.hasNext()) {
            try {
                this.mIterator.next().update(this);
            } catch (Throwable th) {
                this.mIterator = null;
                throw th;
            }
        }
        this.mIterator = null;
    }
}
