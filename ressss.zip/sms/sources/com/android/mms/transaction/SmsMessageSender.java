package com.android.mms.transaction;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.Telephony;
import android.telephony.SubscriptionManager;
import android.util.Log;
import com.android.mms.ui.MessagingPreferenceActivity;
import com.google.android.mms.MmsException;

/* JADX INFO: loaded from: classes.dex */
public class SmsMessageSender implements MessageSender {
    private static final int COLUMN_REPLY_PATH_PRESENT = 0;
    private static final int COLUMN_SERVICE_CENTER = 1;
    private static final boolean DEFAULT_DELIVERY_REPORT_MODE = false;
    private static final String[] SERVICE_CENTER_PROJECTION = {"reply_path_present", "service_center"};
    private static final String TAG = "Mms";
    protected final Context mContext;
    private final String[] mDests;
    protected final String mMessageText;
    protected final int mNumberOfDests;
    protected int mPhoneId;
    protected final String mServiceCenter;
    protected final long mThreadId;
    protected long mTimestamp;

    public SmsMessageSender(Context context, String[] dests, String msgText, long threadId, int phoneId) {
        this.mContext = context;
        this.mMessageText = msgText;
        if (dests != null) {
            this.mNumberOfDests = dests.length;
            this.mDests = new String[this.mNumberOfDests];
            System.arraycopy(dests, 0, this.mDests, 0, this.mNumberOfDests);
        } else {
            this.mNumberOfDests = 0;
            this.mDests = null;
        }
        this.mTimestamp = System.currentTimeMillis();
        this.mThreadId = threadId;
        this.mServiceCenter = getOutgoingServiceCenter(this.mThreadId);
        this.mPhoneId = phoneId;
    }

    public SmsMessageSender(Context context, String[] dests, String msgText, long threadId, long timeStamp) {
        this(context, dests, msgText, threadId, 0);
        this.mTimestamp = timeStamp;
    }

    public SmsMessageSender(Context context, String[] dests, String msgText, long threadId, int subscription, long timeStamp) {
        this(context, dests, msgText, threadId, subscription);
        this.mTimestamp = timeStamp;
    }

    @Override // com.android.mms.transaction.MessageSender
    public boolean sendMessage(long token) throws MmsException {
        return queueMessage(token);
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private boolean queueMessage(long token) throws MmsException {
        if (this.mMessageText == null || this.mNumberOfDests == 0) {
            throw new MmsException("Null message body or dest.");
        }
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        boolean requestDeliveryReport = prefs.getBoolean(MessagingPreferenceActivity.SMS_DELIVERY_REPORT_MODE, false);
        for (int i = 0; i < this.mNumberOfDests; i++) {
            try {
                log("updating Database with phoneId = " + this.mPhoneId);
                int[] subId = SubscriptionManager.getSubId(this.mPhoneId);
                Telephony.Sms.addMessageToUri(subId[0], this.mContext.getContentResolver(), Uri.parse("content://sms/queued"), this.mDests[i], this.mMessageText, null, Long.valueOf(this.mTimestamp), true, requestDeliveryReport, this.mThreadId);
            } catch (SQLiteException e) {
                SqliteWrapper.checkSQLiteException(this.mContext, e);
            }
        }
        Intent intent = new Intent(SmsReceiverService.ACTION_SEND_MESSAGE, null, this.mContext, SmsReceiver.class);
        intent.putExtra("phone", this.mPhoneId);
        this.mContext.sendBroadcast(intent);
        return false;
    }

    private String getOutgoingServiceCenter(long threadId) {
        Cursor cursor = null;
        try {
            cursor = SqliteWrapper.query(this.mContext, this.mContext.getContentResolver(), Telephony.Sms.Inbox.CONTENT_URI, SERVICE_CENTER_PROJECTION, "thread_id = " + threadId, (String[]) null, "date DESC");
            if (cursor == null || !cursor.moveToFirst()) {
                return null;
            }
            boolean replyPathPresent = 1 == cursor.getInt(0);
            String string = replyPathPresent ? cursor.getString(1) : null;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private void log(String msg) {
        Log.d("Mms", "[SmsMsgSender] " + msg);
    }
}
