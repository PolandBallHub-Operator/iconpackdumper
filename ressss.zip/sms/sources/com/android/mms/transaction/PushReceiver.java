package com.android.mms.transaction;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.PowerManager;
import android.provider.Telephony;
import android.util.Log;
import com.android.mms.MmsConfig;
import com.android.mms.ui.ComposeMessageActivity;
import com.android.mms.ui.MessagingPreferenceActivity;
import com.android.mms.util.DownloadManager;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.DeliveryInd;
import com.google.android.mms.pdu.GenericPdu;
import com.google.android.mms.pdu.NotificationInd;
import com.google.android.mms.pdu.PduParser;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.ReadOrigInd;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class PushReceiver extends BroadcastReceiver {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";

    private class ReceivePushTask extends AsyncTask<Intent, Void, Void> {
        private Context mContext;

        public ReceivePushTask(Context context) {
            this.mContext = context;
        }

        int hexCharToInt(char c) {
            if (c >= '0' && c <= '9') {
                return c - '0';
            }
            if (c >= 'A' && c <= 'F') {
                return (c - 'A') + 10;
            }
            if (c < 'a' || c > 'f') {
                throw new RuntimeException("invalid hex char '" + c + "'");
            }
            return (c - 'a') + 10;
        }

        public String bytesToHexString(byte[] bytes) {
            if (bytes == null) {
                return null;
            }
            StringBuilder ret = new StringBuilder(bytes.length * 2);
            for (int i = 0; i < bytes.length; i++) {
                int b = (bytes[i] >> 4) & 15;
                ret.append("0123456789abcdef".charAt(b));
                int b2 = bytes[i] & 15;
                ret.append("0123456789abcdef".charAt(b2));
            }
            return ret.toString();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Intent... intents) {
            Intent intent = intents[0];
            byte[] pushData = intent.getByteArrayExtra("data");
            PduParser parser = new PduParser(pushData, PduParserUtil.shouldParseContentDisposition());
            NotificationInd notificationInd = parser.parse();
            if (notificationInd == null) {
                Log.e("Mms", "Invalid PUSH data");
                return null;
            }
            PduPersister p = PduPersister.getPduPersister(this.mContext);
            ContentResolver cr = this.mContext.getContentResolver();
            int type = notificationInd.getMessageType();
            try {
                switch (type) {
                    case 130:
                        NotificationInd nInd = notificationInd;
                        if (MmsConfig.getTransIdEnabled()) {
                            byte[] contentLocation = nInd.getContentLocation();
                            if (61 == contentLocation[contentLocation.length - 1]) {
                                byte[] transactionId = nInd.getTransactionId();
                                byte[] contentLocationWithId = new byte[contentLocation.length + transactionId.length];
                                System.arraycopy(contentLocation, 0, contentLocationWithId, 0, contentLocation.length);
                                System.arraycopy(transactionId, 0, contentLocationWithId, contentLocation.length, transactionId.length);
                                nInd.setContentLocation(contentLocationWithId);
                            }
                        }
                        if (!PushReceiver.isDuplicateNotification(this.mContext, nInd)) {
                            int phoneId = intent.getIntExtra("slot", 0);
                            int subId = intent.getIntExtra("subscription", 0);
                            Log.d("Mms", "phoneId : " + phoneId + " subId : " + subId);
                            ContentValues values = new ContentValues(1);
                            values.put("phone_id", Integer.valueOf(phoneId));
                            Uri uri = p.persist(notificationInd, Telephony.Mms.Inbox.CONTENT_URI, true, MessagingPreferenceActivity.getIsGroupMmsEnabled(this.mContext), (HashMap) null);
                            SqliteWrapper.update(this.mContext, cr, uri, values, (String) null, (String[]) null);
                            Intent svc = new Intent(this.mContext, (Class<?>) TransactionService.class);
                            svc.putExtra("uri", uri.toString());
                            svc.putExtra("type", 0);
                            svc.putExtra("phone_id", phoneId);
                            this.mContext.startService(svc);
                        }
                        break;
                    case 134:
                    case DownloadManager.STATE_PRE_DOWNLOADING /* 136 */:
                        long threadId = PushReceiver.findThreadId(this.mContext, notificationInd, type);
                        if (threadId != -1) {
                            Uri uri2 = p.persist(notificationInd, Telephony.Mms.Inbox.CONTENT_URI, true, MessagingPreferenceActivity.getIsGroupMmsEnabled(this.mContext), (HashMap) null);
                            ContentValues values2 = new ContentValues(1);
                            values2.put(ComposeMessageActivity.THREAD_ID, Long.valueOf(threadId));
                            SqliteWrapper.update(this.mContext, cr, uri2, values2, (String) null, (String[]) null);
                        }
                        break;
                    default:
                        Log.e("Mms", "Received unrecognized PDU.");
                        break;
                }
            } catch (MmsException e) {
                Log.e("Mms", "Failed to save the data from PUSH: type=" + type, e);
            } catch (RuntimeException e2) {
                Log.e("Mms", "Unexpected RuntimeException.", e2);
            }
            return null;
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.provider.Telephony.WAP_PUSH_DELIVER") && "application/vnd.wap.mms-message".equals(intent.getType())) {
            PowerManager pm = (PowerManager) context.getSystemService("power");
            PowerManager.WakeLock wl = pm.newWakeLock(1, "MMS PushReceiver");
            wl.acquire(5000L);
            new ReceivePushTask(context).execute(intent);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static long findThreadId(Context context, GenericPdu pdu, int type) {
        String messageId;
        if (type == 134) {
            messageId = new String(((DeliveryInd) pdu).getMessageId());
        } else {
            messageId = new String(((ReadOrigInd) pdu).getMessageId());
        }
        StringBuilder sb = new StringBuilder(40);
        sb.append("m_id");
        sb.append('=');
        sb.append(DatabaseUtils.sqlEscapeString(messageId));
        sb.append(" AND ");
        sb.append("m_type");
        sb.append('=');
        sb.append(128);
        Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(), Telephony.Mms.CONTENT_URI, new String[]{ComposeMessageActivity.THREAD_ID}, sb.toString(), (String[]) null, (String) null);
        if (cursor != null) {
            try {
                if (cursor.getCount() == 1 && cursor.moveToFirst()) {
                    return cursor.getLong(0);
                }
            } finally {
                cursor.close();
            }
        }
        return -1L;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean isDuplicateNotification(Context context, NotificationInd nInd) {
        byte[] rawLocation = nInd.getContentLocation();
        if (rawLocation != null) {
            String location = new String(rawLocation);
            String[] selectionArgs = {location};
            Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(), Telephony.Mms.CONTENT_URI, new String[]{"_id"}, "ct_l = ?", selectionArgs, (String) null);
            if (cursor != null) {
                try {
                    if (cursor.getCount() > 0) {
                        cursor.close();
                        return true;
                    }
                    cursor.close();
                } catch (Throwable th) {
                    cursor.close();
                    throw th;
                }
            }
        }
        return false;
    }
}
