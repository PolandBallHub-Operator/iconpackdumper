package com.android.mms.transaction;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/* JADX INFO: loaded from: classes.dex */
public class MmsPushOutboxMessages extends BroadcastReceiver {
    private static final String INTENT_MMS_SEND_OUTBOX_MSG = "android.intent.action.MMS_SEND_OUTBOX_MSG";
    private static final String TAG = "Mms";

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "Received the MMS_SEND_OUTBOX_MSG intent: " + intent);
        }
        String action = intent.getAction();
        if (action.equalsIgnoreCase(INTENT_MMS_SEND_OUTBOX_MSG)) {
            Log.d("Mms", "Now waking up the MMS service");
            context.startService(new Intent(context, (Class<?>) TransactionService.class));
        }
    }
}
