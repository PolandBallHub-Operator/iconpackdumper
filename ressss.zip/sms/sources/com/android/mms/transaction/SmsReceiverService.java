package com.android.mms.transaction;

import android.app.ActivityManager;
import android.app.AlertDialogFp;
import android.app.Service;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.media.AudioManager;
import android.media.Ringtone;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.ISimplePowerOff;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemProperties;
import android.os.Vibrator;
import android.provider.FjSettings;
import android.provider.Telephony;
import android.telephony.CellBroadcastMessage;
import android.telephony.ServiceState;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import com.android.common.speech.LoggingEvents;
import com.android.mms.MmsApp;
import com.android.mms.MmsConfig;
import com.android.mms.R;
import com.android.mms.data.Contact;
import com.android.mms.data.Conversation;
import com.android.mms.model.SmilHelper;
import com.android.mms.ui.ClassZeroActivity;
import com.android.mms.ui.ComposeMessageActivity;
import com.android.mms.util.ModeStringUtil;
import com.android.mms.util.Recycler;
import com.android.mms.widget.MmsWidgetProvider;
import com.google.android.mms.MmsException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Timer;

/* JADX INFO: loaded from: classes.dex */
public class SmsReceiverService extends Service {
    public static final String ACTION_SEND_INACTIVE_MESSAGE = "com.android.mms.transaction.SEND_INACTIVE_MESSAGE";
    public static final String ACTION_SEND_MESSAGE = "com.android.mms.transaction.SEND_MESSAGE";
    static final String CB_AREA_INFO_RECEIVED_ACTION = "android.cellbroadcastreceiver.CB_AREA_INFO_RECEIVED";
    static final int CB_CHANNEL_50 = 50;
    static final int CB_CHANNEL_60 = 60;
    public static final String CLASS_ZERO_BODY_KEY = "CLASS_ZERO_BODY";
    private static final String DOCOMO_SMS = "DoCoMo SMS";
    public static final String EXTRA_MESSAGE_SENT_SEND_NEXT = "SendNextMsg";
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final int MAX_RINGTING_TIME = 36000;
    public static final String MESSAGE_SENT_ACTION = "com.android.mms.transaction.MESSAGE_SENT";
    private static final int REPLACE_COLUMN_ID = 0;
    private static final String[] REPLACE_PROJECTION;
    private static final int SEND_COLUMN_ADDRESS = 2;
    private static final int SEND_COLUMN_BODY = 3;
    private static final int SEND_COLUMN_ID = 0;
    private static final int SEND_COLUMN_PHONE_ID = 5;
    private static final int SEND_COLUMN_STATUS = 4;
    private static final int SEND_COLUMN_THREAD_ID = 1;
    private static final String[] SEND_PROJECTION;
    private static final String TAG = "Mms";
    public static final long[][] VIBRATION_PATTERN;
    private static final String VOICE_MASSAGE_ADDRESS = "NTT DOCOMO";
    private static final String VOICE_MASSAGE_BODY = "VM:";
    private static ISmsRingtoneService mISmsRingtoneService;
    private static ServiceConnection mServiceConnection;
    private static Vibrator mVibrator;
    private static Ringtone ringtone;
    private AudioManager mAudioManager;
    private int mResultCode;
    private ServiceHandler mServiceHandler;
    private Looper mServiceLooper;
    private final String SUBSCRIPTION_KEY = "subscription";
    private boolean[] mSending = new boolean[TelephonyManager.getDefault().getPhoneCount()];
    public Handler mToastHandler = new Handler();
    private String otherMutePartState = LoggingEvents.EXTRA_CALLING_APP_NAME;
    private int serviceId = 0;
    private boolean isPlaying = false;
    private Timer timer = null;
    private boolean isBindRingtoneService = false;

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
        SEND_PROJECTION = new String[]{"_id", ComposeMessageActivity.THREAD_ID, "address", "body", "status", "phone_id"};
        VIBRATION_PATTERN = new long[][]{new long[]{0, 1000, 500, 1000, 500, 1000, 500, 1000, 1000}, new long[]{0, 300, 100, 300, 500, 300, 100, 300, 500}, new long[]{0, 1500, 1500, 1500, 1500}, new long[]{0, 1500, 1000, 1500, 1000, 1500, 1000, 1500, 1000}, new long[]{0, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000}};
        ringtone = null;
        mISmsRingtoneService = null;
        mServiceConnection = new ServiceConnection() { // from class: com.android.mms.transaction.SmsReceiverService.3
            @Override // android.content.ServiceConnection
            public void onServiceConnected(ComponentName name, IBinder binder) {
                ISmsRingtoneService unused = SmsReceiverService.mISmsRingtoneService = ISmsRingtoneService.Stub.asInterface(binder);
            }

            @Override // android.content.ServiceConnection
            public void onServiceDisconnected(ComponentName name) {
                ISmsRingtoneService unused = SmsReceiverService.mISmsRingtoneService = null;
            }
        };
        REPLACE_PROJECTION = new String[]{"_id", "address", "protocol"};
    }

    @Override // android.app.Service
    public void onCreate() {
        HandlerThread thread = new HandlerThread("Mms", 10);
        thread.start();
        startForegroundHidden(1);
        this.mServiceLooper = thread.getLooper();
        this.mServiceHandler = new ServiceHandler(this.mServiceLooper);
        this.mAudioManager = (AudioManager) getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!MmsConfig.isSmsEnabled(this)) {
            Log.d("Mms", "SmsReceiverService: is not the default sms app");
            SmsReceiver.finishStartingService(this, startId);
        } else {
            int resultCode = intent != null ? intent.getIntExtra("result", 0) : 0;
            if (resultCode != 0) {
                Log.v("Mms", "onStart: #" + startId + " resultCode: " + resultCode + " = " + translateResultCode(resultCode));
            }
            Message msg = this.mServiceHandler.obtainMessage();
            msg.arg1 = startId;
            msg.obj = intent;
            this.mServiceHandler.sendMessage(msg);
        }
        return 2;
    }

    private static String translateResultCode(int resultCode) {
        switch (resultCode) {
            case -1:
                return "Activity.RESULT_OK";
            case 0:
            default:
                return "Unknown error code";
            case 1:
                return "SmsManager.RESULT_ERROR_GENERIC_FAILURE";
            case 2:
                return "SmsManager.RESULT_ERROR_RADIO_OFF";
            case 3:
                return "SmsManager.RESULT_ERROR_NULL_PDU";
            case 4:
                return "SmsManager.RESULT_ERROR_NO_SERVICE";
            case 5:
                return "SmsManager.RESULT_ERROR_LIMIT_EXCEEDED";
            case 6:
                return "SmsManager.RESULT_ERROR_FDN_CHECK_FAILURE";
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.mServiceLooper.quit();
        if (this.isBindRingtoneService) {
            unbindService(mServiceConnection);
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    private final class ServiceHandler extends Handler {
        public ServiceHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            SmsReceiverService.this.serviceId = msg.arg1;
            Intent intent = (Intent) msg.obj;
            Log.d("Mms", "handle action = " + intent.getAction() + "    serviceId = " + SmsReceiverService.this.serviceId);
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "handleMessage serviceId: " + SmsReceiverService.this.serviceId + " intent: " + intent);
            }
            if (intent != null && MmsConfig.isSmsEnabled(SmsReceiverService.this.getApplicationContext())) {
                String action = intent.getAction();
                int error = intent.getIntExtra("errorCode", 0);
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "handleMessage action: " + action + " error: " + error);
                }
                if (SmsReceiverService.MESSAGE_SENT_ACTION.equals(intent.getAction())) {
                    SmsReceiverService.this.handleSmsSent(intent, error);
                } else if ("android.provider.Telephony.SMS_DELIVER".equals(action)) {
                    SmsReceiverService.this.handleSmsReceived(intent, error);
                } else if (!"android.provider.Telephony.SMS_CB_RECEIVED".equals(action)) {
                    if (SmsReceiverService.CB_AREA_INFO_RECEIVED_ACTION.equals(action)) {
                        SmsReceiverService.this.handleCbSmsReceived(intent, error);
                    } else if ("android.intent.action.BOOT_COMPLETED".equals(action)) {
                        SmsReceiverService.this.handleBootCompleted();
                    } else if ("android.intent.action.SERVICE_STATE".equals(action)) {
                        SmsReceiverService.this.handleServiceStateChanged(intent);
                    } else if (SmsReceiverService.ACTION_SEND_MESSAGE.endsWith(action)) {
                        SmsReceiverService.this.handleSendMessage(intent);
                    } else if (SmsReceiverService.ACTION_SEND_INACTIVE_MESSAGE.equals(action)) {
                        SmsReceiverService.this.handleSendInactiveMessage();
                    }
                }
            }
            Log.d("Mms", "finish smsReceiverService serviceId = " + SmsReceiverService.this.serviceId);
            SmsReceiver.finishStartingService(SmsReceiverService.this, SmsReceiverService.this.serviceId);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleServiceStateChanged(Intent intent) {
        ServiceState serviceState = ServiceState.newFromBundle(intent.getExtras());
        int subId = intent.getIntExtra("subscription", 0);
        if (serviceState.getState() == 0) {
            int phoneId = SubscriptionManager.getPhoneId(subId);
            sendFirstQueuedMessage(phoneId);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleSendMessage(Intent intent) {
        int phoneId = intent.getIntExtra("phone", SubscriptionManager.getDefaultSmsSubId());
        if (!this.mSending[phoneId]) {
            sendFirstQueuedMessage(phoneId);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleSendInactiveMessage() {
        if (!MmsApp.smsFlag) {
            moveOutboxMessagesToQueuedBox();
            for (int i = 0; i < TelephonyManager.getDefault().getPhoneCount(); i++) {
                if (!this.mSending[i]) {
                    sendFirstQueuedMessage(i);
                }
            }
        }
    }

    public synchronized void sendFirstQueuedMessage(int phId) {
        boolean success = true;
        boolean isExpectMore = false;
        Uri uri = Uri.parse("content://sms/queued");
        ContentResolver resolver = getContentResolver();
        String[] whereArgs = {Integer.toString(phId)};
        Cursor c = SqliteWrapper.query(this, resolver, uri, SEND_PROJECTION, "phone_id=?", whereArgs, "date ASC");
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    String msgText = c.getString(3);
                    String address = c.getString(2);
                    int threadId = c.getInt(1);
                    int status = c.getInt(4);
                    int msgId = c.getInt(0);
                    int phoneId = c.getInt(5);
                    Uri msgUri = ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, msgId);
                    if (c.moveToNext()) {
                        isExpectMore = true;
                    }
                    SmsMessageSender sender = new SmsSingleRecipientSender(this, address, msgText, threadId, status == 32, msgUri, phoneId, isExpectMore);
                    if (Log.isLoggable("Mms", 2)) {
                        if (FJ_TEL_LOG_ACQ_FLG) {
                            Log.v("Mms", "sendFirstQueuedMessage ***, address: ***, threadId: " + threadId);
                        } else {
                            Log.v("Mms", "sendFirstQueuedMessage " + msgUri + ", address: " + address + ", threadId: " + threadId);
                        }
                    }
                    try {
                        sender.sendMessage(-1L);
                        this.mSending[phoneId] = true;
                    } catch (MmsException e) {
                        Log.e("Mms", "sendFirstQueuedMessage: failed to send message " + msgUri + ", caught ", e);
                        this.mSending[phoneId] = false;
                        messageFailedToSend(msgUri, 1);
                        success = false;
                        Intent intent = new Intent(ACTION_SEND_MESSAGE, null, this, SmsReceiver.class);
                        intent.putExtra("phone", phoneId);
                        sendBroadcast(intent);
                    }
                }
                c.close();
            } catch (Throwable th) {
                c.close();
                throw th;
            }
        }
        if (success && (!TelephonyManager.getDefault().isMultiSimEnabled() || isUnRegisterAllowed(phId))) {
            unRegisterForServiceStateChanges();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleSmsSent(Intent intent, int error) {
        Uri uri = intent.getData();
        int resultCode = intent.getIntExtra("result", 0);
        boolean sendNextMsg = intent.getBooleanExtra(EXTRA_MESSAGE_SENT_SEND_NEXT, false);
        int phoneId = intent.getIntExtra("phone", SubscriptionManager.getDefaultSmsSubId());
        this.mSending[phoneId] = false;
        if (resultCode == -1) {
            if (sendNextMsg) {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "handleSmsSent: move message to sent folder uri: " + uri);
                }
                if (!Telephony.Sms.moveMessageToFolder(this, uri, 2, error)) {
                    Log.e("Mms", "handleSmsSent: failed to move message " + uri + " to sent folder");
                }
                sendFirstQueuedMessage(phoneId);
            }
            MessagingNotification.nonBlockingUpdateSendFailedNotification(this);
            return;
        }
        if (resultCode == 2 || resultCode == 4) {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "handleSmsSent: no service, queuing message w/ uri: " + uri);
            }
            registerForServiceStateChanges();
            Telephony.Sms.moveMessageToFolder(this, uri, 6, error);
            this.mToastHandler.post(new Runnable() { // from class: com.android.mms.transaction.SmsReceiverService.1
                @Override // java.lang.Runnable
                public void run() {
                    AlertDialogFp toast = new AlertDialogFp.Builder(SmsReceiverService.this.getApplicationContext()).setMessage(ModeStringUtil.getModeResFromArray(SmsReceiverService.this, R.array.message_queued)).create();
                    toast.getWindow().setType(2003);
                    toast.setAutoDismiss(true);
                    toast.getWindow().addPrivateFlags(4096);
                    toast.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.android.mms.transaction.SmsReceiverService.1.1
                        @Override // android.content.DialogInterface.OnKeyListener
                        public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                            if (keyCode != 6) {
                                return false;
                            }
                            ActivityManager mActivityManager = (ActivityManager) SmsReceiverService.this.getApplicationContext().getSystemService("activity");
                            dialog.dismiss();
                            mActivityManager.goHome();
                            return true;
                        }
                    });
                    toast.show();
                }
            });
            return;
        }
        if (resultCode == 6) {
            messageFailedToSend(uri, resultCode);
            this.mToastHandler.post(new Runnable() { // from class: com.android.mms.transaction.SmsReceiverService.2
                @Override // java.lang.Runnable
                public void run() {
                }
            });
            return;
        }
        if (resultCode == 5) {
            if (this.otherMutePartState == "true") {
                if (sendNextMsg) {
                    sendFirstQueuedMessage(phoneId);
                    return;
                }
                return;
            }
            Telephony.Sms.moveMessageToFolder(this, uri, 5, error);
            return;
        }
        messageFailedToSend(uri, error);
        if (sendNextMsg) {
            sendFirstQueuedMessage(phoneId);
        }
    }

    private void messageFailedToSend(Uri uri, int error) {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "messageFailedToSend msg failed uri: " + uri + " error: " + error);
        }
        Telephony.Sms.moveMessageToFolder(this, uri, 5, error);
        MessagingNotification.notifySendFailed(getApplicationContext(), true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleSmsReceived(Intent intent, int error) {
        SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        String format = intent.getStringExtra("format");
        String orgAddr = msgs[0].getStoreOriginatingAddress();
        String msgBody = msgs[0].getMessageBody();
        Log.d("Mms", "New sms from argAddr:xxxxx  msgBody: **** ");
        boolean isNeedReceived = isMessageCanReceived(orgAddr);
        if (!isNeedReceived) {
            Log.d("Mms", "New message is comming, but not receive");
            return;
        }
        Intent service = new Intent(ISmsRingtoneService.class.getName());
        service.setPackage(getPackageName());
        boolean bindResult = bindService(service, mServiceConnection, 1);
        if (bindResult) {
            this.isBindRingtoneService = true;
        }
        if ("NTT DOCOMO".equalsIgnoreCase(orgAddr) && msgBody != null && msgBody.startsWith(VOICE_MASSAGE_BODY)) {
            Log.d("Mms", "handleSmsReceived() notification isn't registered, return.");
            return;
        }
        Uri messageUri = insertMessage(this, msgs, error, format);
        if (Log.isLoggable("Mms", 2)) {
            SmsMessage sms = msgs[0];
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.v("Mms", "handleSmsReceived" + (sms.isReplace() ? "(replace)" : LoggingEvents.EXTRA_CALLING_APP_NAME) + " messageUri: ***, address: ***, body: ***");
            } else {
                Log.v("Mms", "handleSmsReceived" + (sms.isReplace() ? "(replace)" : LoggingEvents.EXTRA_CALLING_APP_NAME) + " messageUri: " + messageUri + ", address: " + sms.getOriginatingAddress() + ", body: " + sms.getMessageBody());
            }
        }
        if (messageUri != null) {
            IBinder binder = ServiceManager.getService("simple_power_off");
            ISimplePowerOff mService = ISimplePowerOff.Stub.asInterface(binder);
            try {
                boolean isSPO = mService.isSimplePowerOff();
                Log.d("Mms", "new sms isSimplePowerOff = " + isSPO);
                if (isSPO) {
                    Log.d("Mms", "new sms, is power off, return");
                    return;
                }
            } catch (RemoteException e) {
                Log.d("Mms", "do simple exception ");
            }
            long threadId = MessagingNotification.getSmsThreadId(this, messageUri);
            Log.d("Mms", "handleSmsReceived messageUri: " + messageUri + " threadId: " + threadId);
            notifyHandlerNewSms();
            SetWakeLock twl = new SetWakeLock(this);
            twl.acquireWakeLock();
            twl.releasewakeLock();
        }
    }

    public class SetWakeLock {
        private Context mContext;
        private PowerManager.WakeLock mWakeLock_F;
        private PowerManager.WakeLock mWakeLock_P;

        public SetWakeLock(Context context) {
            this.mContext = context;
        }

        public void acquireWakeLock() {
            if (this.mWakeLock_P == null && this.mWakeLock_F == null) {
                PowerManager powerManager = (PowerManager) this.mContext.getSystemService("power");
                if (powerManager != null) {
                    try {
                        this.mWakeLock_P = powerManager.newWakeLock(268435457, "Mms");
                        this.mWakeLock_F = powerManager.newWakeLock(268435482, "Mms");
                        this.mWakeLock_P.acquire();
                        this.mWakeLock_F.acquire();
                        return;
                    } catch (Exception e) {
                        Log.e("Mms", "wakeLock() newWakeLock Error:" + e.getMessage());
                        return;
                    }
                }
                Log.e("Mms", "wakeLock() getSystemService Error");
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void releasewakeLock() {
            if (this.mWakeLock_P != null && this.mWakeLock_F != null) {
                this.mWakeLock_F.release();
                this.mWakeLock_P.release();
                this.mWakeLock_F = null;
                this.mWakeLock_P = null;
            }
        }
    }

    private boolean isMessageCanReceived(String number) {
        boolean isSettingOn = FjSettings.Global.getInt(getContentResolver(), "out_of_contact_message", 1) == 1;
        if (!isSettingOn) {
            Log.d("Mms", "Is message can received, setting off");
            return true;
        }
        Contact cacheContact = Contact.get(number, true);
        boolean isName = cacheContact.isName();
        Log.d("Mms", "New sms from name: ***    isName = " + isName + "  number =  xxxx");
        if (isName || "NTT DOCOMO".equals(number)) {
            Log.d("Mms", "handleSmsReceived from number registered in contacts");
            return true;
        }
        if (!"NTT DOCOMO".equals(number) && !"NTT DoCoMo".equals(number) && !"DoCoMo".equals(number) && !"*PublicPhon".equals(number) && !"PublicPhone".equals(number) && !"*Unavailabl".equals(number) && !DOCOMO_SMS.equals(number) && !"Unavailable".equals(number)) {
            return false;
        }
        Log.d("Mms", "handleSmsReceived special from  xxxxxxxx");
        return true;
    }

    private void notifyHandlerNewSms() {
        Log.d("Mms", "notifyHandleNewSms");
        boolean isMannerModeOn = FjSettings.Global.getInt(getContentResolver(), "manner_mode_on", 0) == 1;
        boolean isMannerModeSilent = FjSettings.Global.getInt(getContentResolver(), "manner_mode", 0) == 1;
        Log.d("Mms", "notifyHandlerNewSms isMannerModeOn " + isMannerModeOn + "   isMannerModeSilent " + isMannerModeSilent);
        if (isMannerModeOn) {
            if (isMannerModeSilent) {
                Log.d("Mms", "notifyHandlerNewSms manner mode is on and silent mode");
                return;
            } else {
                startVibrate();
                return;
            }
        }
        boolean smsVibEnabled = FjSettings.Global.getInt(getContentResolver(), "vibrate_when_message", 1) == 1;
        Log.d("Mms", "notifyHandlerNewSms enable vibrate " + smsVibEnabled);
        if (smsVibEnabled) {
            startVibrate();
        }
        if (!getBuzzerSoundState()) {
            Log.d("Mms", "notifyHandlerNewSms enable playRingtone ");
            playRingtone();
        }
    }

    public boolean getBuzzerSoundState() {
        String state = this.mAudioManager.getParameters("buzzer");
        Log.d("Mms", "getBuzzerSoundState : " + state);
        return !"buzzer=off".equals(state);
    }

    private void playRingtone() {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.startToRington();
            } catch (Exception e) {
                Log.d("Mms", "Play ringtone exception :" + e);
            }
        }
    }

    private void startVibrate() {
        long[][] vibrationPattern = VIBRATION_PATTERN;
        long[] pattern = vibrationPattern[0];
        mVibrator = (Vibrator) getSystemService("vibrator");
        mVibrator.vibrate(pattern, -1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleCbSmsReceived(Intent intent, int error) {
        CellBroadcastMessage cbMessage;
        String country;
        Uri cbMessageUri;
        Bundle extras = intent.getExtras();
        if (extras != null && (cbMessage = (CellBroadcastMessage) extras.get("message")) != null) {
            boolean isMSim = TelephonyManager.getDefault().isMultiSimEnabled();
            if (isMSim) {
                country = TelephonyManager.getDefault().getSimCountryIso(cbMessage.getSubId());
            } else {
                country = TelephonyManager.getDefault().getSimCountryIso();
            }
            int serviceCategory = cbMessage.getServiceCategory();
            if ("in".equals(country)) {
                if ((serviceCategory == 50 || serviceCategory == CB_CHANNEL_60) && (cbMessageUri = storeCbMessage(this, cbMessage, error)) != null) {
                    MessagingNotification.getSmsThreadId(this, cbMessageUri);
                    MessagingNotification.blockingUpdateNewMessageIndicator(this, true, false);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleBootCompleted() {
        int numMoved = moveOutboxMessagesToFailedBox();
        if (numMoved > 0) {
            MessagingNotification.notifySendFailed(getApplicationContext(), true);
        }
        for (int i = 0; i < TelephonyManager.getDefault().getPhoneCount(); i++) {
            if (!this.mSending[i]) {
                sendFirstQueuedMessage(i);
            }
        }
        MessagingNotification.blockingUpdateNewMessageIndicator(this, true, false);
    }

    private int moveOutboxMessagesToQueuedBox() {
        ContentValues values = new ContentValues(1);
        values.put("type", (Integer) 6);
        int messageCount = SqliteWrapper.update(getApplicationContext(), getContentResolver(), Telephony.Sms.Outbox.CONTENT_URI, values, "type = 4", (String[]) null);
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "moveOutboxMessagesToQueuedBox messageCount: " + messageCount);
        }
        if (messageCount >= 0) {
            MmsApp.smsFlag = true;
        }
        return messageCount;
    }

    private int moveOutboxMessagesToFailedBox() {
        ContentValues values = new ContentValues(3);
        values.put("type", (Integer) 5);
        values.put("error_code", (Integer) 1);
        values.put("read", (Integer) 0);
        int messageCount = SqliteWrapper.update(getApplicationContext(), getContentResolver(), Telephony.Sms.Outbox.CONTENT_URI, values, "type = 4", (String[]) null);
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "moveOutboxMessagesToFailedBox messageCount: " + messageCount);
        }
        return messageCount;
    }

    private Uri insertMessage(Context context, SmsMessage[] msgs, int error, String format) {
        SmsMessage sms = msgs[0];
        if (sms.getMessageClass() == SmsMessage.MessageClass.CLASS_0) {
            displayClassZeroMessage(context, sms, format);
            return null;
        }
        if (sms.isReplace()) {
            return replaceMessage(context, msgs, error);
        }
        return storeMessage(context, msgs, error);
    }

    private Uri replaceMessage(Context context, SmsMessage[] msgs, int error) {
        SmsMessage sms = msgs[0];
        ContentValues values = extractContentValues(sms);
        values.put("error_code", Integer.valueOf(error));
        int pduCount = msgs.length;
        replaceSmsOnSim(sms);
        if (pduCount == 1) {
            values.put("body", replaceFormFeeds(sms.getDisplayMessageBody()));
        } else {
            StringBuilder body = new StringBuilder();
            for (int i = 0; i < pduCount; i++) {
                sms = msgs[i];
                if (sms.mWrappedSmsMessage != null) {
                    body.append(sms.getDisplayMessageBody());
                }
            }
            values.put("body", replaceFormFeeds(body.toString()));
        }
        ContentResolver resolver = context.getContentResolver();
        String originatingAddress = sms.getStoreOriginatingAddress();
        int protocolIdentifier = sms.getProtocolIdentifier();
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", " SmsReceiverService: replaceMessage:");
        }
        String[] selectionArgs = {originatingAddress, Integer.toString(protocolIdentifier), Integer.toString(SubscriptionManager.getPhoneId(sms.getSubId()))};
        Cursor cursor = SqliteWrapper.query(context, resolver, Telephony.Sms.Inbox.CONTENT_URI, REPLACE_PROJECTION, "address = ? AND protocol = ? AND phone_id = ? ", selectionArgs, (String) null);
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    long messageId = cursor.getLong(0);
                    Uri messageUri = ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, messageId);
                    SqliteWrapper.update(context, resolver, messageUri, values, (String) null, (String[]) null);
                    return messageUri;
                }
            } finally {
                cursor.close();
            }
        }
        return storeMessage(context, msgs, error);
    }

    public static String replaceFormFeeds(String s) {
        return s == null ? LoggingEvents.EXTRA_CALLING_APP_NAME : s.replace('\f', '\n');
    }

    private void replaceSmsOnSim(SmsMessage sms) {
        if (sms != null && sms.getMessageClass() == SmsMessage.MessageClass.CLASS_2 && sms.isReplace()) {
            ArrayList<SmsMessage> smsOnSimList = SmsManager.getDefault().getAllMessagesFromIcc();
            if (smsOnSimList.size() > 0) {
                ArrayList<Integer> delete = new ArrayList<>();
                boolean meetSelf = false;
                for (int i = 0; i < smsOnSimList.size(); i++) {
                    SmsMessage tmp = smsOnSimList.get(i);
                    if (TextUtils.equals(sms.getOriginatingAddress(), tmp.getOriginatingAddress()) && sms.getProtocolIdentifier() == tmp.getProtocolIdentifier()) {
                        Log.d("Mms", "find replace sms: " + tmp.getIndexOnIcc());
                        if (!meetSelf && TextUtils.equals(sms.getServiceCenterAddress(), tmp.getServiceCenterAddress()) && TextUtils.equals(sms.getMessageBody(), tmp.getMessageBody()) && sms.getTimestampMillis() == tmp.getTimestampMillis()) {
                            Log.d("Mms", "same as current");
                            meetSelf = true;
                        } else {
                            Log.d("Mms", "will delete: " + tmp.getIndexOnIcc());
                            delete.add(Integer.valueOf(tmp.getIndexOnIcc()));
                        }
                    }
                }
                for (int i2 = 0; i2 < delete.size(); i2++) {
                    SmsManager.getDefault().deleteMessageFromIcc(delete.get(i2).intValue());
                }
            }
        }
    }

    private Uri storeMessage(Context context, SmsMessage[] msgs, int error) {
        SmsMessage sms = msgs[0];
        ContentValues values = extractContentValues(sms);
        values.put("error_code", Integer.valueOf(error));
        values.put("phone_id", Integer.valueOf(SubscriptionManager.getPhoneId(sms.getSubId())));
        int pduCount = msgs.length;
        if (pduCount == 1) {
            values.put("body", replaceFormFeeds(sms.getDisplayMessageBody()));
        } else {
            StringBuilder body = new StringBuilder();
            for (SmsMessage sms2 : msgs) {
                if (sms2.mWrappedSmsMessage != null) {
                    body.append(sms2.getDisplayMessageBody());
                }
            }
            values.put("body", replaceFormFeeds(body.toString()));
        }
        Long threadId = values.getAsLong(ComposeMessageActivity.THREAD_ID);
        String address = values.getAsString("address");
        if (!TextUtils.isEmpty(address)) {
            Contact cacheContact = Contact.get(address, true);
            if (cacheContact != null) {
                address = cacheContact.getNumber();
            }
        } else {
            address = getString(ModeStringUtil.getModeResFromArray(context, R.array.unknown_sender));
            values.put("address", address);
        }
        if ((threadId == null || threadId.longValue() == 0) && address != null) {
            threadId = Long.valueOf(Conversation.getOrCreateThreadId(context, SmsMessage.getDispOriginatingAddress(address)));
            values.put(ComposeMessageActivity.THREAD_ID, threadId);
        }
        ContentResolver resolver = context.getContentResolver();
        Uri insertedUri = SqliteWrapper.insert(context, resolver, Telephony.Sms.Inbox.CONTENT_URI, values);
        Recycler.getSmsRecycler().deleteOldMessagesByThreadId(context, threadId.longValue());
        MmsWidgetProvider.notifyDatasetChanged(context);
        return insertedUri;
    }

    private Uri storeCbMessage(Context context, CellBroadcastMessage sms, int error) {
        ContentValues values = new ContentValues();
        values.put("error_code", Integer.valueOf(error));
        values.put("phone_id", Integer.valueOf(SubscriptionManager.getPhoneId(sms.getSubId())));
        values.put("body", sms.getMessageBody());
        String address = getString(R.string.cell_broadcast_sender) + Integer.toString(sms.getServiceCategory());
        values.put("address", address);
        Long threadId = Long.valueOf(Conversation.getOrCreateThreadId(context, address));
        values.put(ComposeMessageActivity.THREAD_ID, threadId);
        values.put("read", (Integer) 0);
        values.put("seen", (Integer) 0);
        ContentResolver resolver = context.getContentResolver();
        Uri insertedUri = SqliteWrapper.insert(context, resolver, Telephony.Sms.Inbox.CONTENT_URI, values);
        Recycler.getSmsRecycler().deleteOldMessagesByThreadId(context, threadId.longValue());
        MmsWidgetProvider.notifyDatasetChanged(context);
        return insertedUri;
    }

    private ContentValues extractContentValues(SmsMessage sms) {
        ContentValues values = new ContentValues();
        values.put("address", sms.getStoreOriginatingAddress());
        Object buildDate = new GregorianCalendar(2011, 8, 18);
        Calendar nowDate = new GregorianCalendar();
        long now = System.currentTimeMillis();
        nowDate.setTimeInMillis(now);
        if (nowDate.before(buildDate)) {
            now = sms.getTimestampMillis();
        }
        values.put("date", new Long(now));
        values.put("date_sent", Long.valueOf(sms.getTimestampMillis()));
        values.put("protocol", Integer.valueOf(sms.getProtocolIdentifier()));
        values.put("read", (Integer) 0);
        values.put("seen", (Integer) 0);
        if (sms.getPseudoSubject().length() > 0) {
            values.put("subject", sms.getPseudoSubject());
        }
        values.put("reply_path_present", Integer.valueOf(sms.isReplyPathPresent() ? 1 : 0));
        values.put("service_center", sms.getServiceCenterAddress());
        return values;
    }

    private void displayClassZeroMessage(Context context, SmsMessage sms, String format) {
        int subId = sms.getSubId();
        int phoneId = SubscriptionManager.getPhoneId(subId);
        Intent smsDialogIntent = new Intent(context, (Class<?>) ClassZeroActivity.class).putExtra("pdu", sms.getPdu()).putExtra("format", format).putExtra("phone", phoneId).setFlags(402653184);
        context.startActivity(smsDialogIntent);
    }

    private void registerForServiceStateChanges() {
        Context context = getApplicationContext();
        unRegisterForServiceStateChanges();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.SERVICE_STATE");
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "registerForServiceStateChanges");
        }
        context.registerReceiver(SmsReceiver.getInstance(), intentFilter);
    }

    private void unRegisterForServiceStateChanges() {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "unRegisterForServiceStateChanges");
        }
        try {
            Context context = getApplicationContext();
            context.unregisterReceiver(SmsReceiver.getInstance());
        } catch (IllegalArgumentException e) {
        }
    }

    private boolean isUnRegisterAllowed(int phoneId) {
        boolean success = true;
        Uri uri = Uri.parse("content://sms/queued");
        ContentResolver resolver = getContentResolver();
        String[] whereArgs = {Integer.toString(phoneId)};
        Cursor c = SqliteWrapper.query(this, resolver, uri, SEND_PROJECTION, "phone_id != ?", whereArgs, "date ASC");
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    success = false;
                }
            } finally {
                c.close();
            }
        }
        return success;
    }
}
