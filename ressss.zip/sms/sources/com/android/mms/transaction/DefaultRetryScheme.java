package com.android.mms.transaction;

import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public class DefaultRetryScheme extends AbstractRetryScheme {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private static final int[] sDefaultRetryScheme = {0, 60000, 300000, 600000, 1800000};

    public DefaultRetryScheme(Context context, int retriedTimes) {
        super(retriedTimes);
        this.mRetriedTimes = this.mRetriedTimes < 0 ? 0 : this.mRetriedTimes;
        this.mRetriedTimes = this.mRetriedTimes >= sDefaultRetryScheme.length ? sDefaultRetryScheme.length - 1 : this.mRetriedTimes;
    }

    @Override // com.android.mms.transaction.AbstractRetryScheme
    public int getRetryLimit() {
        return sDefaultRetryScheme.length;
    }

    @Override // com.android.mms.transaction.AbstractRetryScheme
    public long getWaitingInterval() {
        return sDefaultRetryScheme[this.mRetriedTimes];
    }
}
