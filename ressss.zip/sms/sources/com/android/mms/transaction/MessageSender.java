package com.android.mms.transaction;

import com.google.android.mms.MmsException;

/* JADX INFO: loaded from: classes.dex */
public interface MessageSender {
    public static final String RECIPIENTS_SEPARATOR = ";";

    boolean sendMessage(long j) throws MmsException;
}
