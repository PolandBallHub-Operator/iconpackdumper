package com.android.mms.transaction;

import android.net.Uri;

/* JADX INFO: loaded from: classes.dex */
public class TransactionState {
    public static final int FAILED = 2;
    public static final int INITIALIZED = 0;
    public static final int SUCCESS = 1;
    private int mState = 0;
    private Uri mContentUri = null;

    public synchronized int getState() {
        return this.mState;
    }

    synchronized void setState(int state) {
        try {
            if (state < 0 && state > 2) {
                throw new IllegalArgumentException("Bad state: " + state);
            }
            this.mState = state;
        } catch (Throwable th) {
            throw th;
        }
    }

    public synchronized Uri getContentUri() {
        return this.mContentUri;
    }

    synchronized void setContentUri(Uri uri) {
        this.mContentUri = uri;
    }
}
