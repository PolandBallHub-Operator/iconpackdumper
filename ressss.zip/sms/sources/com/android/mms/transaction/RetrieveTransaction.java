package com.android.mms.transaction;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.provider.Telephony;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.MmsConfig;
import com.android.mms.ui.MessageUtils;
import com.android.mms.ui.MessagingPreferenceActivity;
import com.android.mms.util.DownloadManager;
import com.android.mms.util.Recycler;
import com.android.mms.widget.MmsWidgetProvider;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.AcknowledgeInd;
import com.google.android.mms.pdu.EncodedStringValue;
import com.google.android.mms.pdu.PduComposer;
import com.google.android.mms.pdu.PduParser;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.RetrieveConf;
import java.io.IOException;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class RetrieveTransaction extends Transaction implements Runnable {
    static final int COLUMN_CONTENT_LOCATION = 0;
    static final int COLUMN_LOCKED = 1;
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    static final String[] PROJECTION = {"ct_l", "locked"};
    private static final String TAG = "Mms";
    private final String mContentLocation;
    private boolean mLocked;
    private final Uri mUri;

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    public RetrieveTransaction(Context context, int serviceId, TransactionSettings connectionSettings, String uri) throws MmsException {
        super(context, serviceId, connectionSettings);
        if (uri.startsWith("content://")) {
            this.mUri = Uri.parse(uri);
            String contentLocation = getContentLocation(context, this.mUri);
            this.mContentLocation = contentLocation;
            this.mId = contentLocation;
            attach(RetryScheduler.getInstance(context));
            return;
        }
        throw new IllegalArgumentException("Initializing from X-Mms-Content-Location is abandoned!");
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    private String getContentLocation(Context context, Uri uri) throws MmsException {
        Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(), uri, PROJECTION, (String) null, (String[]) null, (String) null);
        this.mLocked = false;
        if (cursor != null) {
            try {
                if (cursor.getCount() == 1 && cursor.moveToFirst()) {
                    this.mLocked = cursor.getInt(1) == 1;
                    return cursor.getString(0);
                }
            } finally {
                cursor.close();
            }
        }
        throw new MmsException("Cannot get X-Mms-Content-Location from: " + uri);
    }

    @Override // com.android.mms.transaction.Transaction
    public void process() {
        new Thread(this, "RetrieveTransaction").start();
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            try {
                DownloadManager downloadManager = DownloadManager.getInstance();
                int msgSize = downloadManager.getMessageSize(this.mUri);
                downloadManager.markState(this.mUri, DownloadManager.STATE_DOWNLOADING);
                byte[] resp = getPdu(this.mContentLocation);
                RetrieveConf retrieveConf = (RetrieveConf) new PduParser(resp, PduParserUtil.shouldParseContentDisposition()).parse();
                if (retrieveConf == null) {
                    throw new MmsException("Invalid M-Retrieve.conf PDU.");
                }
                Uri msgUri = null;
                if (isDuplicateMessage(this.mContext, retrieveConf)) {
                    this.mTransactionState.setState(2);
                    this.mTransactionState.setContentUri(this.mUri);
                } else {
                    PduPersister persister = PduPersister.getPduPersister(this.mContext);
                    msgUri = persister.persist(retrieveConf, Telephony.Mms.Inbox.CONTENT_URI, true, MessagingPreferenceActivity.getIsGroupMmsEnabled(this.mContext), (HashMap) null);
                    ContentValues values = new ContentValues(3);
                    values.put("date", Long.valueOf(System.currentTimeMillis() / 1000));
                    Cursor c = this.mContext.getContentResolver().query(this.mUri, null, null, null, null);
                    if (c != null) {
                        try {
                            if (c.moveToFirst()) {
                                int phoneId = c.getInt(c.getColumnIndex("phone_id"));
                                Log.d("Mms", "RetrieveTransaction: phoneId value is " + phoneId);
                                values.put("phone_id", Integer.valueOf(phoneId));
                            }
                            c.close();
                        } catch (Throwable th) {
                            c.close();
                            throw th;
                        }
                    }
                    values.put("m_size", Integer.valueOf(msgSize));
                    SqliteWrapper.update(this.mContext, this.mContext.getContentResolver(), msgUri, values, (String) null, (String[]) null);
                    this.mTransactionState.setState(1);
                    this.mTransactionState.setContentUri(msgUri);
                    updateContentLocation(this.mContext, msgUri, this.mContentLocation, this.mLocked);
                }
                SqliteWrapper.delete(this.mContext, this.mContext.getContentResolver(), this.mUri, (String) null, (String[]) null);
                if (msgUri != null) {
                    Recycler.getMmsRecycler().deleteOldMessagesInSameThreadAsMessage(this.mContext, msgUri);
                    MmsWidgetProvider.notifyDatasetChanged(this.mContext);
                }
                sendAcknowledgeInd(retrieveConf);
                if (this.mTransactionState.getState() != 1) {
                    this.mTransactionState.setState(2);
                    this.mTransactionState.setContentUri(this.mUri);
                    Log.e("Mms", "Retrieval failed.");
                }
                notifyObservers();
            } catch (Throwable t) {
                Log.e("Mms", Log.getStackTraceString(t));
                if (this.mTransactionState.getState() != 1) {
                    this.mTransactionState.setState(2);
                    this.mTransactionState.setContentUri(this.mUri);
                    Log.e("Mms", "Retrieval failed.");
                }
                notifyObservers();
            }
        } catch (Throwable th2) {
            if (this.mTransactionState.getState() != 1) {
                this.mTransactionState.setState(2);
                this.mTransactionState.setContentUri(this.mUri);
                Log.e("Mms", "Retrieval failed.");
            }
            notifyObservers();
            throw th2;
        }
    }

    private static boolean isDuplicateMessage(Context context, RetrieveConf rc) {
        byte[] rawMessageId = rc.getMessageId();
        if (rawMessageId != null) {
            String messageId = new String(rawMessageId);
            String[] selectionArgs = {messageId, String.valueOf(132)};
            Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(), Telephony.Mms.CONTENT_URI, new String[]{"_id", "sub", "sub_cs"}, "(m_id = ? AND m_type = ?)", selectionArgs, (String) null);
            if (cursor != null) {
                try {
                    if (cursor.getCount() > 0) {
                        return isDuplicateMessageExtra(cursor, rc);
                    }
                } finally {
                    cursor.close();
                }
            }
        }
        return false;
    }

    private static boolean isDuplicateMessageExtra(Cursor cursor, RetrieveConf rc) {
        EncodedStringValue encodedSubjectStored = null;
        String subjectReceived = null;
        EncodedStringValue encodedSubjectReceived = rc.getSubject();
        if (encodedSubjectReceived != null) {
            subjectReceived = encodedSubjectReceived.getString();
        }
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int subjectIdx = cursor.getColumnIndex("sub");
            int charsetIdx = cursor.getColumnIndex("sub_cs");
            String subject = cursor.getString(subjectIdx);
            int charset = cursor.getInt(charsetIdx);
            if (subject != null) {
                encodedSubjectStored = new EncodedStringValue(charset, PduPersister.getBytes(subject));
            }
            if (encodedSubjectStored == null && encodedSubjectReceived == null) {
                return true;
            }
            if (encodedSubjectStored != null && encodedSubjectReceived != null) {
                String subjectStored = encodedSubjectStored.getString();
                if (!TextUtils.isEmpty(subjectStored) && !TextUtils.isEmpty(subjectReceived)) {
                    return subjectStored.equals(subjectReceived);
                }
                if (TextUtils.isEmpty(subjectStored) && TextUtils.isEmpty(subjectReceived)) {
                    return true;
                }
            }
            cursor.moveToNext();
        }
        return false;
    }

    private void sendAcknowledgeInd(RetrieveConf rc) throws MmsException, IOException {
        byte[] tranId = rc.getTransactionId();
        if (tranId != null) {
            AcknowledgeInd acknowledgeInd = new AcknowledgeInd(18, tranId);
            String lineNumber = MessageUtils.getLocalNumber();
            acknowledgeInd.setFrom(new EncodedStringValue(lineNumber));
            if (MmsConfig.getNotifyWapMMSC()) {
                sendPdu(new PduComposer(this.mContext, acknowledgeInd).make(), this.mContentLocation);
            } else {
                sendPdu(new PduComposer(this.mContext, acknowledgeInd).make());
            }
        }
    }

    private static void updateContentLocation(Context context, Uri uri, String contentLocation, boolean locked) {
        ContentValues values = new ContentValues(2);
        values.put("ct_l", contentLocation);
        values.put("locked", Boolean.valueOf(locked));
        SqliteWrapper.update(context, context.getContentResolver(), uri, values, (String) null, (String[]) null);
    }

    @Override // com.android.mms.transaction.Transaction
    public void abort() {
        Log.d("Mms", "markFailed = " + this);
        DownloadManager downloadManager = DownloadManager.getInstance();
        this.mTransactionState.setState(2);
        this.mTransactionState.setContentUri(this.mUri);
        downloadManager.markState(this.mUri, DownloadManager.STATE_SKIP_RETRYING);
        notifyObservers();
    }

    @Override // com.android.mms.transaction.Transaction
    public int getType() {
        return 1;
    }
}
