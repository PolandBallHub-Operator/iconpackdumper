package com.android.mms.transaction;

/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractRetryScheme {
    public static final int INCOMING = 2;
    public static final int OUTGOING = 1;
    protected int mRetriedTimes;

    public abstract int getRetryLimit();

    public abstract long getWaitingInterval();

    public AbstractRetryScheme(int retriedTimes) {
        this.mRetriedTimes = retriedTimes;
    }
}
