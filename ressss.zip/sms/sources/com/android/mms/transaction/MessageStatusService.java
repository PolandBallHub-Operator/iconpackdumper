package com.android.mms.transaction;

import android.app.IntentService;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.telephony.SmsMessage;
import android.util.Log;
import com.android.mms.MmsConfig;

/* JADX INFO: loaded from: classes.dex */
public class MessageStatusService extends IntentService {
    private static final String LOG_TAG = "Mms";
    private static final String[] ID_PROJECTION = {"_id"};
    private static final Uri STATUS_URI = Uri.parse("content://sms/status");

    public MessageStatusService() {
        super(MessageStatusService.class.getName());
        setIntentRedelivery(true);
    }

    @Override // android.app.IntentService
    protected void onHandleIntent(Intent intent) {
        if (!MmsConfig.isSmsEnabled(this)) {
            Log.d("Mms", "MessageStatusService: is not the default sms app");
            return;
        }
        Uri messageUri = intent.getData();
        byte[] pdu = intent.getByteArrayExtra("pdu");
        String format = intent.getStringExtra("format");
        SmsMessage message = updateMessageStatus(this, messageUri, pdu, format);
        if (message != null && message.getStatus() < 32) {
            MessagingNotification.blockingUpdateNewMessageIndicator(this, true, message.isStatusReportMessage());
        }
    }

    private SmsMessage updateMessageStatus(Context context, Uri messageUri, byte[] pdu, String format) {
        SmsMessage message = SmsMessage.createFromPdu(pdu, format);
        if (message == null) {
            return null;
        }
        Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(), messageUri, ID_PROJECTION, (String) null, (String[]) null, (String) null);
        try {
            if (cursor.moveToFirst()) {
                int messageId = cursor.getInt(0);
                Uri updateUri = ContentUris.withAppendedId(STATUS_URI, messageId);
                int status = message.getStatus();
                boolean isStatusReport = message.isStatusReportMessage();
                ContentValues contentValues = new ContentValues(2);
                if (Log.isLoggable("Mms", 3)) {
                    log("updateMessageStatus: msgUrl=" + messageUri + ", status=" + status + ", isStatusReport=" + isStatusReport);
                }
                contentValues.put("status", Integer.valueOf(status));
                contentValues.put("date_sent", Long.valueOf(System.currentTimeMillis()));
                SqliteWrapper.update(context, context.getContentResolver(), updateUri, contentValues, (String) null, (String[]) null);
            } else {
                error("Can't find message for status update: " + messageUri);
            }
            return message;
        } finally {
            cursor.close();
        }
    }

    private void error(String message) {
        Log.e("Mms", "[MessageStatusReceiver] " + message);
    }

    private void log(String message) {
        Log.d("Mms", "[MessageStatusReceiver] " + message);
    }
}
