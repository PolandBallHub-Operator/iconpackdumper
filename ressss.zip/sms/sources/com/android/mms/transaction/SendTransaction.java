package com.android.mms.transaction;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.SystemProperties;
import android.provider.Telephony;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.ui.MessageUtils;
import com.android.mms.util.RateController;
import com.android.mms.util.SendingProgressTokenManager;
import com.google.android.mms.pdu.EncodedStringValue;
import com.google.android.mms.pdu.PduComposer;
import com.google.android.mms.pdu.PduParser;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.SendConf;
import com.google.android.mms.pdu.SendReq;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class SendTransaction extends Transaction implements Runnable {
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final String TAG = "Mms";
    public final Uri mSendReqURI;
    private Thread mThread;

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
    }

    public SendTransaction(Context context, int transId, TransactionSettings connectionSettings, String uri) {
        super(context, transId, connectionSettings);
        this.mSendReqURI = Uri.parse(uri);
        this.mId = uri;
        attach(RetryScheduler.getInstance(context));
    }

    @Override // com.android.mms.transaction.Transaction
    public void process() {
        this.mThread = new Thread(this, "SendTransaction");
        this.mThread.start();
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            RateController rateCtlr = RateController.getInstance();
            if (rateCtlr.isLimitSurpassed() && !rateCtlr.isAllowedByUser()) {
                Log.e("Mms", "Sending rate limit surpassed.");
                return;
            }
            PduPersister persister = PduPersister.getPduPersister(this.mContext);
            SendReq sendReq = persister.load(this.mSendReqURI);
            long date = System.currentTimeMillis() / 1000;
            sendReq.setDate(date);
            ContentValues values = new ContentValues(1);
            values.put("date", Long.valueOf(date));
            SqliteWrapper.update(this.mContext, this.mContext.getContentResolver(), this.mSendReqURI, values, (String) null, (String[]) null);
            String lineNumber = MessageUtils.getLocalNumber(this.mSubId);
            Log.d("Mms", "lineNumber " + lineNumber);
            if (!TextUtils.isEmpty(lineNumber)) {
                sendReq.setFrom(new EncodedStringValue(lineNumber));
            }
            long tokenKey = ContentUris.parseId(this.mSendReqURI);
            byte[] response = sendPdu(SendingProgressTokenManager.get(Long.valueOf(tokenKey)), new PduComposer(this.mContext, sendReq).make());
            SendingProgressTokenManager.remove(Long.valueOf(tokenKey));
            if (Log.isLoggable("Mms", 2)) {
                String respStr = new String(response);
                if (FJ_TEL_LOG_ACQ_FLG) {
                    Log.d("Mms", "[SendTransaction] run: send mms msg (***), resp=***");
                } else {
                    Log.d("Mms", "[SendTransaction] run: send mms msg (" + this.mId + "), resp=" + respStr);
                }
            }
            SendConf conf = new PduParser(response, PduParserUtil.shouldParseContentDisposition()).parse();
            if (conf == null) {
                Log.e("Mms", "No M-Send.conf received.");
            }
            byte[] reqId = sendReq.getTransactionId();
            byte[] confId = conf.getTransactionId();
            if (!Arrays.equals(reqId, confId)) {
                Log.e("Mms", "Inconsistent Transaction-ID: req=" + new String(reqId) + ", conf=" + new String(confId));
                return;
            }
            ContentValues values2 = new ContentValues(2);
            int respStatus = conf.getResponseStatus();
            values2.put("resp_st", Integer.valueOf(respStatus));
            if (respStatus != 128) {
                SqliteWrapper.update(this.mContext, this.mContext.getContentResolver(), this.mSendReqURI, values2, (String) null, (String[]) null);
                Log.e("Mms", "Server returned an error code: " + respStatus);
                return;
            }
            String messageId = PduPersister.toIsoString(conf.getMessageId());
            values2.put("m_id", messageId);
            SqliteWrapper.update(this.mContext, this.mContext.getContentResolver(), this.mSendReqURI, values2, (String) null, (String[]) null);
            Uri uri = persister.move(this.mSendReqURI, Telephony.Mms.Sent.CONTENT_URI);
            this.mTransactionState.setState(1);
            this.mTransactionState.setContentUri(uri);
        } catch (Throwable t) {
            Log.e("Mms", Log.getStackTraceString(t));
        } finally {
            if (this.mTransactionState.getState() != 1) {
                this.mTransactionState.setState(2);
                this.mTransactionState.setContentUri(this.mSendReqURI);
                Log.e("Mms", "Delivery failed.");
            }
            notifyObservers();
        }
    }

    @Override // com.android.mms.transaction.Transaction
    public void abort() {
        Log.d("Mms", "markFailed = " + this);
        this.mTransactionState.setState(2);
        this.mTransactionState.setContentUri(this.mSendReqURI);
        notifyObservers();
    }

    @Override // com.android.mms.transaction.Transaction
    public int getType() {
        return 2;
    }
}
