package com.android.mms.transaction;

import android.app.ActivityManager;
import android.app.AlertDialogFp;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.KeyEvent;
import com.android.mms.R;
import com.android.mms.util.ModeStringUtil;

/* JADX INFO: loaded from: classes.dex */
public class SmsRejectedReceiver extends BroadcastReceiver {
    public static final int SMS_REJECTED_NOTIFICATION_ID = 239;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Log.d("SmsRejectedReceiver", " handle broadcast action = " + intent.getAction());
        if ("android.provider.Telephony.SMS_REJECTED".equals(intent.getAction())) {
            int reason = intent.getIntExtra("result", -1);
            final ActivityManager mActivityManager = (ActivityManager) context.getSystemService("activity");
            boolean outOfMemory = reason == 3;
            if (!outOfMemory) {
                Log.d("SmsRejectedReceiver", " handle rejected broadcast");
                return;
            }
            Log.d("SmsRejectedReceiver", " handle out of memory broadcast");
            AlertDialogFp toast = new AlertDialogFp.Builder(context.getApplicationContext()).setMessage(ModeStringUtil.getModeResFromArray(context, R.array.sms_out_of_memory)).create();
            toast.getWindow().setType(2003);
            toast.setAutoDismiss(true);
            toast.getWindow().addPrivateFlags(4096);
            toast.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.android.mms.transaction.SmsRejectedReceiver.1
                @Override // android.content.DialogInterface.OnKeyListener
                public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                    if (keyCode != 6) {
                        return false;
                    }
                    dialog.dismiss();
                    mActivityManager.goHome();
                    return true;
                }
            });
            toast.show();
        }
    }
}
