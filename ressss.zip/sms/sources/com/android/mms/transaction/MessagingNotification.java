package com.android.mms.transaction;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SqliteWrapper;
import android.drm.DrmManagerClient;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.provider.FjSettings;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.StyleSpan;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.widget.Toast;
import com.android.common.speech.LoggingEvents;
import com.android.mms.MmsConfig;
import com.android.mms.MmsNewsPreferences;
import com.android.mms.NewMessagePreference;
import com.android.mms.R;
import com.android.mms.data.Contact;
import com.android.mms.data.Conversation;
import com.android.mms.model.SlideModel;
import com.android.mms.model.SlideshowModel;
import com.android.mms.model.SmilHelper;
import com.android.mms.ui.ComposeMessageActivity;
import com.android.mms.ui.ConversationList;
import com.android.mms.ui.MessagingPreferenceActivity;
import com.android.mms.util.AddressUtils;
import com.android.mms.util.DownloadManager;
import com.android.mms.util.ModeStringUtil;
import com.android.mms.widget.MmsWidgetProvider;
import com.google.android.mms.pdu.EncodedStringValue;
import com.google.android.mms.pdu.PduPersister;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/* JADX INFO: loaded from: classes.dex */
public class MessagingNotification {
    private static final int COLUMN_DATE = 1;
    private static final int COLUMN_MMS_ID = 2;
    private static final int COLUMN_PHONE_ID = 5;
    private static final int COLUMN_SMS_ADDRESS = 2;
    private static final int COLUMN_SMS_BODY = 4;
    private static final int COLUMN_SUBJECT = 3;
    private static final int COLUMN_SUBJECT_CS = 4;
    private static final int COLUMN_THREAD_ID = 0;
    private static final boolean DEBUG = false;
    private static final String DOCOMO = "'NTT DOCOMO'";
    public static final int DOWNLOAD_FAILED_NOTIFICATION_ID = 531;
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final MmsSmsNotificationInfoComparator INFO_COMPARATOR;
    private static final float IN_CONVERSATION_NOTIFICATION_VOLUME = 0.25f;
    private static final String KEY_LED_COLOR = "pref_key_led_color";
    private static final int LED_DEFAULT_COLOR = 255;
    private static final int LED_DEFAULT_COLOR_INDEX = 3;
    private static final int MAX_BITMAP_DIMEN_DP = 360;
    private static final int MAX_MESSAGES_TO_SHOW = 8;
    public static final int MESSAGE_FAILED_NOTIFICATION_ID = 789;
    private static final int MMS_PRIVACY_NOTIFICATION_ID = 987;
    private static final String[] MMS_STATUS_PROJECTION;
    private static final String[] MMS_THREAD_ID_PROJECTION;
    private static final String NEW_DELIVERY_SM_CONSTRAINT = "(type = 2 AND status = 0)";
    private static final String NEW_INCOMING_MM_CONSTRAINT = "(msg_box=1 AND seen=0 AND (m_type=130 OR m_type=132))";
    private static final String NEW_INCOMING_SM_CONSTRAINT = "(type = 1 AND seen = 0)";
    private static final String NEW_INCOMING_SM_CONSTRAINT_EX = "((type = 1 AND seen = 0) AND NOT (address LIKE 'NTT DOCOMO' AND body LIKE 'VM:%'))";
    private static final String NOTIFICATION_DELETED_ACTION = "com.android.mms.NOTIFICATION_DELETED_ACTION";
    private static final int NOTIFICATION_ID = 123;
    private static final int READING_FAILED = 1;
    private static final int READING_UPDATE = 0;
    private static final String[] SMS_STATUS_PROJECTION;
    private static final String[] SMS_THREAD_ID_PROJECTION;
    private static final String TAG = "Mms";
    public static final long THREAD_ALL = -1;
    public static final long THREAD_NONE = -2;
    private static final Uri UNDELIVERED_URI;
    private static final String UNREAD_INCOMING_SM_CONSTRAINT = "(type = 1 AND read = 0)";
    private static final String VM = "'VM:%'";
    private static int lcdTime;
    public static Context mContext;
    private static ISmsRingtoneService mISmsRingtoneService;
    private static ServiceConnection mServiceConnection;
    private static long sCurrentlyDisplayedThreadId;
    private static final Object sCurrentlyDisplayedThreadLock;
    private static Handler sHandler;
    private static OnDeletedReceiver sNotificationDeletedReceiver;
    private static Intent sNotificationOnDeleteIntent;
    private static PduPersister sPduPersister;
    private static float sScreenDensity;
    private static OnScreenOnReceiver sScreenOnReceiver;
    public static boolean sUsersAction;

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
        mContext = null;
        MMS_STATUS_PROJECTION = new String[]{ComposeMessageActivity.THREAD_ID, "date", "_id", "sub", "sub_cs", "phone_id"};
        SMS_STATUS_PROJECTION = new String[]{ComposeMessageActivity.THREAD_ID, "date", "address", "subject", "body", "phone_id"};
        lcdTime = 5;
        SMS_THREAD_ID_PROJECTION = new String[]{ComposeMessageActivity.THREAD_ID};
        MMS_THREAD_ID_PROJECTION = new String[]{ComposeMessageActivity.THREAD_ID};
        INFO_COMPARATOR = new MmsSmsNotificationInfoComparator();
        UNDELIVERED_URI = Uri.parse("content://mms-sms/undelivered");
        sScreenOnReceiver = new OnScreenOnReceiver();
        sCurrentlyDisplayedThreadLock = new Object();
        sNotificationDeletedReceiver = new OnDeletedReceiver();
        sHandler = new Handler();
        sUsersAction = false;
        mISmsRingtoneService = null;
        mServiceConnection = new ServiceConnection() { // from class: com.android.mms.transaction.MessagingNotification.1
            @Override // android.content.ServiceConnection
            public void onServiceConnected(ComponentName name, IBinder binder) {
                ISmsRingtoneService unused = MessagingNotification.mISmsRingtoneService = ISmsRingtoneService.Stub.asInterface(binder);
            }

            @Override // android.content.ServiceConnection
            public void onServiceDisconnected(ComponentName name) {
                ISmsRingtoneService unused = MessagingNotification.mISmsRingtoneService = null;
            }
        };
    }

    public static class OnScreenOnReceiver extends BroadcastReceiver {
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
        }
    }

    public static class OnDeletedReceiver extends BroadcastReceiver {
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Log.isLoggable("Mms", 2)) {
                Log.d("Mms", "[MessagingNotification] clear notification: mark all msgs seen");
            }
            Conversation.markAllConversationsAsSeen(context);
        }
    }

    private MessagingNotification() {
    }

    public static void init(Context context) {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(NOTIFICATION_DELETED_ACTION);
        context.registerReceiver(sNotificationDeletedReceiver, intentFilter);
        sPduPersister = PduPersister.getPduPersister(context);
        sNotificationOnDeleteIntent = new Intent(NOTIFICATION_DELETED_ACTION);
        sScreenDensity = context.getResources().getDisplayMetrics().density;
        Intent intent = new Intent(ISmsRingtoneService.class.getName());
        intent.setPackage(context.getPackageName());
        context.bindService(intent, mServiceConnection, 1);
        IntentFilter screenOnFilter = new IntentFilter();
        screenOnFilter.addAction("android.intent.action.SCREEN_ON");
        screenOnFilter.addAction("android.intent.action.SCREEN_OFF");
        context.registerReceiver(sScreenOnReceiver, screenOnFilter);
    }

    public static void setCurrentlyDisplayedThreadId(long threadId) {
        synchronized (sCurrentlyDisplayedThreadLock) {
            sCurrentlyDisplayedThreadId = threadId;
        }
    }

    public static void nonBlockingUpdateNewMessageIndicator(final Context context, final boolean isNew, final boolean isStatusMessage) {
        new Thread(new Runnable() { // from class: com.android.mms.transaction.MessagingNotification.2
            @Override // java.lang.Runnable
            public void run() {
                MessagingNotification.blockingUpdateNewMessageIndicator(context, isNew, isStatusMessage);
            }
        }, "MessagingNotification.nonBlockingUpdateNewMessageIndicator").start();
    }

    public static void blockingUpdateNewMessageIndicator(Context context, boolean isNew, boolean isStatusMessage) {
        boolean isDefaultSmsApp = MmsConfig.isSmsEnabled(context);
        if (!isDefaultSmsApp) {
            cancelNotification(context, NOTIFICATION_ID);
            if (Log.isLoggable("Mms", 2)) {
                Log.d("Mms", "blockingUpdateNewMessageIndicator: not the default sms app - skipping notification");
                return;
            }
            return;
        }
        blockingUpdateNewMessageIndicator(context, isNew, isStatusMessage, true);
    }

    private static void blockingUpdateNewMessageIndicator(Context context, boolean isNew, boolean isStatusMessage, boolean isRingtone) {
        SortedSet<MmsSmsNotificationInfo> accumulator = new TreeSet<>(INFO_COMPARATOR);
        Set<Long> threads = new HashSet<>(4);
        int count = 0 + accumulateNotificationInfo(accumulator, getMmsNewMessageNotificationInfo(context, threads));
        MmsSmsNotificationInfo info = getSmsNewMessageNotificationInfo(context, threads);
        int count2 = count + accumulateNotificationInfo(accumulator, info);
        cancelNotification(context, NOTIFICATION_ID);
        MmsNewsPreferences.setNewsCount(context, 0);
        Uri uri = null;
        if (count2 != 0 && threads.size() == 1 && isNew && info != null) {
            uri = info.mClickIntent.getData();
        }
        NewMessagePreference.setNewsCountToBroadcast(context, count2, uri);
        NewMessagePreference.setUnreadCountToBroadcast(context, getSmsUnreadMessageCount(context));
        if (!accumulator.isEmpty() && !sUsersAction) {
            if (Log.isLoggable("Mms", 2)) {
                Log.d("Mms", "blockingUpdateNewMessageIndicator: count=" + count2 + ", isNew=" + isNew);
            }
            accumulator.first().deliver(context, isNew, count2, threads.size(), isRingtone);
        }
        MmsSmsDeliveryInfo delivery = getSmsNewDeliveryInfo(context);
        if (delivery != null) {
            delivery.deliver(context, isStatusMessage);
        }
        sUsersAction = false;
    }

    public static void blockingUpdateAllNotifications(Context context) {
        nonBlockingUpdateNewMessageIndicator(context, false, false);
        updateSendFailedNotification(context);
        updateDownloadFailedNotification(context);
    }

    private static final int accumulateNotificationInfo(SortedSet set, MmsSmsNotificationInfo info) {
        if (info == null) {
            return 0;
        }
        set.add(info);
        return info.mCount;
    }

    private static void playInConversationNotificationSound(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        String ringtoneStr = sp.getString(MessagingPreferenceActivity.NOTIFICATION_RINGTONE, null);
        if (!TextUtils.isEmpty(ringtoneStr)) {
            Uri ringtoneUri = getCustomRingtoneUri(context, ringtoneStr);
            final NotificationPlayer player = new NotificationPlayer("Mms");
            player.play(context, ringtoneUri, false, 5, IN_CONVERSATION_NOTIFICATION_VOLUME);
            sHandler.postDelayed(new Runnable() { // from class: com.android.mms.transaction.MessagingNotification.3
                @Override // java.lang.Runnable
                public void run() {
                    player.stop();
                }
            }, 5000L);
        }
    }

    public static void blockingUpdateAllNotifications(Context context, long threadId) {
        nonBlockingUpdateNewMessageIndicator(context, false, false);
        nonBlockingUpdateSendFailedNotification(context);
        updateDownloadFailedNotification(context);
        MmsWidgetProvider.notifyDatasetChanged(context);
    }

    private static final class MmsSmsDeliveryInfo {
        public CharSequence mTicker;
        public long mTimeMillis;

        public MmsSmsDeliveryInfo(CharSequence ticker, long timeMillis) {
            this.mTicker = ticker;
            this.mTimeMillis = timeMillis;
        }

        public void deliver(Context context, boolean isStatusMessage) {
            MessagingNotification.updateDeliveryNotification(context, isStatusMessage, this.mTicker, this.mTimeMillis);
        }
    }

    private static final class MmsSmsNotificationInfo {
        public Intent mClickIntent;
        public int mCount;
        public String mDescription;
        public int mIconResourceId;
        public boolean mIsName;
        public final boolean mIsPhoneticName;
        public final String mPhoneticName;
        public int mSubId;
        public CharSequence mTicker;
        public long mTimeMillis;
        public String mTitle;

        public MmsSmsNotificationInfo(Intent clickIntent, String description, int iconResourceId, CharSequence ticker, int subId, long timeMillis, String title, int count, boolean isName, String phoneticName, boolean isPhoneticName) {
            this.mClickIntent = clickIntent;
            this.mDescription = description;
            this.mIconResourceId = iconResourceId;
            this.mTicker = ticker;
            this.mSubId = subId;
            this.mTimeMillis = timeMillis;
            this.mTitle = title;
            this.mCount = count;
            this.mIsName = isName;
            this.mPhoneticName = phoneticName;
            this.mIsPhoneticName = isPhoneticName;
        }

        public void deliver(Context context, boolean isNew, int count, int uniqueThreads, boolean isRingtone) {
            MessagingNotification.updateNotification(context, this.mClickIntent, this.mDescription, this.mIconResourceId, isNew, isNew ? this.mTicker : null, this.mSubId, this.mTimeMillis, this.mTitle, count, uniqueThreads, this.mIsName, isRingtone, this.mPhoneticName, this.mIsPhoneticName);
        }

        public long getTime() {
            return this.mTimeMillis;
        }
    }

    private static CharSequence formatSenders(Context context, ArrayList<MmsSmsNotificationInfo> senders) {
        TextAppearanceSpan notificationSenderSpan = new TextAppearanceSpan(context, R.style.NotificationPrimaryText);
        String separator = context.getString(R.string.enumeration_comma);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        int len = senders.size();
        for (int i = 0; i < len; i++) {
            if (i > 0) {
                spannableStringBuilder.append((CharSequence) separator);
            }
        }
        spannableStringBuilder.setSpan(notificationSenderSpan, 0, spannableStringBuilder.length(), 0);
        return spannableStringBuilder;
    }

    private static final class MmsSmsNotificationInfoComparator implements Comparator<MmsSmsNotificationInfo> {
        private MmsSmsNotificationInfoComparator() {
        }

        @Override // java.util.Comparator
        public int compare(MmsSmsNotificationInfo info1, MmsSmsNotificationInfo info2) {
            return Long.signum(info2.getTime() - info1.getTime());
        }
    }

    private static final MmsSmsNotificationInfo getMmsNewMessageNotificationInfo(Context context, Set<Long> threads) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = SqliteWrapper.query(context, resolver, Telephony.Mms.CONTENT_URI, MMS_STATUS_PROJECTION, NEW_INCOMING_MM_CONSTRAINT, (String[]) null, "date desc");
        if (cursor == null) {
            return null;
        }
        try {
            if (!cursor.moveToFirst()) {
                return null;
            }
            long msgId = cursor.getLong(2);
            Uri msgUri = Telephony.Mms.CONTENT_URI.buildUpon().appendPath(Long.toString(msgId)).build();
            String address = AddressUtils.getFrom(context, msgUri);
            Contact contact = Contact.get(address, false);
            if (contact.getSendToVoicemail()) {
                return null;
            }
            String subject = getMmsSubject(cursor.getString(3), cursor.getInt(4));
            long threadId = cursor.getLong(0);
            long timeMillis = cursor.getLong(1) * 1000;
            int phoneId = cursor.getInt(5);
            if (Log.isLoggable("Mms", 2)) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    Log.d("Mms", "addMmsNotificationInfos: count=" + cursor.getCount() + ", addr = ***, thread_id=" + threadId);
                } else {
                    Log.d("Mms", "addMmsNotificationInfos: count=" + cursor.getCount() + ", addr = " + address + ", thread_id=" + threadId);
                }
            }
            MmsSmsNotificationInfo newMessageNotificationInfo = getNewMessageNotificationInfo(address, subject, context, R.drawable.stat_notify_mms, null, threadId, phoneId, timeMillis, cursor.getCount());
            threads.add(Long.valueOf(threadId));
            while (cursor.moveToNext()) {
                threads.add(Long.valueOf(cursor.getLong(0)));
            }
            return newMessageNotificationInfo;
        } finally {
            cursor.close();
        }
    }

    private static int getAttachmentType(SlideshowModel slideshow) {
        int slideCount = slideshow.size();
        if (slideCount == 0) {
            return 0;
        }
        if (slideCount > 1) {
            return 4;
        }
        SlideModel slide = slideshow.get(0);
        if (slide.hasImage()) {
            return 1;
        }
        if (slide.hasVideo()) {
            return 2;
        }
        return slide.hasAudio() ? 3 : 0;
    }

    private static final int dp2Pixels(int dip) {
        return (int) ((dip * sScreenDensity) + 0.5f);
    }

    private static final MmsSmsDeliveryInfo getSmsNewDeliveryInfo(Context context) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = SqliteWrapper.query(context, resolver, Telephony.Sms.CONTENT_URI, SMS_STATUS_PROJECTION, NEW_DELIVERY_SM_CONSTRAINT, (String[]) null, "date");
        if (cursor == null) {
            return null;
        }
        try {
            if (cursor.moveToLast()) {
                String address = SmsMessage.getDispOriginatingAddress(cursor.getString(2));
                Contact contact = Contact.get(address, false);
                contact.getNameAndNumber();
                Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address));
                Cursor c = context.getContentResolver().query(uri, new String[]{"display_name"}, null, null, null);
                if (c != null) {
                    c.moveToFirst();
                    if (c.getCount() != 0 && (address = c.getString(c.getColumnIndex("display_name"))) == null) {
                        address = cursor.getString(2);
                    }
                    c.close();
                }
                return new MmsSmsDeliveryInfo(String.format(context.getString(R.string.delivery_toast_body), address), 3000L);
            }
            return null;
        } finally {
            cursor.close();
        }
    }

    private static final MmsSmsNotificationInfo getSmsNewMessageNotificationInfo(Context context, Set<Long> threads) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = SqliteWrapper.query(context, resolver, Telephony.Sms.CONTENT_URI, SMS_STATUS_PROJECTION, NEW_INCOMING_SM_CONSTRAINT_EX, (String[]) null, "date desc");
        if (cursor == null) {
            return null;
        }
        try {
            if (!cursor.moveToFirst()) {
                return null;
            }
            String address = SmsMessage.getDispOriginatingAddress(cursor.getString(2));
            Contact contact = Contact.get(address, false);
            contact.reload();
            if (contact.getSendToVoicemail()) {
                return null;
            }
            long threadId = cursor.getLong(0);
            long timeMillis = cursor.getLong(1);
            int phoneId = cursor.getInt(5);
            if (Log.isLoggable("Mms", 2)) {
                Log.d("Mms", "getSmsNewMessageNotificationInfo: count=" + cursor.getCount() + ", first addr=" + address + ", thread_id=" + threadId);
            }
            MmsSmsNotificationInfo newMessageNotificationInfo = getNewMessageNotificationInfo(address, null, context, R.drawable.stat_notify_sms, null, threadId, phoneId, timeMillis, cursor.getCount());
            threads.add(Long.valueOf(threadId));
            while (cursor.moveToNext()) {
                threads.add(Long.valueOf(cursor.getLong(0)));
            }
            return newMessageNotificationInfo;
        } finally {
            cursor.close();
        }
    }

    private static final int getSmsUnreadMessageCount(Context context) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = SqliteWrapper.query(context, resolver, Telephony.Sms.CONTENT_URI, SMS_STATUS_PROJECTION, UNREAD_INCOMING_SM_CONSTRAINT, (String[]) null, "date desc");
        if (cursor == null) {
            return -1;
        }
        try {
            if (!cursor.moveToFirst()) {
                return 0;
            }
            String address = cursor.getString(2);
            Contact contact = Contact.get(address, false);
            if (contact.getSendToVoicemail()) {
                return -1;
            }
            return cursor.getCount();
        } finally {
            cursor.close();
        }
    }

    private static final void addSmsNotificationInfos(Context context, Set<Long> threads, SortedSet<MmsSmsNotificationInfo> notificationSet) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = SqliteWrapper.query(context, resolver, Telephony.Sms.CONTENT_URI, SMS_STATUS_PROJECTION, NEW_INCOMING_SM_CONSTRAINT_EX, (String[]) null, "date desc");
        if (cursor != null) {
            while (cursor.moveToNext()) {
                try {
                    String address = SmsMessage.getDispOriginatingAddress(cursor.getString(2));
                    Contact contact = Contact.get(address, false);
                    if (!contact.getSendToVoicemail()) {
                        long threadId = cursor.getLong(0);
                        long timeMillis = cursor.getLong(1);
                        int phoneId = cursor.getInt(5);
                        if (Log.isLoggable("Mms", 2)) {
                            if (FJ_TEL_LOG_ACQ_FLG) {
                                Log.d("Mms", "addSmsNotificationInfos: count=" + cursor.getCount() + ", addr=***, thread_id=" + threadId);
                            } else {
                                Log.d("Mms", "addSmsNotificationInfos: count=" + cursor.getCount() + ", addr=" + address + ", thread_id=" + threadId);
                            }
                        }
                        MmsSmsNotificationInfo info = getNewMessageNotificationInfo(address, null, context, R.drawable.stat_notify_sms, null, threadId, phoneId, timeMillis, cursor.getCount());
                        notificationSet.add(info);
                        threads.add(Long.valueOf(threadId));
                        threads.add(Long.valueOf(cursor.getLong(0)));
                    }
                } catch (Throwable th) {
                    cursor.close();
                    throw th;
                }
            }
            cursor.close();
        }
    }

    private static final MmsSmsNotificationInfo getNewMessageNotificationInfo(String address, String body, Context context, int iconResourceId, String subject, long threadId, int phoneId, long timeMillis, int count) {
        Intent clickIntent = ComposeMessageActivity.createIntent(context, threadId);
        clickIntent.putExtra("from_notification", true);
        clickIntent.setFlags(872415232);
        String senderInfo = buildTickerMessage(context, address, null, null, phoneId).toString();
        String senderInfoName = senderInfo.substring(0, senderInfo.length());
        String phoneName = Contact.get(address, true).getName();
        CharSequence ticker = buildTickerMessage(context, address, subject, body, phoneId);
        boolean isName = Contact.get(address, true).isName();
        boolean isPhoneticName = Contact.get(address, true).isPhoneticName();
        return new MmsSmsNotificationInfo(clickIntent, body, iconResourceId, ticker, phoneId, timeMillis, senderInfoName, count, isName, phoneName, isPhoneticName);
    }

    public static void cancelNotification(Context context, int notificationId) {
        NotificationManager nm = (NotificationManager) context.getSystemService("notification");
        Log.d("Mms", "cancelNotification");
        nm.cancel(notificationId);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void updateDeliveryNotification(final Context context, boolean isStatusMessage, final CharSequence message, final long timeMillis) {
        if (isStatusMessage && MessagingPreferenceActivity.getNotificationEnabled(context)) {
            sHandler.post(new Runnable() { // from class: com.android.mms.transaction.MessagingNotification.4
                @Override // java.lang.Runnable
                public void run() {
                    Toast.makeText(context, message, (int) timeMillis).show();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void updateNotification(Context context, Intent clickIntent, String description, int iconRes, boolean isNew, CharSequence ticker, int subId, long timeMillis, String title, int messageCount, int uniqueThreadCount, boolean isName, boolean isRingtone, String phoneticName, boolean isPhoneticName) {
        Notification notification;
        if (MessagingPreferenceActivity.getNotificationEnabled(context)) {
            if (isNew || !isRingtone) {
                notification = new Notification();
                notification.icon = R.drawable.stat_notify_sms;
            } else {
                notification = new Notification(iconRes, ticker, timeMillis);
            }
            if (uniqueThreadCount > 1) {
                title = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.notification_multiple_title));
                clickIntent = new Intent("android.intent.action.MAIN");
                clickIntent.setFlags(872415232);
                clickIntent.setType("vnd.android-dir/mms-sms");
            }
            if (messageCount > 1) {
                description = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.notification_multiple), Integer.toString(messageCount));
            }
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, clickIntent, 134217728);
            notification.setLatestEventInfo(context, title, description, pendingIntent);
            stopOutOfName();
            stopRinging();
            stopVibrate();
            if (isNew) {
                boolean isMannerModeOn = FjSettings.Global.getInt(context.getContentResolver(), "manner_mode_on", 0) == 1;
                boolean isMannerModeSilent = FjSettings.Global.getInt(context.getContentResolver(), "manner_mode", 0) == 1;
                boolean smsVibEnabled = FjSettings.Global.getInt(context.getContentResolver(), "vibrate_when_message", 1) == 1;
                Log.d("Mms", "isMannerModeOn = " + isMannerModeOn + "  isMannerModeSilent = " + isMannerModeSilent + "  smsVibEnabled = " + smsVibEnabled);
                if (isMannerModeOn) {
                    if (!isMannerModeSilent) {
                        startVibrate();
                    }
                } else if (smsVibEnabled) {
                    startVibrate();
                }
                if (!isMannerModeOn) {
                    AudioManager audioManager = (AudioManager) context.getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
                    String state = audioManager.getParameters("buzzer");
                    Log.d("Mms", "buzzer state = " + state);
                    if ("buzzer=off".equals(state)) {
                        startToRing();
                    }
                }
            }
            int colorIndex = 3;
            try {
                SharedPreferences ledSettings = PreferenceManager.getDefaultSharedPreferences(context);
                colorIndex = ledSettings.getInt("pref_key_led_color", 3);
            } catch (Exception e) {
                Log.e("Mms", "[Get LED settings][Exception]");
            }
            TypedArray colors = context.getResources().obtainTypedArray(R.array.led_colors);
            if (colorIndex >= 0 && colorIndex < colors.length()) {
                int color = colors.getColor(colorIndex, 255);
                if (color != 0) {
                    notification.ledARGB = color;
                    notification.flags |= 1;
                    notification.ledOnMS = 500;
                    notification.ledOffMS = 2000;
                }
            } else {
                notification.ledARGB = colors.getColor(3, 255);
                notification.flags |= 1;
                notification.ledOnMS = 500;
                notification.ledOffMS = 2000;
            }
            notification.deleteIntent = PendingIntent.getBroadcast(context, 0, sNotificationOnDeleteIntent, 0);
            if (!isRingtone) {
                notification.defaults &= -3;
                notification.sound = null;
            }
            if (messageCount > 0) {
                MmsNewsPreferences.setNewsCount(context, 1);
            }
            if (0 != 0) {
                if (isRingtone) {
                    if (isName) {
                        if (isPhoneticName) {
                            readingOutOfName(context, phoneticName, 0);
                            return;
                        } else {
                            readingOutOfName(context, title, 0);
                            return;
                        }
                    }
                    readingOutOfName(context, null, 0);
                    return;
                }
                stopOutOfName();
            }
        }
    }

    private static Uri getCustomRingtoneUri(Context context, String ringtoneUriString) {
        Uri ret_uri;
        if (ringtoneUriString == null || TextUtils.isEmpty(ringtoneUriString)) {
            return null;
        }
        Uri uri = Uri.parse(ringtoneUriString);
        if (uri.equals(Settings.System.DEFAULT_NOTIFICATION_URI)) {
            String uriStr = getRingtoneUri(context, uri);
            if (uriStr == null) {
                return null;
            }
        }
        if (isRightsValid(context, uri)) {
            ret_uri = uri;
        } else if (isRightsValid(context, Settings.System.DEFAULT_NOTIFICATION_URI)) {
            ret_uri = Settings.System.DEFAULT_NOTIFICATION_URI;
        } else {
            ret_uri = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.flow_tone);
        }
        return ret_uri;
    }

    private static boolean isRightsValid(Context context, Uri uri) {
        boolean result = false;
        if (Log.isLoggable("Mms", 2)) {
            Log.d("Mms", "isRightsValid(" + uri + ")");
        }
        if (uri == null) {
            result = true;
        } else {
            if (uri.equals(Settings.System.DEFAULT_NOTIFICATION_URI)) {
                String uriStr = getRingtoneUri(context, uri);
                if (uriStr == null) {
                    return false;
                }
                uri = Uri.parse(uriStr);
            }
            DrmManagerClient dmc = new DrmManagerClient(context);
            try {
                boolean canhandle = dmc.canHandle(uri, (String) null);
                if (canhandle) {
                    int canPlay = dmc.checkRightsStatus(uri, 1);
                    int canRingtone = dmc.checkRightsStatus(uri, 2);
                    if (canPlay == 0) {
                        if (canRingtone == 0) {
                            result = true;
                            if (Log.isLoggable("Mms", 2)) {
                                Log.d("Mms", "Enable to setting as ringtone");
                            }
                        } else if (Log.isLoggable("Mms", 2)) {
                            Log.w("Mms", "Disable to setting as ringtone");
                        }
                    } else if (Log.isLoggable("Mms", 2)) {
                        Log.w("Mms", "Can not play");
                    }
                } else {
                    result = true;
                    if (Log.isLoggable("Mms", 2)) {
                        Log.w("Mms", "Non protected content");
                    }
                }
            } catch (Exception e) {
                Log.e("Mms", "Exception at canHandle. uri: " + uri);
                return false;
            }
        }
        if (result) {
            boolean isPlayable = false;
            MediaPlayer tmp = null;
            try {
                try {
                    tmp = MediaPlayer.create(context, uri);
                    if (tmp != null) {
                        isPlayable = true;
                        tmp.release();
                    }
                } catch (Exception e2) {
                    Log.e("Mms", "not playable");
                    if (0 != 0) {
                        isPlayable = true;
                        tmp.release();
                    }
                }
                Log.d("Mms", "isPlayable = " + isPlayable);
                result = isPlayable;
            } catch (Throwable th) {
                if (tmp != null) {
                    tmp.release();
                }
                throw th;
            }
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.w("Mms", "isRightsValid(" + uri + ") return: " + result);
        }
        return result;
    }

    private static String getRingtoneUri(Context context, Uri uri) {
        String value = null;
        try {
            Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    value = cursor.getString(cursor.getColumnIndex(LoggingEvents.VoiceSearch.EXTRA_QUERY_UPDATED_VALUE));
                }
                cursor.close();
            }
        } catch (SQLiteException sqle) {
            Log.e(LoggingEvents.EXTRA_CALLING_APP_NAME, sqle.getMessage());
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.w("Mms", "getRingtoneUri()---Value: " + value);
        }
        return value;
    }

    private static void readingOutOfName(Context context, String readingTitle, int readingType) {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.startSpeak(readingTitle, readingType);
            } catch (RemoteException e) {
                Log.e("Mms", "[readingOutOfName][RemoteException]");
            }
        }
    }

    public static void stopOutOfName() {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.stopSpeak();
            } catch (RemoteException e) {
                Log.e("Mms", "[stopOutOfName][RemoteException]");
            }
        }
    }

    protected static CharSequence buildTickerMessage(Context context, String address, String subject, String body, int phoneId) {
        String displayAddress = Contact.get(address, true).getName();
        StringBuilder buf = new StringBuilder(displayAddress == null ? LoggingEvents.EXTRA_CALLING_APP_NAME : displayAddress.replace('\n', ' ').replace('\r', ' '));
        if (!TextUtils.isEmpty(body)) {
            buf.append(':').append(' ');
        }
        if (TelephonyManager.getDefault().getPhoneCount() > 1) {
            SubscriptionInfo sir = SubscriptionManager.from(context).getActiveSubscriptionInfoForSimSlotIndex(phoneId);
            String displayName = sir != null ? sir.getDisplayName().toString() : LoggingEvents.EXTRA_CALLING_APP_NAME;
            Log.e("Mms", "PhoneID : " + phoneId + " displayName ***");
            buf.append(displayName);
            buf.append("-");
        }
        int offset = buf.length();
        if (!TextUtils.isEmpty(subject)) {
            buf.append(subject.replace('\n', ' ').replace('\r', ' '));
            buf.append(' ');
        }
        if (!TextUtils.isEmpty(body)) {
            buf.append(body.replace('\n', ' ').replace('\r', ' '));
        }
        SpannableString spanText = new SpannableString(buf.toString());
        spanText.setSpan(new StyleSpan(1), 0, offset, 33);
        return spanText;
    }

    private static String getMmsSubject(String sub, int charset) {
        return TextUtils.isEmpty(sub) ? LoggingEvents.EXTRA_CALLING_APP_NAME : new EncodedStringValue(charset, PduPersister.getBytes(sub)).getString();
    }

    public static void notifyDownloadFailed(Context context, long threadId) {
        notifyFailed(context, true, threadId, false);
    }

    public static void notifySendFailed(Context context) {
        notifyFailed(context, false, 0L, false);
    }

    public static void notifySendFailed(Context context, boolean noisy) {
        notifyFailed(context, false, 0L, noisy);
    }

    private static void notifyFailed(Context context, boolean isDownload, long threadId, boolean noisy) {
        String title;
        String description;
        Intent failedIntent;
        boolean enabled = MessagingPreferenceActivity.getNotificationEnabled(context);
        if (enabled) {
            long[] msgThreadId = {0, 1};
            int totalFailedCount = getUndeliveredMessageCount(context, msgThreadId);
            if (totalFailedCount != 0 || isDownload) {
                boolean allFailedInSameThread = msgThreadId[1] != 0 || isDownload;
                Notification notification = new Notification();
                if (totalFailedCount > 1) {
                    description = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.notification_failed_multiple), Integer.toString(totalFailedCount));
                    title = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.notification_failed_multiple_title));
                } else {
                    title = isDownload ? context.getString(R.string.message_download_failed_title) : context.getString(ModeStringUtil.getModeResFromArray(context, R.array.message_send_failed_title));
                    description = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.message_failed_body));
                }
                TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(context);
                if (allFailedInSameThread) {
                    failedIntent = new Intent(context, (Class<?>) ComposeMessageActivity.class);
                    if (isDownload) {
                        failedIntent.putExtra("failed_download_flag", true);
                    } else {
                        threadId = msgThreadId[0];
                        failedIntent.putExtra("undelivered_flag", true);
                    }
                    failedIntent.putExtra(ComposeMessageActivity.THREAD_ID, threadId);
                    taskStackBuilder.addParentStack(ComposeMessageActivity.class);
                } else {
                    failedIntent = new Intent(context, (Class<?>) ConversationList.class);
                }
                taskStackBuilder.addNextIntent(failedIntent);
                notification.icon = R.drawable.stat_notify_sms_failed;
                notification.tickerText = title;
                notification.setLatestEventInfo(context, title, description, taskStackBuilder.getPendingIntent(0, 134217728));
                boolean readingFailed = false;
                if (noisy) {
                    SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
                    boolean isMannerModeOn = FjSettings.Global.getInt(context.getContentResolver(), "manner_mode_on", 0) == 1;
                    boolean isMannerModeSilent = FjSettings.Global.getInt(context.getContentResolver(), "manner_mode", 0) == 1;
                    boolean smsVibEnabled = FjSettings.Global.getInt(context.getContentResolver(), "vibrate_when_message", 1) == 1;
                    if (smsVibEnabled && (!isMannerModeOn || !isMannerModeSilent)) {
                        startVibrate();
                    }
                    context.getContentResolver();
                    boolean isReadingOut = sp.getBoolean(MessagingPreferenceActivity.SELECTED_READING_OUT, false);
                    if (isReadingOut) {
                        readingFailed = true;
                        notification.sound = null;
                    } else {
                        readingFailed = false;
                        if (!isMannerModeOn) {
                            AudioManager audioManager = (AudioManager) context.getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
                            String state = audioManager.getParameters("buzzer");
                            if ("buzzer=off".equals(state)) {
                                startToRing();
                            }
                        }
                    }
                }
                if (readingFailed) {
                    readingOutOfName(context, title, 1);
                }
            }
        }
    }

    private static void smsReceiverDisplay(Context context, String name) {
        Intent intent = new Intent("com.nextfp.android.util.sublcd.ACTION_SMS");
        intent.putExtra("com.nextfp.android.util.sublcd.EXTRA_BOTTOMLINE", name);
        intent.setPackage("com.nextfp.android.util.sublcd");
        context.sendBroadcast(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int getUndeliveredMessageCount(Context context, long[] threadIdResult) {
        int count = 0;
        Cursor undeliveredCursor = SqliteWrapper.query(context, context.getContentResolver(), UNDELIVERED_URI, new String[]{ComposeMessageActivity.THREAD_ID}, "read=0", (String[]) null, (String) null);
        if (undeliveredCursor != null) {
            count = undeliveredCursor.getCount();
            if (threadIdResult != null) {
                try {
                    if (undeliveredCursor.moveToFirst()) {
                        threadIdResult[0] = undeliveredCursor.getLong(0);
                        if (threadIdResult.length >= 2) {
                            long firstId = threadIdResult[0];
                            while (undeliveredCursor.moveToNext()) {
                                if (undeliveredCursor.getLong(0) != firstId) {
                                    firstId = 0;
                                    break;
                                }
                            }
                            threadIdResult[1] = firstId;
                        }
                    }
                } finally {
                    undeliveredCursor.close();
                }
            }
        }
        return count;
    }

    public static void updateSendFailedNotification(Context context) {
        if (getUndeliveredMessageCount(context, null) < 1) {
            cancelNotification(context, MESSAGE_FAILED_NOTIFICATION_ID);
        } else {
            notifySendFailed(context);
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [com.android.mms.transaction.MessagingNotification$5] */
    public static void nonBlockingUpdateSendFailedNotification(final Context context) {
        new AsyncTask<Void, Void, Integer>() { // from class: com.android.mms.transaction.MessagingNotification.5
            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public Integer doInBackground(Void... none) {
                return Integer.valueOf(MessagingNotification.getUndeliveredMessageCount(context, null));
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public void onPostExecute(Integer result) {
                if (result.intValue() < 1) {
                    MessagingNotification.cancelNotification(context, MessagingNotification.MESSAGE_FAILED_NOTIFICATION_ID);
                } else {
                    MessagingNotification.notifySendFailed(context);
                }
            }
        }.execute(new Void[0]);
    }

    public static void updateSendFailedNotificationForThread(Context context, long threadId) {
        long[] msgThreadId = {0, 0};
        if (getUndeliveredMessageCount(context, msgThreadId) > 0 && msgThreadId[0] == threadId && msgThreadId[1] != 0) {
            cancelNotification(context, MESSAGE_FAILED_NOTIFICATION_ID);
        }
    }

    private static int getDownloadFailedMessageCount(Context context) {
        Cursor c = SqliteWrapper.query(context, context.getContentResolver(), Telephony.Mms.Inbox.CONTENT_URI, (String[]) null, "m_type=" + String.valueOf(130) + " AND st=" + String.valueOf(DownloadManager.STATE_PERMANENT_FAILURE), (String[]) null, (String) null);
        if (c == null) {
            return 0;
        }
        int count = c.getCount();
        c.close();
        return count;
    }

    public static void updateDownloadFailedNotification(Context context) {
        if (getDownloadFailedMessageCount(context) < 1) {
            cancelNotification(context, DOWNLOAD_FAILED_NOTIFICATION_ID);
        }
    }

    public static boolean isFailedToDeliver(Intent intent) {
        return intent != null && intent.getBooleanExtra("undelivered_flag", false);
    }

    public static boolean isFailedToDownload(Intent intent) {
        return intent != null && intent.getBooleanExtra("failed_download_flag", false);
    }

    public static long getSmsThreadId(Context context, Uri uri) {
        int columnIndex;
        long j = -2;
        Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(), uri, SMS_THREAD_ID_PROJECTION, (String) null, (String[]) null, (String) null);
        if (cursor != null) {
            try {
                if (cursor.moveToFirst() && (columnIndex = cursor.getColumnIndex(ComposeMessageActivity.THREAD_ID)) >= 0) {
                    j = cursor.getLong(columnIndex);
                }
            } finally {
                cursor.close();
            }
        }
        return j;
    }

    public static long getThreadId(Context context, Uri uri) {
        int columnIndex;
        long j = -2;
        Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(), uri, MMS_THREAD_ID_PROJECTION, (String) null, (String[]) null, (String) null);
        if (cursor != null) {
            try {
                if (cursor.moveToFirst() && (columnIndex = cursor.getColumnIndex(ComposeMessageActivity.THREAD_ID)) >= 0) {
                    j = cursor.getLong(columnIndex);
                }
            } finally {
                cursor.close();
            }
        }
        return j;
    }

    private static void startToRing() {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.startToRington();
            } catch (RemoteException e) {
                Log.e("Mms", "[StartRing][RemoteException]");
            }
        }
    }

    public static void stopRinging() {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.stopToRington();
            } catch (RemoteException e) {
                Log.e("Mms", "[StopRing][RemoteException]");
            }
        }
    }

    private static void startVibrate() {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.startToVibrator();
            } catch (RemoteException e) {
                Log.e("Mms", "[StartVibrate][RemoteException]");
            }
        }
    }

    public static void stopVibrate() {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.stopToVibrator();
            } catch (RemoteException e) {
                Log.e("Mms", "[StopVibrate][RemoteException]");
            }
        }
    }

    public static void notifyCautionMessage(Context context) {
        Log.d("Mms", "notifyCautionMessage()...");
        Notification notification = new Notification();
        notification.icon = R.drawable.stat_notify_sms;
        notification.tickerText = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.privacy_caution_message));
        String title = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.privacy_caution_message_title));
        String description = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.privacy_caution_message));
        notification.setLatestEventInfo(context, title, description, null);
        NotificationManager notificationMgr = (NotificationManager) context.getSystemService("notification");
        Log.d("Mms", "notificationMgr.notify");
        notificationMgr.cancel(MMS_PRIVACY_NOTIFICATION_ID);
    }
}
