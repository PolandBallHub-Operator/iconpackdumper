package com.android.mms.transaction;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Uri;
import com.google.android.mms.MmsException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

/* JADX INFO: loaded from: classes.dex */
public abstract class Transaction extends Observable {
    public static final int NOTIFICATION_TRANSACTION = 0;
    public static final int READREC_TRANSACTION = 3;
    public static final int RETRIEVE_TRANSACTION = 1;
    public static final int SEND_TRANSACTION = 2;
    protected Context mContext;
    protected String mId;
    private final int mServiceId;
    protected int mSubId;
    protected TransactionSettings mTransactionSettings;
    protected TransactionState mTransactionState = new TransactionState();

    public abstract void abort();

    public abstract int getType();

    public abstract void process();

    public Transaction(Context context, int serviceId, TransactionSettings settings) {
        this.mContext = context;
        this.mServiceId = serviceId;
        this.mTransactionSettings = settings;
    }

    @Override // com.android.mms.transaction.Observable
    public TransactionState getState() {
        return this.mTransactionState;
    }

    public boolean isEquivalent(Transaction transaction) {
        return this.mId.equals(transaction.mId);
    }

    public int getServiceId() {
        return this.mServiceId;
    }

    public int getSubId() {
        return this.mSubId;
    }

    public void setSubId(int subId) {
        this.mSubId = subId;
    }

    public TransactionSettings getConnectionSettings() {
        return this.mTransactionSettings;
    }

    public void setConnectionSettings(TransactionSettings settings) {
        this.mTransactionSettings = settings;
    }

    protected byte[] sendPdu(byte[] pdu) throws MmsException, IOException {
        return sendPdu(-1L, pdu, this.mTransactionSettings.getMmscUrl());
    }

    protected byte[] sendPdu(byte[] pdu, String mmscUrl) throws MmsException, IOException {
        return sendPdu(-1L, pdu, mmscUrl);
    }

    protected byte[] sendPdu(long token, byte[] pdu) throws MmsException, IOException {
        return sendPdu(token, pdu, this.mTransactionSettings.getMmscUrl());
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    protected byte[] sendPdu(long token, byte[] pdu, String mmscUrl) throws MmsException, IOException {
        if (pdu == null) {
            throw new MmsException();
        }
        ensureRouteToHost(mmscUrl, this.mTransactionSettings);
        return HttpUtils.httpConnection(this.mContext, token, mmscUrl, pdu, 1, this.mTransactionSettings.isProxySet(), this.mTransactionSettings.getProxyAddress(), this.mTransactionSettings.getProxyPort());
    }

    protected byte[] getPdu(String url) throws IOException {
        ensureRouteToHost(url, this.mTransactionSettings);
        return HttpUtils.httpConnection(this.mContext, -1L, url, null, 2, this.mTransactionSettings.isProxySet(), this.mTransactionSettings.getProxyAddress(), this.mTransactionSettings.getProxyPort());
    }

    private void ensureRouteToHost(String url, TransactionSettings settings) throws IOException {
        ConnectivityManager connMgr = (ConnectivityManager) this.mContext.getSystemService("connectivity");
        if (settings.isProxySet()) {
            String proxyAddr = settings.getProxyAddress();
            try {
                InetAddress inetAddr = InetAddress.getByName(proxyAddr);
                if (!connMgr.requestRouteToHostAddress(2, inetAddr)) {
                    throw new IOException("Cannot establish route to proxy " + inetAddr);
                }
                return;
            } catch (UnknownHostException e) {
                throw new IOException("Cannot establish route for " + url + ": Unknown proxy " + proxyAddr);
            }
        }
        Uri uri = Uri.parse(url);
        try {
            InetAddress inetAddr2 = InetAddress.getByName(uri.getHost());
            if (!connMgr.requestRouteToHostAddress(2, inetAddr2)) {
                throw new IOException("Cannot establish route to " + inetAddr2 + " for " + url);
            }
        } catch (UnknownHostException e2) {
            throw new IOException("Cannot establish route for " + url + ": Unknown host");
        }
    }

    public String toString() {
        return getClass().getName() + ": serviceId=" + this.mServiceId + " subId= " + this.mSubId;
    }
}
