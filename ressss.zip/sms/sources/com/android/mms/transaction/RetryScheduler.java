package com.android.mms.transaction;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.provider.Telephony;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.android.mms.R;
import com.android.mms.ui.ComposeMessageActivity;
import com.android.mms.util.DownloadManager;
import com.android.mms.util.ModeStringUtil;
import com.google.android.mms.pdu.PduPersister;

/* JADX INFO: loaded from: classes.dex */
public class RetryScheduler implements Observer {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private static RetryScheduler sInstance;
    private final ContentResolver mContentResolver;
    private final Context mContext;

    private RetryScheduler(Context context) {
        this.mContext = context;
        this.mContentResolver = context.getContentResolver();
    }

    public static RetryScheduler getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new RetryScheduler(context);
        }
        return sInstance;
    }

    private boolean isMmsDataConnectivityPossible(int subId) {
        boolean flag = false;
        TelephonyManager telephonyManager = (TelephonyManager) this.mContext.getSystemService("phone");
        if (telephonyManager != null) {
            flag = telephonyManager.isDataPossibleForSubscription(subId, "mms");
        }
        Log.d("Mms", "isMmsDataConnectivityPossible = " + flag + "subId = " + subId);
        return flag;
    }

    @Override // com.android.mms.transaction.Observer
    public void update(Observable observable) {
        Uri uri = null;
        Transaction t = (Transaction) observable;
        try {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "[RetryScheduler] update " + observable);
            }
            if ((t instanceof NotificationTransaction) || (t instanceof RetrieveTransaction) || (t instanceof ReadRecTransaction) || (t instanceof SendTransaction)) {
                try {
                    TransactionState state = t.getState();
                    if (state.getState() == 2 && (uri = state.getContentUri()) != null) {
                        scheduleRetry(uri);
                    }
                    t.detach(this);
                } catch (Throwable th) {
                    t.detach(this);
                    throw th;
                }
            }
            if (isMmsDataConnectivityPossible(t.getSubId())) {
                setRetryAlarm(this.mContext, uri);
            } else {
                Log.d("Mms", "Retry alarm is not set");
            }
        } catch (Throwable th2) {
            if (isMmsDataConnectivityPossible(t.getSubId())) {
                setRetryAlarm(this.mContext, uri);
            } else {
                Log.d("Mms", "Retry alarm is not set");
            }
            throw th2;
        }
    }

    private void scheduleRetry(Uri uri) {
        long msgId = ContentUris.parseId(uri);
        Uri.Builder uriBuilder = Telephony.MmsSms.PendingMessages.CONTENT_URI.buildUpon();
        uriBuilder.appendQueryParameter("protocol", "mms");
        uriBuilder.appendQueryParameter("message", String.valueOf(msgId));
        Cursor c = SqliteWrapper.query(this.mContext, this.mContentResolver, uriBuilder.build(), (String[]) null, (String) null, (String[]) null, (String) null);
        if (c != null) {
            try {
                if (c.getCount() == 1 && c.moveToFirst()) {
                    int msgType = c.getInt(c.getColumnIndexOrThrow("msg_type"));
                    int retryIndex = c.getInt(c.getColumnIndexOrThrow("retry_index")) + 1;
                    int errorType = 1;
                    DefaultRetryScheme scheme = new DefaultRetryScheme(this.mContext, retryIndex);
                    ContentValues values = new ContentValues(4);
                    long current = System.currentTimeMillis();
                    boolean isRetryDownloading = msgType == 130;
                    boolean retry = true;
                    int respStatus = getResponseStatus(msgId);
                    int errorString = 0;
                    if (!isRetryDownloading) {
                        switch (respStatus) {
                            case 130:
                            case 225:
                                errorString = ModeStringUtil.getModeResFromArray(this.mContext, R.array.service_not_activated);
                                break;
                            case 132:
                                errorString = ModeStringUtil.getModeResFromArray(this.mContext, R.array.invalid_destination);
                                break;
                            case 134:
                                errorString = ModeStringUtil.getModeResFromArray(this.mContext, R.array.service_network_problem);
                                break;
                            case 194:
                            case 228:
                                errorString = ModeStringUtil.getModeResFromArray(this.mContext, R.array.service_message_not_found);
                                break;
                        }
                        if (errorString != 0) {
                            DownloadManager.getInstance().showErrorCodeToast(errorString);
                            retry = false;
                        }
                    } else {
                        int respStatus2 = getRetrieveStatus(msgId);
                        if (respStatus2 == 228) {
                            DownloadManager.getInstance().showErrorCodeToast(ModeStringUtil.getModeResFromArray(this.mContext, R.array.service_message_not_found));
                            SqliteWrapper.delete(this.mContext, this.mContext.getContentResolver(), uri, (String) null, (String[]) null);
                            c.close();
                            return;
                        }
                    }
                    if (retryIndex < scheme.getRetryLimit() && retry) {
                        long retryAt = current + scheme.getWaitingInterval();
                        if (Log.isLoggable("Mms", 2)) {
                            Log.v("Mms", "scheduleRetry: retry for " + uri + " is scheduled at " + (retryAt - System.currentTimeMillis()) + "ms from now");
                        }
                        values.put("due_time", Long.valueOf(retryAt));
                        if (isRetryDownloading) {
                            DownloadManager.getInstance().markState(uri, 130);
                        }
                    } else {
                        errorType = 10;
                        if (isRetryDownloading) {
                            c = SqliteWrapper.query(this.mContext, this.mContext.getContentResolver(), uri, new String[]{ComposeMessageActivity.THREAD_ID}, (String) null, (String[]) null, (String) null);
                            long threadId = -1;
                            if (c != null) {
                                try {
                                    if (c.moveToFirst()) {
                                        threadId = c.getLong(0);
                                    }
                                    c.close();
                                } finally {
                                    c.close();
                                }
                            }
                            if (threadId != -1) {
                                MessagingNotification.notifyDownloadFailed(this.mContext, threadId);
                            }
                            DownloadManager.getInstance().markState(uri, DownloadManager.STATE_PERMANENT_FAILURE);
                        } else {
                            ContentValues readValues = new ContentValues(1);
                            readValues.put("read", (Integer) 0);
                            SqliteWrapper.update(this.mContext, this.mContext.getContentResolver(), uri, readValues, (String) null, (String[]) null);
                            MessagingNotification.notifySendFailed(this.mContext, true);
                        }
                    }
                    values.put("err_type", Integer.valueOf(errorType));
                    values.put("retry_index", Integer.valueOf(retryIndex));
                    values.put("last_try", Long.valueOf(current));
                    int columnIndex = c.getColumnIndexOrThrow("_id");
                    long id = c.getLong(columnIndex);
                    SqliteWrapper.update(this.mContext, this.mContentResolver, Telephony.MmsSms.PendingMessages.CONTENT_URI, values, "_id=" + id, (String[]) null);
                }
            } catch (Throwable th) {
                c.close();
                throw th;
            }
        }
    }

    private int getResponseStatus(long msgID) {
        int respStatus = 0;
        Cursor cursor = SqliteWrapper.query(this.mContext, this.mContentResolver, Telephony.Mms.Outbox.CONTENT_URI, (String[]) null, "_id=" + msgID, (String[]) null, (String) null);
        try {
            if (cursor.moveToFirst()) {
                respStatus = cursor.getInt(cursor.getColumnIndexOrThrow("resp_st"));
            }
            cursor.close();
            if (respStatus != 0) {
                Log.e("Mms", "Response status is: " + respStatus);
            }
            return respStatus;
        } catch (Throwable th) {
            cursor.close();
            throw th;
        }
    }

    private int getRetrieveStatus(long msgID) {
        int retrieveStatus = 0;
        Cursor cursor = SqliteWrapper.query(this.mContext, this.mContentResolver, Telephony.Mms.Inbox.CONTENT_URI, (String[]) null, "_id=" + msgID, (String[]) null, (String) null);
        try {
            if (cursor.moveToFirst()) {
                retrieveStatus = cursor.getInt(cursor.getColumnIndexOrThrow("resp_st"));
            }
            cursor.close();
            if (retrieveStatus != 0 && Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "Retrieve status is: " + retrieveStatus);
            }
            return retrieveStatus;
        } catch (Throwable th) {
            cursor.close();
            throw th;
        }
    }

    public static void setRetryAlarm(Context context) {
        setRetryAlarm(context, null);
    }

    public static void setRetryAlarm(Context context, Uri mmsUrl) {
        Cursor mmsCursor = PduPersister.getPduPersister(context).getPendingMessages(Long.MAX_VALUE);
        if (mmsCursor != null) {
            try {
                Cursor cursor = getMmsCursor(mmsCursor, mmsUrl);
                if (cursor != null) {
                    long retryAt = cursor.getLong(cursor.getColumnIndexOrThrow("due_time"));
                    Intent service = new Intent(TransactionService.ACTION_ONALARM, null, context, TransactionService.class);
                    PendingIntent operation = PendingIntent.getService(context, 0, service, 1073741824);
                    AlarmManager am = (AlarmManager) context.getSystemService("alarm");
                    am.set(1, retryAt, operation);
                    if (Log.isLoggable("Mms", 2)) {
                        Log.v("Mms", "Next retry is scheduled at" + (retryAt - System.currentTimeMillis()) + "ms from now");
                    }
                }
            } finally {
                mmsCursor.close();
            }
        }
    }

    private static Cursor getMmsCursor(Cursor cursor, Uri uri) {
        if (uri == null) {
            if (cursor.moveToFirst()) {
                return cursor;
            }
            return null;
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "Set alarm for " + uri);
        }
        int columnIndexOfMsgId = cursor.getColumnIndexOrThrow("msg_id");
        long msgId = ContentUris.parseId(uri);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            long id = cursor.getLong(columnIndexOfMsgId);
            if (id != msgId) {
                cursor.moveToNext();
            } else {
                if (!Log.isLoggable("Mms", 2)) {
                    break;
                }
                Log.v("Mms", "Find out the MMS in pendingMessage table.");
                break;
            }
        }
        if (cursor.isAfterLast()) {
            Log.e("Mms", "Can't not find the MMS in pendingMessage table.");
            return null;
        }
        return cursor;
    }
}
