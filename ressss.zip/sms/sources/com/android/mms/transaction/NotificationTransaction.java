package com.android.mms.transaction;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.provider.Telephony;
import android.util.Log;
import com.android.mms.MmsApp;
import com.android.mms.MmsConfig;
import com.android.mms.ui.MessagingPreferenceActivity;
import com.android.mms.util.DownloadManager;
import com.android.mms.util.Recycler;
import com.android.mms.widget.MmsWidgetProvider;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.GenericPdu;
import com.google.android.mms.pdu.NotificationInd;
import com.google.android.mms.pdu.NotifyRespInd;
import com.google.android.mms.pdu.PduComposer;
import com.google.android.mms.pdu.PduParser;
import com.google.android.mms.pdu.PduPersister;
import java.io.IOException;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class NotificationTransaction extends Transaction implements Runnable {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private String mContentLocation;
    private NotificationInd mNotificationInd;
    private Uri mUri;

    public NotificationTransaction(Context context, int serviceId, TransactionSettings connectionSettings, String uriString) {
        super(context, serviceId, connectionSettings);
        this.mUri = Uri.parse(uriString);
        try {
            this.mNotificationInd = PduPersister.getPduPersister(context).load(this.mUri);
            this.mContentLocation = new String(this.mNotificationInd.getContentLocation());
            this.mId = this.mContentLocation;
            attach(RetryScheduler.getInstance(context));
        } catch (MmsException e) {
            Log.e("Mms", "Failed to load NotificationInd from: " + uriString, e);
            throw new IllegalArgumentException();
        }
    }

    public NotificationTransaction(Context context, int serviceId, TransactionSettings connectionSettings, NotificationInd ind) {
        super(context, serviceId, connectionSettings);
        try {
            this.mUri = PduPersister.getPduPersister(context).persist(ind, Telephony.Mms.Inbox.CONTENT_URI, !allowAutoDownload(), MessagingPreferenceActivity.getIsGroupMmsEnabled(context), (HashMap) null);
            this.mNotificationInd = ind;
            this.mId = new String(this.mNotificationInd.getContentLocation());
        } catch (MmsException e) {
            Log.e("Mms", "Failed to save NotificationInd in constructor.", e);
            throw new IllegalArgumentException();
        }
    }

    @Override // com.android.mms.transaction.Transaction
    public void process() {
        new Thread(this, "NotificationTransaction").start();
    }

    public static boolean allowAutoDownload() {
        DownloadManager downloadManager = DownloadManager.getInstance();
        boolean autoDownload = downloadManager.isAuto();
        boolean dataSuspended = MmsApp.getApplication().getTelephonyManager().getDataState() == 3;
        return autoDownload && !dataSuspended;
    }

    @Override // java.lang.Runnable
    public void run() {
        DownloadManager downloadManager = DownloadManager.getInstance();
        boolean autoDownload = allowAutoDownload();
        int status = 131;
        try {
            if (!autoDownload) {
                downloadManager.markState(this.mUri, 128);
                sendNotifyRespInd(131);
                this.mTransactionState.setContentUri(this.mUri);
                if (!autoDownload) {
                    this.mTransactionState.setState(1);
                }
                if (this.mTransactionState.getState() != 1) {
                    this.mTransactionState.setState(2);
                    Log.e("Mms", "NotificationTransaction failed.");
                }
                notifyObservers();
                return;
            }
            downloadManager.markState(this.mUri, DownloadManager.STATE_DOWNLOADING);
            byte[] retrieveConfData = null;
            try {
                retrieveConfData = getPdu(this.mContentLocation);
            } catch (IOException e) {
                this.mTransactionState.setState(2);
            }
            if (retrieveConfData != null) {
                GenericPdu pdu = new PduParser(retrieveConfData, PduParserUtil.shouldParseContentDisposition()).parse();
                if (pdu == null || pdu.getMessageType() != 132) {
                    Log.e("Mms", "Invalid M-RETRIEVE.CONF PDU. " + (pdu != null ? "message type: " + pdu.getMessageType() : "null pdu"));
                    this.mTransactionState.setState(2);
                    status = 132;
                } else {
                    PduPersister p = PduPersister.getPduPersister(this.mContext);
                    Uri uri = p.persist(pdu, Telephony.Mms.Inbox.CONTENT_URI, true, MessagingPreferenceActivity.getIsGroupMmsEnabled(this.mContext), (HashMap) null);
                    ContentValues values = new ContentValues(3);
                    values.put("date", Long.valueOf(System.currentTimeMillis() / 1000));
                    Cursor c = this.mContext.getContentResolver().query(this.mUri, null, null, null, null);
                    try {
                        if (c != null) {
                            if (c.moveToFirst()) {
                                int phoneId = c.getInt(c.getColumnIndex("phone_id"));
                                values.put("phone_id", Integer.valueOf(phoneId));
                            }
                        }
                    } catch (Exception ex) {
                        Log.e("Mms", "Exception:" + ex);
                    } finally {
                        c.close();
                    }
                    values.put("m_size", Long.valueOf(this.mNotificationInd.getMessageSize()));
                    SqliteWrapper.update(this.mContext, this.mContext.getContentResolver(), uri, values, (String) null, (String[]) null);
                    SqliteWrapper.delete(this.mContext, this.mContext.getContentResolver(), this.mUri, (String) null, (String[]) null);
                    Log.v("Mms", "NotificationTransaction received new mms message: " + uri);
                    SqliteWrapper.delete(this.mContext, this.mContext.getContentResolver(), Telephony.Threads.OBSOLETE_THREADS_URI, (String) null, (String[]) null);
                    this.mUri = uri;
                    status = DownloadManager.STATE_DOWNLOADING;
                }
            }
            switch (status) {
                case DownloadManager.STATE_DOWNLOADING /* 129 */:
                    this.mTransactionState.setState(1);
                    break;
                case 131:
                    if (this.mTransactionState.getState() == 0) {
                        this.mTransactionState.setState(1);
                    }
                    break;
            }
            sendNotifyRespInd(status);
            Recycler.getMmsRecycler().deleteOldMessagesInSameThreadAsMessage(this.mContext, this.mUri);
            MmsWidgetProvider.notifyDatasetChanged(this.mContext);
            this.mTransactionState.setContentUri(this.mUri);
            if (!autoDownload) {
                this.mTransactionState.setState(1);
            }
            if (this.mTransactionState.getState() != 1) {
                this.mTransactionState.setState(2);
                Log.e("Mms", "NotificationTransaction failed.");
            }
            notifyObservers();
        } catch (Throwable t) {
            Log.e("Mms", Log.getStackTraceString(t));
        } finally {
            this.mTransactionState.setContentUri(this.mUri);
            if (!autoDownload) {
                this.mTransactionState.setState(1);
            }
            if (this.mTransactionState.getState() != 1) {
                this.mTransactionState.setState(2);
                Log.e("Mms", "NotificationTransaction failed.");
            }
            notifyObservers();
        }
    }

    private void sendNotifyRespInd(int status) throws MmsException, IOException {
        NotifyRespInd notifyRespInd = new NotifyRespInd(18, this.mNotificationInd.getTransactionId(), status);
        if (MmsConfig.getNotifyWapMMSC()) {
            sendPdu(new PduComposer(this.mContext, notifyRespInd).make(), this.mContentLocation);
        } else {
            sendPdu(new PduComposer(this.mContext, notifyRespInd).make());
        }
    }

    @Override // com.android.mms.transaction.Transaction
    public void abort() {
        Log.d("Mms", "markFailed = " + this);
        DownloadManager downloadManager = DownloadManager.getInstance();
        this.mTransactionState.setState(2);
        this.mTransactionState.setContentUri(this.mUri);
        downloadManager.markState(this.mUri, DownloadManager.STATE_SKIP_RETRYING);
        notifyObservers();
    }

    @Override // com.android.mms.transaction.Transaction
    public int getType() {
        return 0;
    }
}
