package com.android.mms.transaction;

import android.app.ActivityManager;
import android.app.AlertDialogFp;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.KeyEvent;
import com.android.mms.R;
import com.android.mms.ui.ManageSimMessages;
import com.android.mms.util.ModeStringUtil;

/* JADX INFO: loaded from: classes.dex */
public class SimFullReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Log.d("SimFullReceiver", " handle broadcast action = " + intent.getAction());
        if ("android.provider.Telephony.SIM_FULL".equals(intent.getAction())) {
            final ActivityManager mActivityManager = (ActivityManager) context.getSystemService("activity");
            Intent viewSimIntent = new Intent(context, (Class<?>) ManageSimMessages.class);
            viewSimIntent.setAction("android.intent.action.VIEW");
            viewSimIntent.setFlags(268435456);
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, viewSimIntent, 0);
            Notification notification = new Notification();
            notification.icon = R.drawable.stat_notify_sms_sim_full;
            notification.tickerText = context.getString(ModeStringUtil.getModeResFromArray(context, R.array.sim_full_title));
            notification.defaults = -1;
            notification.setLatestEventInfo(context, context.getString(ModeStringUtil.getModeResFromArray(context, R.array.sim_full_title)), context.getString(ModeStringUtil.getModeResFromArray(context, R.array.sim_full_body)), pendingIntent);
            AlertDialogFp toast = new AlertDialogFp.Builder(context.getApplicationContext()).setMessage(ModeStringUtil.getModeResFromArray(context, R.array.sim_full_title)).create();
            toast.getWindow().setType(2003);
            toast.setAutoDismiss(true);
            toast.getWindow().addPrivateFlags(4096);
            toast.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.android.mms.transaction.SimFullReceiver.1
                @Override // android.content.DialogInterface.OnKeyListener
                public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                    if (keyCode != 6) {
                        return false;
                    }
                    dialog.dismiss();
                    mActivityManager.goHome();
                    return true;
                }
            });
            toast.show();
        }
    }
}
