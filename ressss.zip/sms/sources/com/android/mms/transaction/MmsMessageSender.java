package com.android.mms.transaction;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.Telephony;
import android.util.Log;
import com.android.mms.LogTag;
import com.android.mms.ui.MessagingPreferenceActivity;
import com.android.mms.util.SendingProgressTokenManager;
import com.google.android.mms.InvalidHeaderValueException;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.EncodedStringValue;
import com.google.android.mms.pdu.GenericPdu;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.ReadRecInd;
import com.google.android.mms.pdu.SendReq;
import com.google.android.mms.util.SqliteWrapper;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class MmsMessageSender implements MessageSender {
    private static final boolean DEFAULT_DELIVERY_REPORT_MODE = false;
    private static final long DEFAULT_EXPIRY_TIME = 604800;
    private static final String DEFAULT_MESSAGE_CLASS = "personal";
    private static final int DEFAULT_PRIORITY = 129;
    private static final boolean DEFAULT_READ_REPORT_MODE = false;
    private static final String TAG = "Mms";
    private final Context mContext;
    private final long mMessageSize;
    private final Uri mMessageUri;
    private int mPhoneId;

    public MmsMessageSender(Context context, Uri location, long messageSize, int phoneId) {
        this.mContext = context;
        this.mMessageUri = location;
        this.mMessageSize = messageSize;
        this.mPhoneId = phoneId;
        if (this.mMessageUri == null) {
            throw new IllegalArgumentException("Null message URI.");
        }
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    @Override // com.android.mms.transaction.MessageSender
    public boolean sendMessage(long token) throws MmsException {
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("sendMessage uri: " + this.mMessageUri, new Object[0]);
        }
        PduPersister p = PduPersister.getPduPersister(this.mContext);
        GenericPdu pdu = p.load(this.mMessageUri);
        if (pdu.getMessageType() != 128) {
            throw new MmsException("Invalid message: " + pdu.getMessageType());
        }
        SendReq sendReq = (SendReq) pdu;
        updatePreferencesHeaders(sendReq);
        sendReq.setMessageClass(DEFAULT_MESSAGE_CLASS.getBytes());
        sendReq.setDate(System.currentTimeMillis() / 1000);
        sendReq.setMessageSize(this.mMessageSize);
        p.updateHeaders(this.mMessageUri, sendReq);
        long messageId = ContentUris.parseId(this.mMessageUri);
        if (!this.mMessageUri.toString().startsWith(Telephony.Mms.Draft.CONTENT_URI.toString())) {
            ContentValues values = new ContentValues(7);
            values.put("proto_type", (Integer) 1);
            values.put("msg_id", Long.valueOf(messageId));
            values.put("msg_type", Integer.valueOf(pdu.getMessageType()));
            values.put("err_type", (Integer) 0);
            values.put("err_code", (Integer) 0);
            values.put("retry_index", (Integer) 0);
            values.put("due_time", (Integer) 0);
            SqliteWrapper.insert(this.mContext, this.mContext.getContentResolver(), Telephony.MmsSms.PendingMessages.CONTENT_URI, values);
        } else {
            p.move(this.mMessageUri, Telephony.Mms.Outbox.CONTENT_URI);
        }
        SendingProgressTokenManager.put(Long.valueOf(messageId), token);
        Intent intent = new Intent(this.mContext, (Class<?>) TransactionService.class);
        intent.putExtra("phone_id", this.mPhoneId);
        this.mContext.startService(intent);
        return true;
    }

    private void updatePreferencesHeaders(SendReq sendReq) throws MmsException {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        sendReq.setExpiry(prefs.getLong(MessagingPreferenceActivity.EXPIRY_TIME, DEFAULT_EXPIRY_TIME));
        sendReq.setPriority(prefs.getInt(MessagingPreferenceActivity.PRIORITY, 129));
        boolean dr = prefs.getBoolean(MessagingPreferenceActivity.MMS_DELIVERY_REPORT_MODE, false);
        sendReq.setDeliveryReport(dr ? 128 : 129);
        boolean rr = prefs.getBoolean(MessagingPreferenceActivity.READ_REPORT_MODE, false);
        sendReq.setReadReport(rr ? 128 : 129);
    }

    public static void sendReadRec(Context context, String to, String messageId, int status) {
        EncodedStringValue[] sender = {new EncodedStringValue(to)};
        try {
            ReadRecInd readRec = new ReadRecInd(new EncodedStringValue("insert-address-token".getBytes()), messageId.getBytes(), 18, status, sender);
            readRec.setDate(System.currentTimeMillis() / 1000);
            PduPersister.getPduPersister(context).persist(readRec, Telephony.Mms.Outbox.CONTENT_URI, true, MessagingPreferenceActivity.getIsGroupMmsEnabled(context), (HashMap) null);
            context.startService(new Intent(context, (Class<?>) TransactionService.class));
        } catch (InvalidHeaderValueException e) {
            Log.e("Mms", "Invalide header value", e);
        } catch (MmsException e2) {
            Log.e("Mms", "Persist message failed", e2);
        }
    }
}
