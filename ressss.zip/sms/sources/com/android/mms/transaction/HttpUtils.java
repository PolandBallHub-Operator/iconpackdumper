package com.android.mms.transaction;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.http.AndroidHttpClient;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.MmsConfig;
import com.nextfp.android.util.NfpSharedResources;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.SocketException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.params.ConnRouteParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

/* JADX INFO: loaded from: classes.dex */
public class HttpUtils {
    private static final String ACCEPT_LANG_FOR_US_LOCALE = "en-US";
    private static final boolean DEBUG = false;
    private static final String HDR_KEY_ACCEPT = "Accept";
    private static final String HDR_KEY_ACCEPT_LANGUAGE = "Accept-Language";
    private static final String HDR_VALUE_ACCEPT = "*/*, application/vnd.wap.mms-message, application/vnd.wap.sic";
    public static final int HTTP_GET_METHOD = 2;
    public static final int HTTP_POST_METHOD = 1;
    private static final String INTENT_EXTRA_TAG = "mmstag";
    private static final boolean LOCAL_LOGV = false;
    private static final int MMS_READ_BUFFER = 4096;
    private static final String TAG = "Mms";
    private static final String HDR_VALUE_ACCEPT_LANGUAGE = getCurrentAcceptLanguage(Locale.getDefault());
    private static final long HTTP_TIMEOUT = SystemProperties.getLong("persist.radio.mms.http_timeout", 180000);
    private static long sAlarmTag = 0;
    private static HttpRequestBase sHttpReq = null;
    private static PendingIntent sAlarmIntent = null;
    private static final String INTENT_HTTP_TIMEOUT_ALARM = "org.codeaurora.mms.http_timeout";
    private static IntentFilter sIntentFilter = new IntentFilter(INTENT_HTTP_TIMEOUT_ALARM);
    private static BroadcastReceiver sIntentReceiver = new BroadcastReceiver() { // from class: com.android.mms.transaction.HttpUtils.1
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (HttpUtils.INTENT_HTTP_TIMEOUT_ALARM.equals(intent.getAction())) {
                long tag = intent.getLongExtra(HttpUtils.INTENT_EXTRA_TAG, -1L);
                Log.d("Mms", "[HttpUtils] HTTP timeout alarm. tag = " + tag + " sAlarmTag = " + HttpUtils.sAlarmTag);
                HttpUtils.abortHttpRequest(tag);
            }
        }
    };

    private HttpUtils() {
    }

    /* JADX WARN: Code duplicated, block: B:123:0x0412 A[Catch: all -> 0x040d, TRY_ENTER, TRY_LEAVE, TryCatch #6 {all -> 0x040d, blocks: (B:82:0x0331, B:91:0x034c, B:123:0x0412, B:118:0x03ef), top: B:150:0x0331, outer: #10, inners: #9 }] */
    protected static byte[] httpConnection(Context context, long token, String url, byte[] pdu, int method, boolean isProxySet, String proxyHost, int proxyPort) throws IOException {
        HttpRequestBase req;
        if (url == null) {
            throw new IllegalArgumentException("URL must not be null.");
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "httpConnection: params list");
            Log.v("Mms", "\ttoken\t\t= " + token);
            Log.v("Mms", "\turl\t\t= " + url);
            Log.v("Mms", new StringBuilder().append("\tmethod\t\t= ").append(method == 1 ? "POST" : method == 2 ? "GET" : "UNKNOWN").toString());
            Log.v("Mms", "\tisProxySet\t= " + isProxySet);
            Log.v("Mms", "\tproxyHost\t= " + proxyHost);
            Log.v("Mms", "\tproxyPort\t= " + proxyPort);
        }
        AndroidHttpClient client = null;
        try {
            try {
                try {
                    try {
                        startAlarmForTimeout(context);
                        URI hostUrl = new URI(url);
                        HttpHost target = new HttpHost(hostUrl.getHost(), hostUrl.getPort(), "http");
                        AndroidHttpClient androidHttpClientCreateHttpClient = createHttpClient(context);
                        switch (method) {
                            case 1:
                                ProgressCallbackEntity entity = new ProgressCallbackEntity(context, token, pdu);
                                entity.setContentType("application/vnd.wap.mms-message");
                                HttpPost post = new HttpPost(url);
                                post.setEntity(entity);
                                req = post;
                                break;
                            case 2:
                                req = new HttpGet(url);
                                break;
                            default:
                                Log.e("Mms", "Unknown HTTP method: " + method + ". Must be one of POST[1] or GET[2].");
                                if (androidHttpClientCreateHttpClient == null) {
                                    return null;
                                }
                                androidHttpClientCreateHttpClient.close();
                                return null;
                        }
                        synchronized (HttpUtils.class) {
                            sHttpReq = req;
                        }
                        HttpParams params = androidHttpClientCreateHttpClient.getParams();
                        if (isProxySet) {
                            ConnRouteParams.setDefaultProxy(params, new HttpHost(proxyHost, proxyPort));
                        }
                        req.setParams(params);
                        req.addHeader(HDR_KEY_ACCEPT, HDR_VALUE_ACCEPT);
                        String xWapProfileTagName = MmsConfig.getUaProfTagName();
                        String xWapProfileUrl = MmsConfig.getUaProfUrl();
                        if (xWapProfileUrl != null) {
                            if (Log.isLoggable("Mms", 2)) {
                                Log.d("Mms", "[HttpUtils] httpConn: xWapProfUrl=" + xWapProfileUrl);
                            }
                            req.addHeader(xWapProfileTagName, xWapProfileUrl);
                        }
                        String extraHttpParams = MmsConfig.getHttpParams();
                        if (extraHttpParams != null) {
                            String line1Number = ((TelephonyManager) context.getSystemService("phone")).getLine1Number();
                            String line1Key = MmsConfig.getHttpParamsLine1Key();
                            String[] paramList = extraHttpParams.split("\\|");
                            for (String paramPair : paramList) {
                                String[] splitPair = paramPair.split(":", 2);
                                if (splitPair.length == 2) {
                                    String name = splitPair[0].trim();
                                    String value = splitPair[1].trim();
                                    if (line1Key != null) {
                                        value = value.replace(line1Key, line1Number);
                                    }
                                    if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(value)) {
                                        req.addHeader(name, value);
                                    }
                                }
                            }
                        }
                        req.addHeader(HDR_KEY_ACCEPT_LANGUAGE, HDR_VALUE_ACCEPT_LANGUAGE);
                        HttpResponse response = androidHttpClientCreateHttpClient.execute(target, req);
                        StatusLine status = response.getStatusLine();
                        Log.d("Mms", "HttpUtils: Http request. status = " + status.getStatusCode());
                        if (status.getStatusCode() != 200) {
                            throw new IOException("HTTP error: " + status.getReasonPhrase());
                        }
                        HttpEntity entity2 = response.getEntity();
                        byte[] body = null;
                        if (entity2 != null) {
                            try {
                                if (entity2.getContentLength() > 0) {
                                    body = new byte[(int) entity2.getContentLength()];
                                    DataInputStream dis = new DataInputStream(entity2.getContent());
                                    try {
                                        dis.readFully(body);
                                        try {
                                            dis.close();
                                        } catch (IOException e) {
                                            Log.e("Mms", "Error closing input stream: " + e.getMessage());
                                        }
                                    } catch (Throwable th) {
                                        try {
                                            dis.close();
                                        } catch (IOException e2) {
                                            Log.e("Mms", "Error closing input stream: " + e2.getMessage());
                                        }
                                        throw th;
                                    }
                                }
                                if (entity2.isChunked()) {
                                    Log.v("Mms", "httpConnection: transfer encoding is chunked");
                                    int bytesTobeRead = MmsConfig.getMaxMessageSize();
                                    byte[] tempBody = new byte[bytesTobeRead];
                                    DataInputStream dis2 = new DataInputStream(entity2.getContent());
                                    int bytesRead = 0;
                                    int offset = 0;
                                    boolean readError = false;
                                    try {
                                        do {
                                            try {
                                                try {
                                                    bytesRead = dis2.read(tempBody, offset, bytesTobeRead);
                                                    if (bytesRead > 0) {
                                                        bytesTobeRead -= bytesRead;
                                                        offset += bytesRead;
                                                    }
                                                    if (bytesRead >= 0) {
                                                    }
                                                } catch (IOException e3) {
                                                    readError = true;
                                                    Log.e("Mms", "httpConnection: error reading input stream" + e3.getMessage());
                                                }
                                                if (bytesRead == -1 || offset <= 0 || readError) {
                                                    Log.e("Mms", "httpConnection: Response entity too large or empty");
                                                } else {
                                                    body = new byte[offset];
                                                    System.arraycopy(tempBody, 0, body, 0, offset);
                                                    Log.v("Mms", "httpConnection: Chunked response length [" + Integer.toString(offset) + "]");
                                                }
                                                dis2.close();
                                            } catch (Throwable th2) {
                                                try {
                                                    dis2.close();
                                                } catch (IOException e4) {
                                                    Log.e("Mms", "Error closing input stream: " + e4.getMessage());
                                                }
                                                throw th2;
                                            }
                                        } while (bytesTobeRead > 0);
                                        dis2.close();
                                    } catch (IOException e5) {
                                        Log.e("Mms", "Error closing input stream: " + e5.getMessage());
                                    }
                                    if (bytesRead == -1) {
                                        Log.e("Mms", "httpConnection: Response entity too large or empty");
                                    } else {
                                        Log.e("Mms", "httpConnection: Response entity too large or empty");
                                    }
                                }
                                if (entity2 != null) {
                                    entity2.consumeContent();
                                }
                                cancelTimeoutAlarm(context);
                            } catch (Throwable th3) {
                                if (entity2 != null) {
                                    entity2.consumeContent();
                                }
                                cancelTimeoutAlarm(context);
                                throw th3;
                            }
                        }
                        if (androidHttpClientCreateHttpClient == null) {
                            return body;
                        }
                        androidHttpClientCreateHttpClient.close();
                        return body;
                    } catch (SocketException e6) {
                        handleHttpConnectionException(e6, url);
                        if (0 != 0) {
                            client.close();
                        }
                        return null;
                    } catch (URISyntaxException e7) {
                        handleHttpConnectionException(e7, url);
                        if (0 != 0) {
                            client.close();
                        }
                        return null;
                    }
                } catch (IllegalArgumentException e8) {
                    handleHttpConnectionException(e8, url);
                    if (0 != 0) {
                        client.close();
                    }
                    return null;
                } catch (IllegalStateException e9) {
                    handleHttpConnectionException(e9, url);
                    if (0 != 0) {
                        client.close();
                    }
                    return null;
                }
            } catch (Exception e10) {
                handleHttpConnectionException(e10, url);
                if (0 != 0) {
                    client.close();
                }
                return null;
            }
        } catch (Throwable th4) {
            if (0 != 0) {
                client.close();
            }
            throw th4;
        }
    }

    private static void handleHttpConnectionException(Exception exception, String url) throws IOException {
        Log.e("Mms", "Url: " + url + "\n" + exception.getMessage());
        IOException e = new IOException(exception.getMessage());
        e.initCause(exception);
        throw e;
    }

    private static AndroidHttpClient createHttpClient(Context context) {
        String userAgent = MmsConfig.getUserAgent();
        AndroidHttpClient client = AndroidHttpClient.newInstance(userAgent, context);
        HttpParams params = client.getParams();
        HttpProtocolParams.setContentCharset(params, "UTF-8");
        int soTimeout = MmsConfig.getHttpSocketTimeout();
        if (Log.isLoggable("Mms", 3)) {
            Log.d("Mms", "[HttpUtils] createHttpClient w/ socket timeout " + soTimeout + " ms, , UA=" + userAgent);
        }
        HttpConnectionParams.setSoTimeout(params, soTimeout);
        return client;
    }

    public static String getCurrentAcceptLanguage(Locale locale) {
        StringBuilder buffer = new StringBuilder();
        addLocaleToHttpAcceptLanguage(buffer, locale);
        if (!Locale.US.equals(locale)) {
            if (buffer.length() > 0) {
                buffer.append(", ");
            }
            buffer.append(ACCEPT_LANG_FOR_US_LOCALE);
        }
        return buffer.toString();
    }

    private static String convertObsoleteLanguageCodeToNew(String langCode) {
        if (langCode == null) {
            return null;
        }
        if ("iw".equals(langCode)) {
            return "he";
        }
        if ("in".equals(langCode)) {
            return NfpSharedResources.DEFTYPE_ID;
        }
        if ("ji".equals(langCode)) {
            return "yi";
        }
        return langCode;
    }

    private static void addLocaleToHttpAcceptLanguage(StringBuilder builder, Locale locale) {
        String language = convertObsoleteLanguageCodeToNew(locale.getLanguage());
        if (language != null) {
            builder.append(language);
            String country = locale.getCountry();
            if (country != null) {
                builder.append("-");
                builder.append(country);
            }
        }
    }

    private static synchronized void startAlarmForTimeout(Context context) {
        if (Log.isLoggable("Mms", 2)) {
            Log.d("Mms", "[HttpUtils] startAlarmForTimeout for " + HTTP_TIMEOUT);
        }
        Intent intent = new Intent(INTENT_HTTP_TIMEOUT_ALARM);
        intent.addFlags(268435456);
        sAlarmTag++;
        intent.putExtra(INTENT_EXTRA_TAG, sAlarmTag);
        sAlarmIntent = PendingIntent.getBroadcast(context, 0, intent, 134217728);
        AlarmManager am = (AlarmManager) context.getSystemService("alarm");
        am.setExact(2, SystemClock.elapsedRealtime() + HTTP_TIMEOUT, sAlarmIntent);
        context.registerReceiver(sIntentReceiver, sIntentFilter);
    }

    private static synchronized void cancelTimeoutAlarm(Context context) {
        if (Log.isLoggable("Mms", 2)) {
            Log.d("Mms", "HttpUtils: cancelTimeoutAlarm");
        }
        if (sAlarmIntent != null) {
            context.unregisterReceiver(sIntentReceiver);
            AlarmManager am = (AlarmManager) context.getSystemService("alarm");
            am.cancel(sAlarmIntent);
            sAlarmIntent = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void abortHttpRequest(final long tag) {
        Runnable runnable = new Runnable() { // from class: com.android.mms.transaction.HttpUtils.2
            @Override // java.lang.Runnable
            public void run() {
                synchronized (HttpUtils.class) {
                    Log.d("Mms", "[HttpUtils] abortHttpRequest. tag = " + tag + " sAlarmTag = " + HttpUtils.sAlarmTag);
                    if (tag == HttpUtils.sAlarmTag && HttpUtils.sHttpReq != null) {
                        try {
                            HttpUtils.sHttpReq.abort();
                        } catch (Exception e) {
                            Log.w("Mms", "[HttpUtils] abortHttpRequest: Ex:" + e);
                        }
                    } else {
                        Log.d("Mms", "[HttpUtils] Alarm tags not matching or no req. Ignore!");
                    }
                }
            }
        };
        Thread abortThread = new Thread(runnable);
        abortThread.start();
    }
}
