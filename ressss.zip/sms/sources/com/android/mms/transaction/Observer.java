package com.android.mms.transaction;

/* JADX INFO: loaded from: classes.dex */
public interface Observer {
    void update(Observable observable);
}
