package com.android.mms.transaction;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemProperties;
import android.provider.Telephony;
import android.telephony.PhoneNumberUtils;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;
import android.util.Log;
import com.android.mms.MmsConfig;
import com.android.mms.data.Conversation;
import com.android.mms.ui.MessageUtils;
import com.google.android.mms.MmsException;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class SmsSingleRecipientSender extends SmsMessageSender {
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final String TAG = "Mms";
    private boolean isExpectMore;
    private String mDest;
    private final boolean mRequestDeliveryReport;
    private Uri mUri;

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
    }

    public SmsSingleRecipientSender(Context context, String dest, String msgText, long threadId, boolean requestDeliveryReport, Uri uri, int phoneId, boolean expectMore) {
        super(context, (String[]) null, msgText, threadId, phoneId);
        this.mRequestDeliveryReport = requestDeliveryReport;
        this.mDest = dest;
        this.mUri = uri;
        this.isExpectMore = expectMore;
    }

    private String getNumberInMonkey() {
        return SystemProperties.get("debug.fj.monkey.number", "117");
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    @Override // com.android.mms.transaction.SmsMessageSender, com.android.mms.transaction.MessageSender
    public boolean sendMessage(long token) throws MmsException {
        ArrayList<String> messages;
        if (this.mMessageText == null) {
            throw new MmsException("Null message body or have multiple destinations.");
        }
        int[] subId = SubscriptionManager.getSubId(this.mPhoneId);
        Log.e("Mms", "send SMS phone Id = " + this.mPhoneId + " subId : = " + subId[0]);
        SmsManager smsManager = SmsManager.getSmsManagerForSubscriptionId(subId[0]);
        if (MmsConfig.getEmailGateway() != null && (Telephony.Mms.isEmailAddress(this.mDest) || MessageUtils.isAlias(this.mDest))) {
            String msgText = this.mDest + " " + this.mMessageText;
            this.mDest = MmsConfig.getEmailGateway();
            messages = smsManager.divideMessage(msgText);
        } else {
            messages = smsManager.divideMessage(this.mMessageText);
            this.mDest = PhoneNumberUtils.stripSeparators(this.mDest);
            this.mDest = Conversation.verifySingleRecipient(this.mContext, this.mThreadId, this.mDest);
        }
        int messageCount = messages.size();
        if (messageCount == 0) {
            throw new MmsException("SmsMessageSender.sendMessage: divideMessage returned empty messages. Original message is \"" + this.mMessageText + "\"");
        }
        boolean moved = Telephony.Sms.moveMessageToFolder(this.mContext, this.mUri, 4, 0);
        if (!moved) {
            throw new MmsException("SmsMessageSender.sendMessage: couldn't move message to outbox: " + this.mUri);
        }
        ArrayList<PendingIntent> deliveryIntents = new ArrayList<>(messageCount);
        ArrayList<PendingIntent> sentIntents = new ArrayList<>(messageCount);
        for (int i = 0; i < messageCount; i++) {
            if (this.mRequestDeliveryReport && i == messageCount - 1) {
                deliveryIntents.add(PendingIntent.getBroadcast(this.mContext, 0, new Intent(MessageStatusReceiver.MESSAGE_STATUS_RECEIVED_ACTION, this.mUri, this.mContext, MessageStatusReceiver.class), 0));
            } else {
                deliveryIntents.add(null);
            }
            Intent intent = new Intent(SmsReceiverService.MESSAGE_SENT_ACTION, this.mUri, this.mContext, SmsReceiver.class);
            intent.putExtra("phone", this.mPhoneId);
            int requestCode = 0;
            if (i == messageCount - 1) {
                requestCode = 1;
                intent.putExtra(SmsReceiverService.EXTRA_MESSAGE_SENT_SEND_NEXT, true);
            }
            sentIntents.add(PendingIntent.getBroadcast(this.mContext, requestCode, intent, 0));
        }
        try {
            smsManager.sendMultipartTextMessage(this.mDest, this.mServiceCenter, messages, sentIntents, deliveryIntents);
            if (Log.isLoggable("Mms", 2)) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    log("sendMessage: address=***, threadId=" + this.mThreadId + ", uri=***, msgs.count=" + messageCount);
                    return false;
                }
                log("sendMessage: address=" + this.mDest + ", threadId=" + this.mThreadId + ", uri=" + this.mUri + ", msgs.count=" + messageCount);
                return false;
            }
            return false;
        } catch (Exception ex) {
            Log.e("Mms", "SmsMessageSender.sendMessage: caught", ex);
            throw new MmsException("SmsMessageSender.sendMessage: caught " + ex + " from SmsManager.sendMultipartTextMessage()");
        }
    }

    private void log(String msg) {
        Log.d("Mms", "[SmsSingleRecipientSender] " + msg);
    }
}
