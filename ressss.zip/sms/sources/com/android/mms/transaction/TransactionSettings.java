package com.android.mms.transaction;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.NetworkUtils;
import android.net.Uri;
import android.provider.Telephony;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.ui.MessageDispActivity;

/* JADX INFO: loaded from: classes.dex */
public class TransactionSettings {
    private static final String[] APN_PROJECTION = {"type", "mmsc", "mmsproxy", "mmsport"};
    private static final int COLUMN_MMSC = 1;
    private static final int COLUMN_MMSPORT = 3;
    private static final int COLUMN_MMSPROXY = 2;
    private static final int COLUMN_TYPE = 0;
    private static final boolean DEBUG = true;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private String mProxyAddress;
    private int mProxyPort;
    private String mServiceCenter;

    public TransactionSettings(Context context, String apnName, int subId) {
        this.mProxyPort = -1;
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "TransactionSettings: apnName: " + apnName + "subId: " + subId);
        }
        String selection = null;
        String[] selectionArgs = null;
        Uri contentUri = Telephony.Carriers.CONTENT_URI;
        if (!TextUtils.isEmpty(apnName)) {
            selection = "apn=?";
            selectionArgs = new String[]{apnName.trim()};
        } else {
            contentUri = Uri.withAppendedPath(contentUri, "/subId/" + subId);
        }
        Cursor cursor = SqliteWrapper.query(context, context.getContentResolver(), contentUri, APN_PROJECTION, selection, selectionArgs, (String) null);
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "TransactionSettings looking for apn: " + selection + " returned: " + (cursor == null ? "null cursor" : cursor.getCount() + " hits"));
        }
        if (cursor == null) {
            Log.e("Mms", "Apn is not found in Database!");
            return;
        }
        boolean sawValidApn = false;
        while (cursor.moveToNext() && TextUtils.isEmpty(this.mServiceCenter)) {
            try {
                if (isValidApnType(cursor.getString(0), "mms")) {
                    sawValidApn = true;
                    String mmsc = cursor.getString(1);
                    if (mmsc != null) {
                        this.mServiceCenter = NetworkUtils.trimV4AddrZeros(mmsc.trim());
                        this.mProxyAddress = NetworkUtils.trimV4AddrZeros(cursor.getString(2));
                        if (isProxySet()) {
                            String portString = cursor.getString(3);
                            try {
                                this.mProxyPort = Integer.parseInt(portString);
                            } catch (NumberFormatException e) {
                                if (TextUtils.isEmpty(portString)) {
                                    Log.w("Mms", "mms port not set!");
                                } else {
                                    Log.e("Mms", "Bad port number format: " + portString, e);
                                }
                            }
                        }
                    }
                }
            } catch (Throwable th) {
                cursor.close();
                throw th;
            }
        }
        cursor.close();
        Log.v("Mms", "APN setting: MMSC: " + this.mServiceCenter + " looked for: " + selection);
        if (sawValidApn && TextUtils.isEmpty(this.mServiceCenter)) {
            Log.e("Mms", "Invalid APN setting: MMSC is empty");
        }
    }

    public TransactionSettings(String mmscUrl, String proxyAddr, int proxyPort) {
        this.mProxyPort = -1;
        this.mServiceCenter = mmscUrl != null ? mmscUrl.trim() : null;
        this.mProxyAddress = proxyAddr;
        this.mProxyPort = proxyPort;
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "TransactionSettings: " + this.mServiceCenter + " proxyAddress: " + this.mProxyAddress + " proxyPort: " + this.mProxyPort);
        }
    }

    public String getMmscUrl() {
        return this.mServiceCenter;
    }

    public String getProxyAddress() {
        return this.mProxyAddress;
    }

    public int getProxyPort() {
        return this.mProxyPort;
    }

    public boolean isProxySet() {
        return (this.mProxyAddress == null || this.mProxyAddress.trim().length() == 0) ? false : true;
    }

    private static boolean isValidApnType(String types, String requestType) {
        if (TextUtils.isEmpty(types)) {
            return true;
        }
        String[] arr$ = types.split(MessageDispActivity.string_delimiter);
        for (String t : arr$) {
            if (t.equals(requestType) || t.equals("*")) {
                return true;
            }
        }
        return false;
    }
}
