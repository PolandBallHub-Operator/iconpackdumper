package com.android.mms.transaction;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.FjSettings;
import android.telephony.SmsManager;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.android.mms.MmsApp;
import com.android.mms.R;
import com.android.mms.data.Contact;
import com.android.mms.util.DraftCache;
import com.android.mms.util.ModeStringUtil;

/* JADX INFO: loaded from: classes.dex */
public class MmsSystemEventReceiver extends BroadcastReceiver {
    private static final String TAG = "Mms";
    private static ConnectivityManager mConnMgr = null;
    private static MmsSystemEventReceiver sMmsSystemEventReceiver;

    public static void wakeUpService(Context context) {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "wakeUpService: start transaction service ...");
        }
        context.startService(new Intent(context, (Class<?>) TransactionService.class));
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "Intent received: " + intent);
        }
        String action = intent.getAction();
        if (action.equals("android.intent.action.CONTENT_CHANGED")) {
            Uri changed = (Uri) intent.getParcelableExtra("deleted_contents");
            MmsApp.getApplication().getPduLoaderManager().removePdu(changed);
            return;
        }
        if (action.equals("android.net.conn.CONNECTIVITY_CHANGE")) {
            if (mConnMgr == null) {
                mConnMgr = (ConnectivityManager) context.getSystemService("connectivity");
            }
            if (!mConnMgr.getMobileDataEnabled()) {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "mobile data turned off, bailing");
                    return;
                }
                return;
            }
            NetworkInfo mmsNetworkInfo = mConnMgr.getNetworkInfo(2);
            if (mmsNetworkInfo != null) {
                boolean available = mmsNetworkInfo.isAvailable();
                boolean isConnected = mmsNetworkInfo.isConnected();
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "TYPE_MOBILE_MMS available = " + available + ", isConnected = " + isConnected);
                }
                if (available && !isConnected) {
                    wakeUpService(context);
                    return;
                }
                return;
            }
            return;
        }
        if (action.equals("android.intent.action.BOOT_COMPLETED")) {
            MessagingNotification.nonBlockingUpdateNewMessageIndicator(context, false, false);
            wakeUpService(context);
            return;
        }
        if (action.equals("org.codeaurora.intent.action.ACTION_SUBSCRIPTION_SET_UICC_RESULT")) {
            int status = intent.getIntExtra("operationResult", 1);
            int state = intent.getIntExtra("newSubState", 0);
            int phoneId = intent.getIntExtra("phone", 0);
            Log.d("Mms", "ACTION_SUBSCRIPTION_SET_UICC_RESULT status = " + status + ", state = " + state + " phoneId: " + phoneId);
            if (status == 0 && state == 1) {
                wakeUpService(context);
                return;
            }
            return;
        }
        if (action.equals("android.intent.action.AIRPLANE_MODE")) {
            boolean apm = intent.getBooleanExtra(TransactionService.STATE, false);
            if (!apm) {
                Log.d("Mms", "Airplane mode OFF");
                wakeUpService(context);
                return;
            }
            return;
        }
        if (action.equals("com.android.provider.telephony.SMS_BACKUP_COMPLETED")) {
            Log.d("Mms", "SMS_BACKUP_COMPLETED received");
            Contact.recipientIdCacheInit(context);
            DraftCache.getInstance().refresh();
            return;
        }
        if (action.equals("com.fujitsu.mobile_phone.intent.action.LOW_BATTERY_SMS")) {
            boolean isSettingOn = FjSettings.Global.getInt(context.getContentResolver(), "sms_low_battery_on", 0) == 1;
            String contactUri = FjSettings.Global.getString(context.getContentResolver(), "sms_low_battery_contact");
            if (isSettingOn) {
                if (contactUri != null) {
                    Cursor contactCursor = context.getContentResolver().query(Uri.parse(contactUri), new String[]{"data1", "mimetype"}, null, null, null);
                    if (contactCursor != null && contactCursor.getCount() > 0) {
                        String phoneNumber = getContactNumber(context, Uri.parse(contactUri));
                        if (phoneNumber != null && !phoneNumber.equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
                            SmsManager smsManager = SmsManager.getDefault();
                            String content = context.getResources().getString(ModeStringUtil.getModeResFromArray(context, R.array.battery_low_sms_content));
                            smsManager.sendTextMessage(phoneNumber, null, content, null, null);
                            Log.d("Mms", "Battery low, Send message to xxxxxx");
                            return;
                        }
                        return;
                    }
                    Log.d("Mms", "Battery low, get contactCursor error");
                    return;
                }
                Log.d("Mms", "Battery low, get contact error contactUri is null");
            }
        }
    }

    public String getContactNumber(Context context, Uri uri) {
        Cursor dataCursor = context.getContentResolver().query(uri, new String[]{"data1", "mimetype"}, null, null, null);
        String number = null;
        if (dataCursor != null && dataCursor.getCount() > 0) {
            while (dataCursor.moveToNext()) {
                String type = dataCursor.getString(1);
                if ("vnd.android.cursor.item/name".equals(type)) {
                    dataCursor.getString(0);
                } else if ("vnd.android.cursor.item/phone_v2".equals(type)) {
                    number = dataCursor.getString(0);
                }
            }
        }
        return number;
    }

    public static void registerForConnectionStateChanges(Context context) {
        unRegisterForConnectionStateChanges(context);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.ANY_DATA_STATE");
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "registerForConnectionStateChanges");
        }
        if (sMmsSystemEventReceiver == null) {
            sMmsSystemEventReceiver = new MmsSystemEventReceiver();
        }
        context.registerReceiver(sMmsSystemEventReceiver, intentFilter);
    }

    public static void unRegisterForConnectionStateChanges(Context context) {
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "unRegisterForConnectionStateChanges");
        }
        if (sMmsSystemEventReceiver != null) {
            try {
                context.unregisterReceiver(sMmsSystemEventReceiver);
            } catch (IllegalArgumentException e) {
            }
        }
    }
}
