package com.android.mms.transaction;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.drm.DrmManagerClient;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.provider.FjSettings;
import android.provider.Settings;
import android.telecom.TelecomManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.android.mms.R;
import com.android.mms.model.SmilHelper;
import com.android.mms.ui.SettingMessageActivity;
import com.fujitsu.mobile_phone.android.keynotifier.KeyNotifier;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

/* JADX INFO: loaded from: classes.dex */
public class SmsRingtoneService extends Service {
    private static final boolean DBG = false;
    private static final int DEFAULT_READ_COUNT = 3;
    private static final int MESSAGE_TTS_SPEAK = 3;
    private static final int MESSAGE_TTS_START = 1;
    private static final int READING_FAILED = 1;
    private static final String READING_TTS_UTTERANCE_ID = "READING_TTS_UTTERANCE_ID";
    private static final int READING_UPDATE = 0;
    private static final int REPEAT_INTERVAL = 0;
    private static final int RINGTONE_DURATION = 2000;
    private static final String TAG = "SmsRingtoneService";
    public static final long[][] VIBRATION_PATTERN = {new long[]{0, 1000, 500, 1000, 500, 1000, 500, 1000, 1000}, new long[]{0, 300, 100, 300, 500, 300, 100, 300, 500}, new long[]{0, 1500, 1500, 1500, 1500}, new long[]{0, 1500, 1000, 1500, 1000, 1500, 1000, 1500, 1000}, new long[]{0, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000}};
    public static final String extraKey_ReadingTitle = "ReadingTitle";
    public static final String extraKey_ReadingType = "ReadingType";
    private KeyNotifier mKeyNotifier;
    private Context mContext = null;
    private int mReadCount = 0;
    private String mReadingTitle = null;
    private int mReadingType = -1;
    private MediaPlayer mMediaPlayer = null;
    private Timer mRingtoneStopTimer = null;
    private PowerManager.WakeLock mWakeLock = null;
    private boolean mRinging = false;
    private boolean mThreadInterrupted = false;
    private Ringtone mRingtone = null;
    private Vibrator mVibrator = null;
    private boolean mIsVibrate = false;
    private Timer mVibratorStopTimer = null;
    private int ringTime = 5;
    private BroadcastReceiver mScreenOnReceiver = null;
    private BroadcastReceiver mScreenOffReceiver = null;
    private boolean mSpeaking = false;
    private boolean mStart = false;
    private ISmsRingtoneService.Stub mSmsRingtoneService = new ISmsRingtoneService.Stub() { // from class: com.android.mms.transaction.SmsRingtoneService.3
        @Override // com.android.mms.transaction.ISmsRingtoneService
        public void startSpeak(String readingTitle, int readingType) {
            SmsRingtoneService.this.mStart = true;
            SmsRingtoneService.this.mReadingTitle = readingTitle;
            SmsRingtoneService.this.mReadingType = readingType;
            SmsRingtoneService.this.preparationForSpeech();
            SmsRingtoneService.this.playRingtoneToSpeak();
        }

        @Override // com.android.mms.transaction.ISmsRingtoneService
        public void stopSpeak() {
            SmsRingtoneService.this.stopRingtoneToSpeak();
        }

        @Override // com.android.mms.transaction.ISmsRingtoneService
        public void startToVibrator() {
            SmsRingtoneService.this.startVerbation();
        }

        @Override // com.android.mms.transaction.ISmsRingtoneService
        public void stopToVibrator() {
            SmsRingtoneService.this.stopVerbation();
        }

        @Override // com.android.mms.transaction.ISmsRingtoneService
        public void startToRington() {
            SmsRingtoneService.this.playRingtone();
        }

        @Override // com.android.mms.transaction.ISmsRingtoneService
        public void stopToRington() {
            SmsRingtoneService.this.stopRingtone();
        }
    };
    private Handler mSpeechHandler = new Handler() { // from class: com.android.mms.transaction.SmsRingtoneService.4
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    SmsRingtoneService.this.playRingtoneToSpeak();
                    break;
                case 3:
                    SmsRingtoneService.this.playNameSpeak();
                    break;
            }
        }
    };
    private PhoneStateListener mPhoneStateListener = new PhoneStateListener() { // from class: com.android.mms.transaction.SmsRingtoneService.13
        @Override // android.telephony.PhoneStateListener
        public void onCallStateChanged(int state, String number) {
            if (state == 1) {
                try {
                    SmsRingtoneService.this.mSmsRingtoneService.stopSpeak();
                    SmsRingtoneService.this.mSmsRingtoneService.stopToRington();
                    SmsRingtoneService.this.mSmsRingtoneService.stopToVibrator();
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        if (ISmsRingtoneService.class.getName().equals(intent.getAction())) {
            return this.mSmsRingtoneService;
        }
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        this.mContext = getApplicationContext();
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService("phone");
        telephonyManager.listen(this.mPhoneStateListener, 32);
        startForegroundHidden(1);
        this.mScreenOnReceiver = new BroadcastReceiver() { // from class: com.android.mms.transaction.SmsRingtoneService.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
            }
        };
        IntentFilter screenOnFilter = new IntentFilter();
        screenOnFilter.addAction("android.intent.action.SCREEN_ON");
        registerReceiver(this.mScreenOnReceiver, screenOnFilter);
        this.mScreenOffReceiver = new BroadcastReceiver() { // from class: com.android.mms.transaction.SmsRingtoneService.2
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                SmsRingtoneService.this.mReadCount = 3;
            }
        };
        IntentFilter screenOffFilter = new IntentFilter();
        screenOffFilter.addAction("android.intent.action.SCREEN_OFF");
        registerReceiver(this.mScreenOffReceiver, screenOffFilter);
    }

    @Override // android.app.Service
    public void onDestroy() {
        stopRingtone();
        stopVerbation();
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService("phone");
        telephonyManager.listen(this.mPhoneStateListener, 0);
        unregisterReceiver(this.mScreenOnReceiver);
        unregisterReceiver(this.mScreenOffReceiver);
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendSpeakMessage(int what) {
        Message msg = Message.obtain();
        msg.what = what;
        this.mSpeechHandler.sendMessage(msg);
    }

    private void sendSpeakMessageDelayed(int what) {
        Message msg = Message.obtain();
        msg.what = what;
        this.mSpeechHandler.sendMessageDelayed(msg, 0L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void preparationForSpeech() {
        this.mReadCount = 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playRingtoneToSpeak() {
        if (this.mReadCount < 3) {
            if (this.mMediaPlayer == null) {
                this.mMediaPlayer = MediaPlayer.create(this.mContext, R.raw.chaku_yomi_mail);
                this.mMediaPlayer.setLooping(true);
            }
            if (this.mKeyNotifier == null) {
                this.mKeyNotifier = new KeyNotifier(this.mContext);
            }
            if (this.mKeyNotifier != null) {
                this.mKeyNotifier.setOnKeyListener(new KeyNotifier.OnKeyListener() { // from class: com.android.mms.transaction.SmsRingtoneService.5
                    public void onKeyDown() {
                        Log.d(SmsRingtoneService.TAG, "keydown");
                        SmsRingtoneService.this.stopRingtoneToSpeak();
                    }
                });
            }
            if (this.mMediaPlayer != null) {
                AudioManager audioManager = (AudioManager) this.mContext.getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
                audioManager.setMode(1);
                if (this.mStart) {
                    this.mSpeaking = true;
                    stopNameSpeak();
                    this.mStart = false;
                }
                this.mMediaPlayer.start();
                this.mRingtoneStopTimer = new Timer(true);
                this.mRingtoneStopTimer.schedule(new TimerTask() { // from class: com.android.mms.transaction.SmsRingtoneService.6
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        SmsRingtoneService.this.stopRingtone();
                        SmsRingtoneService.this.sendSpeakMessage(3);
                    }
                }, 2000L);
                this.mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.android.mms.transaction.SmsRingtoneService.7
                    @Override // android.media.MediaPlayer.OnCompletionListener
                    public void onCompletion(MediaPlayer mp) {
                        if (SmsRingtoneService.this.mKeyNotifier != null) {
                            SmsRingtoneService.this.mKeyNotifier.setOnKeyListener((KeyNotifier.OnKeyListener) null);
                        }
                    }
                });
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopRingtoneToSpeak() {
        this.mReadingType = -1;
        if (this.mRingtoneStopTimer != null) {
            this.mRingtoneStopTimer.cancel();
            this.mRingtoneStopTimer = null;
        }
        this.mReadCount = 3;
        stopRingtone();
        stopNameSpeak();
        if (this.mKeyNotifier != null) {
            this.mKeyNotifier.setOnKeyListener((KeyNotifier.OnKeyListener) null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playNameSpeak() {
        if (this.mReadCount < 3) {
            if (this.mReadingType == 0) {
                if (TextUtils.isEmpty(this.mReadingTitle)) {
                    this.mReadCount++;
                    if (this.mReadCount < 3) {
                        sendSpeakMessageDelayed(1);
                        return;
                    }
                    return;
                }
            } else if (this.mReadingType == 1) {
            }
            new HashMap();
            this.mSpeaking = true;
        }
    }

    private void stopNameSpeak() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopRingtone() {
        interruptRingtone();
        cancelRingtoneStopTimer();
        if (this.mRingtone != null) {
            this.mRingtone.stop();
            this.mRinging = false;
        }
        if (this.mMediaPlayer != null) {
            this.mMediaPlayer.stop();
            this.mMediaPlayer.release();
            this.mMediaPlayer = null;
            this.mRinging = false;
        }
        AudioManager audioManager = (AudioManager) this.mContext.getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
        audioManager.setMode(0);
        Log.d(TAG, "stopRingtone:" + this.mKeyNotifier);
        if (this.mKeyNotifier != null) {
            this.mKeyNotifier.setOnKeyListener((KeyNotifier.OnKeyListener) null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playRingtone() {
        boolean canRing;
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        String ringtoneStr = FjSettings.Global.getString(getContentResolver(), "message_tone");
        this.ringTime = sp.getInt(SettingMessageActivity.RINGTONE_TIME, 36);
        AudioManager audio = (AudioManager) getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
        if (audio.getRingerMode() != 2) {
        }
        int current_volume = FjSettings.Global.getInt(getContentResolver(), "volume_message", 4);
        Log.d(TAG, "current_volume = " + current_volume);
        TelecomManager mTelecomManager = TelecomManager.from(this.mContext);
        Log.d(TAG, "getCallState = " + mTelecomManager.getCallState());
        if (mTelecomManager.getCallState() != 0 || current_volume == 0) {
            canRing = false;
        } else {
            canRing = true;
        }
        this.mThreadInterrupted = false;
        if (canRing && this.mMediaPlayer == null && this.ringTime != 0 && Uri.parse(ringtoneStr) != null) {
            this.mMediaPlayer = new MediaPlayer();
        }
        if (this.mMediaPlayer != null) {
            this.mMediaPlayer.reset();
            try {
                this.mMediaPlayer.setDataSource(getApplicationContext(), Uri.parse(ringtoneStr));
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                this.mMediaPlayer.setAudioStreamType(5);
                this.mMediaPlayer.setLooping(false);
                AudioManager audioManager = (AudioManager) this.mContext.getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
                audioManager.setMode(1);
                audioManager.setStreamVolume(5, current_volume, 0);
                audioManager.requestAudioFocus(new AudioManager.OnAudioFocusChangeListener() { // from class: com.android.mms.transaction.SmsRingtoneService.8
                    @Override // android.media.AudioManager.OnAudioFocusChangeListener
                    public void onAudioFocusChange(int focusChange) {
                        if (focusChange != 1 && SmsRingtoneService.this.mMediaPlayer != null && SmsRingtoneService.this.mMediaPlayer.isPlaying()) {
                            Log.d(SmsRingtoneService.TAG, "SmsRingtoneService | onAudioFocusChange stopRingtone");
                            SmsRingtoneService.this.stopRingtone();
                        }
                    }
                }, 4, 2);
                if (this.mKeyNotifier == null) {
                    this.mKeyNotifier = new KeyNotifier(getApplicationContext());
                }
                Log.d(TAG, "mKeyNotifier2 :" + this.mKeyNotifier);
                if (this.mKeyNotifier != null) {
                    this.mKeyNotifier.setOnKeyListener(new KeyNotifier.OnKeyListener() { // from class: com.android.mms.transaction.SmsRingtoneService.9
                        public void onKeyDown() {
                            Log.d(SmsRingtoneService.TAG, "keydown2");
                            SmsRingtoneService.this.stopRingtone();
                            SmsRingtoneService.this.stopVerbation();
                        }
                    });
                }
                this.mMediaPlayer.prepare();
                this.mMediaPlayer.start();
                this.mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.android.mms.transaction.SmsRingtoneService.10
                    @Override // android.media.MediaPlayer.OnCompletionListener
                    public void onCompletion(MediaPlayer mp) {
                        Log.d(SmsRingtoneService.TAG, "onCompletion mKeyNotifier:" + SmsRingtoneService.this.mKeyNotifier);
                        if (SmsRingtoneService.this.mKeyNotifier != null) {
                            SmsRingtoneService.this.mKeyNotifier.setOnKeyListener((KeyNotifier.OnKeyListener) null);
                        }
                    }
                });
                Log.d(TAG, "mediaPlayer.start()..................................");
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            this.mRingtoneStopTimer = new Timer(true);
            this.mRingtoneStopTimer.schedule(new TimerTask() { // from class: com.android.mms.transaction.SmsRingtoneService.11
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    SmsRingtoneService.this.stopRingtone();
                }
            }, this.ringTime * 1000);
            return;
        }
        Log.d(TAG, "mediaPlayer == null....................");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopVerbation() {
        if (this.mVibrator != null) {
            this.mVibrator.cancel();
            this.mIsVibrate = false;
            if (this.mWakeLock != null) {
                this.mWakeLock.release();
                this.mWakeLock = null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startVerbation() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        this.ringTime = sp.getInt(SettingMessageActivity.RINGTONE_TIME, 5);
        AudioManager audio = (AudioManager) getSystemService(SmilHelper.ELEMENT_TAG_AUDIO);
        boolean isVibrate = audio.shouldVibrate(0) || audio.getStreamVolume(2) != 0;
        long[][] vibrationPattern = VIBRATION_PATTERN;
        long[] pattern = vibrationPattern[0];
        if (this.ringTime != 0 && isVibrate) {
            if (this.mWakeLock == null) {
                PowerManager powerManager = (PowerManager) getApplicationContext().getSystemService("power");
                this.mWakeLock = powerManager.newWakeLock(536870913, TAG);
            }
            this.mVibrator = (Vibrator) getSystemService("vibrator");
            if (this.mVibrator != null) {
                if (this.mWakeLock != null) {
                    this.mWakeLock.acquire();
                }
                this.mIsVibrate = true;
                this.mVibrator.vibrate(pattern, 0);
            }
            this.mVibratorStopTimer = new Timer(true);
            this.mVibratorStopTimer.schedule(new TimerTask() { // from class: com.android.mms.transaction.SmsRingtoneService.12
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    SmsRingtoneService.this.stopVerbation();
                }
            }, this.ringTime * 1000);
        }
    }

    private static Uri getCustomRingtoneUri(Context context, String ringtoneUriString) {
        Uri ret_uri;
        if (ringtoneUriString == null || TextUtils.isEmpty(ringtoneUriString)) {
            return null;
        }
        Uri uri = Uri.parse(ringtoneUriString);
        if (isRightsValid(context, uri)) {
            ret_uri = uri;
        } else if (isRightsValid(context, Settings.System.DEFAULT_NOTIFICATION_URI)) {
            ret_uri = Settings.System.DEFAULT_NOTIFICATION_URI;
        } else {
            ret_uri = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.flow_tone);
        }
        return ret_uri;
    }

    private static boolean isRightsValid(Context context, Uri uri) {
        boolean result = false;
        if (uri == null) {
            result = true;
        } else {
            if (uri.equals(Settings.System.DEFAULT_NOTIFICATION_URI)) {
                String uriStr = getRingtoneUri(context, uri);
                if (uriStr == null) {
                    return false;
                }
                uri = Uri.parse(uriStr);
            }
            DrmManagerClient dmc = new DrmManagerClient(context);
            try {
                boolean canhandle = dmc.canHandle(uri, (String) null);
                if (canhandle) {
                    int canPlay = dmc.checkRightsStatus(uri, 1);
                    if (canPlay == 0) {
                        result = true;
                    }
                } else {
                    result = true;
                }
            } catch (Exception e) {
                return false;
            }
        }
        return result;
    }

    private static String getRingtoneUri(Context context, Uri uri) {
        String value = null;
        try {
            Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    value = cursor.getString(cursor.getColumnIndex(LoggingEvents.VoiceSearch.EXTRA_QUERY_UPDATED_VALUE));
                }
                cursor.close();
            }
        } catch (SQLiteException sqle) {
            Log.e(LoggingEvents.EXTRA_CALLING_APP_NAME, sqle.getMessage());
        }
        return value;
    }

    private void interruptRingtone() {
        this.mThreadInterrupted = true;
    }

    private void cancelRingtoneStopTimer() {
        if (this.mRingtoneStopTimer != null) {
            this.mRingtoneStopTimer.cancel();
            this.mRingtoneStopTimer = null;
        }
    }
}
