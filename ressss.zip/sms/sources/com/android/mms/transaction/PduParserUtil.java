package com.android.mms.transaction;

import android.telephony.SmsManager;

/* JADX INFO: loaded from: classes.dex */
public class PduParserUtil {
    public static boolean shouldParseContentDisposition() {
        return SmsManager.getDefault().getCarrierConfigValues().getBoolean("supportMmsContentDisposition", true);
    }
}
