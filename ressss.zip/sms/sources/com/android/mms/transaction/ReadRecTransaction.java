package com.android.mms.transaction;

import android.content.Context;
import android.net.Uri;
import android.provider.Telephony;
import android.util.Log;
import com.android.mms.ui.MessageUtils;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.EncodedStringValue;
import com.google.android.mms.pdu.PduComposer;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.ReadRecInd;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public class ReadRecTransaction extends Transaction implements Runnable {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private final Uri mReadReportURI;
    private Thread mThread;

    public ReadRecTransaction(Context context, int transId, TransactionSettings connectionSettings, String uri) {
        super(context, transId, connectionSettings);
        this.mReadReportURI = Uri.parse(uri);
        this.mId = uri;
        attach(RetryScheduler.getInstance(context));
    }

    @Override // com.android.mms.transaction.Transaction
    public void process() {
        this.mThread = new Thread(this, "ReadRecTransaction");
        this.mThread.start();
    }

    @Override // java.lang.Runnable
    public void run() {
        PduPersister persister = PduPersister.getPduPersister(this.mContext);
        try {
            ReadRecInd readRecInd = persister.load(this.mReadReportURI);
            String lineNumber = MessageUtils.getLocalNumber();
            readRecInd.setFrom(new EncodedStringValue(lineNumber));
            byte[] postingData = new PduComposer(this.mContext, readRecInd).make();
            sendPdu(postingData);
            Uri uri = persister.move(this.mReadReportURI, Telephony.Mms.Sent.CONTENT_URI);
            this.mTransactionState.setState(1);
            this.mTransactionState.setContentUri(uri);
        } catch (IOException e) {
        } catch (RuntimeException e2) {
        } catch (MmsException e3) {
        } finally {
            if (this.mTransactionState.getState() != 1) {
                this.mTransactionState.setState(2);
                this.mTransactionState.setContentUri(this.mReadReportURI);
            }
            notifyObservers();
        }
    }

    @Override // com.android.mms.transaction.Transaction
    public void abort() {
        Log.d("Mms", "markFailed = " + this);
        this.mTransactionState.setState(2);
        this.mTransactionState.setContentUri(this.mReadReportURI);
        notifyObservers();
    }

    @Override // com.android.mms.transaction.Transaction
    public int getType() {
        return 3;
    }
}
