package com.android.mms;

import java.io.Serializable;
import java.util.ArrayList;

/* JADX INFO: compiled from: QTIBackupSMS.java */
/* JADX INFO: loaded from: classes.dex */
class SMSBackup implements Serializable {
    public ArrayList<SMSObject> SMSList = new ArrayList<>();
}
