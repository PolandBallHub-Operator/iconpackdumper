package com.android.mms;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public class QTIMMSObject implements Serializable {
    private String date;
    private String id;
    private String locked;
    private byte[] mmData;
    private String msg_box;
    private String msg_size;
    private String msg_type;
    private String read;

    public byte[] getMmData() {
        return this.mmData;
    }

    public void setMmData(byte[] mmData) {
        this.mmData = mmData;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMsg_box() {
        return this.msg_box;
    }

    public void setMsg_box(String msg_box) {
        this.msg_box = msg_box;
    }

    public String getMsg_type() {
        return this.msg_type;
    }

    public void setMsg_type(String msg_type) {
        this.msg_type = msg_type;
    }

    public String getRead() {
        return this.read;
    }

    public void setRead(String read) {
        this.read = read;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocked() {
        return this.locked;
    }

    public void setLocked(String locked) {
        this.locked = locked;
    }

    public String getMsg_size() {
        return this.msg_size;
    }

    public void setMsg_size(String msg_size) {
        this.msg_size = msg_size;
    }
}
