package com.android.mms;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Telephony;
import android.util.Log;
import com.android.mms.transaction.PduParserUtil;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.PduComposer;
import com.google.android.mms.pdu.PduParser;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.RetrieveConf;
import com.google.android.mms.pdu.SendReq;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class QTIBackupMMS {
    static final String[] MAILBOX_PROJECTION = {"_id", "msg_box", "m_type", "read", "date", "locked", "m_size", "sub_id"};
    Cursor cursor;
    Context mContext;
    FileInputStream mFileInputStream;
    FileOutputStream mFileOutputStream;
    String vfile;
    private final boolean DEBUG = false;
    private final String TAG = "QTIBackupMMS";
    QMMSBackup mmsBackupSent = new QMMSBackup();
    QMMSBackup mmsBackupInbox = new QMMSBackup();
    QMMSBackup mmsBackupDraft = new QMMSBackup();

    private enum MsgBox {
        SENT,
        INBOX,
        DRAFT
    }

    public QTIBackupMMS(Context context, String _vfile) {
        this.mContext = context;
        this.vfile = _vfile;
    }

    public void performBackup() {
        int numOfMmsSent = getMmsList(MsgBox.SENT);
        int numOfMmsInbox = getMmsList(MsgBox.INBOX);
        int numOfMmsDraft = getMmsList(MsgBox.DRAFT);
        writeMmsList(numOfMmsSent, numOfMmsInbox, numOfMmsDraft);
    }

    public void performRestore() {
        try {
            this.mFileInputStream = this.mContext.openFileInput(this.vfile);
            ObjectInputStream ois = new ObjectInputStream(this.mFileInputStream);
            int numOfObjects = ois.readInt();
            QMMSBackup mmsbk = (QMMSBackup) ois.readObject();
            if (numOfObjects > 0) {
                Log.d("QTIBackupMMS", "No messages to restore in Sent");
            }
            writeMMS(mmsbk, Telephony.Mms.Sent.CONTENT_URI);
            int numOfObjects2 = ois.readInt();
            QMMSBackup mmsbk2 = (QMMSBackup) ois.readObject();
            if (numOfObjects2 > 0) {
                Log.d("QTIBackupMMS", "No messages to restore in Inbox");
            }
            writeMMS(mmsbk2, Telephony.Mms.Inbox.CONTENT_URI);
            int numOfObjects3 = ois.readInt();
            QMMSBackup mmsbk3 = (QMMSBackup) ois.readObject();
            if (numOfObjects3 > 0) {
                Log.d("QTIBackupMMS", "No messages to restore in Draft");
            }
            writeMMS(mmsbk3, Telephony.Mms.Draft.CONTENT_URI);
        } catch (FileNotFoundException e) {
            Log.e("QTIBackupMMS", e.getLocalizedMessage());
        } catch (StreamCorruptedException e2) {
            Log.e("QTIBackupMMS", e2.getLocalizedMessage());
        } catch (IOException e3) {
            Log.e("QTIBackupMMS", e3.getLocalizedMessage());
        } catch (ClassNotFoundException e4) {
            Log.e("QTIBackupMMS", e4.getLocalizedMessage());
        }
    }

    private void writeMMS(QMMSBackup mmsbk, Uri uri) {
        this.mContext.getContentResolver();
        ContentValues values = new ContentValues();
        PduPersister pdup = PduPersister.getPduPersister(this.mContext);
        for (QTIMMSObject mmsObj : mmsbk.MMSList) {
            byte[] Data = mmsObj.getMmData();
            Uri msgUri = null;
            try {
                if (uri.equals(Telephony.Mms.Inbox.CONTENT_URI)) {
                    RetrieveConf retrieveConf = new PduParser(Data, PduParserUtil.shouldParseContentDisposition()).parse();
                    msgUri = pdup.persist(retrieveConf, uri, true, false, (HashMap) null);
                } else {
                    SendReq retrieveConf2 = new PduParser(Data, PduParserUtil.shouldParseContentDisposition()).parse();
                    msgUri = pdup.persist(retrieveConf2, uri, true, false, (HashMap) null);
                }
            } catch (MmsException e) {
                Log.e("QTIBackupMMS", e.getLocalizedMessage());
            }
            values.put("date", mmsObj.getDate());
            values.put("read", mmsObj.getRead());
            values.put("locked", mmsObj.getLocked());
            values.put("m_size", mmsObj.getMsg_size());
            try {
                this.mContext.getContentResolver().update(msgUri, values, null, null);
            } catch (Exception e2) {
                Log.e("QTIBackupMMS", e2.getLocalizedMessage());
                return;
            }
        }
    }

    private void writeMmsList(int numSent, int numInbox, int numDraft) {
        try {
            this.mFileOutputStream = this.mContext.openFileOutput(this.vfile, 0);
            ObjectOutputStream oos = new ObjectOutputStream(this.mFileOutputStream);
            oos.writeInt(numSent);
            oos.writeObject(this.mmsBackupSent);
            oos.writeInt(numInbox);
            oos.writeObject(this.mmsBackupInbox);
            oos.writeInt(numDraft);
            oos.writeObject(this.mmsBackupDraft);
            oos.flush();
            oos.close();
            this.mFileOutputStream.close();
        } catch (IOException e) {
            Log.e("QTIBackupMMS", e.getLocalizedMessage());
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    private int getMmsList(MsgBox Box) {
        int numOfEntries = 0;
        switch (Box) {
            case SENT:
                Uri uri = Telephony.Mms.Sent.CONTENT_URI;
                Cursor cr = this.mContext.getContentResolver().query(uri, null, null, null, null);
                numOfEntries = BackupMsg(cr, this.mmsBackupSent);
                if (cr != null) {
                    cr.close();
                }
                return numOfEntries;
            case INBOX:
                Uri uri2 = Telephony.Mms.Inbox.CONTENT_URI;
                Cursor cr2 = this.mContext.getContentResolver().query(uri2, null, null, null, null);
                numOfEntries = BackupMsg(cr2, this.mmsBackupInbox);
                if (cr2 != null) {
                    cr2.close();
                }
                return numOfEntries;
            case DRAFT:
                Uri uri3 = Telephony.Mms.Draft.CONTENT_URI;
                Cursor cr3 = this.mContext.getContentResolver().query(uri3, null, null, null, null);
                numOfEntries = BackupMsg(cr3, this.mmsBackupDraft);
                if (cr3 != null) {
                    cr3.close();
                }
                return numOfEntries;
            default:
                return numOfEntries;
        }
    }

    private int BackupMsg(Cursor cr, QMMSBackup mmsBackup) {
        if (cr == null) {
            return -1;
        }
        if (cr.getCount() == 0) {
            return 0;
        }
        int numOfEntries = 0;
        cr.moveToFirst();
        int i = 0;
        while (true) {
            QTIMMSObject mmsObj = exportMms(cr);
            mmsBackup.MMSList.add(mmsObj);
            numOfEntries++;
            if (!cr.isLast()) {
                cr.moveToNext();
                i++;
            } else {
                return numOfEntries;
            }
        }
    }

    private QTIMMSObject exportMms(Cursor c) {
        QTIMMSObject mms = new QTIMMSObject();
        mms.setId(c.getString(c.getColumnIndexOrThrow("_id")));
        mms.setDate(c.getString(c.getColumnIndexOrThrow("date")));
        mms.setLocked(c.getString(c.getColumnIndexOrThrow("locked")));
        mms.setMsg_box(c.getString(c.getColumnIndexOrThrow("msg_box")));
        mms.setMsg_size(c.getString(c.getColumnIndexOrThrow("m_size")));
        mms.setMsg_type(c.getString(c.getColumnIndexOrThrow("m_type")));
        mms.setRead(c.getString(c.getColumnIndexOrThrow("read")));
        Uri uri = ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, Long.parseLong(mms.getId()));
        PduPersister persister = PduPersister.getPduPersister(this.mContext);
        byte[] mmData = null;
        if (1 == Long.parseLong(mms.getMsg_box())) {
            try {
                RetrieveConf retrieveConf = persister.load(uri);
                PduComposer composer = new PduComposer(this.mContext, retrieveConf);
                try {
                    mmData = composer.make();
                } catch (MmsException e) {
                    e = e;
                    Log.e("QTIBackupMMS", e.getLocalizedMessage());
                } catch (ClassCastException e2) {
                    e = e2;
                    Log.e("QTIBackupMMS", e.getLocalizedMessage());
                } catch (Exception e3) {
                    e = e3;
                    Log.e("QTIBackupMMS", e.getLocalizedMessage());
                }
            } catch (ClassCastException e4) {
                e = e4;
            } catch (Exception e5) {
                e = e5;
            } catch (MmsException e6) {
                e = e6;
            }
        } else {
            try {
                SendReq sendReq = persister.load(uri);
                mmData = new PduComposer(this.mContext, sendReq).make();
            } catch (MmsException e7) {
                Log.e("QTIBackupMMS", e7.getLocalizedMessage());
            }
        }
        mms.setMmData(mmData);
        return mms;
    }
}
