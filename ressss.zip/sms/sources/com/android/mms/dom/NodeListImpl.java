package com.android.mms.dom;

import java.util.ArrayList;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/* JADX INFO: loaded from: classes.dex */
public class NodeListImpl implements NodeList {
    private boolean mDeepSearch;
    private Node mRootNode;
    private ArrayList<Node> mSearchNodes;
    private ArrayList<Node> mStaticNodes;
    private String mTagName;

    public NodeListImpl(Node rootNode, String tagName, boolean deepSearch) {
        this.mRootNode = rootNode;
        this.mTagName = tagName;
        this.mDeepSearch = deepSearch;
    }

    public NodeListImpl(ArrayList<Node> nodes) {
        this.mStaticNodes = nodes;
    }

    @Override // org.w3c.dom.NodeList
    public int getLength() {
        if (this.mStaticNodes != null) {
            return this.mStaticNodes.size();
        }
        fillList(this.mRootNode);
        return this.mSearchNodes.size();
    }

    @Override // org.w3c.dom.NodeList
    public Node item(int index) {
        if (this.mStaticNodes == null) {
            fillList(this.mRootNode);
            try {
                Node node = this.mSearchNodes.get(index);
                return node;
            } catch (IndexOutOfBoundsException e) {
                return null;
            }
        }
        try {
            Node node2 = this.mStaticNodes.get(index);
            return node2;
        } catch (IndexOutOfBoundsException e2) {
            return null;
        }
    }

    private void fillList(Node node) {
        if (node == this.mRootNode) {
            this.mSearchNodes = new ArrayList<>();
        } else if (this.mTagName == null || node.getNodeName().equals(this.mTagName)) {
            this.mSearchNodes.add(node);
        }
        for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
            if (this.mDeepSearch) {
                fillList(node2);
            } else if (this.mTagName == null || node2.getNodeName().equals(this.mTagName)) {
                this.mSearchNodes.add(node2);
            }
        }
    }
}
