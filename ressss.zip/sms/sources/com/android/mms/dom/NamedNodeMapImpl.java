package com.android.mms.dom;

import java.util.Vector;
import org.w3c.dom.DOMException;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/* JADX INFO: loaded from: classes.dex */
public class NamedNodeMapImpl implements NamedNodeMap {
    private Vector<Node> mNodes = new Vector<>();

    @Override // org.w3c.dom.NamedNodeMap
    public int getLength() {
        return this.mNodes.size();
    }

    @Override // org.w3c.dom.NamedNodeMap
    public Node getNamedItem(String name) {
        for (int i = 0; i < this.mNodes.size(); i++) {
            if (name.equals(this.mNodes.elementAt(i).getNodeName())) {
                Node node = this.mNodes.elementAt(i);
                return node;
            }
        }
        return null;
    }

    @Override // org.w3c.dom.NamedNodeMap
    public Node getNamedItemNS(String namespaceURI, String localName) {
        return null;
    }

    @Override // org.w3c.dom.NamedNodeMap
    public Node item(int index) {
        if (index < this.mNodes.size()) {
            return this.mNodes.elementAt(index);
        }
        return null;
    }

    @Override // org.w3c.dom.NamedNodeMap
    public Node removeNamedItem(String name) throws DOMException {
        Node node = getNamedItem(name);
        if (node == null) {
            throw new DOMException((short) 8, "Not found");
        }
        this.mNodes.remove(node);
        return node;
    }

    @Override // org.w3c.dom.NamedNodeMap
    public Node removeNamedItemNS(String namespaceURI, String localName) throws DOMException {
        return null;
    }

    @Override // org.w3c.dom.NamedNodeMap
    public Node setNamedItem(Node arg) throws DOMException {
        Node existing = getNamedItem(arg.getNodeName());
        if (existing != null) {
            this.mNodes.remove(existing);
        }
        this.mNodes.add(arg);
        return existing;
    }

    @Override // org.w3c.dom.NamedNodeMap
    public Node setNamedItemNS(Node arg) throws DOMException {
        return null;
    }
}
