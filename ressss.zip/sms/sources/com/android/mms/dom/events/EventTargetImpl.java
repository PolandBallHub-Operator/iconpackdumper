package com.android.mms.dom.events;

import android.util.Log;
import com.android.common.speech.LoggingEvents;
import java.util.ArrayList;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventException;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.events.EventTarget;

/* JADX INFO: loaded from: classes.dex */
public class EventTargetImpl implements EventTarget {
    private static final String TAG = "Mms";
    private ArrayList<EventListenerEntry> mListenerEntries;
    private EventTarget mNodeTarget;

    static class EventListenerEntry {
        final EventListener mListener;
        final String mType;
        final boolean mUseCapture;

        EventListenerEntry(String type, EventListener listener, boolean useCapture) {
            this.mType = type;
            this.mListener = listener;
            this.mUseCapture = useCapture;
        }
    }

    public EventTargetImpl(EventTarget target) {
        this.mNodeTarget = target;
    }

    @Override // org.w3c.dom.events.EventTarget
    public void addEventListener(String type, EventListener listener, boolean useCapture) {
        if (type != null && !type.equals(LoggingEvents.EXTRA_CALLING_APP_NAME) && listener != null) {
            removeEventListener(type, listener, useCapture);
            if (this.mListenerEntries == null) {
                this.mListenerEntries = new ArrayList<>();
            }
            this.mListenerEntries.add(new EventListenerEntry(type, listener, useCapture));
        }
    }

    @Override // org.w3c.dom.events.EventTarget
    public boolean dispatchEvent(Event evt) throws EventException {
        EventImpl eventImpl = (EventImpl) evt;
        if (!eventImpl.isInitialized()) {
            throw new EventException((short) 0, "Event not initialized");
        }
        if (eventImpl.getType() == null || eventImpl.getType().equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
            throw new EventException((short) 0, "Unspecified even type");
        }
        eventImpl.setTarget(this.mNodeTarget);
        eventImpl.setEventPhase((short) 2);
        eventImpl.setCurrentTarget(this.mNodeTarget);
        if (!eventImpl.isPropogationStopped() && this.mListenerEntries != null) {
            for (int i = 0; i < this.mListenerEntries.size(); i++) {
                EventListenerEntry listenerEntry = this.mListenerEntries.get(i);
                if (!listenerEntry.mUseCapture && listenerEntry.mType.equals(eventImpl.getType())) {
                    try {
                        listenerEntry.mListener.handleEvent(eventImpl);
                    } catch (Exception e) {
                        Log.w("Mms", "Catched EventListener exception", e);
                    }
                }
            }
        }
        if (eventImpl.getBubbles()) {
        }
        return eventImpl.isPreventDefault();
    }

    @Override // org.w3c.dom.events.EventTarget
    public void removeEventListener(String type, EventListener listener, boolean useCapture) {
        if (this.mListenerEntries != null) {
            for (int i = 0; i < this.mListenerEntries.size(); i++) {
                EventListenerEntry listenerEntry = this.mListenerEntries.get(i);
                if (listenerEntry.mUseCapture == useCapture && listenerEntry.mListener == listener && listenerEntry.mType.equals(type)) {
                    this.mListenerEntries.remove(i);
                    return;
                }
            }
        }
    }
}
