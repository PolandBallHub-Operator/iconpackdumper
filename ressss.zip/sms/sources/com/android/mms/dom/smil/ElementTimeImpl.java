package com.android.mms.dom.smil;

import android.support.v4.view.MotionEventCompat;
import android.util.Log;
import com.android.mms.transaction.MessageSender;
import com.android.mms.ui.EditSlideDurationActivity;
import java.util.ArrayList;
import org.w3c.dom.DOMException;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

/* JADX INFO: loaded from: classes.dex */
public abstract class ElementTimeImpl implements ElementTime {
    private static final String FILLDEFAULT_ATTRIBUTE_NAME = "fillDefault";
    private static final String FILL_ATTRIBUTE_NAME = "fill";
    private static final String FILL_AUTO_ATTRIBUTE = "auto";
    private static final String FILL_FREEZE_ATTRIBUTE = "freeze";
    private static final String FILL_HOLD_ATTRIBUTE = "hold";
    private static final String FILL_REMOVE_ATTRIBUTE = "remove";
    private static final String FILL_TRANSITION_ATTRIBUTE = "transition";
    private static final String TAG = "Mms";
    final SMILElement mSmilElement;

    abstract ElementTime getParentElementTime();

    ElementTimeImpl(SMILElement element) {
        this.mSmilElement = element;
    }

    int getBeginConstraints() {
        return MotionEventCompat.ACTION_MASK;
    }

    int getEndConstraints() {
        return MotionEventCompat.ACTION_MASK;
    }

    @Override // org.w3c.dom.smil.ElementTime
    public TimeList getBegin() {
        String[] beginTimeStringList = this.mSmilElement.getAttribute("begin").split(MessageSender.RECIPIENTS_SEPARATOR);
        ArrayList<Time> beginTimeList = new ArrayList<>();
        for (String str : beginTimeStringList) {
            try {
                beginTimeList.add(new TimeImpl(str, getBeginConstraints()));
            } catch (IllegalArgumentException e) {
            }
        }
        if (beginTimeList.size() == 0) {
            beginTimeList.add(new TimeImpl("0", MotionEventCompat.ACTION_MASK));
        }
        return new TimeListImpl(beginTimeList);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getDur() {
        try {
            String durString = this.mSmilElement.getAttribute(EditSlideDurationActivity.SLIDE_DUR);
            if (durString == null) {
                return 0.0f;
            }
            float dur = TimeImpl.parseClockValue(durString) / 1000.0f;
            return dur;
        } catch (IllegalArgumentException e) {
            return 0.0f;
        }
    }

    @Override // org.w3c.dom.smil.ElementTime
    public TimeList getEnd() {
        ArrayList<Time> endTimeList = new ArrayList<>();
        String[] endTimeStringList = this.mSmilElement.getAttribute("end").split(MessageSender.RECIPIENTS_SEPARATOR);
        int len = endTimeStringList.length;
        if (len != 1 || endTimeStringList[0].length() != 0) {
            for (String str : endTimeStringList) {
                try {
                    endTimeList.add(new TimeImpl(str, getEndConstraints()));
                } catch (IllegalArgumentException e) {
                    Log.e("Mms", "Malformed time value.", e);
                }
            }
        }
        if (endTimeList.size() == 0) {
            float duration = getDur();
            if (duration < 0.0f) {
                endTimeList.add(new TimeImpl("indefinite", getEndConstraints()));
            } else {
                TimeList begin = getBegin();
                for (int i = 0; i < begin.getLength(); i++) {
                    endTimeList.add(new TimeImpl((begin.item(i).getResolvedOffset() + ((double) duration)) + "s", getEndConstraints()));
                }
            }
        }
        return new TimeListImpl(endTimeList);
    }

    private boolean beginAndEndAreZero() {
        TimeList begin = getBegin();
        TimeList end = getEnd();
        if (begin.getLength() != 1 || end.getLength() != 1) {
            return false;
        }
        Time beginTime = begin.item(0);
        Time endTime = end.item(0);
        return beginTime.getOffset() == 0.0d && endTime.getOffset() == 0.0d;
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getFill() {
        short fillDefault;
        String fill = this.mSmilElement.getAttribute(FILL_ATTRIBUTE_NAME);
        if (fill.equalsIgnoreCase(FILL_FREEZE_ATTRIBUTE)) {
            return (short) 1;
        }
        if (fill.equalsIgnoreCase(FILL_REMOVE_ATTRIBUTE)) {
            return (short) 0;
        }
        if (!fill.equalsIgnoreCase(FILL_HOLD_ATTRIBUTE) && !fill.equalsIgnoreCase(FILL_TRANSITION_ATTRIBUTE)) {
            if (fill.equalsIgnoreCase(FILL_AUTO_ATTRIBUTE) || (fillDefault = getFillDefault()) == 2) {
                return ((this.mSmilElement.getAttribute(EditSlideDurationActivity.SLIDE_DUR).length() == 0 && this.mSmilElement.getAttribute("end").length() == 0 && this.mSmilElement.getAttribute("repeatCount").length() == 0 && this.mSmilElement.getAttribute("repeatDur").length() == 0) || beginAndEndAreZero()) ? (short) 1 : (short) 0;
            }
            return fillDefault;
        }
        return (short) 1;
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getFillDefault() {
        String fillDefault = this.mSmilElement.getAttribute(FILLDEFAULT_ATTRIBUTE_NAME);
        if (fillDefault.equalsIgnoreCase(FILL_REMOVE_ATTRIBUTE)) {
            return (short) 0;
        }
        if (fillDefault.equalsIgnoreCase(FILL_FREEZE_ATTRIBUTE)) {
            return (short) 1;
        }
        if (fillDefault.equalsIgnoreCase(FILL_AUTO_ATTRIBUTE)) {
            return (short) 2;
        }
        if (fillDefault.equalsIgnoreCase(FILL_HOLD_ATTRIBUTE) || fillDefault.equalsIgnoreCase(FILL_TRANSITION_ATTRIBUTE)) {
            return (short) 1;
        }
        ElementTime parent = getParentElementTime();
        if (parent == null) {
            return (short) 2;
        }
        return ((ElementTimeImpl) parent).getFillDefault();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getRepeatCount() {
        String repeatCount = this.mSmilElement.getAttribute("repeatCount");
        try {
            float value = Float.parseFloat(repeatCount);
            if (value > 0.0f) {
                return value;
            }
            return 0.0f;
        } catch (NumberFormatException e) {
            return 0.0f;
        }
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getRepeatDur() {
        try {
            float repeatDur = TimeImpl.parseClockValue(this.mSmilElement.getAttribute("repeatDur"));
            if (repeatDur > 0.0f) {
                return repeatDur;
            }
            return 0.0f;
        } catch (IllegalArgumentException e) {
            return 0.0f;
        }
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getRestart() {
        String restart = this.mSmilElement.getAttribute("restart");
        if (restart.equalsIgnoreCase("never")) {
            return (short) 1;
        }
        if (restart.equalsIgnoreCase("whenNotActive")) {
            return (short) 2;
        }
        return (short) 0;
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setBegin(TimeList begin) throws DOMException {
        this.mSmilElement.setAttribute("begin", "indefinite");
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setDur(float dur) throws DOMException {
        this.mSmilElement.setAttribute(EditSlideDurationActivity.SLIDE_DUR, Integer.toString((int) (1000.0f * dur)) + "ms");
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setEnd(TimeList end) throws DOMException {
        this.mSmilElement.setAttribute("end", "indefinite");
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setFill(short fill) throws DOMException {
        if (fill == 1) {
            this.mSmilElement.setAttribute(FILL_ATTRIBUTE_NAME, FILL_FREEZE_ATTRIBUTE);
        } else {
            this.mSmilElement.setAttribute(FILL_ATTRIBUTE_NAME, FILL_REMOVE_ATTRIBUTE);
        }
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setFillDefault(short fillDefault) throws DOMException {
        if (fillDefault == 1) {
            this.mSmilElement.setAttribute(FILLDEFAULT_ATTRIBUTE_NAME, FILL_FREEZE_ATTRIBUTE);
        } else {
            this.mSmilElement.setAttribute(FILLDEFAULT_ATTRIBUTE_NAME, FILL_REMOVE_ATTRIBUTE);
        }
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRepeatCount(float repeatCount) throws DOMException {
        String repeatCountString = "indefinite";
        if (repeatCount > 0.0f) {
            repeatCountString = Float.toString(repeatCount);
        }
        this.mSmilElement.setAttribute("repeatCount", repeatCountString);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRepeatDur(float repeatDur) throws DOMException {
        String repeatDurString = "indefinite";
        if (repeatDur > 0.0f) {
            repeatDurString = Float.toString(repeatDur) + "ms";
        }
        this.mSmilElement.setAttribute("repeatDur", repeatDurString);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRestart(short restart) throws DOMException {
        if (restart == 1) {
            this.mSmilElement.setAttribute("restart", "never");
        } else if (restart == 2) {
            this.mSmilElement.setAttribute("restart", "whenNotActive");
        } else {
            this.mSmilElement.setAttribute("restart", "always");
        }
    }
}
