package com.android.mms.dom.smil;

import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.smil.Time;

/* JADX INFO: loaded from: classes.dex */
public class TimeImpl implements Time {
    static final int ALLOW_ALL = 255;
    static final int ALLOW_EVENT_VALUE = 16;
    static final int ALLOW_INDEFINITE_VALUE = 1;
    static final int ALLOW_MARKER_VALUE = 32;
    static final int ALLOW_NEGATIVE_VALUE = 128;
    static final int ALLOW_OFFSET_VALUE = 2;
    static final int ALLOW_SYNCBASE_VALUE = 4;
    static final int ALLOW_SYNCTOPREV_VALUE = 8;
    static final int ALLOW_WALLCLOCK_VALUE = 64;
    boolean mResolved;
    double mResolvedOffset;
    short mTimeType;

    TimeImpl(String timeValue, int constraints) {
        if (timeValue.equals("indefinite") && (constraints & 1) != 0) {
            this.mTimeType = (short) 0;
            return;
        }
        if ((constraints & 2) != 0) {
            int sign = 1;
            if (timeValue.startsWith("+")) {
                timeValue = timeValue.substring(1);
            } else if (timeValue.startsWith("-")) {
                timeValue = timeValue.substring(1);
                sign = -1;
            }
            this.mResolvedOffset = ((double) (sign * parseClockValue(timeValue))) / 1000.0d;
            this.mResolved = true;
            this.mTimeType = (short) 1;
            return;
        }
        throw new IllegalArgumentException("Unsupported time value");
    }

    public static float parseClockValue(String clockValue) {
        int indexOfMinutes;
        float result;
        float result2 = 0.0f;
        try {
            String clockValue2 = clockValue.trim();
            if (clockValue2.endsWith("ms")) {
                result = parseFloat(clockValue2, 2, true);
            } else if (clockValue2.endsWith("s")) {
                result = 1000.0f * parseFloat(clockValue2, 1, true);
            } else if (clockValue2.endsWith("min")) {
                result = 60000.0f * parseFloat(clockValue2, 3, true);
            } else if (clockValue2.endsWith("h")) {
                result = 3600000.0f * parseFloat(clockValue2, 1, true);
            } else {
                try {
                    return parseFloat(clockValue2, 0, true) * 1000.0f;
                } catch (NumberFormatException e) {
                    String[] timeValues = clockValue2.split(":");
                    if (timeValues.length == 2) {
                        indexOfMinutes = 0;
                    } else if (timeValues.length == 3) {
                        result2 = 3600000 * ((int) parseFloat(timeValues[0], 0, false));
                        indexOfMinutes = 1;
                    } else {
                        throw new IllegalArgumentException();
                    }
                    int minutes = (int) parseFloat(timeValues[indexOfMinutes], 0, false);
                    if (minutes >= 0 && minutes <= 59) {
                        float result3 = result2 + (60000 * minutes);
                        float seconds = parseFloat(timeValues[indexOfMinutes + 1], 0, true);
                        if (seconds >= 0.0f && seconds < 60.0f) {
                            result = result3 + (60000.0f * seconds);
                        } else {
                            throw new IllegalArgumentException();
                        }
                    } else {
                        throw new IllegalArgumentException();
                    }
                }
            }
            return result;
        } catch (NumberFormatException e2) {
            throw new IllegalArgumentException();
        }
    }

    private static float parseFloat(String value, int ignoreLast, boolean parseDecimal) {
        String value2 = value.substring(0, value.length() - ignoreLast);
        int indexOfComma = value2.indexOf(46);
        if (indexOfComma != -1) {
            if (!parseDecimal) {
                throw new IllegalArgumentException("int value contains decimal");
            }
            String value3 = value2 + "000";
            float result = Float.parseFloat(value3.substring(0, indexOfComma));
            return result + (Float.parseFloat(value3.substring(indexOfComma + 1, indexOfComma + 4)) / 1000.0f);
        }
        float result2 = Integer.parseInt(value2);
        return result2;
    }

    @Override // org.w3c.dom.smil.Time
    public boolean getBaseBegin() {
        return false;
    }

    @Override // org.w3c.dom.smil.Time
    public Element getBaseElement() {
        return null;
    }

    @Override // org.w3c.dom.smil.Time
    public String getEvent() {
        return null;
    }

    @Override // org.w3c.dom.smil.Time
    public String getMarker() {
        return null;
    }

    @Override // org.w3c.dom.smil.Time
    public double getOffset() {
        return 0.0d;
    }

    @Override // org.w3c.dom.smil.Time
    public boolean getResolved() {
        return this.mResolved;
    }

    @Override // org.w3c.dom.smil.Time
    public double getResolvedOffset() {
        return this.mResolvedOffset;
    }

    @Override // org.w3c.dom.smil.Time
    public short getTimeType() {
        return this.mTimeType;
    }

    @Override // org.w3c.dom.smil.Time
    public void setBaseBegin(boolean baseBegin) throws DOMException {
    }

    @Override // org.w3c.dom.smil.Time
    public void setBaseElement(Element baseElement) throws DOMException {
    }

    @Override // org.w3c.dom.smil.Time
    public void setEvent(String event) throws DOMException {
    }

    @Override // org.w3c.dom.smil.Time
    public void setMarker(String marker) throws DOMException {
    }

    @Override // org.w3c.dom.smil.Time
    public void setOffset(double offset) throws DOMException {
    }
}
