package com.android.mms.dom.smil;

import org.w3c.dom.smil.ElementTimeContainer;
import org.w3c.dom.smil.SMILElement;

/* JADX INFO: loaded from: classes.dex */
public abstract class ElementTimeContainerImpl extends ElementTimeImpl implements ElementTimeContainer {
    ElementTimeContainerImpl(SMILElement element) {
        super(element);
    }
}
