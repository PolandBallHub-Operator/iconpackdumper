package com.android.mms.dom.smil;

import org.w3c.dom.DOMException;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILRegionElement;

/* JADX INFO: loaded from: classes.dex */
public class SmilRegionElementImpl extends SmilElementImpl implements SMILRegionElement {
    private static final String BACKGROUND_COLOR_ATTRIBUTE_NAME = "backgroundColor";
    private static final String BOTTOM_ATTRIBUTE_NAME = "bottom";
    private static final boolean DEBUG = false;
    private static final String FILL_ATTRIBUTE = "fill";
    private static final String FIT_ATTRIBUTE_NAME = "fit";
    private static final String HEIGHT_ATTRIBUTE_NAME = "height";
    private static final String HIDDEN_ATTRIBUTE = "hidden";
    private static final String ID_ATTRIBUTE_NAME = "id";
    private static final String LEFT_ATTRIBUTE_NAME = "left";
    private static final boolean LOCAL_LOGV = false;
    private static final String MEET_ATTRIBUTE = "meet";
    private static final String RIGHT_ATTRIBUTE_NAME = "right";
    private static final String SCROLL_ATTRIBUTE = "scroll";
    private static final String SLICE_ATTRIBUTE = "slice";
    private static final String TAG = "Mms";
    private static final String TITLE_ATTRIBUTE_NAME = "title";
    private static final String TOP_ATTRIBUTE_NAME = "top";
    private static final String WIDTH_ATTRIBUTE_NAME = "width";
    private static final String Z_INDEX_ATTRIBUTE_NAME = "z-index";

    SmilRegionElementImpl(SmilDocumentImpl owner, String tagName) {
        super(owner, tagName);
    }

    @Override // org.w3c.dom.smil.SMILRegionElement
    public String getFit() {
        String fit = getAttribute(FIT_ATTRIBUTE_NAME);
        if (FILL_ATTRIBUTE.equalsIgnoreCase(fit)) {
            return FILL_ATTRIBUTE;
        }
        if (MEET_ATTRIBUTE.equalsIgnoreCase(fit)) {
            return MEET_ATTRIBUTE;
        }
        if (SCROLL_ATTRIBUTE.equalsIgnoreCase(fit)) {
            return SCROLL_ATTRIBUTE;
        }
        if (SLICE_ATTRIBUTE.equalsIgnoreCase(fit)) {
            return SLICE_ATTRIBUTE;
        }
        return HIDDEN_ATTRIBUTE;
    }

    @Override // org.w3c.dom.smil.SMILRegionElement
    public int getLeft() {
        try {
            return parseRegionLength(getAttribute(LEFT_ATTRIBUTE_NAME), true);
        } catch (NumberFormatException e) {
            try {
                int bbw = ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getWidth();
                int right = parseRegionLength(getAttribute(RIGHT_ATTRIBUTE_NAME), true);
                int width = parseRegionLength(getAttribute(WIDTH_ATTRIBUTE_NAME), true);
                return (bbw - right) - width;
            } catch (NumberFormatException e2) {
                return 0;
            }
        }
    }

    @Override // org.w3c.dom.smil.SMILRegionElement
    public int getTop() {
        try {
            return parseRegionLength(getAttribute(TOP_ATTRIBUTE_NAME), false);
        } catch (NumberFormatException e) {
            try {
                int bbh = ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getHeight();
                int bottom = parseRegionLength(getAttribute(BOTTOM_ATTRIBUTE_NAME), false);
                int height = parseRegionLength(getAttribute(HEIGHT_ATTRIBUTE_NAME), false);
                return (bbh - bottom) - height;
            } catch (NumberFormatException e2) {
                return 0;
            }
        }
    }

    @Override // org.w3c.dom.smil.SMILRegionElement
    public int getZIndex() {
        try {
            return Integer.parseInt(getAttribute(Z_INDEX_ATTRIBUTE_NAME));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @Override // org.w3c.dom.smil.SMILRegionElement
    public void setFit(String fit) throws DOMException {
        if (fit.equalsIgnoreCase(FILL_ATTRIBUTE) || fit.equalsIgnoreCase(MEET_ATTRIBUTE) || fit.equalsIgnoreCase(SCROLL_ATTRIBUTE) || fit.equalsIgnoreCase(SLICE_ATTRIBUTE)) {
            setAttribute(FIT_ATTRIBUTE_NAME, fit.toLowerCase());
        } else {
            setAttribute(FIT_ATTRIBUTE_NAME, HIDDEN_ATTRIBUTE);
        }
    }

    @Override // org.w3c.dom.smil.SMILRegionElement
    public void setLeft(int left) throws DOMException {
        setAttribute(LEFT_ATTRIBUTE_NAME, String.valueOf(left));
    }

    @Override // org.w3c.dom.smil.SMILRegionElement
    public void setTop(int top) throws DOMException {
        setAttribute(TOP_ATTRIBUTE_NAME, String.valueOf(top));
    }

    @Override // org.w3c.dom.smil.SMILRegionElement
    public void setZIndex(int zIndex) throws DOMException {
        if (zIndex > 0) {
            setAttribute(Z_INDEX_ATTRIBUTE_NAME, Integer.toString(zIndex));
        } else {
            setAttribute(Z_INDEX_ATTRIBUTE_NAME, Integer.toString(0));
        }
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public String getBackgroundColor() {
        return getAttribute(BACKGROUND_COLOR_ATTRIBUTE_NAME);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public int getHeight() {
        try {
            int height = parseRegionLength(getAttribute(HEIGHT_ATTRIBUTE_NAME), false);
            if (height == 0) {
                return ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getHeight();
            }
            return height;
        } catch (NumberFormatException e) {
            int bbh = ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getHeight();
            try {
                bbh -= parseRegionLength(getAttribute(TOP_ATTRIBUTE_NAME), false);
            } catch (NumberFormatException e2) {
            }
            try {
                bbh -= parseRegionLength(getAttribute(BOTTOM_ATTRIBUTE_NAME), false);
            } catch (NumberFormatException e3) {
            }
            return bbh;
        }
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public String getTitle() {
        return getAttribute("title");
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public int getWidth() {
        try {
            int width = parseRegionLength(getAttribute(WIDTH_ATTRIBUTE_NAME), true);
            if (width == 0) {
                return ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getWidth();
            }
            return width;
        } catch (NumberFormatException e) {
            int bbw = ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getWidth();
            try {
                bbw -= parseRegionLength(getAttribute(LEFT_ATTRIBUTE_NAME), true);
            } catch (NumberFormatException e2) {
            }
            try {
                bbw -= parseRegionLength(getAttribute(RIGHT_ATTRIBUTE_NAME), true);
            } catch (NumberFormatException e3) {
            }
            return bbw;
        }
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public void setBackgroundColor(String backgroundColor) throws DOMException {
        setAttribute(BACKGROUND_COLOR_ATTRIBUTE_NAME, backgroundColor);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public void setHeight(int height) throws DOMException {
        setAttribute(HEIGHT_ATTRIBUTE_NAME, String.valueOf(height) + "px");
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public void setTitle(String title) throws DOMException {
        setAttribute("title", title);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public void setWidth(int width) throws DOMException {
        setAttribute(WIDTH_ATTRIBUTE_NAME, String.valueOf(width) + "px");
    }

    @Override // com.android.mms.dom.smil.SmilElementImpl, org.w3c.dom.smil.SMILElement
    public String getId() {
        return getAttribute("id");
    }

    @Override // com.android.mms.dom.smil.SmilElementImpl, org.w3c.dom.smil.SMILElement
    public void setId(String id) throws DOMException {
        setAttribute("id", id);
    }

    private int parseRegionLength(String length, boolean horizontal) {
        double value;
        if (length.endsWith("px")) {
            return Integer.parseInt(length.substring(0, length.indexOf("px")));
        }
        if (length.endsWith("%")) {
            double value2 = 0.01d * ((double) Integer.parseInt(length.substring(0, length.length() - 1)));
            if (horizontal) {
                value = value2 * ((double) ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getWidth());
            } else {
                value = value2 * ((double) ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getHeight());
            }
            return (int) Math.round(value);
        }
        return Integer.parseInt(length);
    }

    public String toString() {
        return super.toString() + ": id=" + getId() + ", width=" + getWidth() + ", height=" + getHeight() + ", left=" + getLeft() + ", top=" + getTop();
    }
}
