package com.android.mms.dom.smil;

import java.util.ArrayList;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

/* JADX INFO: loaded from: classes.dex */
public class TimeListImpl implements TimeList {
    private final ArrayList<Time> mTimes;

    TimeListImpl(ArrayList<Time> times) {
        this.mTimes = times;
    }

    @Override // org.w3c.dom.smil.TimeList
    public int getLength() {
        return this.mTimes.size();
    }

    @Override // org.w3c.dom.smil.TimeList
    public Time item(int index) {
        try {
            Time time = this.mTimes.get(index);
            return time;
        } catch (IndexOutOfBoundsException e) {
            return null;
        }
    }
}
