package com.android.mms.dom.smil;

import org.w3c.dom.DOMException;
import org.w3c.dom.smil.SMILRootLayoutElement;

/* JADX INFO: loaded from: classes.dex */
public class SmilRootLayoutElementImpl extends SmilElementImpl implements SMILRootLayoutElement {
    private static final String BACKGROUND_COLOR_ATTRIBUTE_NAME = "backgroundColor";
    private static final String HEIGHT_ATTRIBUTE_NAME = "height";
    private static final String TITLE_ATTRIBUTE_NAME = "title";
    private static final String WIDTH_ATTRIBUTE_NAME = "width";

    SmilRootLayoutElementImpl(SmilDocumentImpl owner, String tagName) {
        super(owner, tagName);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public String getBackgroundColor() {
        return getAttribute(BACKGROUND_COLOR_ATTRIBUTE_NAME);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public int getHeight() {
        String heightString = getAttribute(HEIGHT_ATTRIBUTE_NAME);
        return parseAbsoluteLength(heightString);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public String getTitle() {
        return getAttribute("title");
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public int getWidth() {
        String widthString = getAttribute(WIDTH_ATTRIBUTE_NAME);
        return parseAbsoluteLength(widthString);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public void setBackgroundColor(String backgroundColor) throws DOMException {
        setAttribute(BACKGROUND_COLOR_ATTRIBUTE_NAME, backgroundColor);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public void setHeight(int height) throws DOMException {
        setAttribute(HEIGHT_ATTRIBUTE_NAME, String.valueOf(height) + "px");
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public void setTitle(String title) throws DOMException {
        setAttribute("title", title);
    }

    @Override // org.w3c.dom.smil.ElementLayout
    public void setWidth(int width) throws DOMException {
        setAttribute(WIDTH_ATTRIBUTE_NAME, String.valueOf(width) + "px");
    }

    private int parseAbsoluteLength(String length) {
        if (length.endsWith("px")) {
            length = length.substring(0, length.indexOf("px"));
        }
        try {
            return Integer.parseInt(length);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
