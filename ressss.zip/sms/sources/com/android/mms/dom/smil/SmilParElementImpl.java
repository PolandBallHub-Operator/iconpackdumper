package com.android.mms.dom.smil;

import java.util.ArrayList;
import org.w3c.dom.DOMException;
import org.w3c.dom.NodeList;
import org.w3c.dom.events.DocumentEvent;
import org.w3c.dom.events.Event;
import org.w3c.dom.smil.ElementParallelTimeContainer;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.SMILParElement;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

/* JADX INFO: loaded from: classes.dex */
public class SmilParElementImpl extends SmilElementImpl implements SMILParElement {
    public static final String SMIL_SLIDE_END_EVENT = "SmilSlideEnd";
    public static final String SMIL_SLIDE_START_EVENT = "SmilSlideStart";
    ElementParallelTimeContainer mParTimeContainer;

    SmilParElementImpl(SmilDocumentImpl owner, String tagName) {
        super(owner, tagName.toUpperCase());
        this.mParTimeContainer = new ElementParallelTimeContainerImpl(this) { // from class: com.android.mms.dom.smil.SmilParElementImpl.1
            @Override // com.android.mms.dom.smil.ElementTimeImpl, org.w3c.dom.smil.ElementTime
            public TimeList getBegin() {
                TimeList beginTimeList = super.getBegin();
                if (beginTimeList.getLength() > 1) {
                    ArrayList<Time> singleTimeContainer = new ArrayList<>();
                    singleTimeContainer.add(beginTimeList.item(0));
                    return new TimeListImpl(singleTimeContainer);
                }
                return beginTimeList;
            }

            @Override // org.w3c.dom.smil.ElementTimeContainer
            public NodeList getTimeChildren() {
                return SmilParElementImpl.this.getChildNodes();
            }

            @Override // org.w3c.dom.smil.ElementTime
            public boolean beginElement() {
                DocumentEvent doc = (DocumentEvent) SmilParElementImpl.this.getOwnerDocument();
                Event startEvent = doc.createEvent("Event");
                startEvent.initEvent(SmilParElementImpl.SMIL_SLIDE_START_EVENT, false, false);
                SmilParElementImpl.this.dispatchEvent(startEvent);
                return true;
            }

            @Override // org.w3c.dom.smil.ElementTime
            public boolean endElement() {
                DocumentEvent doc = (DocumentEvent) SmilParElementImpl.this.getOwnerDocument();
                Event endEvent = doc.createEvent("Event");
                endEvent.initEvent(SmilParElementImpl.SMIL_SLIDE_END_EVENT, false, false);
                SmilParElementImpl.this.dispatchEvent(endEvent);
                return true;
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void pauseElement() {
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void resumeElement() {
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void seekElement(float seekTo) {
            }

            @Override // com.android.mms.dom.smil.ElementTimeImpl
            ElementTime getParentElementTime() {
                return ((SmilDocumentImpl) this.mSmilElement.getOwnerDocument()).mSeqTimeContainer;
            }
        };
    }

    int getBeginConstraints() {
        return 2;
    }

    @Override // org.w3c.dom.smil.ElementParallelTimeContainer
    public String getEndSync() {
        return this.mParTimeContainer.getEndSync();
    }

    @Override // org.w3c.dom.smil.ElementParallelTimeContainer
    public float getImplicitDuration() {
        return this.mParTimeContainer.getImplicitDuration();
    }

    @Override // org.w3c.dom.smil.ElementParallelTimeContainer
    public void setEndSync(String endSync) throws DOMException {
        this.mParTimeContainer.setEndSync(endSync);
    }

    @Override // org.w3c.dom.smil.ElementTimeContainer
    public NodeList getActiveChildrenAt(float instant) {
        return this.mParTimeContainer.getActiveChildrenAt(instant);
    }

    @Override // org.w3c.dom.smil.ElementTimeContainer
    public NodeList getTimeChildren() {
        return this.mParTimeContainer.getTimeChildren();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public boolean beginElement() {
        return this.mParTimeContainer.beginElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public boolean endElement() {
        return this.mParTimeContainer.endElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public TimeList getBegin() {
        return this.mParTimeContainer.getBegin();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getDur() {
        return this.mParTimeContainer.getDur();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public TimeList getEnd() {
        return this.mParTimeContainer.getEnd();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getFill() {
        return this.mParTimeContainer.getFill();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getFillDefault() {
        return this.mParTimeContainer.getFillDefault();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getRepeatCount() {
        return this.mParTimeContainer.getRepeatCount();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getRepeatDur() {
        return this.mParTimeContainer.getRepeatDur();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getRestart() {
        return this.mParTimeContainer.getRestart();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void pauseElement() {
        this.mParTimeContainer.pauseElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void resumeElement() {
        this.mParTimeContainer.resumeElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void seekElement(float seekTo) {
        this.mParTimeContainer.seekElement(seekTo);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setBegin(TimeList begin) throws DOMException {
        this.mParTimeContainer.setBegin(begin);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setDur(float dur) throws DOMException {
        this.mParTimeContainer.setDur(dur);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setEnd(TimeList end) throws DOMException {
        this.mParTimeContainer.setEnd(end);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setFill(short fill) throws DOMException {
        this.mParTimeContainer.setFill(fill);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setFillDefault(short fillDefault) throws DOMException {
        this.mParTimeContainer.setFillDefault(fillDefault);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRepeatCount(float repeatCount) throws DOMException {
        this.mParTimeContainer.setRepeatCount(repeatCount);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRepeatDur(float repeatDur) throws DOMException {
        this.mParTimeContainer.setRepeatDur(repeatDur);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRestart(short restart) throws DOMException {
        this.mParTimeContainer.setRestart(restart);
    }
}
