package com.android.mms.dom.smil;

import com.android.mms.dom.NodeListImpl;
import java.util.ArrayList;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.smil.ElementParallelTimeContainer;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

/* JADX INFO: loaded from: classes.dex */
public abstract class ElementParallelTimeContainerImpl extends ElementTimeContainerImpl implements ElementParallelTimeContainer {
    private static final String ENDSYNC_ALL = "all";
    private static final String ENDSYNC_ATTRIBUTE_NAME = "endsync";
    private static final String ENDSYNC_FIRST = "first";
    private static final String ENDSYNC_LAST = "last";
    private static final String ENDSYNC_MEDIA = "media";

    ElementParallelTimeContainerImpl(SMILElement element) {
        super(element);
    }

    @Override // org.w3c.dom.smil.ElementParallelTimeContainer
    public String getEndSync() {
        String endsync = this.mSmilElement.getAttribute(ENDSYNC_ATTRIBUTE_NAME);
        if (endsync == null || endsync.length() == 0) {
            setEndSync(ENDSYNC_LAST);
            return ENDSYNC_LAST;
        }
        if (!ENDSYNC_FIRST.equals(endsync) && !ENDSYNC_LAST.equals(endsync) && !ENDSYNC_ALL.equals(endsync) && !ENDSYNC_MEDIA.equals(endsync)) {
            setEndSync(ENDSYNC_LAST);
            return ENDSYNC_LAST;
        }
        return endsync;
    }

    @Override // org.w3c.dom.smil.ElementParallelTimeContainer
    public void setEndSync(String endSync) throws DOMException {
        if (ENDSYNC_FIRST.equals(endSync) || ENDSYNC_LAST.equals(endSync) || ENDSYNC_ALL.equals(endSync) || ENDSYNC_MEDIA.equals(endSync)) {
            this.mSmilElement.setAttribute(ENDSYNC_ATTRIBUTE_NAME, endSync);
            return;
        }
        throw new DOMException((short) 9, "Unsupported endsync value" + endSync);
    }

    @Override // com.android.mms.dom.smil.ElementTimeImpl, org.w3c.dom.smil.ElementTime
    public float getDur() {
        float dur = super.getDur();
        if (dur == 0.0f) {
            return getImplicitDuration();
        }
        return dur;
    }

    @Override // org.w3c.dom.smil.ElementParallelTimeContainer
    public float getImplicitDuration() {
        float dur = -1.0f;
        if (ENDSYNC_LAST.equals(getEndSync())) {
            NodeList children = getTimeChildren();
            for (int i = 0; i < children.getLength(); i++) {
                ElementTime child = (ElementTime) children.item(i);
                TimeList endTimeList = child.getEnd();
                for (int j = 0; j < endTimeList.getLength(); j++) {
                    Time endTime = endTimeList.item(j);
                    if (endTime.getTimeType() == 0) {
                        return -1.0f;
                    }
                    if (endTime.getResolved()) {
                        float end = (float) endTime.getResolvedOffset();
                        if (end > dur) {
                            dur = end;
                        }
                    }
                }
            }
        }
        return dur;
    }

    @Override // org.w3c.dom.smil.ElementTimeContainer
    public NodeList getActiveChildrenAt(float instant) {
        ArrayList<Node> activeChildren = new ArrayList<>();
        NodeList children = getTimeChildren();
        int childrenLen = children.getLength();
        for (int i = 0; i < childrenLen; i++) {
            double maxOffset = 0.0d;
            boolean active = false;
            ElementTime child = (ElementTime) children.item(i);
            TimeList beginList = child.getBegin();
            int len = beginList.getLength();
            for (int j = 0; j < len; j++) {
                Time begin = beginList.item(j);
                if (begin.getResolved()) {
                    double resolvedOffset = begin.getResolvedOffset() * 1000.0d;
                    if (resolvedOffset <= instant && resolvedOffset >= maxOffset) {
                        maxOffset = resolvedOffset;
                        active = true;
                    }
                }
            }
            TimeList endList = child.getEnd();
            int len2 = endList.getLength();
            for (int j2 = 0; j2 < len2; j2++) {
                Time end = endList.item(j2);
                if (end.getResolved()) {
                    double resolvedOffset2 = end.getResolvedOffset() * 1000.0d;
                    if (resolvedOffset2 <= instant && resolvedOffset2 >= maxOffset) {
                        maxOffset = resolvedOffset2;
                        active = false;
                    }
                }
            }
            if (active) {
                activeChildren.add((Node) child);
            }
        }
        return new NodeListImpl(activeChildren);
    }
}
