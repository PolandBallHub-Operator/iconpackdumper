package com.android.mms.dom.smil;

import org.w3c.dom.NodeList;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILRegionElement;
import org.w3c.dom.smil.SMILRegionMediaElement;

/* JADX INFO: loaded from: classes.dex */
public class SmilRegionMediaElementImpl extends SmilMediaElementImpl implements SMILRegionMediaElement {
    private SMILRegionElement mRegion;

    SmilRegionMediaElementImpl(SmilDocumentImpl owner, String tagName) {
        super(owner, tagName);
    }

    @Override // org.w3c.dom.smil.SMILRegionInterface
    public SMILRegionElement getRegion() {
        if (this.mRegion == null) {
            SMILDocument doc = (SMILDocument) getOwnerDocument();
            NodeList regions = doc.getLayout().getElementsByTagName("region");
            for (int i = 0; i < regions.getLength(); i++) {
                SMILRegionElement region = (SMILRegionElement) regions.item(i);
                if (region.getId().equals(getAttribute("region"))) {
                    this.mRegion = region;
                }
            }
        }
        return this.mRegion;
    }

    @Override // org.w3c.dom.smil.SMILRegionInterface
    public void setRegion(SMILRegionElement region) {
        setAttribute("region", region.getId());
        this.mRegion = region;
    }
}
