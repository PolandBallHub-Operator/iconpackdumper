package com.android.mms.dom.smil;

import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import org.w3c.dom.NodeList;
import org.w3c.dom.events.DocumentEvent;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.smil.ElementParallelTimeContainer;
import org.w3c.dom.smil.ElementSequentialTimeContainer;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

/* JADX INFO: loaded from: classes.dex */
public class SmilPlayer implements Runnable {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    public static final String MEDIA_TIME_UPDATED_EVENT = "mediaTimeUpdated";
    private static final String TAG = "Mms";
    private static final int TIMESLICE = 200;
    private static SmilPlayer sPlayer;
    private static final Comparator<TimelineEntry> sTimelineEntryComparator = new Comparator<TimelineEntry>() { // from class: com.android.mms.dom.smil.SmilPlayer.1
        @Override // java.util.Comparator
        public int compare(TimelineEntry o1, TimelineEntry o2) {
            return Double.compare(o1.getOffsetTime(), o2.getOffsetTime());
        }
    };
    private ArrayList<ElementTime> mActiveElements;
    private ArrayList<TimelineEntry> mAllEntries;
    private int mCurrentElement;
    private int mCurrentSlide;
    private long mCurrentTime;
    private Event mMediaTimeUpdatedEvent;
    private Thread mPlayerThread;
    private ElementTime mRoot;
    private SmilPlayerState mState = SmilPlayerState.INITIALIZED;
    private SmilPlayerAction mAction = SmilPlayerAction.NO_ACTIVE_ACTION;

    private enum SmilPlayerAction {
        NO_ACTIVE_ACTION,
        RELOAD,
        STOP,
        PAUSE,
        START,
        NEXT,
        PREV
    }

    private enum SmilPlayerState {
        INITIALIZED,
        PLAYING,
        PLAYED,
        PAUSED,
        STOPPED
    }

    private static ArrayList<TimelineEntry> getParTimeline(ElementParallelTimeContainer par, double offset, double maxOffset) {
        ArrayList<TimelineEntry> timeline = new ArrayList<>();
        TimeList myBeginList = par.getBegin();
        Time begin = myBeginList.item(0);
        double beginOffset = begin.getResolvedOffset() + offset;
        if (beginOffset <= maxOffset) {
            TimelineEntry myBegin = new TimelineEntry(beginOffset, par, 0);
            timeline.add(myBegin);
            TimeList myEndList = par.getEnd();
            Time end = myEndList.item(0);
            double endOffset = end.getResolvedOffset() + offset;
            if (endOffset > maxOffset) {
                endOffset = maxOffset;
            }
            TimelineEntry myEnd = new TimelineEntry(endOffset, par, 1);
            double maxOffset2 = endOffset;
            NodeList children = par.getTimeChildren();
            for (int i = 0; i < children.getLength(); i++) {
                ElementTime child = (ElementTime) children.item(i);
                ArrayList<TimelineEntry> childTimeline = getTimeline(child, offset, maxOffset2);
                timeline.addAll(childTimeline);
            }
            Collections.sort(timeline, sTimelineEntryComparator);
            NodeList activeChildrenAtEnd = par.getActiveChildrenAt(((float) (endOffset - offset)) * 1000.0f);
            for (int i2 = 0; i2 < activeChildrenAtEnd.getLength(); i2++) {
                timeline.add(new TimelineEntry(endOffset, (ElementTime) activeChildrenAtEnd.item(i2), 1));
            }
            timeline.add(myEnd);
        }
        return timeline;
    }

    private static ArrayList<TimelineEntry> getSeqTimeline(ElementSequentialTimeContainer seq, double offset, double maxOffset) {
        ArrayList<TimelineEntry> timeline = new ArrayList<>();
        TimeList myBeginList = seq.getBegin();
        Time begin = myBeginList.item(0);
        double beginOffset = begin.getResolvedOffset() + offset;
        if (beginOffset <= maxOffset) {
            TimelineEntry myBegin = new TimelineEntry(beginOffset, seq, 0);
            timeline.add(myBegin);
            TimeList myEndList = seq.getEnd();
            Time end = myEndList.item(0);
            double endOffset = end.getResolvedOffset() + offset;
            if (endOffset > maxOffset) {
                endOffset = maxOffset;
            }
            TimelineEntry myEnd = new TimelineEntry(endOffset, seq, 1);
            double maxOffset2 = endOffset;
            NodeList children = seq.getTimeChildren();
            for (int i = 0; i < children.getLength(); i++) {
                ElementTime child = (ElementTime) children.item(i);
                ArrayList<TimelineEntry> childTimeline = getTimeline(child, offset, maxOffset2);
                timeline.addAll(childTimeline);
                offset = childTimeline.get(childTimeline.size() - 1).getOffsetTime();
            }
            NodeList activeChildrenAtEnd = seq.getActiveChildrenAt((float) (endOffset - offset));
            for (int i2 = 0; i2 < activeChildrenAtEnd.getLength(); i2++) {
                timeline.add(new TimelineEntry(endOffset, (ElementTime) activeChildrenAtEnd.item(i2), 1));
            }
            timeline.add(myEnd);
        }
        return timeline;
    }

    private static ArrayList<TimelineEntry> getTimeline(ElementTime element, double offset, double maxOffset) {
        if (element instanceof ElementParallelTimeContainer) {
            return getParTimeline((ElementParallelTimeContainer) element, offset, maxOffset);
        }
        if (element instanceof ElementSequentialTimeContainer) {
            return getSeqTimeline((ElementSequentialTimeContainer) element, offset, maxOffset);
        }
        ArrayList<TimelineEntry> timeline = new ArrayList<>();
        TimeList beginList = element.getBegin();
        for (int i = 0; i < beginList.getLength(); i++) {
            Time begin = beginList.item(i);
            if (begin.getResolved()) {
                double beginOffset = begin.getResolvedOffset() + offset;
                if (beginOffset <= maxOffset) {
                    TimelineEntry entry = new TimelineEntry(beginOffset, element, 0);
                    timeline.add(entry);
                }
            }
        }
        TimeList endList = element.getEnd();
        for (int i2 = 0; i2 < endList.getLength(); i2++) {
            Time end = endList.item(i2);
            if (end.getResolved()) {
                double endOffset = end.getResolvedOffset() + offset;
                if (endOffset <= maxOffset) {
                    TimelineEntry entry2 = new TimelineEntry(endOffset, element, 1);
                    timeline.add(entry2);
                }
            }
        }
        Collections.sort(timeline, sTimelineEntryComparator);
        return timeline;
    }

    private SmilPlayer() {
    }

    public static SmilPlayer getPlayer() {
        if (sPlayer == null) {
            sPlayer = new SmilPlayer();
        }
        return sPlayer;
    }

    public synchronized boolean isPlayingState() {
        return this.mState == SmilPlayerState.PLAYING;
    }

    public synchronized boolean isPlayedState() {
        return this.mState == SmilPlayerState.PLAYED;
    }

    public synchronized boolean isPausedState() {
        return this.mState == SmilPlayerState.PAUSED;
    }

    public synchronized boolean isStoppedState() {
        return this.mState == SmilPlayerState.STOPPED;
    }

    private synchronized boolean isPauseAction() {
        return this.mAction == SmilPlayerAction.PAUSE;
    }

    private synchronized boolean isStartAction() {
        return this.mAction == SmilPlayerAction.START;
    }

    private synchronized boolean isStopAction() {
        return this.mAction == SmilPlayerAction.STOP;
    }

    private synchronized boolean isReloadAction() {
        return this.mAction == SmilPlayerAction.RELOAD;
    }

    private synchronized boolean isNextAction() {
        return this.mAction == SmilPlayerAction.NEXT;
    }

    private synchronized boolean isPrevAction() {
        return this.mAction == SmilPlayerAction.PREV;
    }

    public synchronized void init(ElementTime root) {
        this.mRoot = root;
        this.mAllEntries = getTimeline(this.mRoot, 0.0d, 9.223372036854776E18d);
        this.mMediaTimeUpdatedEvent = ((DocumentEvent) this.mRoot).createEvent("Event");
        this.mMediaTimeUpdatedEvent.initEvent(MEDIA_TIME_UPDATED_EVENT, false, false);
        this.mActiveElements = new ArrayList<>();
    }

    public synchronized void play() {
        if (!isPlayingState()) {
            this.mCurrentTime = 0L;
            this.mCurrentElement = 0;
            this.mCurrentSlide = 0;
            this.mPlayerThread = new Thread(this, "SmilPlayer thread");
            this.mState = SmilPlayerState.PLAYING;
            this.mPlayerThread.start();
        } else {
            Log.w("Mms", "Error State: Playback is playing!");
        }
    }

    public synchronized void pause() {
        if (isPlayingState()) {
            this.mAction = SmilPlayerAction.PAUSE;
            notifyAll();
        } else {
            Log.w("Mms", "Error State: Playback is not playing!");
        }
    }

    public synchronized void start() {
        if (isPausedState()) {
            resumeActiveElements();
            this.mAction = SmilPlayerAction.START;
            notifyAll();
        } else if (isPlayedState()) {
            play();
        } else {
            Log.w("Mms", "Error State: Playback can not be started!");
        }
    }

    public synchronized void stop() {
        if (isPlayingState() || isPausedState()) {
            this.mAction = SmilPlayerAction.STOP;
            notifyAll();
        } else if (isPlayedState()) {
            actionStop();
        }
    }

    public synchronized void stopWhenReload() {
        endActiveElements();
    }

    public synchronized void reload() {
        if (isPlayingState() || isPausedState()) {
            this.mAction = SmilPlayerAction.RELOAD;
            notifyAll();
        } else if (isPlayedState()) {
            actionReload();
        }
    }

    public synchronized void next() {
        if (isPlayingState() || isPausedState()) {
            this.mAction = SmilPlayerAction.NEXT;
            notifyAll();
        }
    }

    public synchronized void prev() {
        if (isPlayingState() || isPausedState()) {
            this.mAction = SmilPlayerAction.PREV;
            notifyAll();
        }
    }

    private synchronized boolean isBeginOfSlide(TimelineEntry entry) {
        return entry.getAction() == 0 && (entry.getElement() instanceof SmilParElementImpl);
    }

    private synchronized void reloadActiveSlide() {
        this.mActiveElements.clear();
        beginSmilDocument();
        for (int i = this.mCurrentSlide; i < this.mCurrentElement; i++) {
            TimelineEntry entry = this.mAllEntries.get(i);
            actionEntry(entry);
        }
        seekActiveMedia();
    }

    private synchronized void beginSmilDocument() {
        TimelineEntry entry = this.mAllEntries.get(0);
        actionEntry(entry);
    }

    private synchronized double getOffsetTime(ElementTime element) {
        double offsetTime;
        for (int i = this.mCurrentSlide; i < this.mCurrentElement; i++) {
            TimelineEntry entry = this.mAllEntries.get(i);
            if (element.equals(entry.getElement())) {
                offsetTime = entry.getOffsetTime() * 1000.0d;
            }
        }
        offsetTime = -1.0d;
        return offsetTime;
    }

    private synchronized void seekActiveMedia() {
        for (int i = this.mActiveElements.size() - 1; i >= 0; i--) {
            ElementTime element = this.mActiveElements.get(i);
            if (element instanceof SmilParElementImpl) {
                break;
            }
            double offset = getOffsetTime(element);
            if (offset >= 0.0d && offset <= this.mCurrentTime) {
                element.seekElement((float) (this.mCurrentTime - offset));
            }
        }
    }

    private synchronized void waitForEntry(long interval) throws InterruptedException {
        long overhead = 0;
        while (interval > 0) {
            long startAt = System.currentTimeMillis();
            long sleep = Math.min(interval, 200L);
            if (overhead < sleep) {
                wait(sleep - overhead);
                this.mCurrentTime += sleep;
            } else {
                sleep = 0;
                this.mCurrentTime += overhead;
            }
            if (isStopAction() || isReloadAction() || isPauseAction() || isNextAction() || isPrevAction()) {
                break;
            }
            ((EventTarget) this.mRoot).dispatchEvent(this.mMediaTimeUpdatedEvent);
            interval -= 200;
            overhead = (System.currentTimeMillis() - startAt) - sleep;
        }
    }

    public synchronized int getDuration() {
        return (this.mAllEntries == null || this.mAllEntries.isEmpty()) ? 0 : ((int) this.mAllEntries.get(this.mAllEntries.size() - 1).mOffsetTime) * 1000;
    }

    public synchronized int getCurrentPosition() {
        return (int) this.mCurrentTime;
    }

    private synchronized void endActiveElements() {
        for (int i = this.mActiveElements.size() - 1; i >= 0; i--) {
            ElementTime element = this.mActiveElements.get(i);
            element.endElement();
        }
    }

    private synchronized void pauseActiveElements() {
        for (int i = this.mActiveElements.size() - 1; i >= 0; i--) {
            ElementTime element = this.mActiveElements.get(i);
            element.pauseElement();
        }
    }

    private synchronized void resumeActiveElements() {
        int size = this.mActiveElements.size();
        for (int i = 0; i < size; i++) {
            ElementTime element = this.mActiveElements.get(i);
            element.resumeElement();
        }
    }

    private synchronized void waitForWakeUp() {
        while (!isStartAction() && !isStopAction() && !isReloadAction() && !isNextAction() && !isPrevAction()) {
            try {
                wait(200L);
            } catch (InterruptedException e) {
                Log.e("Mms", "Unexpected InterruptedException.", e);
            }
        }
        if (isStartAction()) {
            this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
            this.mState = SmilPlayerState.PLAYING;
        }
    }

    private synchronized void actionEntry(TimelineEntry entry) {
        switch (entry.getAction()) {
            case 0:
                entry.getElement().beginElement();
                this.mActiveElements.add(entry.getElement());
                break;
            case 1:
                entry.getElement().endElement();
                this.mActiveElements.remove(entry.getElement());
                break;
        }
    }

    private synchronized TimelineEntry reloadCurrentEntry() {
        return this.mCurrentElement < this.mAllEntries.size() ? this.mAllEntries.get(this.mCurrentElement) : null;
    }

    private void stopCurrentSlide() {
        HashSet<TimelineEntry> skippedEntries = new HashSet<>();
        int totalEntries = this.mAllEntries.size();
        for (int i = this.mCurrentElement; i < totalEntries; i++) {
            TimelineEntry entry = this.mAllEntries.get(i);
            int action = entry.getAction();
            if ((entry.getElement() instanceof SmilParElementImpl) && action == 1) {
                actionEntry(entry);
                this.mCurrentElement = i;
                return;
            }
            if (action == 1 && !skippedEntries.contains(entry)) {
                actionEntry(entry);
            } else if (action == 0) {
                skippedEntries.add(entry);
            }
        }
    }

    private TimelineEntry loadNextSlide() {
        int totalEntries = this.mAllEntries.size();
        for (int i = this.mCurrentElement; i < totalEntries; i++) {
            TimelineEntry entry = this.mAllEntries.get(i);
            if (isBeginOfSlide(entry)) {
                this.mCurrentElement = i;
                this.mCurrentSlide = i;
                this.mCurrentTime = (long) (entry.getOffsetTime() * 1000.0d);
                return entry;
            }
        }
        this.mCurrentElement++;
        TimelineEntry entry2 = null;
        if (this.mCurrentElement < totalEntries) {
            TimelineEntry entry3 = this.mAllEntries.get(this.mCurrentElement);
            entry2 = entry3;
            this.mCurrentTime = (long) (entry2.getOffsetTime() * 1000.0d);
        }
        return entry2;
    }

    private TimelineEntry loadPrevSlide() {
        int skippedSlides;
        int latestBeginEntryIndex = -1;
        int i = this.mCurrentSlide;
        int skippedSlides2 = 1;
        while (i >= 0) {
            TimelineEntry entry = this.mAllEntries.get(i);
            if (isBeginOfSlide(entry)) {
                latestBeginEntryIndex = i;
                skippedSlides = skippedSlides2 - 1;
                if (skippedSlides2 == 0) {
                    this.mCurrentElement = i;
                    this.mCurrentSlide = i;
                    this.mCurrentTime = (long) (entry.getOffsetTime() * 1000.0d);
                    return entry;
                }
            } else {
                skippedSlides = skippedSlides2;
            }
            i--;
            skippedSlides2 = skippedSlides;
        }
        if (latestBeginEntryIndex != -1) {
            this.mCurrentElement = latestBeginEntryIndex;
            this.mCurrentSlide = latestBeginEntryIndex;
            return this.mAllEntries.get(this.mCurrentElement);
        }
        return null;
    }

    private synchronized TimelineEntry actionNext() {
        stopCurrentSlide();
        return loadNextSlide();
    }

    private synchronized TimelineEntry actionPrev() {
        stopCurrentSlide();
        return loadPrevSlide();
    }

    private synchronized void actionPause() {
        pauseActiveElements();
        this.mState = SmilPlayerState.PAUSED;
        this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
    }

    private synchronized void actionStop() {
        endActiveElements();
        this.mCurrentTime = 0L;
        this.mCurrentElement = 0;
        this.mCurrentSlide = 0;
        this.mState = SmilPlayerState.STOPPED;
        this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
    }

    private synchronized void actionReload() {
        reloadActiveSlide();
        this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (!isStoppedState()) {
            int size = this.mAllEntries.size();
            this.mCurrentElement = 0;
            while (this.mCurrentElement < size) {
                TimelineEntry entry = this.mAllEntries.get(this.mCurrentElement);
                if (isBeginOfSlide(entry)) {
                    this.mCurrentSlide = this.mCurrentElement;
                }
                long offset = (long) (entry.getOffsetTime() * 1000.0d);
                while (offset > this.mCurrentTime) {
                    try {
                        waitForEntry(offset - this.mCurrentTime);
                        while (true) {
                            if (isPauseAction() || isStopAction() || isReloadAction() || isNextAction() || isPrevAction()) {
                                if (isPauseAction()) {
                                    actionPause();
                                    waitForWakeUp();
                                }
                                if (isStopAction()) {
                                    actionStop();
                                    return;
                                }
                                if (isReloadAction()) {
                                    actionReload();
                                    entry = reloadCurrentEntry();
                                    if (entry != null) {
                                        if (isPausedState()) {
                                            this.mAction = SmilPlayerAction.PAUSE;
                                        }
                                    } else {
                                        return;
                                    }
                                }
                                if (isNextAction()) {
                                    TimelineEntry nextEntry = actionNext();
                                    if (nextEntry != null) {
                                        entry = nextEntry;
                                    }
                                    if (this.mState == SmilPlayerState.PAUSED) {
                                        this.mAction = SmilPlayerAction.PAUSE;
                                        actionEntry(entry);
                                    } else {
                                        this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
                                    }
                                    offset = this.mCurrentTime;
                                }
                                if (isPrevAction()) {
                                    TimelineEntry prevEntry = actionPrev();
                                    if (prevEntry != null) {
                                        entry = prevEntry;
                                    }
                                    if (this.mState == SmilPlayerState.PAUSED) {
                                        this.mAction = SmilPlayerAction.PAUSE;
                                        actionEntry(entry);
                                    } else {
                                        this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
                                    }
                                    offset = this.mCurrentTime;
                                }
                            }
                        }
                    } catch (InterruptedException e) {
                        Log.e("Mms", "Unexpected InterruptedException.", e);
                    }
                }
                this.mCurrentTime = offset;
                actionEntry(entry);
                this.mCurrentElement++;
            }
            this.mState = SmilPlayerState.PLAYED;
        }
    }

    private static final class TimelineEntry {
        static final int ACTION_BEGIN = 0;
        static final int ACTION_END = 1;
        private final int mAction;
        private final ElementTime mElement;
        private final double mOffsetTime;

        public TimelineEntry(double offsetTime, ElementTime element, int action) {
            this.mOffsetTime = offsetTime;
            this.mElement = element;
            this.mAction = action;
        }

        public double getOffsetTime() {
            return this.mOffsetTime;
        }

        public ElementTime getElement() {
            return this.mElement;
        }

        public int getAction() {
            return this.mAction;
        }

        public String toString() {
            return "Type = " + this.mElement + " offset = " + getOffsetTime() + " action = " + getAction();
        }
    }

    private void dumpAllEntries() {
    }
}
