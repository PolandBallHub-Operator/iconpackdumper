package com.android.mms.dom.smil;

import com.android.mms.layout.LayoutManager;
import org.w3c.dom.NodeList;
import org.w3c.dom.smil.SMILLayoutElement;
import org.w3c.dom.smil.SMILRootLayoutElement;

/* JADX INFO: loaded from: classes.dex */
public class SmilLayoutElementImpl extends SmilElementImpl implements SMILLayoutElement {
    SmilLayoutElementImpl(SmilDocumentImpl owner, String tagName) {
        super(owner, tagName);
    }

    @Override // org.w3c.dom.smil.SMILLayoutElement
    public boolean getResolved() {
        return false;
    }

    @Override // org.w3c.dom.smil.SMILLayoutElement
    public String getType() {
        return getAttribute("type");
    }

    @Override // org.w3c.dom.smil.SMILLayoutElement
    public NodeList getRegions() {
        return getElementsByTagName("region");
    }

    @Override // org.w3c.dom.smil.SMILLayoutElement
    public SMILRootLayoutElement getRootLayout() {
        NodeList childNodes = getChildNodes();
        SMILRootLayoutElement rootLayoutNode = null;
        int childrenCount = childNodes.getLength();
        for (int i = 0; i < childrenCount; i++) {
            if (childNodes.item(i).getNodeName().equals("root-layout")) {
                rootLayoutNode = (SMILRootLayoutElement) childNodes.item(i);
            }
        }
        if (rootLayoutNode == null) {
            SMILRootLayoutElement rootLayoutNode2 = (SMILRootLayoutElement) getOwnerDocument().createElement("root-layout");
            rootLayoutNode2.setWidth(LayoutManager.getInstance().getLayoutParameters().getWidth());
            rootLayoutNode2.setHeight(LayoutManager.getInstance().getLayoutParameters().getHeight());
            appendChild(rootLayoutNode2);
            return rootLayoutNode2;
        }
        return rootLayoutNode;
    }
}
