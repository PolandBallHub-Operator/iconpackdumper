package com.android.mms.dom.smil;

import android.util.Log;
import com.android.mms.dom.events.EventImpl;
import com.android.mms.model.SmilHelper;
import com.android.mms.ui.MainMenuActivity;
import org.w3c.dom.DOMException;
import org.w3c.dom.events.DocumentEvent;
import org.w3c.dom.events.Event;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.SMILMediaElement;
import org.w3c.dom.smil.TimeList;

/* JADX INFO: loaded from: classes.dex */
public class SmilMediaElementImpl extends SmilElementImpl implements SMILMediaElement {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    public static final String SMIL_MEDIA_END_EVENT = "SmilMediaEnd";
    public static final String SMIL_MEDIA_PAUSE_EVENT = "SmilMediaPause";
    public static final String SMIL_MEDIA_SEEK_EVENT = "SmilMediaSeek";
    public static final String SMIL_MEDIA_START_EVENT = "SmilMediaStart";
    private static final String TAG = "Mms";
    ElementTime mElementTime;

    SmilMediaElementImpl(SmilDocumentImpl owner, String tagName) {
        super(owner, tagName);
        this.mElementTime = new ElementTimeImpl(this) { // from class: com.android.mms.dom.smil.SmilMediaElementImpl.1
            private Event createEvent(String eventType) {
                DocumentEvent doc = (DocumentEvent) SmilMediaElementImpl.this.getOwnerDocument();
                Event event = doc.createEvent("Event");
                event.initEvent(eventType, false, false);
                return event;
            }

            private Event createEvent(String eventType, int seekTo) {
                DocumentEvent doc = (DocumentEvent) SmilMediaElementImpl.this.getOwnerDocument();
                EventImpl event = (EventImpl) doc.createEvent("Event");
                event.initEvent(eventType, false, false, seekTo);
                return event;
            }

            @Override // org.w3c.dom.smil.ElementTime
            public boolean beginElement() {
                Event startEvent = createEvent(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT);
                SmilMediaElementImpl.this.dispatchEvent(startEvent);
                return true;
            }

            @Override // org.w3c.dom.smil.ElementTime
            public boolean endElement() {
                Event endEvent = createEvent(SmilMediaElementImpl.SMIL_MEDIA_END_EVENT);
                SmilMediaElementImpl.this.dispatchEvent(endEvent);
                return true;
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void resumeElement() {
                Event resumeEvent = createEvent(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT);
                SmilMediaElementImpl.this.dispatchEvent(resumeEvent);
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void pauseElement() {
                Event pauseEvent = createEvent(SmilMediaElementImpl.SMIL_MEDIA_PAUSE_EVENT);
                SmilMediaElementImpl.this.dispatchEvent(pauseEvent);
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void seekElement(float seekTo) {
                Event seekEvent = createEvent(SmilMediaElementImpl.SMIL_MEDIA_SEEK_EVENT, (int) seekTo);
                SmilMediaElementImpl.this.dispatchEvent(seekEvent);
            }

            @Override // com.android.mms.dom.smil.ElementTimeImpl, org.w3c.dom.smil.ElementTime
            public float getDur() {
                float dur = super.getDur();
                if (dur == 0.0f) {
                    String tag = SmilMediaElementImpl.this.getTagName();
                    if (tag.equals(SmilHelper.ELEMENT_TAG_VIDEO) || tag.equals(SmilHelper.ELEMENT_TAG_AUDIO)) {
                        return -1.0f;
                    }
                    if (tag.equals(SmilHelper.ELEMENT_TAG_TEXT) || tag.equals(SmilHelper.ELEMENT_TAG_IMAGE)) {
                        return 0.0f;
                    }
                    Log.w("Mms", "Unknown media type");
                    return dur;
                }
                return dur;
            }

            @Override // com.android.mms.dom.smil.ElementTimeImpl
            ElementTime getParentElementTime() {
                return ((SmilParElementImpl) this.mSmilElement.getParentNode()).mParTimeContainer;
            }
        };
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getAbstractAttr() {
        return getAttribute("abstract");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getAlt() {
        return getAttribute("alt");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getAuthor() {
        return getAttribute("author");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getClipBegin() {
        return getAttribute("clipBegin");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getClipEnd() {
        return getAttribute("clipEnd");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getCopyright() {
        return getAttribute("copyright");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getLongdesc() {
        return getAttribute("longdesc");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getPort() {
        return getAttribute("port");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getReadIndex() {
        return getAttribute("readIndex");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getRtpformat() {
        return getAttribute("rtpformat");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getSrc() {
        return getAttribute("src");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getStripRepeat() {
        return getAttribute("stripRepeat");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getTitle() {
        return getAttribute(MainMenuActivity.FOLDER_LIST_DATA_TITLE);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getTransport() {
        return getAttribute("transport");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public String getType() {
        return getAttribute("type");
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setAbstractAttr(String abstractAttr) throws DOMException {
        setAttribute("abstract", abstractAttr);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setAlt(String alt) throws DOMException {
        setAttribute("alt", alt);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setAuthor(String author) throws DOMException {
        setAttribute("author", author);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setClipBegin(String clipBegin) throws DOMException {
        setAttribute("clipBegin", clipBegin);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setClipEnd(String clipEnd) throws DOMException {
        setAttribute("clipEnd", clipEnd);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setCopyright(String copyright) throws DOMException {
        setAttribute("copyright", copyright);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setLongdesc(String longdesc) throws DOMException {
        setAttribute("longdesc", longdesc);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setPort(String port) throws DOMException {
        setAttribute("port", port);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setReadIndex(String readIndex) throws DOMException {
        setAttribute("readIndex", readIndex);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setRtpformat(String rtpformat) throws DOMException {
        setAttribute("rtpformat", rtpformat);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setSrc(String src) throws DOMException {
        setAttribute("src", src);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setStripRepeat(String stripRepeat) throws DOMException {
        setAttribute("stripRepeat", stripRepeat);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setTitle(String title) throws DOMException {
        setAttribute(MainMenuActivity.FOLDER_LIST_DATA_TITLE, title);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setTransport(String transport) throws DOMException {
        setAttribute("transport", transport);
    }

    @Override // org.w3c.dom.smil.SMILMediaElement
    public void setType(String type) throws DOMException {
        setAttribute("type", type);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public boolean beginElement() {
        return this.mElementTime.beginElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public boolean endElement() {
        return this.mElementTime.endElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public TimeList getBegin() {
        return this.mElementTime.getBegin();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getDur() {
        return this.mElementTime.getDur();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public TimeList getEnd() {
        return this.mElementTime.getEnd();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getFill() {
        return this.mElementTime.getFill();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getFillDefault() {
        return this.mElementTime.getFillDefault();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getRepeatCount() {
        return this.mElementTime.getRepeatCount();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getRepeatDur() {
        return this.mElementTime.getRepeatDur();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getRestart() {
        return this.mElementTime.getRestart();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void pauseElement() {
        this.mElementTime.pauseElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void resumeElement() {
        this.mElementTime.resumeElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void seekElement(float seekTo) {
        this.mElementTime.seekElement(seekTo);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setBegin(TimeList begin) throws DOMException {
        this.mElementTime.setBegin(begin);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setDur(float dur) throws DOMException {
        this.mElementTime.setDur(dur);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setEnd(TimeList end) throws DOMException {
        this.mElementTime.setEnd(end);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setFill(short fill) throws DOMException {
        this.mElementTime.setFill(fill);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setFillDefault(short fillDefault) throws DOMException {
        this.mElementTime.setFillDefault(fillDefault);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRepeatCount(float repeatCount) throws DOMException {
        this.mElementTime.setRepeatCount(repeatCount);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRepeatDur(float repeatDur) throws DOMException {
        this.mElementTime.setRepeatDur(repeatDur);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRestart(short restart) throws DOMException {
        this.mElementTime.setRestart(restart);
    }
}
