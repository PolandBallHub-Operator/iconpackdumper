package com.android.mms.dom.smil;

import com.android.mms.dom.DocumentImpl;
import com.android.mms.dom.events.EventImpl;
import com.android.mms.model.SmilHelper;
import com.nextfp.android.util.NfpSharedResources;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.events.DocumentEvent;
import org.w3c.dom.events.Event;
import org.w3c.dom.smil.ElementSequentialTimeContainer;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.SMILLayoutElement;
import org.w3c.dom.smil.TimeList;

/* JADX INFO: loaded from: classes.dex */
public class SmilDocumentImpl extends DocumentImpl implements SMILDocument, DocumentEvent {
    public static final String SMIL_DOCUMENT_END_EVENT = "SimlDocumentEnd";
    public static final String SMIL_DOCUMENT_START_EVENT = "SmilDocumentStart";
    ElementSequentialTimeContainer mSeqTimeContainer;

    @Override // org.w3c.dom.smil.ElementTimeContainer
    public NodeList getActiveChildrenAt(float instant) {
        return this.mSeqTimeContainer.getActiveChildrenAt(instant);
    }

    @Override // org.w3c.dom.smil.ElementTimeContainer
    public NodeList getTimeChildren() {
        return this.mSeqTimeContainer.getTimeChildren();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public boolean beginElement() {
        return this.mSeqTimeContainer.beginElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public boolean endElement() {
        return this.mSeqTimeContainer.endElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public TimeList getBegin() {
        return this.mSeqTimeContainer.getBegin();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getDur() {
        return this.mSeqTimeContainer.getDur();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public TimeList getEnd() {
        return this.mSeqTimeContainer.getEnd();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getFill() {
        return this.mSeqTimeContainer.getFill();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getFillDefault() {
        return this.mSeqTimeContainer.getFillDefault();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getRepeatCount() {
        return this.mSeqTimeContainer.getRepeatCount();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public float getRepeatDur() {
        return this.mSeqTimeContainer.getRepeatDur();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public short getRestart() {
        return this.mSeqTimeContainer.getRestart();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void pauseElement() {
        this.mSeqTimeContainer.pauseElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void resumeElement() {
        this.mSeqTimeContainer.resumeElement();
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void seekElement(float seekTo) {
        this.mSeqTimeContainer.seekElement(seekTo);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setBegin(TimeList begin) throws DOMException {
        this.mSeqTimeContainer.setBegin(begin);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setDur(float dur) throws DOMException {
        this.mSeqTimeContainer.setDur(dur);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setEnd(TimeList end) throws DOMException {
        this.mSeqTimeContainer.setEnd(end);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setFill(short fill) throws DOMException {
        this.mSeqTimeContainer.setFill(fill);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setFillDefault(short fillDefault) throws DOMException {
        this.mSeqTimeContainer.setFillDefault(fillDefault);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRepeatCount(float repeatCount) throws DOMException {
        this.mSeqTimeContainer.setRepeatCount(repeatCount);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRepeatDur(float repeatDur) throws DOMException {
        this.mSeqTimeContainer.setRepeatDur(repeatDur);
    }

    @Override // org.w3c.dom.smil.ElementTime
    public void setRestart(short restart) throws DOMException {
        this.mSeqTimeContainer.setRestart(restart);
    }

    @Override // com.android.mms.dom.DocumentImpl, org.w3c.dom.Document
    public Element createElement(String tagName) throws DOMException {
        String tagName2 = tagName.toLowerCase();
        if (tagName2.equals(SmilHelper.ELEMENT_TAG_TEXT) || tagName2.equals(SmilHelper.ELEMENT_TAG_IMAGE) || tagName2.equals(SmilHelper.ELEMENT_TAG_VIDEO)) {
            return new SmilRegionMediaElementImpl(this, tagName2);
        }
        if (tagName2.equals(SmilHelper.ELEMENT_TAG_AUDIO)) {
            return new SmilMediaElementImpl(this, tagName2);
        }
        if (tagName2.equals(NfpSharedResources.DEFTYPE_LAYOUT)) {
            return new SmilLayoutElementImpl(this, tagName2);
        }
        if (tagName2.equals("root-layout")) {
            return new SmilRootLayoutElementImpl(this, tagName2);
        }
        if (tagName2.equals("region")) {
            return new SmilRegionElementImpl(this, tagName2);
        }
        if (tagName2.equals(SmilHelper.ELEMENT_TAG_REF)) {
            return new SmilRefElementImpl(this, tagName2);
        }
        if (tagName2.equals("par")) {
            return new SmilParElementImpl(this, tagName2);
        }
        return new SmilElementImpl(this, tagName2);
    }

    @Override // com.android.mms.dom.DocumentImpl, org.w3c.dom.Document
    public SMILElement getDocumentElement() {
        Node rootElement = getFirstChild();
        if (rootElement == null || !(rootElement instanceof SMILElement)) {
            rootElement = createElement("smil");
            appendChild(rootElement);
        }
        return (SMILElement) rootElement;
    }

    @Override // org.w3c.dom.smil.SMILDocument
    public SMILElement getHead() {
        Node rootElement = getDocumentElement();
        Node headElement = rootElement.getFirstChild();
        if (headElement == null || !(headElement instanceof SMILElement)) {
            headElement = createElement("head");
            rootElement.appendChild(headElement);
        }
        return (SMILElement) headElement;
    }

    @Override // org.w3c.dom.smil.SMILDocument
    public SMILElement getBody() {
        Node rootElement = getDocumentElement();
        Node headElement = getHead();
        Node bodyElement = headElement.getNextSibling();
        if (bodyElement == null || !(bodyElement instanceof SMILElement)) {
            bodyElement = createElement("body");
            rootElement.appendChild(bodyElement);
        }
        this.mSeqTimeContainer = new ElementSequentialTimeContainerImpl((SMILElement) bodyElement) { // from class: com.android.mms.dom.smil.SmilDocumentImpl.1
            @Override // org.w3c.dom.smil.ElementTimeContainer
            public NodeList getTimeChildren() {
                return SmilDocumentImpl.this.getBody().getElementsByTagName("par");
            }

            @Override // org.w3c.dom.smil.ElementTime
            public boolean beginElement() {
                Event startEvent = SmilDocumentImpl.this.createEvent("Event");
                startEvent.initEvent(SmilDocumentImpl.SMIL_DOCUMENT_START_EVENT, false, false);
                SmilDocumentImpl.this.dispatchEvent(startEvent);
                return true;
            }

            @Override // org.w3c.dom.smil.ElementTime
            public boolean endElement() {
                Event endEvent = SmilDocumentImpl.this.createEvent("Event");
                endEvent.initEvent(SmilDocumentImpl.SMIL_DOCUMENT_END_EVENT, false, false);
                SmilDocumentImpl.this.dispatchEvent(endEvent);
                return true;
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void pauseElement() {
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void resumeElement() {
            }

            @Override // org.w3c.dom.smil.ElementTime
            public void seekElement(float seekTo) {
            }

            @Override // com.android.mms.dom.smil.ElementTimeImpl
            ElementTime getParentElementTime() {
                return null;
            }
        };
        return (SMILElement) bodyElement;
    }

    @Override // org.w3c.dom.smil.SMILDocument
    public SMILLayoutElement getLayout() {
        Node headElement = getHead();
        Node layoutElement = headElement.getFirstChild();
        while (layoutElement != null && !(layoutElement instanceof SMILLayoutElement)) {
            layoutElement = layoutElement.getNextSibling();
        }
        if (layoutElement == null) {
            layoutElement = new SmilLayoutElementImpl(this, NfpSharedResources.DEFTYPE_LAYOUT);
            headElement.appendChild(layoutElement);
        }
        return (SMILLayoutElement) layoutElement;
    }

    @Override // org.w3c.dom.events.DocumentEvent
    public Event createEvent(String eventType) throws DOMException {
        if ("Event".equals(eventType)) {
            return new EventImpl();
        }
        throw new DOMException((short) 9, "Not supported interface");
    }
}
