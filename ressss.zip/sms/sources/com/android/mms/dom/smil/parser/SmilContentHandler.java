package com.android.mms.dom.smil.parser;

import com.android.mms.dom.smil.SmilDocumentImpl;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.smil.SMILDocument;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

/* JADX INFO: loaded from: classes.dex */
public class SmilContentHandler extends DefaultHandler {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private Node mCurrentNode;
    private SMILDocument mSmilDocument;

    public void reset() {
        this.mSmilDocument = new SmilDocumentImpl();
        this.mCurrentNode = this.mSmilDocument;
    }

    public SMILDocument getSmilDocument() {
        return this.mSmilDocument;
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        Element element = this.mSmilDocument.createElement(localName);
        if (attributes != null) {
            for (int i = 0; i < attributes.getLength(); i++) {
                element.setAttribute(attributes.getLocalName(i), attributes.getValue(i));
            }
        }
        this.mCurrentNode.appendChild(element);
        this.mCurrentNode = element;
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void endElement(String uri, String localName, String qName) {
        this.mCurrentNode = this.mCurrentNode.getParentNode();
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void characters(char[] ch, int start, int length) {
    }
}
