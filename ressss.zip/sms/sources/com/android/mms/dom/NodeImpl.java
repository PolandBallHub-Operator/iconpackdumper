package com.android.mms.dom;

import com.android.mms.dom.events.EventTargetImpl;
import java.util.NoSuchElementException;
import java.util.Vector;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.UserDataHandler;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventException;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.events.EventTarget;

/* JADX INFO: loaded from: classes.dex */
public abstract class NodeImpl implements Node, EventTarget {
    private final Vector<Node> mChildNodes = new Vector<>();
    private final EventTarget mEventTarget = new EventTargetImpl(this);
    DocumentImpl mOwnerDocument;
    private Node mParentNode;

    @Override // org.w3c.dom.Node
    public abstract String getNodeName();

    @Override // org.w3c.dom.Node
    public abstract short getNodeType();

    protected NodeImpl(DocumentImpl owner) {
        this.mOwnerDocument = owner;
    }

    @Override // org.w3c.dom.Node
    public Node appendChild(Node newChild) throws DOMException {
        ((NodeImpl) newChild).setParentNode(this);
        this.mChildNodes.remove(newChild);
        this.mChildNodes.add(newChild);
        return newChild;
    }

    @Override // org.w3c.dom.Node
    public Node cloneNode(boolean deep) {
        return null;
    }

    @Override // org.w3c.dom.Node
    public NamedNodeMap getAttributes() {
        return null;
    }

    @Override // org.w3c.dom.Node
    public NodeList getChildNodes() {
        return new NodeListImpl(this, null, false);
    }

    @Override // org.w3c.dom.Node
    public Node getFirstChild() {
        try {
            Node firstChild = this.mChildNodes.firstElement();
            return firstChild;
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    @Override // org.w3c.dom.Node
    public Node getLastChild() {
        try {
            Node lastChild = this.mChildNodes.lastElement();
            return lastChild;
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    @Override // org.w3c.dom.Node
    public String getLocalName() {
        return null;
    }

    @Override // org.w3c.dom.Node
    public String getNamespaceURI() {
        return null;
    }

    @Override // org.w3c.dom.Node
    public Node getNextSibling() {
        if (this.mParentNode == null || this == this.mParentNode.getLastChild()) {
            return null;
        }
        Vector<Node> siblings = ((NodeImpl) this.mParentNode).mChildNodes;
        int indexOfThis = siblings.indexOf(this);
        return siblings.elementAt(indexOfThis + 1);
    }

    @Override // org.w3c.dom.Node
    public String getNodeValue() throws DOMException {
        return null;
    }

    @Override // org.w3c.dom.Node
    public Document getOwnerDocument() {
        return this.mOwnerDocument;
    }

    @Override // org.w3c.dom.Node
    public Node getParentNode() {
        return this.mParentNode;
    }

    @Override // org.w3c.dom.Node
    public String getPrefix() {
        return null;
    }

    @Override // org.w3c.dom.Node
    public Node getPreviousSibling() {
        if (this.mParentNode == null || this == this.mParentNode.getFirstChild()) {
            return null;
        }
        Vector<Node> siblings = ((NodeImpl) this.mParentNode).mChildNodes;
        int indexOfThis = siblings.indexOf(this);
        return siblings.elementAt(indexOfThis - 1);
    }

    @Override // org.w3c.dom.Node
    public boolean hasAttributes() {
        return false;
    }

    @Override // org.w3c.dom.Node
    public boolean hasChildNodes() {
        return !this.mChildNodes.isEmpty();
    }

    @Override // org.w3c.dom.Node
    public Node insertBefore(Node newChild, Node refChild) throws DOMException {
        return null;
    }

    @Override // org.w3c.dom.Node
    public boolean isSupported(String feature, String version) {
        return false;
    }

    @Override // org.w3c.dom.Node
    public void normalize() {
    }

    @Override // org.w3c.dom.Node
    public Node removeChild(Node oldChild) throws DOMException {
        if (this.mChildNodes.contains(oldChild)) {
            this.mChildNodes.remove(oldChild);
            ((NodeImpl) oldChild).setParentNode(null);
            return null;
        }
        throw new DOMException((short) 8, "Child does not exist");
    }

    @Override // org.w3c.dom.Node
    public Node replaceChild(Node newChild, Node oldChild) throws DOMException {
        if (this.mChildNodes.contains(oldChild)) {
            try {
                this.mChildNodes.remove(newChild);
            } catch (DOMException e) {
            }
            this.mChildNodes.setElementAt(newChild, this.mChildNodes.indexOf(oldChild));
            ((NodeImpl) newChild).setParentNode(this);
            ((NodeImpl) oldChild).setParentNode(null);
            return oldChild;
        }
        throw new DOMException((short) 8, "Old child does not exist");
    }

    @Override // org.w3c.dom.Node
    public void setNodeValue(String nodeValue) throws DOMException {
    }

    @Override // org.w3c.dom.Node
    public void setPrefix(String prefix) throws DOMException {
    }

    private void setParentNode(Node parentNode) {
        this.mParentNode = parentNode;
    }

    @Override // org.w3c.dom.events.EventTarget
    public void addEventListener(String type, EventListener listener, boolean useCapture) {
        this.mEventTarget.addEventListener(type, listener, useCapture);
    }

    @Override // org.w3c.dom.events.EventTarget
    public void removeEventListener(String type, EventListener listener, boolean useCapture) {
        this.mEventTarget.removeEventListener(type, listener, useCapture);
    }

    @Override // org.w3c.dom.events.EventTarget
    public boolean dispatchEvent(Event evt) throws EventException {
        return this.mEventTarget.dispatchEvent(evt);
    }

    @Override // org.w3c.dom.Node
    public String getBaseURI() {
        return null;
    }

    @Override // org.w3c.dom.Node
    public short compareDocumentPosition(Node other) throws DOMException {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Node
    public String getTextContent() throws DOMException {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Node
    public void setTextContent(String textContent) throws DOMException {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Node
    public boolean isSameNode(Node other) {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Node
    public String lookupPrefix(String namespaceURI) {
        return null;
    }

    @Override // org.w3c.dom.Node
    public boolean isDefaultNamespace(String namespaceURI) {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Node
    public String lookupNamespaceURI(String prefix) {
        return null;
    }

    @Override // org.w3c.dom.Node
    public boolean isEqualNode(Node arg) {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Node
    public Object getFeature(String feature, String version) {
        return null;
    }

    @Override // org.w3c.dom.Node
    public Object setUserData(String key, Object data, UserDataHandler handler) {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Node
    public Object getUserData(String key) {
        return null;
    }
}
