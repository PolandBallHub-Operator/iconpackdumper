package com.android.mms.dom;

import com.android.common.speech.LoggingEvents;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.TypeInfo;

/* JADX INFO: loaded from: classes.dex */
public class ElementImpl extends NodeImpl implements Element {
    private NamedNodeMap mAttributes;
    private String mTagName;

    protected ElementImpl(DocumentImpl owner, String tagName) {
        super(owner);
        this.mAttributes = new NamedNodeMapImpl();
        this.mTagName = tagName;
    }

    @Override // org.w3c.dom.Element
    public String getAttribute(String name) {
        Attr attrNode = getAttributeNode(name);
        if (attrNode == null) {
            return LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        String attrValue = attrNode.getValue();
        return attrValue;
    }

    @Override // org.w3c.dom.Element
    public String getAttributeNS(String namespaceURI, String localName) {
        return null;
    }

    @Override // org.w3c.dom.Element
    public Attr getAttributeNode(String name) {
        return (Attr) this.mAttributes.getNamedItem(name);
    }

    @Override // org.w3c.dom.Element
    public Attr getAttributeNodeNS(String namespaceURI, String localName) {
        return null;
    }

    @Override // org.w3c.dom.Element
    public NodeList getElementsByTagName(String name) {
        return new NodeListImpl(this, name, true);
    }

    @Override // org.w3c.dom.Element
    public NodeList getElementsByTagNameNS(String namespaceURI, String localName) {
        return null;
    }

    @Override // org.w3c.dom.Element
    public String getTagName() {
        return this.mTagName;
    }

    @Override // org.w3c.dom.Element
    public boolean hasAttribute(String name) {
        return getAttributeNode(name) != null;
    }

    @Override // org.w3c.dom.Element
    public boolean hasAttributeNS(String namespaceURI, String localName) {
        return false;
    }

    @Override // org.w3c.dom.Element
    public void removeAttribute(String name) throws DOMException {
    }

    @Override // org.w3c.dom.Element
    public void removeAttributeNS(String namespaceURI, String localName) throws DOMException {
    }

    @Override // org.w3c.dom.Element
    public Attr removeAttributeNode(Attr oldAttr) throws DOMException {
        return null;
    }

    @Override // org.w3c.dom.Element
    public void setAttribute(String name, String value) throws DOMException {
        Attr attribute = getAttributeNode(name);
        if (attribute == null) {
            attribute = this.mOwnerDocument.createAttribute(name);
        }
        attribute.setNodeValue(value);
        this.mAttributes.setNamedItem(attribute);
    }

    @Override // org.w3c.dom.Element
    public void setAttributeNS(String namespaceURI, String qualifiedName, String value) throws DOMException {
    }

    @Override // org.w3c.dom.Element
    public Attr setAttributeNode(Attr newAttr) throws DOMException {
        return null;
    }

    @Override // org.w3c.dom.Element
    public Attr setAttributeNodeNS(Attr newAttr) throws DOMException {
        return null;
    }

    @Override // com.android.mms.dom.NodeImpl, org.w3c.dom.Node
    public short getNodeType() {
        return (short) 1;
    }

    @Override // com.android.mms.dom.NodeImpl, org.w3c.dom.Node
    public String getNodeName() {
        return this.mTagName;
    }

    @Override // com.android.mms.dom.NodeImpl, org.w3c.dom.Node
    public NamedNodeMap getAttributes() {
        return this.mAttributes;
    }

    @Override // com.android.mms.dom.NodeImpl, org.w3c.dom.Node
    public boolean hasAttributes() {
        return this.mAttributes.getLength() > 0;
    }

    @Override // org.w3c.dom.Element
    public TypeInfo getSchemaTypeInfo() {
        return null;
    }

    @Override // org.w3c.dom.Element
    public void setIdAttribute(String name, boolean isId) throws DOMException {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Element
    public void setIdAttributeNS(String namespaceURI, String localName, boolean isId) throws DOMException {
        throw new DOMException((short) 9, null);
    }

    @Override // org.w3c.dom.Element
    public void setIdAttributeNode(Attr idAttr, boolean isId) throws DOMException {
        throw new DOMException((short) 9, null);
    }
}
