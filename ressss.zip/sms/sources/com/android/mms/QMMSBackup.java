package com.android.mms;

import java.io.Serializable;
import java.util.ArrayList;

/* JADX INFO: compiled from: QTIBackupMMS.java */
/* JADX INFO: loaded from: classes.dex */
class QMMSBackup implements Serializable {
    public ArrayList<QTIMMSObject> MMSList = new ArrayList<>();
}
