package com.android.mms;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.drm.DrmManagerClient;
import android.location.Country;
import android.location.CountryDetector;
import android.location.CountryListener;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.provider.SearchRecentSuggestions;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.android.mms.data.Contact;
import com.android.mms.data.Conversation;
import com.android.mms.layout.LayoutManager;
import com.android.mms.transaction.MessagingNotification;
import com.android.mms.transaction.MmsSystemEventReceiver;
import com.android.mms.transaction.SmsReceiver;
import com.android.mms.transaction.SmsReceiverService;
import com.android.mms.util.DownloadManager;
import com.android.mms.util.DraftCache;
import com.android.mms.util.PduLoaderManager;
import com.android.mms.util.RateController;
import com.android.mms.util.ThumbnailManager;

/* JADX INFO: loaded from: classes.dex */
public class MmsApp extends Application {
    private static final int DELAY_TIME = 30000;
    public static final String LOG_TAG = "Mms";
    private static final int SEND_FLAG = 1;
    private static MmsApp sMmsApp = null;
    public static boolean smsFlag = false;
    Handler handler = new Handler(new Handler.Callback() { // from class: com.android.mms.MmsApp.3
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    MmsApp.this.sendBroadcast(new Intent(SmsReceiverService.ACTION_SEND_INACTIVE_MESSAGE, null, MmsApp.this, SmsReceiver.class));
                    break;
            }
            return false;
        }
    });
    private CountryDetector mCountryDetector;
    private String mCountryIso;
    private CountryListener mCountryListener;
    private DrmManagerClient mDrmManagerClient;
    private PduLoaderManager mPduLoaderManager;
    private SearchRecentSuggestions mRecentSuggestions;
    private TelephonyManager mTelephonyManager;
    private ThumbnailManager mThumbnailManager;

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        if (Log.isLoggable("Mms", 3)) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build());
        }
        sMmsApp = this;
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);
        this.mCountryDetector = (CountryDetector) getSystemService("country_detector");
        this.mCountryListener = new CountryListener() { // from class: com.android.mms.MmsApp.1
            public synchronized void onCountryDetected(Country country) {
                MmsApp.this.mCountryIso = country.getCountryIso();
            }
        };
        this.mCountryDetector.addCountryListener(this.mCountryListener, getMainLooper());
        Context context = getApplicationContext();
        this.mPduLoaderManager = new PduLoaderManager(context);
        this.mThumbnailManager = new ThumbnailManager(context);
        MmsConfig.init(this);
        Contact.init(this);
        DraftCache.init(this);
        Conversation.init(this);
        DownloadManager.init(this);
        RateController.init(this);
        LayoutManager.init(this);
        MessagingNotification.init(this);
        activePendingMessages();
        registerMobileDataObserver();
    }

    private void registerMobileDataObserver() {
        int phoneCount = TelephonyManager.getDefault().getPhoneCount();
        for (int i = 0; i < phoneCount; i++) {
            Uri uri = Settings.Global.getUriFor("mobile_data" + i);
            getContentResolver().registerContentObserver(uri, false, new ContentObserver(null) { // from class: com.android.mms.MmsApp.2
                @Override // android.database.ContentObserver
                public void onChange(boolean selfChange, Uri uri2) {
                    Log.d("Mms", "MobileData UI changed = " + uri2);
                    String uriLastSegment = uri2.getLastPathSegment();
                    int uriLength = uriLastSegment.length();
                    int phoneId = Character.getNumericValue(uriLastSegment.charAt(uriLength - 1));
                    try {
                        int value = Settings.Global.getInt(MmsApp.this.getContentResolver(), "mobile_data" + phoneId);
                        Log.d("Mms", "value = " + value);
                        if (value == 1) {
                            if (Log.isLoggable("Mms", 2)) {
                                Log.d("Mms", "MobileData turned ON, trigger pending mms processing");
                            }
                            MmsApp.this.activePendingMessages();
                        }
                    } catch (Settings.SettingNotFoundException e) {
                        Log.e("Mms", "Exception in getting MobileData UI value. e = " + e);
                    }
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void activePendingMessages() {
        MmsSystemEventReceiver.wakeUpService(this);
        new Thread(new Runnable() { // from class: com.android.mms.MmsApp.4
            @Override // java.lang.Runnable
            public void run() {
                try {
                    Thread.sleep(30000L);
                } catch (Exception e) {
                }
                MmsApp.this.handler.sendEmptyMessage(1);
            }
        }).start();
    }

    public static synchronized MmsApp getApplication() {
        return sMmsApp;
    }

    @Override // android.app.Application
    public void onTerminate() {
        this.mCountryDetector.removeCountryListener(this.mCountryListener);
    }

    @Override // android.app.Application, android.content.ComponentCallbacks
    public void onLowMemory() {
        super.onLowMemory();
        this.mPduLoaderManager.onLowMemory();
        this.mThumbnailManager.onLowMemory();
    }

    public PduLoaderManager getPduLoaderManager() {
        return this.mPduLoaderManager;
    }

    public ThumbnailManager getThumbnailManager() {
        return this.mThumbnailManager;
    }

    @Override // android.app.Application, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        LayoutManager.getInstance().onConfigurationChanged(newConfig);
    }

    public TelephonyManager getTelephonyManager() {
        if (this.mTelephonyManager == null) {
            this.mTelephonyManager = (TelephonyManager) getApplicationContext().getSystemService("phone");
        }
        return this.mTelephonyManager;
    }

    public SearchRecentSuggestions getRecentSuggestions() {
        return this.mRecentSuggestions;
    }

    public String getCurrentCountryIso() {
        Country country;
        if (this.mCountryIso == null && (country = this.mCountryDetector.detectCountry()) != null) {
            this.mCountryIso = country.getCountryIso();
        }
        return this.mCountryIso;
    }

    public DrmManagerClient getDrmManagerClient() {
        if (this.mDrmManagerClient == null) {
            this.mDrmManagerClient = new DrmManagerClient(getApplicationContext());
        }
        return this.mDrmManagerClient;
    }
}
