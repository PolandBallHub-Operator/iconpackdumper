package com.android.mms;

import android.app.backup.BackupAgentHelper;
import android.app.backup.FullBackupDataOutput;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public class QTIBackupAgent extends BackupAgentHelper {
    static final String MMS = "mmsBackup";
    static final String SMS = "smsBackup";
    private static final String TAG = "QTIBackupAgent";

    @Override // android.app.backup.BackupAgent
    public void onFullBackup(FullBackupDataOutput data) throws IOException {
        QTIBackupSMS smsBackup = new QTIBackupSMS(this, SMS);
        smsBackup.performBackup();
        QTIBackupMMS mmsBackup = new QTIBackupMMS(this, MMS);
        mmsBackup.performBackup();
        super.onFullBackup(data);
    }

    @Override // android.app.backup.BackupAgent
    public void onRestoreFile(ParcelFileDescriptor data, long size, File destination, int type, long mode, long mtime) throws IOException {
        super.onRestoreFile(data, size, destination, type, mode, mtime);
        if (destination.getName().equalsIgnoreCase(MMS)) {
            QTIBackupMMS mmsBackup = new QTIBackupMMS(this, MMS);
            mmsBackup.performRestore();
        }
        if (destination.getName().equalsIgnoreCase(SMS)) {
            QTIBackupSMS smsBackup = new QTIBackupSMS(this, SMS);
            smsBackup.performRestore();
        }
    }
}
