package com.android.mms;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import com.android.mms.data.Contact;
import com.android.mms.data.Conversation;
import com.android.mms.data.RecipientIdCache;

/* JADX INFO: loaded from: classes.dex */
public class LogTag {
    public static final boolean ALLOW_DUMP_IN_LOGS = false;
    public static final String APP = "Mms";
    public static final String CONTACT = "Mms";
    public static final boolean DEBUG_DUMP = false;
    public static final boolean DEBUG_SEND = false;
    public static final String PDU_CACHE = "Mms";
    public static final boolean SEVERE_WARNING = true;
    private static final boolean SHOW_SEVERE_WARNING_DIALOG = false;
    public static final String STRICT_MODE_TAG = "Mms";
    public static final String TAG = "Mms";
    public static final String THREAD_CACHE = "Mms";
    public static final String THUMBNAIL_CACHE = "Mms";
    public static final String TRANSACTION = "Mms";
    public static final boolean VERBOSE = false;
    public static final String WIDGET = "Mms";

    private static String prettyArray(String[] array) {
        if (array.length == 0) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        int len = array.length - 1;
        for (int i = 0; i < len; i++) {
            sb.append(array[i]);
            sb.append(", ");
        }
        sb.append(array[len]);
        sb.append("]");
        return sb.toString();
    }

    private static String logFormat(String format, Object... args) {
        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof String[]) {
                args[i] = prettyArray((String[]) args[i]);
            }
        }
        String s = String.format(format, args);
        return "[" + Thread.currentThread().getId() + "] " + s;
    }

    public static void debug(String format, Object... args) {
        Log.d("Mms", logFormat(format, args));
    }

    public static void warn(String format, Object... args) {
        Log.w("Mms", logFormat(format, args));
    }

    public static void error(String format, Object... args) {
        Log.e("Mms", logFormat(format, args));
    }

    public static void dumpInternalTables(Context context) {
    }

    /* JADX INFO: renamed from: com.android.mms.LogTag$1, reason: invalid class name */
    static class AnonymousClass1 implements Runnable {
        final /* synthetic */ Context val$context;

        AnonymousClass1(Context context) {
            this.val$context = context;
        }

        @Override // java.lang.Runnable
        public void run() {
            RecipientIdCache.canonicalTableDump();
            RecipientIdCache.dump();
            Conversation.dumpThreadsTable(this.val$context);
            Conversation.dump();
            Conversation.dumpSmsTable(this.val$context);
            Contact.dump();
        }
    }

    public static void warnPossibleRecipientMismatch(String msg, Activity activity) {
        Log.e("Mms", "WARNING!!!! " + msg, new RuntimeException());
    }
}
