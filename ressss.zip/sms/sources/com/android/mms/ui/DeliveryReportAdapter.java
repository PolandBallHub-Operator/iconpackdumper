package com.android.mms.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import com.android.mms.R;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class DeliveryReportAdapter extends ArrayAdapter<DeliveryReportItem> {
    static final String LOG_TAG = "Mms";

    public DeliveryReportAdapter(Context context, List<DeliveryReportItem> items) {
        super(context, R.layout.delivery_report_list_item, R.id.recipient, items);
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int position, View view, ViewGroup viewGroup) {
        DeliveryReportListItem listItem;
        DeliveryReportItem item = getItem(position);
        if (view == null) {
            LayoutInflater factory = LayoutInflater.from(getContext());
            listItem = (DeliveryReportListItem) factory.inflate(R.layout.delivery_report_list_item, viewGroup, false);
        } else if (view instanceof DeliveryReportListItem) {
            listItem = (DeliveryReportListItem) view;
        } else {
            return view;
        }
        listItem.bind(item.recipient, item.status, item.deliveryDate);
        return listItem;
    }
}
