package com.android.mms.ui;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.mms.R;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class AudioAttachmentView extends LinearLayout implements SlideViewInterface {
    private static final String TAG = "Mms";
    private TextView mAlbumView;
    private TextView mArtistView;
    private Uri mAudioUri;
    private TextView mErrorMsgView;
    private boolean mIsPlaying;
    private MediaPlayer mMediaPlayer;
    private TextView mNameView;
    private final Resources mRes;

    public AudioAttachmentView(Context context) {
        super(context);
        this.mRes = context.getResources();
    }

    public AudioAttachmentView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mRes = context.getResources();
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        this.mNameView = (TextView) findViewById(R.id.audio_name);
        this.mAlbumView = (TextView) findViewById(R.id.album_name);
        this.mArtistView = (TextView) findViewById(R.id.artist_name);
        this.mErrorMsgView = (TextView) findViewById(R.id.audio_error_msg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onPlaybackError() {
        Log.e("Mms", "Error occurred while playing audio.");
        showErrorMessage(this.mRes.getString(R.string.cannot_play_audio));
        stopAudio();
    }

    private void cleanupMediaPlayer() {
        if (this.mMediaPlayer != null) {
            try {
                this.mMediaPlayer.stop();
                this.mMediaPlayer.release();
            } finally {
                this.mMediaPlayer = null;
            }
        }
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public synchronized void startAudio() {
        if (!this.mIsPlaying && this.mAudioUri != null) {
            this.mMediaPlayer = MediaPlayer.create(this.mContext, this.mAudioUri);
            if (this.mMediaPlayer != null) {
                this.mMediaPlayer.setAudioStreamType(3);
                this.mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.android.mms.ui.AudioAttachmentView.1
                    @Override // android.media.MediaPlayer.OnCompletionListener
                    public void onCompletion(MediaPlayer mp) {
                        AudioAttachmentView.this.stopAudio();
                    }
                });
                this.mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.android.mms.ui.AudioAttachmentView.2
                    @Override // android.media.MediaPlayer.OnErrorListener
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        AudioAttachmentView.this.onPlaybackError();
                        return true;
                    }
                });
                this.mIsPlaying = true;
                this.mMediaPlayer.start();
            }
        }
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void startVideo() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setAudio(Uri audio, String name, Map<String, ?> extras) {
        synchronized (this) {
            this.mAudioUri = audio;
        }
        this.mNameView.setText(name);
        this.mAlbumView.setText((String) extras.get("album"));
        this.mArtistView.setText((String) extras.get("artist"));
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImage(String name, Bitmap bitmap) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImageRegionFit(String fit) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImageVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setText(String name, String text) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setTextVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideo(String name, Uri video) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideoThumbnail(String name, Bitmap bitmap) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideoVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public synchronized void stopAudio() {
        try {
            cleanupMediaPlayer();
            this.mIsPlaying = false;
        } catch (Throwable th) {
            this.mIsPlaying = false;
            throw th;
        }
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void stopVideo() {
    }

    @Override // com.android.mms.ui.ViewInterface
    public void reset() {
        synchronized (this) {
            if (this.mIsPlaying) {
                stopAudio();
            }
        }
        this.mErrorMsgView.setVisibility(8);
    }

    @Override // com.android.mms.ui.ViewInterface
    public void setVisibility(boolean visible) {
    }

    private void showErrorMessage(String msg) {
        this.mErrorMsgView.setText(msg);
        this.mErrorMsgView.setVisibility(0);
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void pauseAudio() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void pauseVideo() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void seekAudio(int seekTo) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void seekVideo(int seekTo) {
    }
}
