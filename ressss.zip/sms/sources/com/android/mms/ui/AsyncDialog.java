package com.android.mms.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public class AsyncDialog {
    private final Activity mActivity;
    private ProgressDialog mProgressDialog;
    private Runnable mShowProgressDialogRunnable = new Runnable() { // from class: com.android.mms.ui.AsyncDialog.1
        @Override // java.lang.Runnable
        public void run() {
            if (AsyncDialog.this.mProgressDialog != null) {
                AsyncDialog.this.mProgressDialog.show();
            }
        }
    };
    private final Handler mHandler = new Handler();

    public AsyncDialog(Activity activity) {
        this.mActivity = activity;
    }

    public void runAsync(Runnable backgroundTask, Runnable postExecuteTask, int dialogStringId) {
        new ModalDialogAsyncTask(dialogStringId, postExecuteTask).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, backgroundTask);
    }

    public void clearPendingProgressDialog() {
        if (this.mProgressDialog != null && this.mProgressDialog.isShowing()) {
            this.mProgressDialog.dismiss();
        }
        this.mHandler.removeCallbacks(this.mShowProgressDialogRunnable);
        this.mProgressDialog = null;
    }

    private class ModalDialogAsyncTask extends AsyncTask<Runnable, Void, Void> {
        final Runnable mPostExecuteTask;

        public ModalDialogAsyncTask(int dialogStringId, Runnable postExecuteTask) {
            this.mPostExecuteTask = postExecuteTask;
            if (AsyncDialog.this.mProgressDialog == null) {
                AsyncDialog.this.mProgressDialog = createProgressDialog();
            }
            AsyncDialog.this.mProgressDialog.setMessage(AsyncDialog.this.mActivity.getText(dialogStringId));
        }

        private ProgressDialog createProgressDialog() {
            ProgressDialog dialog = new ProgressDialog(AsyncDialog.this.mActivity);
            dialog.setIndeterminate(true);
            dialog.setProgressStyle(0);
            dialog.setCanceledOnTouchOutside(false);
            dialog.setCancelable(false);
            return dialog;
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            AsyncDialog.this.mHandler.postDelayed(AsyncDialog.this.mShowProgressDialogRunnable, 500L);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Runnable... params) {
            if (params != null) {
                for (Runnable runnable : params) {
                    try {
                        runnable.run();
                    } catch (Throwable th) {
                        AsyncDialog.this.mHandler.removeCallbacks(AsyncDialog.this.mShowProgressDialogRunnable);
                        throw th;
                    }
                }
                AsyncDialog.this.mHandler.removeCallbacks(AsyncDialog.this.mShowProgressDialogRunnable);
                return null;
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Void result) {
            if (!AsyncDialog.this.mActivity.isFinishing()) {
                if (AsyncDialog.this.mProgressDialog != null && AsyncDialog.this.mProgressDialog.isShowing()) {
                    AsyncDialog.this.mProgressDialog.dismiss();
                }
                if (this.mPostExecuteTask != null) {
                    this.mPostExecuteTask.run();
                }
            }
        }
    }
}
