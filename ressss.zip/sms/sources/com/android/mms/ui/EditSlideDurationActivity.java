package com.android.mms.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.ex.editstyledtext.EditStyledText;
import com.android.mms.R;

/* JADX INFO: loaded from: classes.dex */
public class EditSlideDurationActivity extends Activity {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    public static final String SLIDE_DUR = "dur";
    public static final String SLIDE_INDEX = "slide_index";
    public static final String SLIDE_TOTAL = "slide_total";
    private static final String STATE = "state";
    private static final String TAG = "Mms";
    private int mCurSlide;
    private Button mDone;
    private EditText mDur;
    private TextView mLabel;
    private Bundle mState;
    private int mTotal;
    private final View.OnKeyListener mOnKeyListener = new View.OnKeyListener() { // from class: com.android.mms.ui.EditSlideDurationActivity.1
        @Override // android.view.View.OnKeyListener
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (event.getAction() == 0) {
                switch (keyCode) {
                    case EditStyledText.MODE_SHOW_MENU /* 23 */:
                        EditSlideDurationActivity.this.editDone();
                    default:
                        return false;
                }
            }
            return false;
        }
    };
    private final View.OnClickListener mOnDoneClickListener = new View.OnClickListener() { // from class: com.android.mms.ui.EditSlideDurationActivity.2
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            EditSlideDurationActivity.this.editDone();
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle icicle) {
        int dur;
        super.onCreate(icicle);
        requestWindowFeature(1);
        setContentView(R.layout.edit_slide_duration);
        if (icicle == null) {
            Intent intent = getIntent();
            this.mCurSlide = intent.getIntExtra("slide_index", 1);
            this.mTotal = intent.getIntExtra(SLIDE_TOTAL, 1);
            dur = intent.getIntExtra(SLIDE_DUR, 8);
        } else {
            this.mState = icicle.getBundle("state");
            this.mCurSlide = this.mState.getInt("slide_index", 1);
            this.mTotal = this.mState.getInt(SLIDE_TOTAL, 1);
            dur = this.mState.getInt(SLIDE_DUR, 8);
        }
        this.mLabel = (TextView) findViewById(R.id.label);
        this.mLabel.setText(getString(R.string.duration_selector_title) + " " + (this.mCurSlide + 1) + "/" + this.mTotal);
        this.mDur = (EditText) findViewById(R.id.text);
        this.mDur.setText(String.valueOf(dur));
        this.mDur.setOnKeyListener(this.mOnKeyListener);
        this.mDone = (Button) findViewById(R.id.done);
        this.mDone.setOnClickListener(this.mOnDoneClickListener);
    }

    @Override // android.app.Activity
    protected void onSaveInstanceState(Bundle outState) {
        int durValue;
        super.onSaveInstanceState(outState);
        this.mState = new Bundle();
        this.mState.putInt("slide_index", this.mCurSlide);
        this.mState.putInt(SLIDE_TOTAL, this.mTotal);
        try {
            durValue = Integer.parseInt(this.mDur.getText().toString());
        } catch (NumberFormatException e) {
            durValue = 5;
        }
        this.mState.putInt(SLIDE_DUR, durValue);
        outState.putBundle("state", this.mState);
    }

    protected void editDone() {
        String dur = this.mDur.getText().toString();
        try {
            int durValue = Integer.valueOf(dur).intValue();
            if (durValue <= 0) {
                notifyUser(R.string.duration_zero);
            } else {
                setResult(-1, new Intent(this.mDur.getText().toString()));
                finish();
            }
        } catch (NumberFormatException e) {
            notifyUser(R.string.duration_not_a_number);
        }
    }

    private void notifyUser(int msgId) {
        this.mDur.requestFocus();
        this.mDur.selectAll();
        Toast.makeText(this, msgId, 0).show();
    }
}
