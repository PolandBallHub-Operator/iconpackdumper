package com.android.mms.ui;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CursorAdapter;
import com.android.mms.R;
import com.android.mms.data.Conversation;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class ConversationListAdapter extends CursorAdapter implements AbsListView.RecyclerListener {
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private boolean isSelectMode;
    private int mAllUnreadMessageCount;
    private final LayoutInflater mFactory;
    private OnContentChangedListener mOnContentChangedListener;
    private HashSet<Long> mSelectedIdSet;
    private int mSelectedIndex;
    private long mSelectedThreadId;

    public interface OnContentChangedListener {
        void onContentChanged(ConversationListAdapter conversationListAdapter);
    }

    public void setSelectMode(boolean bool) {
        this.isSelectMode = bool;
    }

    public void setAllSelectedId(Set<Long> temp) {
        this.mSelectedIdSet = (HashSet) temp;
    }

    public ConversationListAdapter(Context context, Cursor cursor) {
        super(context, cursor, false);
        this.isSelectMode = false;
        this.mSelectedIdSet = new HashSet<>();
        this.mAllUnreadMessageCount = 0;
        this.mFactory = LayoutInflater.from(context);
    }

    public void setSelectedIndex(int index) {
        this.mSelectedIndex = index;
    }

    public void setSelectedIndex(int index, long threadId) {
        this.mSelectedIndex = index;
        this.mSelectedThreadId = threadId;
    }

    @Override // android.widget.CursorAdapter
    public void bindView(View view, Context context, Cursor cursor) {
        if (!(view instanceof ConversationListItem)) {
            Log.e("Mms", "Unexpected bound view: " + view);
            return;
        }
        ConversationListItem headerView = (ConversationListItem) view;
        Conversation conv = Conversation.from(context, cursor);
        if (conv.getThreadId() == this.mSelectedThreadId) {
            this.mSelectedIndex = cursor.getPosition();
        }
        if (cursor.getPosition() == this.mSelectedIndex) {
            headerView.bind(context, conv, true);
        } else {
            headerView.bind(context, conv, false);
        }
        boolean flage = headerView.getSelectedStatus();
        Log.v("Mms", "headerView.getSelectedStatus()-->" + flage);
        long threaId = conv.getThreadId();
        boolean flag = this.mSelectedIdSet.contains(Long.valueOf(threaId));
        if (this.isSelectMode) {
            headerView.setCheckVisibility(0);
            if (flag) {
                headerView.setItemSelected(true);
            } else {
                headerView.setItemSelected(false);
            }
        } else {
            headerView.setItemSelected(false);
            headerView.setCheckVisibility(8);
        }
        AdditionUnreadMessageCount(conv.getUnreadMessageCount());
    }

    @Override // android.widget.AbsListView.RecyclerListener
    public void onMovedToScrapHeap(View view) {
        ConversationListItem headerView = (ConversationListItem) view;
        headerView.unbind();
    }

    @Override // android.widget.CursorAdapter
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return this.mFactory.inflate(R.layout.conversation_list_item, parent, false);
    }

    public void setOnContentChangedListener(OnContentChangedListener l) {
        this.mOnContentChangedListener = l;
    }

    @Override // android.widget.CursorAdapter
    protected void onContentChanged() {
        if (this.mCursor != null && !this.mCursor.isClosed() && this.mOnContentChangedListener != null) {
            this.mOnContentChangedListener.onContentChanged(this);
        }
    }

    public void uncheckAll() {
        int count = getCount();
        for (int i = 0; i < count; i++) {
            Cursor cursor = (Cursor) getItem(i);
            Conversation conv = Conversation.from(this.mContext, cursor);
            conv.setIsChecked(false);
        }
    }

    private void AdditionUnreadMessageCount(int unreadMessageCount) {
        this.mAllUnreadMessageCount += unreadMessageCount;
    }

    public void initAllUnreadMessageCount() {
        this.mAllUnreadMessageCount = 0;
    }

    public int getAllUnreadMessageCount() {
        return this.mAllUnreadMessageCount;
    }
}
