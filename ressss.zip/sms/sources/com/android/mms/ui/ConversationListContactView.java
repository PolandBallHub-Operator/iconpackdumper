package com.android.mms.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class ConversationListContactView extends TextView {
    private final List<EllipsizeListener> ellipsizeListeners;
    private String fullText;
    private boolean isEllipsized;
    private boolean isStale;
    private float lineAdditionalVerticalPadding;
    private float lineSpacingMultiplier;
    private int maxLines;
    private boolean programmaticChange;

    public interface EllipsizeListener {
        void ellipsizeStateChanged(boolean z);
    }

    public ConversationListContactView(Context context) {
        super(context);
        this.ellipsizeListeners = new ArrayList();
        this.maxLines = -1;
        this.lineSpacingMultiplier = 1.0f;
        this.lineAdditionalVerticalPadding = 0.0f;
    }

    public ConversationListContactView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.ellipsizeListeners = new ArrayList();
        this.maxLines = -1;
        this.lineSpacingMultiplier = 1.0f;
        this.lineAdditionalVerticalPadding = 0.0f;
    }

    public ConversationListContactView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.ellipsizeListeners = new ArrayList();
        this.maxLines = -1;
        this.lineSpacingMultiplier = 1.0f;
        this.lineAdditionalVerticalPadding = 0.0f;
    }

    public void addEllipsizeListener(EllipsizeListener listener) {
        if (listener == null) {
            throw new NullPointerException();
        }
        this.ellipsizeListeners.add(listener);
    }

    public void removeEllipsizeListener(EllipsizeListener listener) {
        this.ellipsizeListeners.remove(listener);
    }

    public boolean isEllipsized() {
        return this.isEllipsized;
    }

    @Override // android.widget.TextView
    public void setMaxLines(int maxLines) {
        super.setMaxLines(maxLines);
        this.maxLines = maxLines;
        this.isStale = true;
    }

    @Override // android.widget.TextView
    public int getMaxLines() {
        return super.getMaxLines();
    }

    @Override // android.widget.TextView
    public void setLineSpacing(float add, float mult) {
        this.lineAdditionalVerticalPadding = add;
        this.lineSpacingMultiplier = mult;
        super.setLineSpacing(add, mult);
    }

    @Override // android.widget.TextView
    protected void onTextChanged(CharSequence text, int start, int before, int after) {
        super.onTextChanged(text, start, before, after);
        if (!this.programmaticChange) {
            this.fullText = text.toString();
            this.isStale = true;
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        if (this.isStale) {
            super.setEllipsize(null);
            resetText();
        }
        super.onDraw(canvas);
    }

    private void resetText() {
        int maxLines = getMaxLines();
        String workingText = this.fullText;
        boolean ellipsized = false;
        if (maxLines != -1) {
            Layout layout = createWorkingLayout(workingText);
            if (layout.getLineCount() > maxLines) {
                float avail = 0.0f;
                for (int i = 0; i < maxLines; i++) {
                    avail += layout.getLineMax(i);
                }
                CharSequence ellipsizedText = TextUtils.ellipsize(workingText, getPaint(), avail, TextUtils.TruncateAt.END);
                workingText = ((Object) ellipsizedText) + LoggingEvents.EXTRA_CALLING_APP_NAME;
                ellipsized = true;
            }
        }
        if (!workingText.equals(getText())) {
            this.programmaticChange = true;
            try {
                setText(workingText);
                this.programmaticChange = false;
            } catch (Throwable th) {
                this.programmaticChange = false;
                throw th;
            }
        }
        this.isStale = false;
        if (ellipsized != this.isEllipsized) {
            this.isEllipsized = ellipsized;
            for (EllipsizeListener listener : this.ellipsizeListeners) {
                listener.ellipsizeStateChanged(ellipsized);
            }
        }
    }

    private Layout createWorkingLayout(String workingText) {
        return new StaticLayout(workingText, getPaint(), (getWidth() - getPaddingLeft()) - getPaddingRight(), Layout.Alignment.ALIGN_NORMAL, this.lineSpacingMultiplier, this.lineAdditionalVerticalPadding, false);
    }
}
