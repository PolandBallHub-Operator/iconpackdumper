package com.android.mms.ui;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class ComposeMessageActivityNoLockScreen extends ComposeMessageActivity {
    @Override // com.android.mms.ui.ComposeMessageActivity
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().addFlags(4718592);
        super.onCreate(savedInstanceState);
    }
}
