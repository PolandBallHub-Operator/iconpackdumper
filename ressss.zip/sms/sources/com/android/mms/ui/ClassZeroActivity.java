package com.android.mms.ui;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialogFp;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import com.android.common.speech.LoggingEvents;
import com.android.mms.R;
import com.android.mms.transaction.MessagingNotification;
import com.android.mms.util.ModeStringUtil;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class ClassZeroActivity extends Activity {
    private static final long DEFAULT_TIMER = 300000;
    private static final int ON_AUTO_SAVE = 1;
    private static final int REPLACE_COLUMN_ID = 0;
    private static final String TAG = "Mms";
    private static final String TIMER_FIRE = "timer_fire";
    private int mPhoneId;
    private static final String BUFFER = "         ";
    private static final int BUFFER_OFFSET = BUFFER.length() * 2;
    private static final String[] REPLACE_PROJECTION = {"_id", "address", "protocol"};
    static AlertDialogFp myDialog = null;
    private final boolean DEBUG = false;
    private SmsMessage mMessage = null;
    private boolean mRead = false;
    private long mTimerSet = 0;
    private ArrayList<SmsMessage> mMessageQueue = null;
    private Handler mHandler = new Handler() { // from class: com.android.mms.ui.ClassZeroActivity.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                ClassZeroActivity.this.mRead = false;
                ClassZeroActivity.myDialog.dismiss();
                ClassZeroActivity.this.saveMessage();
                ClassZeroActivity.this.processNextMessage();
            }
        }
    };
    private final DialogInterface.OnClickListener mCancelListener = new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ClassZeroActivity.3
        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int whichButton) {
            dialog.dismiss();
            ClassZeroActivity.this.processNextMessage();
        }
    };
    private final DialogInterface.OnClickListener mSaveListener = new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ClassZeroActivity.4
        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int whichButton) {
            ClassZeroActivity.this.mRead = true;
            ClassZeroActivity.this.saveMessage();
            dialog.dismiss();
            ClassZeroActivity.this.processNextMessage();
        }
    };

    private boolean queueMsgFromIntent(Intent msgIntent) {
        byte[] pdu = msgIntent.getByteArrayExtra("pdu");
        String format = msgIntent.getStringExtra("format");
        this.mPhoneId = msgIntent.getIntExtra("phone", -1);
        SmsMessage rawMessage = SmsMessage.createFromPdu(pdu, format);
        String message = rawMessage.getMessageBody();
        if (TextUtils.isEmpty(message)) {
            if (this.mMessageQueue.size() == 0) {
                finish();
            }
            return false;
        }
        this.mMessageQueue.add(rawMessage);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void processNextMessage() {
        this.mMessageQueue.remove(0);
        if (this.mMessageQueue.size() == 0) {
            finish();
        } else {
            displayZeroMessage(this.mMessageQueue.get(0));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void saveMessage() {
        Uri messageUri;
        if (this.mMessage.isReplace()) {
            messageUri = replaceMessage(this.mMessage);
        } else {
            messageUri = storeMessage(this.mMessage);
        }
        if (!this.mRead && messageUri != null) {
            MessagingNotification.nonBlockingUpdateNewMessageIndicator(this, true, false);
        }
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent msgIntent) {
        queueMsgFromIntent(msgIntent);
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawableResource(R.drawable.class_zero_background);
        getWindow().addPrivateFlags(4096);
        if (this.mMessageQueue == null) {
            this.mMessageQueue = new ArrayList<>();
        }
        if (queueMsgFromIntent(getIntent())) {
            if (this.mMessageQueue.size() == 1) {
                displayZeroMessage(this.mMessageQueue.get(0));
            }
            if (icicle != null) {
                this.mTimerSet = icicle.getLong(TIMER_FIRE, this.mTimerSet);
            }
        }
    }

    private void displayZeroMessage(SmsMessage rawMessage) {
        CharSequence messageChars = rawMessage.getMessageBody();
        this.mMessage = rawMessage;
        String message = messageChars.toString();
        if (message.length() < BUFFER_OFFSET) {
            String str = BUFFER + message + BUFFER;
        }
        String originatingAddress = this.mMessage.getOriginatingAddress();
        System.out.print("originatingAddress = " + originatingAddress);
        String timestampMillis = MessageUtils.formatTimeStampString(this, System.currentTimeMillis(), false);
        String senderName = null;
        String[] projection = {"display_name", "data1"};
        Cursor cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, "data1 = '" + originatingAddress + "'", null, null);
        if (cursor == null || cursor.getCount() == 0) {
            senderName = originatingAddress;
        } else {
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToPosition(i);
                int nameFieldColumnIndex = cursor.getColumnIndex("display_name");
                String name = cursor.getString(nameFieldColumnIndex);
                Log.i("Contacts", LoggingEvents.EXTRA_CALLING_APP_NAME + name + " .... " + nameFieldColumnIndex);
                senderName = name;
                System.out.println("name = " + name);
            }
        }
        if (cursor != null) {
            cursor.close();
        }
        myDialog = new AlertDialogFp.Builder(this).setTitle(R.string.class0_sms_message_title).setMessage(message + "\n" + senderName + " " + timestampMillis).setPositiveButton(ModeStringUtil.getModeResFromArray(this, R.array.dialog_button_save), this.mSaveListener).setNegativeButton(ModeStringUtil.getModeResFromArray(this, R.array.dialog_button_save_cancel), this.mCancelListener).create();
        myDialog.getWindow().addPrivateFlags(4096);
        myDialog.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.android.mms.ui.ClassZeroActivity.2
            @Override // android.content.DialogInterface.OnKeyListener
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == 4) {
                    dialog.dismiss();
                    ClassZeroActivity.this.finish();
                }
                if (keyCode != 6) {
                    return false;
                }
                Log.d("Mms", "ClassZeroActivity | displayZeroMessage click endkey.");
                ActivityManager mActivityManager = (ActivityManager) ClassZeroActivity.this.getSystemService("activity");
                dialog.dismiss();
                mActivityManager.goHome();
                boolean locked = ((ActivityManager) ClassZeroActivity.this.getSystemService("activity")).isInLockTaskMode();
                if (!locked) {
                    ClassZeroActivity.this.finish();
                }
                return true;
            }
        });
        myDialog.show();
        long now = SystemClock.uptimeMillis();
        this.mTimerSet = DEFAULT_TIMER + now;
    }

    @Override // android.app.Activity
    protected void onStart() {
        super.onStart();
        long now = SystemClock.uptimeMillis();
        if (this.mTimerSet <= now) {
            this.mHandler.sendEmptyMessage(1);
        } else {
            this.mHandler.sendEmptyMessageAtTime(1, this.mTimerSet);
        }
    }

    @Override // android.app.Activity
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(TIMER_FIRE, this.mTimerSet);
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        this.mHandler.removeMessages(1);
    }

    private ContentValues extractContentValues(SmsMessage sms) {
        ContentValues values = new ContentValues();
        values.put("address", sms.getStoreOriginatingAddress());
        values.put("date", new Long(System.currentTimeMillis()));
        values.put("protocol", Integer.valueOf(sms.getProtocolIdentifier()));
        values.put("read", Integer.valueOf(this.mRead ? 1 : 0));
        values.put("seen", Integer.valueOf(this.mRead ? 1 : 0));
        if (sms.getPseudoSubject().length() > 0) {
            values.put("subject", sms.getPseudoSubject());
        }
        values.put("reply_path_present", Integer.valueOf(sms.isReplyPathPresent() ? 1 : 0));
        values.put("service_center", sms.getServiceCenterAddress());
        values.put("phone_id", Integer.valueOf(this.mPhoneId));
        return values;
    }

    private Uri replaceMessage(SmsMessage sms) {
        ContentValues values = extractContentValues(sms);
        values.put("body", sms.getMessageBody());
        ContentResolver resolver = getContentResolver();
        String originatingAddress = sms.getStoreOriginatingAddress();
        int protocolIdentifier = sms.getProtocolIdentifier();
        String[] selectionArgs = {originatingAddress, Integer.toString(protocolIdentifier)};
        Cursor cursor = SqliteWrapper.query(this, resolver, Telephony.Sms.Inbox.CONTENT_URI, REPLACE_PROJECTION, "address = ? AND protocol = ?", selectionArgs, (String) null);
        try {
            if (cursor.moveToFirst()) {
                long messageId = cursor.getLong(0);
                Uri messageUri = ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, messageId);
                SqliteWrapper.update(this, resolver, messageUri, values, (String) null, (String[]) null);
                return messageUri;
            }
            return storeMessage(sms);
        } finally {
            cursor.close();
        }
    }

    private Uri storeMessage(SmsMessage sms) {
        ContentValues values = extractContentValues(sms);
        values.put("body", sms.getDisplayMessageBody());
        ContentResolver resolver = getContentResolver();
        return SqliteWrapper.insert(this, resolver, Telephony.Sms.Inbox.CONTENT_URI, values);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode != 6 || event.getRepeatCount() != 0) {
            return super.onKeyDown(keyCode, event);
        }
        MessageUtils.endCallToHome(this);
        return true;
    }
}
