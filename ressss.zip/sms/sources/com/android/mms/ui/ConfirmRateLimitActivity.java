package com.android.mms.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import com.android.mms.R;
import com.android.mms.util.RateController;

/* JADX INFO: loaded from: classes.dex */
public class ConfirmRateLimitActivity extends Activity {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "Mms";
    private long mCreateTime;
    private Handler mHandler;
    private Runnable mRunnable;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(R.layout.confirm_rate_limit_activity);
        Button button = (Button) findViewById(R.id.btn_yes);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.android.mms.ui.ConfirmRateLimitActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ConfirmRateLimitActivity.this.doAnswer(true);
            }
        });
        Button button2 = (Button) findViewById(R.id.btn_no);
        button2.setOnClickListener(new View.OnClickListener() { // from class: com.android.mms.ui.ConfirmRateLimitActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ConfirmRateLimitActivity.this.doAnswer(false);
            }
        });
        this.mHandler = new Handler();
        this.mRunnable = new Runnable() { // from class: com.android.mms.ui.ConfirmRateLimitActivity.3
            @Override // java.lang.Runnable
            public void run() {
                ConfirmRateLimitActivity.this.doAnswer(false);
            }
        };
        this.mCreateTime = System.currentTimeMillis();
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        long delay = (this.mCreateTime - System.currentTimeMillis()) + 19500;
        if (delay <= 0) {
            doAnswer(false);
        } else if (this.mHandler != null) {
            this.mHandler.postDelayed(this.mRunnable, delay);
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        if (this.mHandler != null) {
            this.mHandler.removeCallbacks(this.mRunnable);
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4 && event.getRepeatCount() == 0) {
            doAnswer(false);
        }
        return super.onKeyDown(keyCode, event);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doAnswer(boolean answer) {
        Intent intent = new Intent(RateController.RATE_LIMIT_CONFIRMED_ACTION);
        intent.putExtra("answer", answer);
        sendBroadcast(intent);
        finish();
    }
}
