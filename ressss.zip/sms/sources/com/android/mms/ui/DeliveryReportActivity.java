package com.android.mms.ui;

import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import com.android.common.speech.LoggingEvents;
import com.android.mms.R;
import com.android.mms.util.DownloadManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class DeliveryReportActivity extends ListActivity {
    static final int COLUMN_DATE_SENT = 2;
    static final int COLUMN_DELIVERY_REPORT = 1;
    static final int COLUMN_DELIVERY_STATUS = 1;
    static final int COLUMN_MESSAGE_TYPE = 3;
    static final int COLUMN_READ_REPORT = 2;
    static final int COLUMN_READ_STATUS = 2;
    static final int COLUMN_RECIPIENT = 0;
    private static final String LOG_TAG = "Mms";
    static final String[] MMS_REPORT_REQUEST_PROJECTION = {"address", "d_rpt", "rr"};
    static final String[] MMS_REPORT_STATUS_PROJECTION = {"address", "delivery_status", "read_status"};
    static final String[] SMS_REPORT_STATUS_PROJECTION = {"address", "status", "date_sent", "type"};
    private long mMessageId;
    private String mMessageType;

    @Override // android.app.Activity
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        requestWindowFeature(1);
        setContentView(R.layout.delivery_report_activity);
        Intent intent = getIntent();
        this.mMessageId = getMessageId(icicle, intent);
        this.mMessageType = getMessageType(icicle, intent);
        initListView();
        initListAdapter();
    }

    private void initListView() {
        LayoutInflater inflater = getLayoutInflater();
        View header = inflater.inflate(R.layout.delivery_report_header, (ViewGroup) null);
        getListView().addHeaderView(header, null, true);
    }

    private void initListAdapter() {
        List<DeliveryReportItem> items = getReportItems();
        if (items == null) {
            items = new ArrayList<>(1);
            items.add(new DeliveryReportItem(LoggingEvents.EXTRA_CALLING_APP_NAME, getString(R.string.status_none), null));
            Log.w("Mms", "cursor == null");
        }
        setListAdapter(new DeliveryReportAdapter(this, items));
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        refreshDeliveryReport();
    }

    private void refreshDeliveryReport() {
        ListView list = getListView();
        list.invalidateViews();
        list.requestFocus();
    }

    private long getMessageId(Bundle icicle, Intent intent) {
        long msgId = 0;
        if (icicle != null) {
            msgId = icicle.getLong("message_id");
        }
        if (msgId == 0) {
            long msgId2 = intent.getLongExtra("message_id", 0L);
            return msgId2;
        }
        return msgId;
    }

    private String getMessageType(Bundle icicle, Intent intent) {
        String msgType = null;
        if (icicle != null) {
            msgType = icicle.getString("message_type");
        }
        if (msgType == null) {
            String msgType2 = intent.getStringExtra("message_type");
            return msgType2;
        }
        return msgType;
    }

    private List<DeliveryReportItem> getReportItems() {
        return this.mMessageType.equals("sms") ? getSmsReportItems() : getMmsReportItems();
    }

    private List<DeliveryReportItem> getSmsReportItems() {
        String selection = "_id = " + this.mMessageId;
        Cursor c = SqliteWrapper.query(this, getContentResolver(), Telephony.Sms.CONTENT_URI, SMS_REPORT_STATUS_PROJECTION, selection, (String[]) null, (String) null);
        if (c == null) {
            return null;
        }
        try {
            if (c.getCount() <= 0) {
                return null;
            }
            List<DeliveryReportItem> items = new ArrayList<>();
            while (c.moveToNext()) {
                String deliveryDateString = null;
                long deliveryDate = c.getLong(2);
                int messageType = c.getInt(3);
                if (messageType == 2 && deliveryDate > 0) {
                    deliveryDateString = getString(R.string.delivered_label) + MessageUtils.formatTimeStampString(this, deliveryDate, true);
                }
                items.add(new DeliveryReportItem(getString(R.string.recipient_label) + c.getString(0), getString(R.string.status_label) + getSmsStatusText(c.getInt(1)), deliveryDateString));
            }
            return items;
        } finally {
            c.close();
        }
    }

    private String getMmsReportStatusText(MmsReportRequest request, Map<String, MmsReportStatus> reportStatus) {
        if (reportStatus == null) {
            return getString(R.string.status_pending);
        }
        String recipient = request.getRecipient();
        MmsReportStatus status = queryStatusByRecipient(reportStatus, Telephony.Mms.isEmailAddress(recipient) ? Telephony.Mms.extractAddrSpec(recipient) : PhoneNumberUtils.stripSeparators(recipient));
        if (status == null) {
            return getString(R.string.status_pending);
        }
        if (request.isReadReportRequested() && status.readStatus != 0) {
            switch (status.readStatus) {
                case 128:
                    return getString(R.string.status_read);
                case DownloadManager.STATE_DOWNLOADING /* 129 */:
                    return getString(R.string.status_unread);
            }
        }
        switch (status.deliveryStatus) {
            case 0:
                return getString(R.string.status_pending);
            case DownloadManager.STATE_DOWNLOADING /* 129 */:
            case 134:
                return getString(R.string.status_received);
            case 130:
                return getString(R.string.status_rejected);
            default:
                return getString(R.string.status_failed);
        }
    }

    private static MmsReportStatus queryStatusByRecipient(Map<String, MmsReportStatus> status, String recipient) {
        Set<String> recipientSet = status.keySet();
        for (String r : recipientSet) {
            if (Telephony.Mms.isEmailAddress(recipient)) {
                if (TextUtils.equals(r, recipient)) {
                    return status.get(r);
                }
            } else if (PhoneNumberUtils.compare(r, recipient)) {
                return status.get(r);
            }
        }
        return null;
    }

    private List<DeliveryReportItem> getMmsReportItems() {
        List<MmsReportRequest> reportReqs = getMmsReportRequests();
        if (reportReqs != null && reportReqs.size() != 0) {
            Map<String, MmsReportStatus> reportStatus = getMmsReportStatus();
            List<DeliveryReportItem> items = new ArrayList<>();
            for (MmsReportRequest reportReq : reportReqs) {
                String statusText = getString(R.string.status_label) + getMmsReportStatusText(reportReq, reportStatus);
                items.add(new DeliveryReportItem(getString(R.string.recipient_label) + reportReq.getRecipient(), statusText, null));
            }
            return items;
        }
        return null;
    }

    private Map<String, MmsReportStatus> getMmsReportStatus() {
        Uri uri = Uri.withAppendedPath(Telephony.Mms.REPORT_STATUS_URI, String.valueOf(this.mMessageId));
        Cursor c = SqliteWrapper.query(this, getContentResolver(), uri, MMS_REPORT_STATUS_PROJECTION, (String) null, (String[]) null, (String) null);
        if (c == null) {
            return null;
        }
        try {
            Map<String, MmsReportStatus> statusMap = new HashMap<>();
            while (c.moveToNext()) {
                String recipient = c.getString(0);
                String recipient2 = Telephony.Mms.isEmailAddress(recipient) ? Telephony.Mms.extractAddrSpec(recipient) : PhoneNumberUtils.stripSeparators(recipient);
                MmsReportStatus status = new MmsReportStatus(c.getInt(1), c.getInt(2));
                statusMap.put(recipient2, status);
            }
            return statusMap;
        } finally {
            c.close();
        }
    }

    private List<MmsReportRequest> getMmsReportRequests() {
        Uri uri = Uri.withAppendedPath(Telephony.Mms.REPORT_REQUEST_URI, String.valueOf(this.mMessageId));
        Cursor c = SqliteWrapper.query(this, getContentResolver(), uri, MMS_REPORT_REQUEST_PROJECTION, (String) null, (String[]) null, (String) null);
        if (c == null) {
            return null;
        }
        try {
            if (c.getCount() > 0) {
                List<MmsReportRequest> reqList = new ArrayList<>();
                while (c.moveToNext()) {
                    reqList.add(new MmsReportRequest(c.getString(0), c.getInt(1), c.getInt(2)));
                }
                c.close();
                return reqList;
            }
            c.close();
            return null;
        } catch (Throwable th) {
            c.close();
            throw th;
        }
    }

    private String getSmsStatusText(int status) {
        if (status == -1) {
            return getString(R.string.status_none);
        }
        if (status >= 64) {
            return getString(R.string.status_failed);
        }
        if (status >= 32) {
            return getString(R.string.status_pending);
        }
        return getString(R.string.status_received);
    }

    private static final class MmsReportStatus {
        final int deliveryStatus;
        final int readStatus;

        public MmsReportStatus(int drStatus, int rrStatus) {
            this.deliveryStatus = drStatus;
            this.readStatus = rrStatus;
        }
    }

    private static final class MmsReportRequest {
        private final boolean mIsDeliveryReportRequsted;
        private final boolean mIsReadReportRequested;
        private final String mRecipient;

        public MmsReportRequest(String recipient, int drValue, int rrValue) {
            this.mRecipient = recipient;
            this.mIsDeliveryReportRequsted = drValue == 128;
            this.mIsReadReportRequested = rrValue == 128;
        }

        public String getRecipient() {
            return this.mRecipient;
        }

        public boolean isDeliveryReportRequested() {
            return this.mIsDeliveryReportRequsted;
        }

        public boolean isReadReportRequested() {
            return this.mIsReadReportRequested;
        }
    }
}
