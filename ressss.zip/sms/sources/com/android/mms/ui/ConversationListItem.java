package com.android.mms.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.SystemProperties;
import android.provider.FjSettings;
import android.provider.Telephony;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import com.android.mms.MmsApp;
import com.android.mms.R;
import com.android.mms.data.Contact;
import com.android.mms.data.ContactList;
import com.android.mms.data.Conversation;
import com.android.mms.util.ModeStringUtil;
import com.android.mms.widget.MarqueeTextView;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class ConversationListItem extends RelativeLayout implements Contact.UpdateListener, Checkable {
    private static final boolean DEBUG = false;
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final int PHONENUMBERSIZE = 10;
    public static final StyleSpan STYLE_BOLD;
    private static final String TAG = "Mms";
    private static Drawable sDefaultContactImage;
    private CheckBox mCheck;
    private Conversation mConversation;
    private TextView mCountView;
    private int mFontFocusColor;
    private int mFontNormalColor;
    private MarqueeTextView mFromView;
    private Handler mHandler;

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
        STYLE_BOLD = new StyleSpan(1);
    }

    public void setItemSelected(boolean bool) {
        if (this.mCheck != null) {
            this.mCheck.setChecked(bool);
        }
    }

    public boolean getSelectedStatus() {
        if (this.mCheck != null) {
            return this.mCheck.isChecked();
        }
        return false;
    }

    public void selectStatusToggle() {
        if (this.mCheck != null) {
            this.mCheck.toggle();
        }
    }

    public void setCheckVisibility(int flag) {
        if (this.mCheck != null) {
            this.mCheck.setVisibility(flag);
        }
    }

    public ConversationListItem(Context context) {
        super(context);
        this.mHandler = new Handler();
    }

    public ConversationListItem(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mHandler = new Handler();
        if (sDefaultContactImage == null) {
            sDefaultContactImage = context.getResources().getDrawable(R.drawable.ic_contact_picture);
        }
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mFromView = (MarqueeTextView) findViewById(R.id.from);
        this.mCountView = (TextView) findViewById(R.id.count);
        int themeMode = FjSettings.System.getInt(this.mContext.getContentResolver(), "theme_type", 1);
        if (themeMode == 1) {
            this.mFromView.setTextColor(this.mContext.getResources().getColor(R.color.text_normal_color));
        } else if (themeMode == 4) {
            XmlResourceParser xpp = getResources().getXml(R.drawable.listitem_selector_simple);
            try {
                ColorStateList colorStateList = ColorStateList.createFromXml(getResources(), xpp);
                this.mFromView.setTextColor(colorStateList);
            } catch (Exception e) {
                Log.d("Mms", "Exception:" + e.getMessage());
            }
        } else {
            XmlResourceParser xpp2 = getResources().getXml(R.drawable.listitem_selector);
            try {
                ColorStateList colorStateList2 = ColorStateList.createFromXml(getResources(), xpp2);
                this.mFromView.setTextColor(colorStateList2);
            } catch (Exception e2) {
                Log.d("Mms", "Exception:" + e2.getMessage());
            }
        }
        this.mCheck = (CheckBox) findViewById(R.id.select);
    }

    public Conversation getConversation() {
        return this.mConversation;
    }

    public void bind(String title, String explain) {
    }

    private CharSequence formatMessage() {
        ContactList list = this.mConversation.getRecipients();
        String from = LoggingEvents.EXTRA_CALLING_APP_NAME;
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                from = from + ", ";
            }
            String number = list.get(i).getNumber();
            Contact cacheContact = Contact.get(number, true);
            String name = cacheContact.getName();
            if (name.equals(cacheContact.getNumber()) && cacheContact.isNotExistName()) {
                name = name.replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll(" ", LoggingEvents.EXTRA_CALLING_APP_NAME);
            }
            from = from + name;
        }
        boolean isSelf = isMySelf();
        if (isSelf) {
            from = this.mContext.getResources().getString(ModeStringUtil.getModeResFromArray(this.mContext, R.array.messagelist_sender_self));
        }
        SpannableStringBuilder buf = new SpannableStringBuilder(from);
        return buf;
    }

    private void updateAvatarView() {
    }

    private boolean isMyProfile() {
        if (this.mConversation.getRecipients().size() > 0) {
            Contact contact = this.mConversation.getRecipients().get(0);
            String contactPhoneNumber = contact.getNumber().replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME);
            String myNumber = MmsApp.getApplication().getTelephonyManager().getLine1Number();
            return (TextUtils.isEmpty(myNumber) || TextUtils.isEmpty(contactPhoneNumber) || !myNumber.equals(contactPhoneNumber)) ? false : true;
        }
        Log.w("Mms", "isMyProfile: contacts list is null!");
        return false;
    }

    public boolean isMySelf() {
        if (this.mConversation.getRecipients().size() > 0) {
            Contact contact = this.mConversation.getRecipients().get(0);
            String contactPhoneNumber = contact.getNumber().replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME).replace(" ", LoggingEvents.EXTRA_CALLING_APP_NAME);
            int num = contactPhoneNumber.length();
            String TelephonyNumber = MmsApp.getApplication().getTelephonyManager().getLine1Number();
            if (TextUtils.isEmpty(TelephonyNumber)) {
                return false;
            }
            String myNumber = TelephonyNumber.replace(" ", LoggingEvents.EXTRA_CALLING_APP_NAME);
            if (myNumber.length() < 10 || num < 10) {
                return false;
            }
            String contactPhoneNumber2 = contactPhoneNumber.substring(num - 10, num).toString();
            return (TextUtils.isEmpty(myNumber) || TextUtils.isEmpty(contactPhoneNumber2) || !myNumber.substring(myNumber.length() + (-10), myNumber.length()).toString().equals(contactPhoneNumber2)) ? false : true;
        }
        Log.w("Mms", "isMyProfile: contacts list is null!");
        return false;
    }

    public boolean isPhoneNumber() {
        if (this.mConversation.getRecipients().size() <= 0) {
            return false;
        }
        Contact contact = this.mConversation.getRecipients().get(0);
        String contactPhoneNumber = contact.getNumber();
        return !TextUtils.isEmpty(contactPhoneNumber) && Telephony.Mms.isPhoneNumber(contactPhoneNumber);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateFromView() {
        this.mFromView.setText(formatMessage());
        setUnreadMessagesCount(this.mCountView);
        updateAvatarView();
    }

    @Override // com.android.mms.data.Contact.UpdateListener
    public void onUpdate(Contact updated) {
        if (Log.isLoggable("Mms", 3)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                Log.v("Mms", "onUpdate: *** contact: ***");
            } else {
                Log.v("Mms", "onUpdate: " + this + " contact: " + updated);
            }
        }
        this.mHandler.post(new Runnable() { // from class: com.android.mms.ui.ConversationListItem.1
            @Override // java.lang.Runnable
            public void run() {
                ConversationListItem.this.updateFromView();
            }
        });
    }

    public final void bind(Context context, Conversation conversation, boolean isSelected) {
        this.mConversation = conversation;
        ContactList list = this.mConversation.getRecipients();
        for (Contact contact : list) {
            contact.blockReload();
        }
        this.mFromView.setText(formatMessage());
        setUnreadMessagesCount(this.mCountView);
        if (!this.mConversation.hasUnreadMessages() || this.mConversation.getUnreadMessageCount() <= 0) {
            this.mFromView.setSelected(isSelected);
        }
        updateAvatarView();
    }

    private void updateBackground() {
        int backgroundId;
        if (this.mConversation.isChecked()) {
            backgroundId = R.drawable.list_selected_holo_light;
        } else {
            backgroundId = R.drawable.conversation_item_background_read;
        }
        Drawable background = this.mContext.getResources().getDrawable(backgroundId);
        setBackground(background);
    }

    public final void unbind() {
        if (Log.isLoggable("Mms", 3)) {
            Log.v("Mms", "unbind: contacts.removeListeners " + this);
        }
        Contact.removeListener(this);
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean checked) {
        this.mConversation.setIsChecked(checked);
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.mConversation.isChecked();
    }

    @Override // android.widget.Checkable
    public void toggle() {
        this.mConversation.setIsChecked(!this.mConversation.isChecked());
    }

    public void setUnreadMessagesCount(TextView mCountView) {
        if (this.mConversation.hasUnreadMessages() && this.mConversation.getUnreadMessageCount() > 0) {
            SpannableStringBuilder unreadBuf = new SpannableStringBuilder();
            mCountView.setVisibility(0);
            if (this.mConversation.getUnreadMessageCount() > 99) {
                unreadBuf.append((CharSequence) this.mContext.getResources().getString(R.string.sms_unread_message_100more));
            } else {
                unreadBuf.append((CharSequence) (this.mConversation.getUnreadMessageCount() + LoggingEvents.EXTRA_CALLING_APP_NAME));
            }
            unreadBuf.setSpan(STYLE_BOLD, 0, unreadBuf.length(), 17);
            mCountView.setText(unreadBuf);
            int unreadCountBackground = getResources().getThemeResFromArray(R.array.unread_message_count_background);
            mCountView.setBackgroundResource(unreadCountBackground);
            return;
        }
        mCountView.setText(LoggingEvents.EXTRA_CALLING_APP_NAME);
        mCountView.setVisibility(8);
        mCountView.setBackgroundColor(this.mContext.getResources().getColor(R.color.solid_color));
    }

    public CharSequence formatConMessage() {
        StringBuffer sbFrom = new StringBuffer();
        List<Contact> sendList = this.mConversation.getRecipients();
        for (int i = 0; i < sendList.size(); i++) {
            sbFrom.append(sendList.get(i).getNumber().replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME));
            if (i < sendList.size() - 1) {
                sbFrom.append(MessageDispActivity.string_delimiter);
            }
        }
        return sbFrom.toString();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchSetSelected(boolean selected) {
        super.dispatchSetSelected(selected);
        setItemTextColor();
        if (selected) {
            this.mFromView.setTextColor(this.mFontFocusColor);
        } else {
            this.mFromView.setTextColor(this.mFontNormalColor);
        }
    }

    private void setItemTextColor() {
        int themeMode = FjSettings.System.getInt(this.mContext.getContentResolver(), "theme_type", 1);
        if (themeMode == 1) {
            int color = this.mContext.getResources().getColor(R.color.text_normal_color);
            this.mFontNormalColor = color;
            this.mFontFocusColor = color;
        } else if (themeMode == 4) {
            this.mFontFocusColor = this.mContext.getResources().getColor(R.color.text_focus_color);
            this.mFontNormalColor = this.mContext.getResources().getColor(R.color.text_normal_simple_color);
        } else {
            this.mFontFocusColor = this.mContext.getResources().getColor(R.color.text_focus_color);
            this.mFontNormalColor = this.mContext.getResources().getColor(R.color.text_normal_color);
        }
    }
}
