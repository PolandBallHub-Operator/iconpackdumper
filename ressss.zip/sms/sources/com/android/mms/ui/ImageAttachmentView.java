package com.android.mms.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.android.mms.R;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class ImageAttachmentView extends LinearLayout implements SlideViewInterface {
    private static final String TAG = "Mms";
    private ImageView mImageView;

    public ImageAttachmentView(Context context) {
        super(context);
    }

    public ImageAttachmentView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        this.mImageView = (ImageView) findViewById(R.id.image_content);
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void startAudio() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void startVideo() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setAudio(Uri audio, String name, Map<String, ?> extras) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImage(String name, Bitmap bitmap) {
        if (bitmap == null) {
            try {
                bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_missing_thumbnail_picture);
            } catch (OutOfMemoryError e) {
                Log.e("Mms", "setImage: out of memory: ", e);
                return;
            }
        }
        this.mImageView.setImageBitmap(bitmap);
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImageRegionFit(String fit) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImageVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setText(String name, String text) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setTextVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideo(String name, Uri video) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideoThumbnail(String name, Bitmap bitmap) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideoVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void stopAudio() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void stopVideo() {
    }

    @Override // com.android.mms.ui.ViewInterface
    public void reset() {
        this.mImageView.setImageDrawable(null);
    }

    @Override // com.android.mms.ui.ViewInterface
    public void setVisibility(boolean visible) {
        setVisibility(visible ? 0 : 8);
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void pauseAudio() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void pauseVideo() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void seekAudio(int seekTo) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void seekVideo(int seekTo) {
    }
}
