package com.android.mms.ui;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import com.android.mms.R;
import com.android.mms.data.Contact;

/* JADX INFO: loaded from: classes.dex */
public class DeliveryReportListItem extends LinearLayout {
    private TextView mDeliveryDateView;
    private ImageView mIconView;
    private TextView mRecipientView;
    private TextView mStatusView;

    DeliveryReportListItem(Context context) {
        super(context);
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mRecipientView = (TextView) findViewById(R.id.recipient);
        this.mStatusView = (TextView) findViewById(R.id.status);
        this.mDeliveryDateView = (TextView) findViewById(R.id.delivery_date);
        this.mIconView = (ImageView) findViewById(R.id.icon);
    }

    public DeliveryReportListItem(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public final void bind(String recipient, String status, String deliveryDate) {
        if (!TextUtils.isEmpty(recipient)) {
            this.mRecipientView.setText(Contact.get(recipient, false).getName());
        } else {
            this.mRecipientView.setText(LoggingEvents.EXTRA_CALLING_APP_NAME);
        }
        this.mStatusView.setText(status);
        Context context = getContext();
        String receivedStr = context.getString(R.string.status_received);
        String failedStr = context.getString(R.string.status_failed);
        String pendingStr = context.getString(R.string.status_pending);
        String rejectStr = context.getString(R.string.status_rejected);
        if (status.compareTo(receivedStr) == 0) {
            this.mIconView.setImageResource(R.drawable.ic_sms_mms_delivered);
        } else if (status.compareTo(failedStr) == 0) {
            this.mIconView.setImageResource(R.drawable.ic_sms_mms_not_delivered);
        } else if (status.compareTo(pendingStr) == 0) {
            this.mIconView.setImageResource(R.drawable.ic_sms_mms_pending);
        } else if (status.compareTo(rejectStr) == 0) {
            this.mIconView.setImageResource(R.drawable.ic_sms_mms_not_delivered);
        }
        if (TextUtils.isEmpty(deliveryDate)) {
            this.mDeliveryDateView.setVisibility(8);
        } else {
            this.mDeliveryDateView.setVisibility(0);
            this.mDeliveryDateView.setText(deliveryDate);
        }
    }
}
