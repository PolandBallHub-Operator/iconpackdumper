package com.android.mms.ui;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.AlertDialogFp;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TitleBarActivity;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.provider.ContactsContract;
import android.provider.FjSettings;
import android.provider.MediaStore;
import android.provider.Settings;
import android.provider.Telephony;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.telephony.PhoneNumberUtils;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.TextKeyListener;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.AppMenuHandler;
import android.widget.AppMenuObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ListViewFP;
import android.widget.PopupMenu;
import android.widget.SoftkeyView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.common.speech.LoggingEvents;
import com.android.mms.LogTag;
import com.android.mms.MmsApp;
import com.android.mms.MmsConfig;
import com.android.mms.R;
import com.android.mms.TempFileProvider;
import com.android.mms.data.Contact;
import com.android.mms.data.ContactList;
import com.android.mms.data.Conversation;
import com.android.mms.data.WorkingMessage;
import com.android.mms.drm.DrmUtils;
import com.android.mms.model.SlideModel;
import com.android.mms.model.SlideshowModel;
import com.android.mms.transaction.ISmsRingtoneService;
import com.android.mms.transaction.MessagingNotification;
import com.android.mms.transaction.ProgressCallbackEntity;
import com.android.mms.util.DraftCache;
import com.android.mms.util.LogUtil;
import com.android.mms.util.ModeStringUtil;
import com.android.mms.util.PhoneNumberFormatter;
import com.android.mms.widget.MmsWidgetProvider;
import com.google.android.mms.ContentType;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.EncodedStringValue;
import com.google.android.mms.pdu.PduBody;
import com.google.android.mms.pdu.PduPart;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.SendReq;
import com.google.android.mms.util.PduCache;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public class ComposeMessageActivity extends TitleBarActivity implements View.OnClickListener, TextView.OnEditorActionListener, WorkingMessage.MessageStatusListener, Contact.UpdateListener {
    private static final int CHARS_REMAINING_BEFORE_COUNTER_SHOWN = 10;
    private static final boolean DEBUG = false;
    private static final boolean DEFER_LOADING_MESSAGES_AND_DRAFT = false;
    private static final int DELETED_FAILED = 2;
    private static final int DELETED_SUCCESS = 1;
    private static final int DELETE_ALL_MESSAGE_TOKEN = 10000;
    private static final int DELETE_MESSAGE_TOKEN = 9700;
    private static final int DIALOG_ID_CLEAR_ALL_MESSAGE = 1;
    private static final int DIALOG_ID_DELETE_DRAFT = 5;
    private static final int DIALOG_ID_DELETE_THREAD = 4;
    private static final int DIALOG_ID_HAVE_DRAFT = 6;
    public static final String DISP_ORIGINATING_ADDRESS = "NTT DOCOMO";
    private static final String EXIT_ECM_RESULT = "exit_ecm_result";
    public static final String EXTRA_LOAD_DRAFT = "load_draft";
    private static final boolean FJ_TEL_LOG_ACQ_FLG;
    private static final int GUIDE_ID_MESSAGE = 180;
    private static final int GUIDE_ID_NO_MESSAGE = 181;
    private static final String KEY_EXIT_ON_SENT = "exit_on_sent";
    private static final String KEY_FORWARDED_MESSAGE = "forwarded_message";
    private static final int LOADING_MESSAGES_AND_DRAFT_MAX_DELAY_MS = 500;
    private static final boolean LOCAL_LOGV = false;
    private static final int MAX_FULL_SHAPE_TEXT_SIZE = 70;
    private static final int MAX_HALF_SHAPE_TEXT_SIZE = 160;
    private static final int MAX_ITEMS_TO_INVOKE_SCROLL_SHORTCUT = 20;
    private static final int MENU_ADD_ADDRESS_TO_CONTACTS = 27;
    private static final int MENU_ADD_ATTACHMENT = 2;
    private static final int MENU_ADD_SUBJECT = 0;
    private static final int MENU_ADD_TO_CONTACTS = 13;
    private static final int MENU_CALL_BACK = 22;
    private static final int MENU_CALL_RECIPIENT = 5;
    private static final int MENU_CONVERSATION_LIST = 6;
    private static final int MENU_COPY_MESSAGE_TEXT = 24;
    private static final int MENU_COPY_TO_SDCARD = 25;
    private static final int MENU_DEBUG_DUMP = 7;
    private static final int MENU_DELETE_MESSAGE = 18;
    private static final int MENU_DELETE_THREAD = 1;
    private static final int MENU_DELIVERY_REPORT = 20;
    private static final int MENU_DISCARD = 3;
    private static final int MENU_EDIT_MESSAGE = 14;
    private static final int MENU_FORWARD_MESSAGE = 21;
    private static final int MENU_GROUP_PARTICIPANTS = 32;
    private static final int MENU_LOCK_MESSAGE = 28;
    private static final int MENU_PREFERENCES = 31;
    private static final int MENU_SAVE_RINGTONE = 30;
    private static final int MENU_SEARCH = 19;
    private static final int MENU_SEND = 4;
    private static final int MENU_SEND_EMAIL = 23;
    private static final int MENU_UNLOCK_MESSAGE = 29;
    private static final int MENU_VIEW_CONTACT = 12;
    private static final int MENU_VIEW_MESSAGE_DETAILS = 17;
    private static final int MENU_VIEW_SLIDESHOW = 16;
    private static final int MESSAGE_LIST_QUERY_AFTER_DELETE_TOKEN = 9528;
    private static final int MESSAGE_LIST_QUERY_TOKEN = 9527;
    private static final long NO_DATE_FOR_DIALOG = -1;
    private static final int PHONENUMBERSIZE = 10;
    private static final String RECIPIENTS = "recipients";
    private static final int RECIPIENTS_MAX_LENGTH = 312;
    public static final int REQUEST_CODE_ADD_CONTACT = 108;
    public static final int REQUEST_CODE_ADD_TO_CONTACTS = 1005;
    public static final int REQUEST_CODE_ATTACH_IMAGE = 100;
    public static final int REQUEST_CODE_ATTACH_SOUND = 104;
    public static final int REQUEST_CODE_ATTACH_VIDEO = 102;
    public static final int REQUEST_CODE_CREATE_SLIDESHOW = 106;
    private static final int REQUEST_CODE_DO_ADD_CONTACTS = 1007;
    public static final int REQUEST_CODE_ECM_EXIT_DIALOG = 107;
    public static final int REQUEST_CODE_FROM_DRAFT = 1002;
    public static final int REQUEST_CODE_ITEM_ADD_TO_CONTACTS = 1006;
    public static final int REQUEST_CODE_NEW_MESSAGE = 1000;
    public static final int REQUEST_CODE_PICK = 109;
    public static final int REQUEST_CODE_RECORD_SOUND = 105;
    public static final int REQUEST_CODE_SEND_VIA_MMS = 1001;
    public static final int REQUEST_CODE_TAKE_PICTURE = 101;
    public static final int REQUEST_CODE_TAKE_VIDEO = 103;
    public static final int REQUEST_CODE_UNSEND_MESSAGE = 1000;
    private static final int SMOOTH_SCROLL_THRESHOLD = 200;
    private static final String SMS_DRAFT_WHERE = "type=3";
    private static final String SORT_ORDER_DATE_ASC = "date ASC";
    private static final String SORT_ORDER_DATE_DESC = "date DESC";
    private static final String TAG = "Mms";
    public static final String THREAD_ID = "thread_id";
    private static final boolean TRACE = false;
    private static final int WAITING_TIME_OF_VOICE = 1500;
    public static Activity instance;
    private static int keyGuideFlag;
    private static ISmsRingtoneService mISmsRingtoneService;
    private static final String mImageUri;
    private static boolean mReadyAttachment;
    private static ServiceConnection mServiceConnection;
    private static final String mVideoUri;
    static AlertDialogFp myDialog;
    private static ContactList sEmptyContactList;
    public static String selectedNumber;
    public static int subSelected;
    private MessageItem g_mMsgItem;
    private int g_msgList;
    private ListViewFP listView;
    private Intent mAddContactIntent;
    private AsyncDialog mAsyncDialog;
    private AttachmentEditor mAttachmentEditor;
    private View mAttachmentEditorScrollView;
    private AttachmentTypeSelectorAdapter mAttachmentTypeSelectorAdapter;
    private BackgroundQueryHandler mBackgroundQueryHandler;
    private View mBottomPanel;
    private ContentResolver mContentResolver;
    private Conversation mConversation;
    private String mDebugRecipients;
    private boolean mDeleteMsg;
    private boolean mForwardMessageMode;
    private boolean mIsDeleteDraftDialogDisp;
    private boolean mIsDialogDisp;
    private boolean mIsFromSendTo;
    private boolean mIsKeyboardOpen;
    private boolean mIsLandscape;
    private boolean mIsRunning;
    private boolean mIsSmsEnabled;
    private long mItemAdapterId;
    private long mLastMessageId;
    private int mLastRecipientCount;
    private int mLastSmoothScrollPosition;
    private Menu mMenu;
    private AppMenuHandler mMenuHandler;
    private MessageItem mMessageItem;
    private boolean mMessagesAndDraftLoaded;
    public MessageListAdapter mMsgListAdapter;
    private MessageListView mMsgListView;
    private AlertDialog mMsimDialog;
    private boolean mNeedToMarkAsSeen;
    private boolean mPossiblePendingNotification;
    private ProgressDialog mProgressDialog;
    private RecipientsEditor mRecipientsEditor;
    private ImageButton mRecipientsPicker;
    private boolean mScrollOnSend;
    private TextView mSendButtonMms;
    private ImageButton mSendButtonSms;
    private boolean mSendDiscreetMode;
    private boolean mSendingMessage;
    private boolean mSentMessage;
    private boolean mShouldLoadDraft;
    private AlertDialog mSmileyDialog;
    private SoftkeyView mSoftkey;
    private EditText mSubjectTextEditor;
    private Uri mTempMmsUri;
    private long mTempThreadId;
    private TextView mTextCounter;
    private MmsEditText mTextEditor;
    private long mThreadID;
    private View mTileFooterView;
    private boolean mToastForDraftSave;
    private View mTopPanel;
    private boolean mWaitingForSubActivity;
    private WorkingMessage mWorkingMessage;
    private int mSavedScrollPosition = -1;
    private int mSavedScrollPositionBack = -1;
    private int mSavedFirstScrollPosition = -1;
    private int mTop = -1;
    private int mOldSize = 0;
    private Handler mHandler = new Handler();
    private String mTitle = LoggingEvents.EXTRA_CALLING_APP_NAME;
    private View mGuidanceButton = null;
    private View mCreateNewMessageButton = null;
    private TextView mEmptyConversation = null;
    private boolean mIsAllMessageDeleted = false;
    private boolean mDialogVisibility = false;
    private boolean mIsSpeechStop = false;
    private String mAddressNumber = null;
    private int mPosition = 0;
    private boolean mVoiceCapable = true;
    boolean mIsSaveFocusTextEditor = false;
    private TextView tv_titles_top = null;
    private boolean mIsSelf = false;
    private boolean isFromOut = false;
    private boolean isReplyMessage = false;
    private boolean mStartSendNewMessage = false;
    boolean isSendNewMessage = false;
    private final Handler mAttachmentEditorHandler = new Handler() { // from class: com.android.mms.ui.ComposeMessageActivity.3
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    ComposeMessageActivity.this.editSlideshow();
                    break;
                case 2:
                    if (ComposeMessageActivity.this.isPreparedForSending()) {
                        ComposeMessageActivity.this.confirmSendMessageIfNeeded();
                    }
                    break;
                case 3:
                case 7:
                case 8:
                case 9:
                    MessageUtils.viewMmsMessageAttachment(ComposeMessageActivity.this, ComposeMessageActivity.this.mWorkingMessage, msg.what);
                    break;
                case 4:
                case 5:
                case 6:
                    ComposeMessageActivity.this.showAddAttachmentDialog(true);
                    break;
                case 10:
                    ComposeMessageActivity.this.mWorkingMessage.removeAttachment(true);
                    break;
            }
        }
    };
    private final Handler mMessageListItemHandler = new Handler() { // from class: com.android.mms.ui.ComposeMessageActivity.6
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            MessageItem msgItem = (MessageItem) msg.obj;
            if (msgItem != null) {
                switch (msg.what) {
                    case 1:
                        ComposeMessageActivity.this.editMessageItem(msgItem);
                        ComposeMessageActivity.this.drawBottomPanel();
                        break;
                    case 2:
                        switch (msgItem.mAttachmentType) {
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                MessageUtils.viewMmsMessageAttachment(ComposeMessageActivity.this, msgItem.mMessageUri, msgItem.mSlideshow, ComposeMessageActivity.this.getAsyncDialog());
                                break;
                        }
                        break;
                    case 3:
                        ComposeMessageActivity.this.showMessageDetails(msgItem);
                        break;
                    default:
                        Log.w("Mms", "Unknown message: " + msg.what);
                        break;
                }
            }
        }
    };
    private final View.OnKeyListener mSubjectKeyListener = new View.OnKeyListener() { // from class: com.android.mms.ui.ComposeMessageActivity.7
        @Override // android.view.View.OnKeyListener
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (event.getAction() != 0 || keyCode != 67 || ComposeMessageActivity.this.mSubjectTextEditor.length() != 0) {
                return false;
            }
            ComposeMessageActivity.this.showSubjectEditor(false);
            ComposeMessageActivity.this.mWorkingMessage.setSubject(null, true);
            return true;
        }
    };
    private Runnable mShowProgressDialogRunnable = new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.8
        @Override // java.lang.Runnable
        public void run() {
            if (ComposeMessageActivity.this.mProgressDialog != null) {
                ComposeMessageActivity.this.mProgressDialog.show();
            }
        }
    };
    private final TextWatcher mRecipientsWatcher = new TextWatcher() { // from class: com.android.mms.ui.ComposeMessageActivity.12
        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            ComposeMessageActivity.this.onUserInteraction();
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable s) {
            if (ComposeMessageActivity.this.isRecipientsEditorVisible()) {
                List<String> numbers = ComposeMessageActivity.this.mRecipientsEditor.getNumbers();
                ComposeMessageActivity.this.mWorkingMessage.setWorkingRecipients(numbers);
                boolean multiRecipients = numbers != null && numbers.size() > 1;
                ComposeMessageActivity.this.mMsgListAdapter.setIsGroupConversation(multiRecipients);
                ComposeMessageActivity.this.mWorkingMessage.setHasMultipleRecipients(multiRecipients, true);
                ComposeMessageActivity.this.mWorkingMessage.setHasEmail(ComposeMessageActivity.this.mRecipientsEditor.containsEmail(), true);
                ComposeMessageActivity.this.checkForTooManyRecipients();
                for (int pos = s.length() - 1; pos >= 0; pos--) {
                    char c = s.charAt(pos);
                    if (c != ' ') {
                        if (c != ',') {
                            break;
                        }
                        ComposeMessageActivity.this.updateTitle(ComposeMessageActivity.this.mConversation.getRecipients());
                        break;
                    }
                }
                ComposeMessageActivity.this.updateSendButtonState();
                return;
            }
            new IllegalStateException("afterTextChanged called with invisible mRecipientsEditor");
            Log.w("Mms", "RecipientsWatcher: afterTextChanged called with invisible mRecipientsEditor");
        }
    };
    private final View.OnCreateContextMenuListener mRecipientsMenuCreateListener = new View.OnCreateContextMenuListener() { // from class: com.android.mms.ui.ComposeMessageActivity.13
        @Override // android.view.View.OnCreateContextMenuListener
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            if (menuInfo != null) {
                Contact c = ((RecipientsEditor.RecipientContextMenuInfo) menuInfo).recipient;
                RecipientsMenuClickListener l = ComposeMessageActivity.this.new RecipientsMenuClickListener(c);
                menu.setHeaderTitle(c.getName());
                if (!c.existsInDatabase()) {
                    if (ComposeMessageActivity.this.canAddToContacts(c)) {
                        menu.add(0, 13, 0, ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.menu_add_to_contacts)).setOnMenuItemClickListener(l);
                        return;
                    }
                    return;
                }
                menu.add(0, 12, 0, ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.menu_view_contact)).setOnMenuItemClickListener(l);
            }
        }
    };
    private final View.OnCreateContextMenuListener mMsgListMenuCreateListener = new View.OnCreateContextMenuListener() { // from class: com.android.mms.ui.ComposeMessageActivity.14
        @Override // android.view.View.OnCreateContextMenuListener
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            if (ComposeMessageActivity.this.isCursorValid()) {
                Cursor cursor = ComposeMessageActivity.this.mMsgListAdapter.getCursor();
                String type = cursor.getString(0);
                long msgId = cursor.getLong(1);
                ComposeMessageActivity.this.mPosition = cursor.getPosition();
                ComposeMessageActivity.this.addPositionBasedMenuItems(menu, v, menuInfo);
                MessageItem msgItem = ComposeMessageActivity.this.mMsgListAdapter.getCachedMessageItem(type, msgId, cursor);
                if (msgItem == null) {
                    Log.e("Mms", "Cannot load message item for type = " + type + ", msgId = " + msgId);
                    return;
                }
                menu.setHeaderTitle(ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.message_options));
                MsgListMenuClickListener l = ComposeMessageActivity.this.new MsgListMenuClickListener(msgItem);
                if (msgItem.isSms()) {
                    if (ComposeMessageActivity.this.getRecipients().size() == 1 && (msgItem.mBoxId == 4 || msgItem.mBoxId == 5)) {
                        menu.add(0, 14, 0, ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.menu_edit)).setOnMenuItemClickListener(l);
                    }
                    menu.add(0, ComposeMessageActivity.MENU_COPY_MESSAGE_TEXT, 0, ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.copy_message_text)).setOnMenuItemClickListener(l);
                }
                ComposeMessageActivity.this.addCallAndContactMenuItems(menu, l, msgItem);
                if (msgItem.isDownloaded() && ((msgItem.isSms() || ComposeMessageActivity.this.isForwardable(msgId)) && ComposeMessageActivity.this.mIsSmsEnabled)) {
                    menu.add(0, 21, 0, ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.menu_forward)).setOnMenuItemClickListener(l);
                }
                if (msgItem.isMms()) {
                    switch (msgItem.mBoxId) {
                        case 4:
                            if (ComposeMessageActivity.this.getRecipients().size() == 1) {
                                menu.add(0, 14, 0, ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.menu_edit)).setOnMenuItemClickListener(l);
                            }
                            break;
                    }
                    switch (msgItem.mAttachmentType) {
                        case 0:
                            break;
                        case 1:
                        case 2:
                            if (ComposeMessageActivity.this.haveSomethingToCopyToSDCard(msgItem.mMsgId)) {
                                menu.add(0, ComposeMessageActivity.MENU_COPY_TO_SDCARD, 0, R.string.copy_to_sdcard).setOnMenuItemClickListener(l);
                            }
                            break;
                        default:
                            menu.add(0, 16, 0, R.string.view_slideshow).setOnMenuItemClickListener(l);
                            if (ComposeMessageActivity.this.haveSomethingToCopyToSDCard(msgItem.mMsgId)) {
                                menu.add(0, ComposeMessageActivity.MENU_COPY_TO_SDCARD, 0, R.string.copy_to_sdcard).setOnMenuItemClickListener(l);
                            }
                            if (ComposeMessageActivity.this.isDrmRingtoneWithRights(msgItem.mMsgId)) {
                                menu.add(0, ComposeMessageActivity.MENU_SAVE_RINGTONE, 0, ComposeMessageActivity.this.getDrmMimeMenuStringRsrc(msgItem.mMsgId)).setOnMenuItemClickListener(l);
                            }
                            break;
                    }
                }
                if (!msgItem.mLocked || !ComposeMessageActivity.this.mIsSmsEnabled) {
                    if (ComposeMessageActivity.this.mIsSmsEnabled) {
                        menu.add(0, ComposeMessageActivity.MENU_LOCK_MESSAGE, 0, R.string.menu_lock).setOnMenuItemClickListener(l);
                    }
                } else {
                    menu.add(0, ComposeMessageActivity.MENU_UNLOCK_MESSAGE, 0, R.string.menu_unlock).setOnMenuItemClickListener(l);
                }
                menu.add(0, 17, 0, R.string.view_message_details).setOnMenuItemClickListener(l);
                if (msgItem.mDeliveryStatus != MessageItem.DeliveryStatus.NONE || msgItem.mReadReport) {
                    menu.add(0, 20, 0, R.string.view_delivery_report).setOnMenuItemClickListener(l);
                }
                if (ComposeMessageActivity.this.mIsSmsEnabled) {
                    menu.add(0, 18, 0, ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.delete_message)).setOnMenuItemClickListener(l);
                }
            }
        }
    };
    private final IntentFilter mHttpProgressFilter = new IntentFilter(ProgressCallbackEntity.PROGRESS_STATUS_ACTION);
    private final BroadcastReceiver mHttpProgressReceiver = new BroadcastReceiver() { // from class: com.android.mms.ui.ComposeMessageActivity.18
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (ProgressCallbackEntity.PROGRESS_STATUS_ACTION.equals(intent.getAction())) {
                long token = intent.getLongExtra("token", -1L);
                if (token == ComposeMessageActivity.this.mConversation.getThreadId()) {
                    int progress = intent.getIntExtra("progress", 0);
                    switch (progress) {
                        case -2:
                        case 100:
                            ComposeMessageActivity.this.setProgressBarVisibility(false);
                            break;
                        case -1:
                            ComposeMessageActivity.this.setProgressBarVisibility(true);
                            break;
                        default:
                            ComposeMessageActivity.this.setProgress(progress * 100);
                            break;
                    }
                }
            }
        }
    };
    Runnable mResetMessageRunnable = new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.32
        @Override // java.lang.Runnable
        public void run() {
            ComposeMessageActivity.this.resetMessage();
        }
    };
    private final MessageUtils.ResizeImageResultCallback mResizeImageCallback = new MessageUtils.ResizeImageResultCallback() { // from class: com.android.mms.ui.ComposeMessageActivity.48
        @Override // com.android.mms.ui.MessageUtils.ResizeImageResultCallback
        public void onResizeResult(PduPart part, boolean append) {
            int result;
            if (part == null) {
                ComposeMessageActivity.this.handleAddAttachmentError(-1, R.string.type_picture);
                return;
            }
            PduPersister persister = PduPersister.getPduPersister(ComposeMessageActivity.this);
            Uri messageUri = ComposeMessageActivity.this.mWorkingMessage.saveAsMms(true);
            if (messageUri == null) {
                result = -1;
            } else {
                try {
                    Uri dataUri = persister.persistPart(part, ContentUris.parseId(messageUri), (HashMap) null);
                    result = ComposeMessageActivity.this.mWorkingMessage.setAttachment(1, dataUri, append);
                    if (Log.isLoggable("Mms", 2)) {
                        ComposeMessageActivity.log("ResizeImageResultCallback: dataUri=" + dataUri);
                    }
                } catch (MmsException e) {
                    result = -1;
                }
            }
            ComposeMessageActivity.this.handleAddAttachmentError(result, R.string.type_picture);
        }
    };
    private boolean isShowingDialog = false;
    private boolean isBlockingFinish = false;
    private boolean isDeleteAll = false;
    private Handler mDeletedHandler = new Handler() { // from class: com.android.mms.ui.ComposeMessageActivity.54
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    String message = ComposeMessageActivity.this.getString(ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.delete_success_message));
                    ComposeMessageActivity.this.showCompleteDialog(message);
                    break;
            }
        }
    };
    private final TextWatcher mTextEditorWatcher = new TextWatcher() { // from class: com.android.mms.ui.ComposeMessageActivity.57
        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            ComposeMessageActivity.this.onUserInteraction();
            ComposeMessageActivity.this.mWorkingMessage.setText(s);
            ComposeMessageActivity.this.updateSendButtonState();
            ComposeMessageActivity.this.updateCounter(s, start, before, count);
            ComposeMessageActivity.this.ensureCorrectButtonHeight();
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable s) {
        }
    };
    private final TextWatcher mSubjectEditorWatcher = new TextWatcher() { // from class: com.android.mms.ui.ComposeMessageActivity.58
        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            ComposeMessageActivity.this.mWorkingMessage.setSubject(s, true);
            ComposeMessageActivity.this.updateSendButtonState();
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable s) {
        }
    };
    private final MessageListAdapter.OnDataSetChangedListener mDataSetChangedListener = new MessageListAdapter.OnDataSetChangedListener() { // from class: com.android.mms.ui.ComposeMessageActivity.64
        @Override // com.android.mms.ui.MessageListAdapter.OnDataSetChangedListener
        public void onDataSetChanged(MessageListAdapter adapter) {
            ComposeMessageActivity.this.mPossiblePendingNotification = true;
        }

        @Override // com.android.mms.ui.MessageListAdapter.OnDataSetChangedListener
        public void onContentChanged(MessageListAdapter adapter) {
            ComposeMessageActivity.this.startMsgListQuery();
            MessagingNotification.sUsersAction = false;
        }
    };
    private boolean mIsScreenOff = false;
    private boolean mIsForeground = false;
    private OnScreenReceiver mScreenReceiver = new OnScreenReceiver();

    static {
        FJ_TEL_LOG_ACQ_FLG = SystemProperties.getInt("ro.debuggable", 0) == 0;
        myDialog = null;
        keyGuideFlag = 0;
        subSelected = 0;
        mReadyAttachment = false;
        selectedNumber = null;
        mISmsRingtoneService = null;
        mServiceConnection = new ServiceConnection() { // from class: com.android.mms.ui.ComposeMessageActivity.21
            @Override // android.content.ServiceConnection
            public void onServiceConnected(ComponentName name, IBinder binder) {
                ISmsRingtoneService unused = ComposeMessageActivity.mISmsRingtoneService = ISmsRingtoneService.Stub.asInterface(binder);
            }

            @Override // android.content.ServiceConnection
            public void onServiceDisconnected(ComponentName name) {
                ISmsRingtoneService unused = ComposeMessageActivity.mISmsRingtoneService = null;
            }
        };
        mVideoUri = MediaStore.Video.Media.getContentUri("external").toString();
        mImageUri = MediaStore.Images.Media.getContentUri("external").toString();
    }

    public static void log(String logMsg) {
        Thread current = Thread.currentThread();
        long tid = current.getId();
        StackTraceElement[] stack = current.getStackTrace();
        String methodName = stack[3].getMethodName();
        Log.d("Mms", "[" + tid + "] [" + methodName + "] " + logMsg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void editSlideshow() {
        getAsyncDialog().runAsync(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.1
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.mTempMmsUri = ComposeMessageActivity.this.mWorkingMessage.saveAsMms(false);
            }
        }, new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.2
            @Override // java.lang.Runnable
            public void run() {
                if (ComposeMessageActivity.this.mTempMmsUri != null) {
                    Intent intent = new Intent((Context) ComposeMessageActivity.this, (Class<?>) SlideshowEditActivity.class);
                    intent.setData(ComposeMessageActivity.this.mTempMmsUri);
                    ComposeMessageActivity.this.startActivityForResult(intent, ComposeMessageActivity.REQUEST_CODE_CREATE_SLIDESHOW);
                }
            }
        }, R.string.building_slideshow_title);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void viewMmsMessageAttachment(final int requestCode) {
        SlideshowModel slideshow = this.mWorkingMessage.getSlideshow();
        if (slideshow == null) {
            throw new IllegalStateException("mWorkingMessage.getSlideshow() == null");
        }
        if (slideshow.isSimple()) {
            MessageUtils.viewSimpleSlideshow(this, slideshow);
        } else {
            getAsyncDialog().runAsync(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.4
                @Override // java.lang.Runnable
                public void run() {
                    ComposeMessageActivity.this.mTempMmsUri = ComposeMessageActivity.this.mWorkingMessage.saveAsMms(false);
                }
            }, new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.5
                @Override // java.lang.Runnable
                public void run() {
                    if (ComposeMessageActivity.this.mTempMmsUri != null) {
                        MessageUtils.launchSlideshowActivity(ComposeMessageActivity.this, ComposeMessageActivity.this.mTempMmsUri, requestCode);
                    }
                }
            }, R.string.building_slideshow_title);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public boolean showMessageDetails(MessageItem msgItem) {
        Cursor cursor = this.mMsgListAdapter.getCursorForItem(msgItem);
        if (cursor == null) {
            return false;
        }
        String messageDetails = MessageUtils.getMessageDetails(this, cursor, msgItem.mMessageSize);
        new AlertDialog.Builder(this).setTitle(ModeStringUtil.getModeResFromArray(this, R.array.message_details_title)).setMessage(messageDetails).setCancelable(true).show();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public MessageItem getMessageItem(String type, long msgId, boolean createFromCursorIfNotInCache) {
        return this.mMsgListAdapter.getCachedMessageItem(type, msgId, createFromCursorIfNotInCache ? this.mMsgListAdapter.getCursor() : null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isCursorValid() {
        Cursor cursor = this.mMsgListAdapter.getCursor();
        if (!cursor.isClosed() && !cursor.isBeforeFirst() && !cursor.isAfterLast()) {
            return true;
        }
        Log.e("Mms", "Bad cursor.", new RuntimeException());
        return false;
    }

    private void resetCounter() {
        this.mTextCounter.setText(LoggingEvents.EXTRA_CALLING_APP_NAME);
        this.mTextCounter.setVisibility(8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateCounter(CharSequence text, int start, int before, int count) {
        boolean z = false;
        WorkingMessage workingMessage = this.mWorkingMessage;
        if (workingMessage.requiresMms()) {
            boolean textRemoved = before > count;
            if (!textRemoved) {
                showSmsOrMmsSendButton(workingMessage.requiresMms());
                return;
            }
        }
        int[] params = SmsMessage.calculateLength(text, false);
        int msgCount = params[0];
        int remainingInCurrentMessage = params[2];
        if (!MmsConfig.getMultipartSmsEnabled()) {
            this.mWorkingMessage.setLengthRequiresMms(msgCount > 1, true);
        } else {
            int threshold = MmsConfig.getSmsToMmsTextThreshold();
            WorkingMessage workingMessage2 = this.mWorkingMessage;
            if (threshold > 0 && msgCount > threshold) {
                z = true;
            }
            workingMessage2.setLengthRequiresMms(z, true);
        }
        boolean showCounter = false;
        if (!workingMessage.requiresMms() && (msgCount > 1 || remainingInCurrentMessage <= 10)) {
            showCounter = true;
        }
        showSmsOrMmsSendButton(workingMessage.requiresMms());
        if (showCounter) {
            String counterText = msgCount > 1 ? remainingInCurrentMessage + " / " + msgCount : String.valueOf(remainingInCurrentMessage);
            this.mTextCounter.setText(counterText);
        } else {
            this.mTextCounter.setVisibility(8);
        }
    }

    public void startActivityForResult(Intent intent, int requestCode) {
        if (requestCode >= 0) {
            this.mWaitingForSubActivity = true;
        }
        if (this.mIsKeyboardOpen && !"android.provider.action.QUICK_CONTACT".equals(intent.getAction())) {
            hideKeyboard();
        }
        super.startActivityForResult(intent, requestCode);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void toastConvertInfo(boolean toMms) {
        int resId = toMms ? R.string.converting_to_picture_message : R.string.converting_to_text_message;
        Toast.makeText((Context) this, resId, 0).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showConvertToMmsToast() {
        Toast.makeText((Context) this, R.string.converting_to_picture_message, 0).show();
    }

    private class DeleteMessageListener implements DialogInterface.OnClickListener {
        public DeleteMessageListener(MessageItem messageItem) {
        }

        /* JADX WARN: Type inference failed for: r1v2, types: [com.android.mms.ui.ComposeMessageActivity$DeleteMessageListener$1] */
        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int whichButton) {
            dialog.dismiss();
            ComposeMessageActivity.this.mDialogVisibility = false;
            final MessageItem mMessageItem = ComposeMessageActivity.this.g_mMsgItem;
            new AsyncTask<Void, Void, Void>() { // from class: com.android.mms.ui.ComposeMessageActivity.DeleteMessageListener.1
                /* JADX INFO: Access modifiers changed from: protected */
                @Override // android.os.AsyncTask
                public Void doInBackground(Void... none) {
                    if (mMessageItem.isMms()) {
                        WorkingMessage.removeThumbnailsFromCache(mMessageItem.getSlideshow());
                        MmsApp.getApplication().getPduLoaderManager().removePdu(mMessageItem.mMessageUri);
                    }
                    boolean deletingLastItem = false;
                    Cursor cursor = ComposeMessageActivity.this.mMsgListAdapter != null ? ComposeMessageActivity.this.mMsgListAdapter.getCursor() : null;
                    if (cursor != null) {
                        cursor.moveToLast();
                        long msgId = cursor.getLong(1);
                        deletingLastItem = Boolean.valueOf(msgId == mMessageItem.mMsgId);
                    }
                    ComposeMessageActivity.this.mBackgroundQueryHandler.startDelete(ComposeMessageActivity.DELETE_MESSAGE_TOKEN, deletingLastItem, mMessageItem.mMessageUri, mMessageItem.mLocked ? null : "locked=0", null);
                    return null;
                }
            }.execute(new Void[0]);
        }
    }

    private class DiscardDraftListener implements DialogInterface.OnClickListener {
        private DiscardDraftListener() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int whichButton) {
            ComposeMessageActivity.this.mWorkingMessage.discard();
            dialog.dismiss();
            ComposeMessageActivity.this.finish();
        }
    }

    private class SendIgnoreInvalidRecipientListener implements DialogInterface.OnClickListener {
        private SendIgnoreInvalidRecipientListener() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int whichButton) {
            if (TelephonyManager.getDefault().getPhoneCount() > 1) {
                ComposeMessageActivity.this.sendMsimMessage(true);
            } else {
                ComposeMessageActivity.this.sendMessage(true);
            }
            dialog.dismiss();
        }
    }

    private class CancelSendingListener implements DialogInterface.OnClickListener {
        private CancelSendingListener() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int whichButton) {
            if (ComposeMessageActivity.this.isRecipientsEditorVisible()) {
                ComposeMessageActivity.this.mRecipientsEditor.requestFocus();
            }
            dialog.dismiss();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dismissMsimDialog() {
        if (this.mMsimDialog != null) {
            this.mMsimDialog.dismiss();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void processMsimSendMessage(int phoneId, boolean bCheckEcmMode) {
        if (this.mMsimDialog != null) {
            this.mMsimDialog.dismiss();
        }
        this.mWorkingMessage.setWorkingMessageSub(phoneId);
        sendMessage(bCheckEcmMode);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void LaunchMsimDialog(final boolean bCheckEcmMode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = (LayoutInflater) getSystemService("layout_inflater");
        View layout = inflater.inflate(R.layout.multi_sim_sms_sender, (ViewGroup) findViewById(R.id.layout_root));
        builder.setView(layout);
        builder.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.android.mms.ui.ComposeMessageActivity.9
            @Override // android.content.DialogInterface.OnKeyListener
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                switch (keyCode) {
                    case 4:
                        ComposeMessageActivity.this.dismissMsimDialog();
                        return true;
                    case 84:
                        return true;
                    default:
                        return false;
                }
            }
        });
        builder.setNegativeButton(ModeStringUtil.getModeResFromArray(this, R.array.no), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.10
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                ComposeMessageActivity.this.dismissMsimDialog();
            }
        });
        ContactList recipients = isRecipientsEditorVisible() ? this.mRecipientsEditor.constructContactsFromInput(false) : getRecipients();
        builder.setTitle(getResources().getString(R.string.to_address_label) + recipients.formatNamesAndNumbers(MessageDispActivity.string_delimiter));
        this.mMsimDialog = builder.create();
        this.mMsimDialog.setCanceledOnTouchOutside(true);
        int[] smsBtnIds = {R.id.BtnSimOne, R.id.BtnSimTwo, R.id.BtnSimThree};
        int phoneCount = TelephonyManager.getDefault().getPhoneCount();
        Button[] smsBtns = new Button[phoneCount];
        for (int i = 0; i < phoneCount; i++) {
            final int phoneId = i;
            smsBtns[i] = (Button) layout.findViewById(smsBtnIds[i]);
            smsBtns[i].setVisibility(0);
            SubscriptionInfo sir = SubscriptionManager.from(this).getActiveSubscriptionInfoForSimSlotIndex(phoneId);
            String displayName = sir != null ? sir.getDisplayName().toString() : "SIM " + (i + 1);
            Log.e("Mms", "PhoneID : " + phoneId + " displayName " + displayName);
            smsBtns[i].setText(displayName);
            smsBtns[i].setOnClickListener(new View.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.11
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    Log.d("Mms", "Phone Id slected " + phoneId);
                    ComposeMessageActivity.this.processMsimSendMessage(phoneId, bCheckEcmMode);
                }
            });
        }
        this.mMsimDialog.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendMsimMessage(boolean bCheckEcmMode) {
        if (SubscriptionManager.isSMSPromptEnabled()) {
            LaunchMsimDialog(bCheckEcmMode);
            return;
        }
        int subId = SubscriptionManager.getDefaultSmsSubId();
        int phoneId = SubscriptionManager.getPhoneId(subId);
        this.mWorkingMessage.setWorkingMessageSub(phoneId);
        sendMessage(bCheckEcmMode);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void confirmSendMessageIfNeeded() {
        boolean max_exceed_flag = isMaximumCharactersExceed();
        if (max_exceed_flag) {
            new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle(ModeStringUtil.getModeResFromArray(this, R.array.cannot_send_message)).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.max_characters_exceed)).setPositiveButton(R.string.monaka_yes, new CancelSendingListener()).show();
            return;
        }
        if (!isRecipientsEditorVisible()) {
            if (TelephonyManager.getDefault().getPhoneCount() > 1) {
                sendMsimMessage(true);
                return;
            } else {
                sendMessage(true);
                return;
            }
        }
        boolean isMms = this.mWorkingMessage.requiresMms();
        if (this.mRecipientsEditor.hasInvalidRecipient(isMms)) {
            if (this.mRecipientsEditor.hasValidRecipient(isMms)) {
                String title = getResourcesString(ModeStringUtil.getModeResFromArray(this, R.array.has_invalid_recipient), this.mRecipientsEditor.formatInvalidNumbers(isMms));
                new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle(title).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.invalid_recipient_message)).setPositiveButton(ModeStringUtil.getModeResFromArray(this, R.array.try_to_send), new SendIgnoreInvalidRecipientListener()).setNegativeButton(R.string.monaka_no, new CancelSendingListener()).show().getButton(-2).requestFocus();
                return;
            } else {
                new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle(ModeStringUtil.getModeResFromArray(this, R.array.cannot_send_message)).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.cannot_send_message_reason)).setPositiveButton(R.string.monaka_yes, new CancelSendingListener()).show();
                return;
            }
        }
        ContactList contacts = this.mRecipientsEditor.constructContactsFromInput(false);
        this.mDebugRecipients = contacts.serialize();
        if (TelephonyManager.getDefault().getPhoneCount() > 1) {
            sendMsimMessage(true);
        } else {
            sendMessage(true);
        }
    }

    private boolean isMaximumCharactersExceed() {
        int remainingInCurrentMessage;
        CharSequence text = this.mWorkingMessage.getText();
        int[] params = SmsMessage.calculateLength(text, false);
        int msgInputedNumber = params[1];
        int msgEncodingType = params[3];
        if (msgEncodingType == 1) {
            remainingInCurrentMessage = 160 - msgInputedNumber;
        } else {
            remainingInCurrentMessage = 70 - msgInputedNumber;
        }
        return remainingInCurrentMessage < 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void checkForTooManyRecipients() {
        int recipientLimit = MmsConfig.getRecipientLimit();
        if (recipientLimit != Integer.MAX_VALUE && recipientLimit > 0) {
            int recipientCount = recipientCount();
            boolean tooMany = recipientCount > recipientLimit;
            if (recipientCount != this.mLastRecipientCount) {
                this.mLastRecipientCount = recipientCount;
                if (tooMany) {
                    String tooManyMsg = getString(ModeStringUtil.getModeResFromArray(this, R.array.too_many_recipients), new Object[]{Integer.valueOf(recipientCount), Integer.valueOf(recipientLimit)});
                    AlertDialogFp toast = new AlertDialogFp.Builder(this).setMessage(tooManyMsg).create();
                    toast.setAutoDismiss(true);
                    MessageUtils.dialogEndCallToHome(this, toast);
                    toast.show();
                }
            }
        }
    }

    private final class RecipientsMenuClickListener implements MenuItem.OnMenuItemClickListener {
        private final Contact mRecipient;

        RecipientsMenuClickListener(Contact recipient) {
            this.mRecipient = recipient;
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem item) {
            switch (item.getItemId()) {
                case 12:
                    Uri contactUri = this.mRecipient.getUri();
                    Intent intent = new Intent("android.intent.action.VIEW", contactUri);
                    intent.setFlags(AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END);
                    ComposeMessageActivity.this.startActivity(intent);
                    return true;
                case 13:
                    ComposeMessageActivity.this.mAddContactIntent = ConversationList.createAddContactIntent(this.mRecipient.getNumber());
                    ComposeMessageActivity.this.startActivityForResult(ComposeMessageActivity.this.mAddContactIntent, ComposeMessageActivity.REQUEST_CODE_ADD_CONTACT);
                    return true;
                default:
                    return false;
            }
        }
    }

    private boolean isPhoneNumber(Contact contact) {
        String number = contact.getNumber();
        return !TextUtils.isEmpty(number) && Telephony.Mms.isPhoneNumber(number);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean canAddToContacts(Contact contact) {
        String name = contact.getName();
        if (!TextUtils.isEmpty(contact.getNumber())) {
            char c = contact.getNumber().charAt(0);
            if (isSpecialChar(c)) {
                return false;
            }
        }
        if (!TextUtils.isEmpty(name)) {
            char c2 = name.charAt(0);
            if (isSpecialChar(c2)) {
                return false;
            }
        }
        return (Telephony.Mms.isEmailAddress(name) || Telephony.Mms.isPhoneNumber(name) || contact.isMe()) && !DISP_ORIGINATING_ADDRESS.equals(name);
    }

    private boolean isSpecialChar(char c) {
        return c == '*' || c == '%' || c == '$';
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void addPositionBasedMenuItems(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        try {
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;
            int position = info.position;
            addUriSpecificMenuItems(menu, v, position);
        } catch (ClassCastException e) {
            Log.e("Mms", "bad menuInfo");
        }
    }

    private Uri getSelectedUriFromMessageList(ListView listView, int position) {
        MessageListItem msglistItem = (MessageListItem) listView.getChildAt(position);
        if (msglistItem == null) {
            return null;
        }
        CharSequence text = null;
        int selStart = -1;
        int selEnd = -1;
        TextView textView = (TextView) msglistItem.findViewById(R.id.text_view);
        if (textView != null) {
            text = textView.getText();
            selStart = textView.getSelectionStart();
            selEnd = textView.getSelectionEnd();
        }
        if (selStart == selEnd) {
            return null;
        }
        int min = Math.min(selStart, selEnd);
        int max = Math.max(selStart, selEnd);
        URLSpan[] urls = (URLSpan[]) ((Spanned) text).getSpans(min, max, URLSpan.class);
        if (urls.length == 1) {
            return Uri.parse(urls[0].getURL());
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addUriSpecificMenuItems(ContextMenu menu, View v, int position) {
        Uri uri = getSelectedUriFromMessageList((ListView) v, position);
        if (uri != null) {
            Intent intent = new Intent((String) null, uri);
            intent.addCategory("android.intent.category.SELECTED_ALTERNATIVE");
            menu.addIntentOptions(0, 0, 0, new ComponentName((Context) this, (Class<?>) ComposeMessageActivity.class), null, intent, 0, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public final void addCallAndContactMenuItems(ContextMenu menu, MsgListMenuClickListener l, MessageItem msgItem) {
        if (!TextUtils.isEmpty(msgItem.mBody)) {
            SpannableString msg = new SpannableString(msgItem.mBody);
            Linkify.addLinks(msg, 15);
            ArrayList<String> uris = MessageUtils.extractUris((URLSpan[]) msg.getSpans(0, msg.length(), URLSpan.class));
            HashSet<String> collapsedUris = new HashSet<>();
            for (String uri : uris) {
                collapsedUris.add(uri.toLowerCase());
            }
            for (String uriString : collapsedUris) {
                String prefix = null;
                int sep = uriString.indexOf(":");
                if (sep >= 0) {
                    prefix = uriString.substring(0, sep);
                    uriString = uriString.substring(sep + 1);
                }
                Uri contactUri = null;
                boolean knownPrefix = true;
                if ("mailto".equalsIgnoreCase(prefix)) {
                    contactUri = getContactUriForEmail(uriString);
                } else if (Contact.TEL_SCHEME.equalsIgnoreCase(prefix)) {
                    contactUri = getContactUriForPhoneNumber(uriString);
                } else {
                    knownPrefix = false;
                }
                if (knownPrefix && contactUri == null) {
                    Intent intent = ConversationList.createAddContactIntent(uriString);
                    String addContactString = getString(ModeStringUtil.getModeResFromArray(this, R.array.menu_add_address_to_contacts), new Object[]{uriString});
                    menu.add(0, MENU_ADD_ADDRESS_TO_CONTACTS, 0, addContactString).setOnMenuItemClickListener(l).setIntent(intent);
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private Uri getContactUriForEmail(String emailAddress) {
        Uri uriWithAppendedId = null;
        Cursor cursor = SqliteWrapper.query(this, getContentResolver(), Uri.withAppendedPath(ContactsContract.CommonDataKinds.Email.CONTENT_LOOKUP_URI, Uri.encode(emailAddress)), new String[]{"contact_id", "display_name"}, (String) null, (String[]) null, (String) null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                try {
                    String name = cursor.getString(1);
                    if (!TextUtils.isEmpty(name)) {
                        uriWithAppendedId = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, cursor.getLong(0));
                        cursor.close();
                    }
                } catch (Throwable th) {
                    cursor.close();
                    throw th;
                }
            }
            cursor.close();
        }
        return uriWithAppendedId;
    }

    private Uri getContactUriForPhoneNumber(String phoneNumber) {
        Contact contact = Contact.get(phoneNumber, false);
        if (contact.existsInDatabase()) {
            return contact.getUri();
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void editMessageItem(MessageItem msgItem) {
        if ("sms".equals(msgItem.mType)) {
            editSmsMessageItem(msgItem);
        } else {
            editMmsMessageItem(msgItem);
        }
        if (!msgItem.isFailedMessage() || this.mMsgListAdapter.getCount() <= 1) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void editSmsMessageItem(MessageItem msgItem) {
        synchronized (this.mConversation) {
            if (this.mConversation.getMessageCount() <= 1) {
                this.mConversation.clearThreadId();
                MessagingNotification.setCurrentlyDisplayedThreadId(-2L);
            }
        }
        Uri uri = ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, msgItem.mMsgId);
        SqliteWrapper.delete(this, this.mContentResolver, uri, (String) null, (String[]) null);
        this.mWorkingMessage.setText(msgItem.mBody);
    }

    private void editMmsMessageItem(MessageItem msgItem) {
        WorkingMessage newWorkingMessage = WorkingMessage.load(this, msgItem.mMessageUri);
        if (newWorkingMessage != null) {
            this.mWorkingMessage.discard();
            this.mWorkingMessage = newWorkingMessage;
            this.mWorkingMessage.setConversation(this.mConversation);
            invalidateOptionsMenu();
            drawTopPanel(false);
            this.mWorkingMessage.setSubject(msgItem.mSubject, false);
            if (this.mWorkingMessage.hasSubject()) {
                showSubjectEditor(true);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void copyToClipboard(String str) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService("clipboard");
        clipboard.setPrimaryClip(ClipData.newPlainText(null, str));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void forwardMessage(final MessageItem msgItem) {
        this.mTempThreadId = 0L;
        getAsyncDialog().runAsync(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.15
            @Override // java.lang.Runnable
            public void run() {
                if (msgItem.mType.equals("mms")) {
                    SendReq sendReq = new SendReq();
                    String subject = ComposeMessageActivity.this.getString(R.string.forward_prefix);
                    if (msgItem.mSubject != null) {
                        subject = subject + msgItem.mSubject;
                    }
                    sendReq.setSubject(new EncodedStringValue(subject));
                    sendReq.setBody(msgItem.mSlideshow.makeCopy());
                    ComposeMessageActivity.this.mTempMmsUri = null;
                    try {
                        PduPersister persister = PduPersister.getPduPersister(ComposeMessageActivity.this);
                        ComposeMessageActivity.this.mTempMmsUri = persister.persist(sendReq, Telephony.Mms.Draft.CONTENT_URI, true, MessagingPreferenceActivity.getIsGroupMmsEnabled(ComposeMessageActivity.this), (HashMap) null);
                        ComposeMessageActivity.this.mTempThreadId = MessagingNotification.getThreadId(ComposeMessageActivity.this, ComposeMessageActivity.this.mTempMmsUri);
                    } catch (MmsException e) {
                        Log.e("Mms", "Failed to copy message: " + msgItem.mMessageUri);
                        AlertDialogFp toast = new AlertDialogFp.Builder(ComposeMessageActivity.this).setMessage(ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.cannot_save_message)).create();
                        toast.setAutoDismiss(true);
                        MessageUtils.dialogEndCallToHome(ComposeMessageActivity.this, toast);
                        toast.show();
                    }
                }
            }
        }, new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.16
            /* JADX WARN: Type inference fix 'apply assigned field type' failed
            java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
            	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
            	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
            	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
            	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
            	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
            	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
            	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
             */
            @Override // java.lang.Runnable
            public void run() {
                Intent intentCreateIntent = ComposeMessageActivity.createIntent(ComposeMessageActivity.this, 0L);
                intentCreateIntent.putExtra(ComposeMessageActivity.KEY_EXIT_ON_SENT, true);
                intentCreateIntent.putExtra(ComposeMessageActivity.KEY_FORWARDED_MESSAGE, true);
                if (ComposeMessageActivity.this.mTempThreadId > 0) {
                    intentCreateIntent.putExtra(ComposeMessageActivity.THREAD_ID, ComposeMessageActivity.this.mTempThreadId);
                }
                if (msgItem.mType.equals("sms")) {
                    intentCreateIntent.putExtra("sms_body", msgItem.mBody);
                } else {
                    intentCreateIntent.putExtra("msg_uri", ComposeMessageActivity.this.mTempMmsUri);
                    String subject = ComposeMessageActivity.this.getString(R.string.forward_prefix);
                    if (msgItem.mSubject != null) {
                        subject = subject + msgItem.mSubject;
                    }
                    intentCreateIntent.putExtra("subject", subject);
                    String[] numbers = ComposeMessageActivity.this.mConversation.getRecipients().getNumbers();
                    if (numbers != null) {
                        intentCreateIntent.putExtra("msg_recipient", numbers[0]);
                    }
                }
                intentCreateIntent.setClassName((Context) ComposeMessageActivity.this, "com.android.mms.ui.ForwardMessageActivity");
                ComposeMessageActivity.this.startActivity(intentCreateIntent);
            }
        }, R.string.building_slideshow_title);
    }

    private final class MsgListMenuClickListener implements MenuItem.OnMenuItemClickListener {
        private MessageItem mMsgItem;

        public MsgListMenuClickListener(MessageItem msgItem) {
            this.mMsgItem = msgItem;
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem item) {
            if (!ComposeMessageActivity.this.isCursorValid()) {
                return false;
            }
            Cursor cursor = ComposeMessageActivity.this.mMsgListAdapter.getCursor();
            cursor.moveToPosition(ComposeMessageActivity.this.mPosition);
            String type = cursor.getString(0);
            long msgId = cursor.getLong(1);
            ComposeMessageActivity.this.getMessageItem(type, msgId, true);
            if (this.mMsgItem != null) {
                switch (item.getItemId()) {
                    case 14:
                        ComposeMessageActivity.this.editMessageItem(this.mMsgItem);
                        ComposeMessageActivity.this.drawBottomPanel();
                        return true;
                    case 15:
                    case 19:
                    case 22:
                    case 23:
                    case 26:
                    case ComposeMessageActivity.MENU_ADD_ADDRESS_TO_CONTACTS /* 27 */:
                    default:
                        return false;
                    case 16:
                        return true;
                    case 17:
                        return ComposeMessageActivity.this.showMessageDetails(this.mMsgItem);
                    case 18:
                        DeleteMessageListener l = ComposeMessageActivity.this.new DeleteMessageListener(this.mMsgItem);
                        ComposeMessageActivity.this.confirmDeleteDialog(l, this.mMsgItem.mLocked);
                        return true;
                    case 20:
                        ComposeMessageActivity.this.showDeliveryReport(this.mMsgItem.mMsgId, this.mMsgItem.mType);
                        return true;
                    case 21:
                        ComposeMessageActivity.this.forwardMessage(this.mMsgItem);
                        return true;
                    case ComposeMessageActivity.MENU_COPY_MESSAGE_TEXT /* 24 */:
                        ComposeMessageActivity.this.copyToClipboard(this.mMsgItem.mBody);
                        return true;
                    case ComposeMessageActivity.MENU_COPY_TO_SDCARD /* 25 */:
                        int resId = ComposeMessageActivity.this.copyMedia(this.mMsgItem.mMsgId) ? R.string.copy_to_sdcard_success : R.string.copy_to_sdcard_fail;
                        Toast.makeText((Context) ComposeMessageActivity.this, resId, 0).show();
                        return true;
                    case ComposeMessageActivity.MENU_LOCK_MESSAGE /* 28 */:
                        ComposeMessageActivity.this.lockMessage(this.mMsgItem, true);
                        return true;
                    case ComposeMessageActivity.MENU_UNLOCK_MESSAGE /* 29 */:
                        ComposeMessageActivity.this.lockMessage(this.mMsgItem, false);
                        return true;
                    case ComposeMessageActivity.MENU_SAVE_RINGTONE /* 30 */:
                        int resId2 = ComposeMessageActivity.this.getDrmMimeSavedStringRsrc(this.mMsgItem.mMsgId, ComposeMessageActivity.this.saveRingtone(this.mMsgItem.mMsgId));
                        Toast.makeText((Context) ComposeMessageActivity.this, resId2, 0).show();
                        return true;
                }
            }
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void lockMessage(MessageItem msgItem, boolean locked) {
        Uri uri;
        if ("sms".equals(msgItem.mType)) {
            uri = Telephony.Sms.CONTENT_URI;
        } else {
            uri = Telephony.Mms.CONTENT_URI;
        }
        final Uri lockUri = ContentUris.withAppendedId(uri, msgItem.mMsgId);
        final ContentValues values = new ContentValues(1);
        values.put("locked", Integer.valueOf(locked ? 1 : 0));
        new Thread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.17
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.getContentResolver().update(lockUri, values, null, null);
            }
        }, "ComposeMessageActivity.lockMessage").start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    /* JADX WARN: Multi-variable type inference failed */
    public boolean haveSomethingToCopyToSDCard(long msgId) {
        PduBody body = null;
        try {
            body = SlideshowModel.getPduBody(this, ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, msgId));
        } catch (MmsException e) {
            Log.e("Mms", "haveSomethingToCopyToSDCard can't load pdu body: " + msgId);
        }
        if (body == null) {
            return false;
        }
        int partNum = body.getPartsNum();
        for (int i = 0; i < partNum; i++) {
            PduPart part = body.getPart(i);
            String type = new String(part.getContentType());
            if (Log.isLoggable("Mms", 2)) {
                log("[CMA] haveSomethingToCopyToSDCard: part[" + i + "] contentType=" + type);
            }
            if (ContentType.isImageType(type) || ContentType.isVideoType(type) || ContentType.isAudioType(type) || DrmUtils.isDrmType(type)) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    /* JADX WARN: Multi-variable type inference failed */
    public boolean saveRingtone(long msgId) {
        boolean result = true;
        PduBody body = null;
        try {
            body = SlideshowModel.getPduBody(this, ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, msgId));
        } catch (MmsException e) {
            Log.e("Mms", "copyToDrmProvider can't load pdu body: " + msgId);
        }
        if (body == null) {
            return false;
        }
        int partNum = body.getPartsNum();
        for (int i = 0; i < partNum; i++) {
            PduPart part = body.getPart(i);
            String type = new String(part.getContentType());
            if (DrmUtils.isDrmType(type)) {
                result &= copyPart(part, Long.toHexString(msgId));
            }
        }
        return result;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    /* JADX WARN: Multi-variable type inference failed */
    public boolean isDrmRingtoneWithRights(long msgId) {
        PduBody body = null;
        try {
            body = SlideshowModel.getPduBody(this, ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, msgId));
        } catch (MmsException e) {
            Log.e("Mms", "isDrmRingtoneWithRights can't load pdu body: " + msgId);
        }
        if (body == null) {
            return false;
        }
        int partNum = body.getPartsNum();
        for (int i = 0; i < partNum; i++) {
            PduPart part = body.getPart(i);
            String type = new String(part.getContentType());
            if (DrmUtils.isDrmType(type)) {
                String mimeType = MmsApp.getApplication().getDrmManagerClient().getOriginalMimeType(part.getDataUri());
                if (ContentType.isAudioType(mimeType) && DrmUtils.haveRightsForAction(part.getDataUri(), 2)) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    /* JADX WARN: Multi-variable type inference failed */
    public boolean isForwardable(long msgId) {
        PduBody body = null;
        try {
            body = SlideshowModel.getPduBody(this, ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, msgId));
        } catch (MmsException e) {
            Log.e("Mms", "getDrmMimeType can't load pdu body: " + msgId);
        }
        if (body == null) {
            return false;
        }
        int partNum = body.getPartsNum();
        for (int i = 0; i < partNum; i++) {
            PduPart part = body.getPart(i);
            String type = new String(part.getContentType());
            if (DrmUtils.isDrmType(type) && !DrmUtils.haveRightsForAction(part.getDataUri(), 3)) {
                return false;
            }
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getDrmMimeMenuStringRsrc(long msgId) {
        if (isDrmRingtoneWithRights(msgId)) {
            return R.string.save_ringtone;
        }
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getDrmMimeSavedStringRsrc(long msgId, boolean success) {
        if (isDrmRingtoneWithRights(msgId)) {
            return success ? R.string.saved_ringtone : R.string.saved_ringtone_fail;
        }
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: Thrown type has an unknown type hierarchy: com.google.android.mms.MmsException */
    /* JADX WARN: Multi-variable type inference failed */
    public boolean copyMedia(long msgId) {
        boolean result = true;
        PduBody body = null;
        try {
            body = SlideshowModel.getPduBody(this, ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, msgId));
        } catch (MmsException e) {
            Log.e("Mms", "copyMedia can't load pdu body: " + msgId);
        }
        if (body == null) {
            return false;
        }
        int partNum = body.getPartsNum();
        for (int i = 0; i < partNum; i++) {
            PduPart part = body.getPart(i);
            String type = new String(part.getContentType());
            if (ContentType.isImageType(type) || ContentType.isVideoType(type) || ContentType.isAudioType(type)) {
                result &= copyPart(part, Long.toHexString(msgId));
            }
        }
        return result;
    }

    private boolean copyPart(PduPart part, String fallback) throws Throwable {
        String extension;
        Uri uri = part.getDataUri();
        String type = new String(part.getContentType());
        boolean isDrm = DrmUtils.isDrmType(type);
        if (isDrm) {
            type = MmsApp.getApplication().getDrmManagerClient().getOriginalMimeType(part.getDataUri());
        }
        if (!ContentType.isImageType(type) && !ContentType.isVideoType(type) && !ContentType.isAudioType(type)) {
            return true;
        }
        InputStream input = null;
        FileOutputStream fout = null;
        try {
            try {
                input = this.mContentResolver.openInputStream(uri);
                if (input instanceof FileInputStream) {
                    FileInputStream fin = (FileInputStream) input;
                    byte[] location = part.getName();
                    if (location == null) {
                        location = part.getFilename();
                    }
                    if (location == null) {
                        location = part.getContentLocation();
                    }
                    File originalFile = new File(location == null ? fallback : new String(location));
                    String fileName = originalFile.getName();
                    String dir = Environment.getExternalStorageDirectory() + "/" + (ContentType.isAudioType(type) ? Environment.DIRECTORY_RINGTONES : Environment.DIRECTORY_DOWNLOADS) + "/";
                    int index = fileName.lastIndexOf(46);
                    if (index == -1) {
                        extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(type);
                    } else {
                        extension = fileName.substring(index + 1, fileName.length());
                        fileName = fileName.substring(0, index);
                    }
                    if (isDrm) {
                        extension = extension + DrmUtils.getConvertExtension(type);
                    }
                    File file = getUniqueDestination(dir + fileName.replaceAll("^.", LoggingEvents.EXTRA_CALLING_APP_NAME), extension);
                    File parentFile = file.getParentFile();
                    if (!parentFile.exists() && !parentFile.mkdirs()) {
                        Log.e("Mms", "[MMS] copyPart: mkdirs for " + parentFile.getPath() + " failed!");
                        if (input != null) {
                            try {
                                input.close();
                            } catch (IOException e) {
                                Log.e("Mms", "IOException caught while closing stream", e);
                                return false;
                            }
                        }
                        if (0 == 0) {
                            return false;
                        }
                        try {
                            fout.close();
                            return false;
                        } catch (IOException e2) {
                            Log.e("Mms", "IOException caught while closing stream", e2);
                            return false;
                        }
                    }
                    FileOutputStream fout2 = new FileOutputStream(file);
                    try {
                        byte[] buffer = new byte[8000];
                        while (true) {
                            int size = fin.read(buffer);
                            if (size == -1) {
                                break;
                            }
                            fout2.write(buffer, 0, size);
                        }
                        sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file)));
                        fout = fout2;
                    } catch (IOException e3) {
                        e = e3;
                        fout = fout2;
                        Log.e("Mms", "IOException caught while opening or reading stream", e);
                        if (input != null) {
                            try {
                                input.close();
                            } catch (IOException e4) {
                                Log.e("Mms", "IOException caught while closing stream", e4);
                                return false;
                            }
                        }
                        if (fout == null) {
                            return false;
                        }
                        try {
                            fout.close();
                            return false;
                        } catch (IOException e5) {
                            Log.e("Mms", "IOException caught while closing stream", e5);
                            return false;
                        }
                    } catch (Throwable th) {
                        th = th;
                        fout = fout2;
                        if (input != null) {
                            try {
                                input.close();
                            } catch (IOException e6) {
                                Log.e("Mms", "IOException caught while closing stream", e6);
                                return false;
                            }
                        }
                        if (fout != null) {
                            try {
                                fout.close();
                            } catch (IOException e7) {
                                Log.e("Mms", "IOException caught while closing stream", e7);
                                return false;
                            }
                        }
                        throw th;
                    }
                }
                if (input != null) {
                    try {
                        input.close();
                    } catch (IOException e8) {
                        Log.e("Mms", "IOException caught while closing stream", e8);
                        return false;
                    }
                }
                if (fout != null) {
                    try {
                        fout.close();
                    } catch (IOException e9) {
                        Log.e("Mms", "IOException caught while closing stream", e9);
                        return false;
                    }
                }
                return true;
            } catch (IOException e10) {
                e = e10;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    private File getUniqueDestination(String base, String extension) {
        File file = new File(base + "." + extension);
        int i = 2;
        while (file.exists()) {
            file = new File(base + "_" + i + "." + extension);
            i++;
        }
        return file;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showDeliveryReport(long messageId, String type) {
        Intent intent = new Intent((Context) this, (Class<?>) DeliveryReportActivity.class);
        intent.putExtra("message_id", messageId);
        intent.putExtra("message_type", type);
        startActivity(intent);
    }

    public ContactList getRecipients() {
        if (!isRecipientsEditorVisible()) {
            return this.mConversation.getRecipients();
        }
        if (sEmptyContactList == null) {
            sEmptyContactList = new ContactList();
        }
        return sEmptyContactList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void updateTitle(ContactList list) {
        String title = LoggingEvents.EXTRA_CALLING_APP_NAME;
        int cnt = list.size();
        this.mIsSelf = false;
        switch (cnt) {
            case 0:
                String recipient = null;
                if (this.mRecipientsEditor != null) {
                    recipient = this.mRecipientsEditor.getText().toString();
                }
                title = TextUtils.isEmpty(recipient) ? getString(ModeStringUtil.getModeResFromArray(this, R.array.new_message)) : recipient;
                break;
            case 1:
                title = list.get(0).getNumber();
                String titleName = MessageDispActivity.getContactNameByPhoneNumber(this, title);
                if (!TextUtils.isEmpty(titleName)) {
                    title = titleName;
                }
                String number = list.get(0).getNumber();
                this.mIsSelf = isMySelf(number);
                if (this.mIsSelf) {
                    title = getString(ModeStringUtil.getModeResFromArray(this, R.array.messagelist_sender_self));
                }
                if (!title.equals(number)) {
                    PhoneNumberUtils.formatNumber(number, number, MmsApp.getApplication().getCurrentCountryIso());
                } else if (list.get(0).isNotExistName()) {
                    title = title.replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll(" ", LoggingEvents.EXTRA_CALLING_APP_NAME);
                }
                break;
            default:
                for (int i = 0; i < list.size(); i++) {
                    if (i != 0) {
                        title = title + ", ";
                    }
                    String name = list.get(i).getNumber();
                    String titleName2 = MessageDispActivity.getContactNameByPhoneNumber(this, name);
                    if (!TextUtils.isEmpty(titleName2) && !list.get(i).isNotExistName()) {
                        title = title + titleName2;
                    } else {
                        if (name.equals(titleName2) && list.get(i).isNotExistName()) {
                            name = list.get(i).getNumber().replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll(" ", LoggingEvents.EXTRA_CALLING_APP_NAME);
                        }
                        title = title + name;
                    }
                }
                getResources().getQuantityString(R.plurals.recipient_count, cnt, Integer.valueOf(cnt));
                break;
        }
        this.mDebugRecipients = list.serialize();
        this.mTitle = title;
        this.tv_titles_top.setVisibility(8);
        setTitle(title);
    }

    private boolean isMyProfile(String number) {
        String number2 = number.replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME);
        String myNumber = MmsApp.getApplication().getTelephonyManager().getLine1Number();
        return (TextUtils.isEmpty(myNumber) || TextUtils.isEmpty(number2) || !myNumber.equals(number2)) ? false : true;
    }

    private boolean isMySelf(String number) {
        String number2 = number.replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME).replace(" ", LoggingEvents.EXTRA_CALLING_APP_NAME);
        int num = number2.length();
        String TelephonyNumber = MmsApp.getApplication().getTelephonyManager().getLine1Number();
        if (TextUtils.isEmpty(TelephonyNumber)) {
            return false;
        }
        String myNumber = TelephonyNumber.replace(" ", LoggingEvents.EXTRA_CALLING_APP_NAME);
        if (myNumber.length() < 10 || num < 10) {
            return false;
        }
        String number3 = number2.substring(num - 10, num).toString();
        return (TextUtils.isEmpty(myNumber) || TextUtils.isEmpty(number3) || !myNumber.substring(myNumber.length() + (-10), myNumber.length()).toString().equals(number3)) ? false : true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initRecipientsEditor() {
        if (!isRecipientsEditorVisible()) {
            ContactList recipients = getRecipients();
            ViewStub stub = (ViewStub) findViewById(R.id.recipients_editor_stub);
            if (stub != null) {
                View stubView = stub.inflate();
                this.mRecipientsEditor = (RecipientsEditor) stubView.findViewById(R.id.recipients_editor);
                this.mRecipientsPicker = (ImageButton) stubView.findViewById(R.id.recipients_picker);
            } else {
                this.mRecipientsEditor = (RecipientsEditor) findViewById(R.id.recipients_editor);
                this.mRecipientsPicker = (ImageButton) findViewById(R.id.recipients_picker);
            }
            this.mRecipientsEditor.setVisibility(8);
            this.mRecipientsPicker.setOnClickListener(this);
            this.mRecipientsEditor.setAdapter(new ChipsRecipientAdapter(this));
            this.mRecipientsEditor.setText((CharSequence) null);
            this.mRecipientsEditor.populate(recipients);
            this.mRecipientsEditor.setOnCreateContextMenuListener(this.mRecipientsMenuCreateListener);
            this.mRecipientsEditor.addTextChangedListener(this.mRecipientsWatcher);
            this.mRecipientsEditor.setOnSelectChipRunnable(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.19
                @Override // java.lang.Runnable
                public void run() {
                    if (ComposeMessageActivity.this.mRecipientsEditor.getRecipientCount() == 1) {
                        InputMethodManager inputManager = (InputMethodManager) ComposeMessageActivity.this.getSystemService("input_method");
                        if (inputManager == null || !inputManager.isFullscreenMode()) {
                            ComposeMessageActivity.this.requestFocusTextEditor(ComposeMessageActivity.this.mIsSaveFocusTextEditor ? false : true);
                        }
                    }
                }
            });
            this.mRecipientsEditor.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.android.mms.ui.ComposeMessageActivity.20
                @Override // android.view.View.OnFocusChangeListener
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        RecipientsEditor editor = (RecipientsEditor) v;
                        ContactList contacts = editor.constructContactsFromInput(false);
                        ComposeMessageActivity.this.updateTitle(contacts);
                    }
                }
            });
            PhoneNumberFormatter.setPhoneNumberFormattingTextWatcher(this, this.mRecipientsEditor);
            this.mTopPanel.setVisibility(0);
        }
    }

    public static boolean cancelFailedToDeliverNotification(Intent intent, Context context) {
        if (!MessagingNotification.isFailedToDeliver(intent)) {
            return false;
        }
        MessagingNotification.cancelNotification(context, MessagingNotification.MESSAGE_FAILED_NOTIFICATION_ID);
        return true;
    }

    public static boolean cancelFailedDownloadNotification(Intent intent, Context context) {
        if (!MessagingNotification.isFailedToDownload(intent)) {
            return false;
        }
        MessagingNotification.cancelNotification(context, MessagingNotification.DOWNLOAD_FAILED_NOTIFICATION_ID);
        return true;
    }

    private static void stopNotification() {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.stopToRington();
                mISmsRingtoneService.stopToVibrator();
            } catch (RemoteException e) {
                Log.e("Mms", "[Ringtone][RemoteException]");
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle savedInstanceState) {
        String message;
        Uri uri;
        Conversation con;
        this.mIsSmsEnabled = MmsConfig.isSmsEnabled(this);
        super.onCreate(savedInstanceState);
        getWindow().addFlags(131072);
        getWindow().addPrivateFlags(4096);
        this.mIsDeleteDraftDialogDisp = false;
        this.mIsFromSendTo = false;
        boolean fromNotification = getIntent().getBooleanExtra("from_notification", false);
        Intent intentRing = new Intent(ISmsRingtoneService.class.getName());
        intentRing.setPackage(getPackageName());
        bindService(intentRing, mServiceConnection, 1);
        stopNotification();
        IntentFilter screenFilter = new IntentFilter();
        screenFilter.addAction("android.intent.action.USER_PRESENT");
        screenFilter.addAction("android.intent.action.SCREEN_OFF");
        registerReceiver(this.mScreenReceiver, screenFilter);
        final Intent sentitent = new Intent();
        boolean hasDraft = false;
        if (getIntent().getAction() != null && savedInstanceState == null) {
            boolean isIntentAction = false;
            String body = null;
            ArrayList<String[]> senderList = null;
            if ("android.intent.action.SEND".equals(getIntent().getAction())) {
                isIntentAction = true;
                Bundle extras = getIntent().getExtras();
                if (extras != null && extras.containsKey("android.intent.extra.TEXT")) {
                    body = extras.getString("android.intent.extra.TEXT");
                } else {
                    body = getIntent().getStringExtra("sms_body");
                }
                senderList = getSenderListExtra();
            } else if ("android.intent.action.SENDTO".equals(getIntent().getAction())) {
                isIntentAction = true;
                body = getIntent().getStringExtra("sms_body");
                Uri uri2 = getIntent().getData();
                String address = LoggingEvents.EXTRA_CALLING_APP_NAME;
                if (uri2 != null) {
                    address = Conversation.getRecipients(uri2);
                    ContactList contactList = ContactList.getByNumbers(address, false, true);
                    senderList = createSenderList(contactList);
                } else {
                    senderList = getSenderListExtra();
                }
                if (!LoggingEvents.EXTRA_CALLING_APP_NAME.equals(address)) {
                    this.mConversation = Conversation.get((Context) this, ContactList.getByNumbers(address, false, true), false);
                    hasDraft = DraftCache.getInstance().hasDraft(this.mConversation.getThreadId());
                }
                Log.d("Mms", "hasDraft :" + hasDraft);
                if (senderList.size() > 0) {
                    sentitent.setClass(this, MessageDispActivity.class);
                    sentitent.putExtra("key_message", body);
                    sentitent.putExtra("key_sender", senderList);
                    sentitent.putExtra("key_sender_edit", true);
                    sentitent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
                    this.mIsDeleteDraftDialogDisp = true;
                } else {
                    sentitent.setClass(this, RecipientSelectActivity.class);
                }
                this.mIsFromSendTo = true;
                if (!hasDraft) {
                    sentitent.putExtra("Activity", "ComposeMessageActivity");
                    startActivity(sentitent);
                    finish();
                    return;
                }
            } else if ("android.intent.action.VIEW".equals(getIntent().getAction()) && ((uri = getIntent().getData()) == null || !uri.toString().startsWith("content://mms-sms/conversations/"))) {
                isIntentAction = true;
                body = getIntent().getStringExtra("sms_body");
                if (body == null) {
                    body = getBody(uri);
                }
                Log.d("Mms", "body:*****");
                senderList = getSenderListExtra();
                String address2 = LoggingEvents.EXTRA_CALLING_APP_NAME;
                if (uri != null) {
                    address2 = Conversation.getRecipients(uri);
                    if (senderList == null) {
                        ContactList contactList2 = ContactList.getByNumbers(address2, false, true);
                        senderList = createSenderList(contactList2);
                    }
                }
                Log.d("Mms", "address:******");
                if (!LoggingEvents.EXTRA_CALLING_APP_NAME.equals(address2) && (con = Conversation.get(this, ContactList.getByNumbers(address2, false, true))) != null) {
                    sentitent.setClass(this, MessageDispActivity.class);
                    sentitent.putExtra("key_message", body);
                    sentitent.putExtra("key_sender", senderList);
                    sentitent.putExtra("key_sender_edit", true);
                    sentitent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
                    hasDraft = DraftCache.getInstance().hasDraft(con.getThreadId());
                    this.mIsDeleteDraftDialogDisp = true;
                }
                Log.d("Mms", "hasDraft2 :" + hasDraft);
            }
            if (isIntentAction) {
                Intent intent = null;
                if (!TextUtils.isEmpty(body)) {
                    if (!hasDraft) {
                        intent = new Intent((Context) this, (Class<?>) MessageDispActivity.class);
                        intent.putExtra("key_message", body);
                        if (senderList != null && senderList.size() > 0) {
                            intent.putExtra("key_sender", senderList);
                        }
                    }
                } else if (senderList == null || senderList.size() == 0) {
                    intent = new Intent((Context) this, (Class<?>) RecipientSelectActivity.class);
                    intent.setType("vnd.android-dir/mms-sms");
                }
                if (intent != null) {
                    intent.putExtra("key_sender_edit", true);
                    intent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
                    intent.putExtra(MessageDispActivity.extraKey_show_edit, false);
                    intent.putExtra("Activity", "ComposeMessageActivity");
                    startActivity(intent);
                    finish();
                    return;
                }
            }
        }
        resetConfiguration(getResources().getConfiguration());
        View view = getLayoutInflater().inflate(R.layout.compose_message_activity, (ViewGroup) null);
        setContentView(view);
        int resId = getResources().getThemeResFromArray(R.array.theme_background);
        getWindow().setBackgroundDrawableResource(resId);
        this.tv_titles_top = (TextView) view.findViewById(R.id.tv_titles_top);
        this.tv_titles_top.setText(LoggingEvents.EXTRA_CALLING_APP_NAME);
        this.tv_titles_top.setOnClickListener(new View.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.22
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                ComposeMessageActivity.this.createNewMessage();
            }
        });
        this.mSoftkey = findViewById(R.id.soft_key);
        this.mSoftkey.SetRightSoftkey(ModeStringUtil.getModeResFromArray(this, R.array.soft_back_text));
        setProgressBarVisibility(false);
        getWindow().setSoftInputMode(18);
        initResourceRefs();
        this.mContentResolver = getContentResolver();
        this.mBackgroundQueryHandler = new BackgroundQueryHandler(this.mContentResolver);
        this.mVoiceCapable = getResources().getBoolean(android.R.^attr-private.floatingToolbarDividerColor);
        initialize(savedInstanceState, 0L);
        if (fromNotification) {
            this.mShouldLoadDraft = false;
        }
        this.mIsDialogDisp = true;
        if (this.mIsDeleteDraftDialogDisp && DraftCache.getInstance().hasDraft(this.mConversation.getThreadId())) {
            AlertDialogFp dialog = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.draft_delete)).setPositiveButton(R.string.monaka_yes, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.24
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog2, int which) {
                    ComposeMessageActivity.this.mIsDialogDisp = false;
                    DraftCache.getInstance().setDraftState(ComposeMessageActivity.this.mConversation.getThreadId(), false);
                    ComposeMessageActivity.this.deleteDraftSmsMessage(ComposeMessageActivity.this.mConversation.getThreadId());
                    sentitent.putExtra("Activity", "ComposeMessageActivity");
                    ComposeMessageActivity.this.startActivity(sentitent);
                    ComposeMessageActivity.this.finish();
                    ComposeMessageActivity.this.overridePendingTransition(0, 0);
                }
            }).setNegativeButton(R.string.monaka_no, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.23
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog2, int which) {
                    ComposeMessageActivity.this.overridePendingTransition(0, 0);
                }
            }).create();
            MessageUtils.dialogEndCallToHome(this, dialog);
            dialog.show();
            dialog.getButton(-2).requestFocus();
            dialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.android.mms.ui.ComposeMessageActivity.25
                @Override // android.content.DialogInterface.OnDismissListener
                public void onDismiss(DialogInterface arg0) {
                    if (ComposeMessageActivity.this.mIsDialogDisp) {
                        ComposeMessageActivity.this.mIsDialogDisp = false;
                        ComposeMessageActivity.this.finish();
                    }
                }
            });
        } else {
            this.mIsDeleteDraftDialogDisp = false;
        }
        MessagingNotification.sUsersAction = true;
        this.isSendNewMessage = getIntent().getBooleanExtra(MessageDispActivity.extraKey_send_new_message, false);
        this.isFromOut = getIntent().getBooleanExtra(MessageDispActivity.extraKey_from_out, false);
        this.isReplyMessage = getIntent().getBooleanExtra(MessageDispActivity.extraKey_reply_message, false);
        Log.d("Mms", "onCreate isFromOut = " + this.isFromOut + "   isSendNewMessage = " + this.isSendNewMessage);
        if (this.isSendNewMessage && savedInstanceState == null && (message = getIntent().getStringExtra("key_message")) != null && !message.isEmpty()) {
            ArrayList<String> recipients = (ArrayList) getIntent().getSerializableExtra(MessageDispActivity.extraKey_working_recipients);
            Log.d("Mms", "recipients = ***");
            this.mWorkingMessage.setWorkingRecipients(recipients);
            this.mStartSendNewMessage = true;
            sendNewMessage(message);
        }
        boolean isSaveDraft = getIntent().getBooleanExtra(MessageDispActivity.extraKey_savedraft, false);
        if (isSaveDraft) {
            String msg = getIntent().getStringExtra("key_message");
            Log.d("Mms", "msg:******");
            this.mWorkingMessage.setText(msg);
            this.mWorkingMessage.saveDraft(true);
            finish();
        }
        this.mDialogVisibility = false;
    }

    private ArrayList<String[]> getSenderListExtra() {
        String address = getIntent().getStringExtra("address");
        if (TextUtils.isEmpty(address)) {
            return null;
        }
        ContactList contactList = ContactList.getByNumbers(address, false, true);
        ArrayList<String[]> senderList = createSenderList(contactList);
        return senderList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showSubjectEditor(boolean show) {
        if (Log.isLoggable("Mms", 2)) {
            log(LoggingEvents.EXTRA_CALLING_APP_NAME + show);
        }
        if (this.mSubjectTextEditor == null) {
            if (show) {
                this.mSubjectTextEditor = (EditText) findViewById(R.id.subject);
                this.mSubjectTextEditor.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MmsConfig.getMaxSubjectLength())});
            } else {
                return;
            }
        }
        this.mSubjectTextEditor.setOnKeyListener(show ? this.mSubjectKeyListener : null);
        if (show) {
            this.mSubjectTextEditor.addTextChangedListener(this.mSubjectEditorWatcher);
        } else {
            this.mSubjectTextEditor.removeTextChangedListener(this.mSubjectEditorWatcher);
        }
        this.mSubjectTextEditor.setText(this.mWorkingMessage.getSubject());
        hideOrShowTopPanel();
    }

    private void hideOrShowTopPanel() {
        if (isSubjectEditorVisible() || isRecipientsEditorVisible()) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void initialize(Bundle savedInstanceState, long originalThreadId) {
        this.mWorkingMessage = WorkingMessage.createEmpty(this);
        initActivityState(savedInstanceState);
        if (originalThreadId != 0 && originalThreadId == this.mConversation.getThreadId()) {
            LogTag.warnPossibleRecipientMismatch("ComposeMessageActivity.initialize:  threadId didn't change from: " + originalThreadId, this);
        }
        if (FJ_TEL_LOG_ACQ_FLG) {
            log("savedInstanceState = " + savedInstanceState + " intent = " + getIntent() + " mConversation = ***");
        } else {
            log("savedInstanceState = " + savedInstanceState + " intent = " + getIntent() + " mConversation = " + this.mConversation);
        }
        if (cancelFailedToDeliverNotification(getIntent(), this)) {
            undeliveredMessageDialog(getMessageDate(null));
        }
        cancelFailedDownloadNotification(getIntent(), this);
        initMessageList();
        this.mShouldLoadDraft = getIntent().getBooleanExtra(EXTRA_LOAD_DRAFT, false);
        if (savedInstanceState == null && (handleSendIntent() || handleForwardedMessage())) {
            this.mShouldLoadDraft = false;
        }
        this.mWorkingMessage.setConversation(this.mConversation);
        if (this.mConversation.getThreadId() <= 0) {
            hideRecipientEditor();
            getWindow().setSoftInputMode(20);
        } else {
            hideRecipientEditor();
        }
        invalidateOptionsMenu();
        updateSendButtonState();
        drawTopPanel(false);
        if (!this.mShouldLoadDraft) {
            drawBottomPanel();
        }
        onKeyboardStateChanged();
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                log("update title, mConversation=***");
            } else {
                log("update title, mConversation=" + this.mConversation.toString());
            }
        }
        updateTitle(this.mConversation.getRecipients());
        updateFooterView();
        if (0 != 0 && isRecipientsEditorVisible()) {
            this.mRecipientsEditor.requestFocus();
        }
        this.mMsgListAdapter.setIsGroupConversation(this.mConversation.getRecipients().size() > 1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onNewIntent(Intent intent) {
        Conversation conversation;
        String message;
        super.onNewIntent(intent);
        setIntent(intent);
        this.mSentMessage = false;
        long originalThreadId = this.mConversation.getThreadId();
        long threadId = intent.getLongExtra(THREAD_ID, 0L);
        Uri intentUri = intent.getData();
        if (threadId > 0) {
            conversation = Conversation.get((Context) this, threadId, false);
        } else {
            if (this.mConversation.getThreadId() == 0) {
                this.mWorkingMessage.syncWorkingRecipients();
            }
            conversation = Conversation.get((Context) this, intentUri, false);
        }
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                log("onNewIntent: data=***, thread_id extra is " + threadId + ", new conversation=***, mConversation=***");
            } else {
                log("onNewIntent: data=" + intentUri + ", thread_id extra is " + threadId + ", new conversation=" + conversation + ", mConversation=" + this.mConversation);
            }
        }
        boolean sameThread = (conversation.getThreadId() == this.mConversation.getThreadId() || this.mConversation.getThreadId() == 0) && conversation.equals(this.mConversation);
        Log.d("Mms", "onNewIntent isFromOut = " + this.isFromOut + "   sameThread = " + sameThread);
        if (!this.isFromOut) {
            conversation.blockMarkAsRead(true);
        }
        if (sameThread) {
            log("onNewIntent: same conversation");
            if (this.mConversation.getThreadId() == 0) {
                this.mConversation = conversation;
                this.mWorkingMessage.setConversation(this.mConversation);
                updateThreadIdIfRunning();
                invalidateOptionsMenu();
            }
            Log.d("Mms", "onNewIntent isFromOut = " + this.isFromOut + "   isSendNewMessage = " + this.isSendNewMessage);
            if (!this.isFromOut) {
                this.mConversation.markAsRead();
            }
        } else {
            if (Log.isLoggable("Mms", 2)) {
                log("onNewIntent: different conversation");
            }
            saveDraft(false);
            initialize(null, originalThreadId);
        }
        this.isSendNewMessage = getIntent().getBooleanExtra(MessageDispActivity.extraKey_send_new_message, false);
        Log.d("Mms", "onNewIntent:  isSendNewMessage = " + this.isSendNewMessage);
        if (this.isSendNewMessage && (message = getIntent().getStringExtra("key_message")) != null && !message.isEmpty()) {
            ArrayList<String> recipients = (ArrayList) getIntent().getSerializableExtra(MessageDispActivity.extraKey_working_recipients);
            Log.d("Mms", "recipients = ***");
            this.mWorkingMessage.setWorkingRecipients(recipients);
            this.mStartSendNewMessage = true;
            sendNewMessage(message);
        }
        loadMessagesAndDraft(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void sanityCheckConversation() {
        if (this.mWorkingMessage.getConversation() != this.mConversation) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                LogTag.warnPossibleRecipientMismatch("ComposeMessageActivity: mWorkingMessage.mConversation=***, mConversation=***, MISMATCH!", this);
            } else {
                LogTag.warnPossibleRecipientMismatch("ComposeMessageActivity: mWorkingMessage.mConversation=" + this.mWorkingMessage.getConversation() + ", mConversation=" + this.mConversation + ", MISMATCH!", this);
            }
        }
    }

    protected void onRestart() {
        super.onRestart();
        this.mIsSaveFocusTextEditor = this.mTextEditor.isFocused();
        hideBottomPanel();
        if (this.mWorkingMessage.isDiscarded() && this.mWorkingMessage.isWorthSaving()) {
            this.mWorkingMessage.unDiscard();
            sanityCheckConversation();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onStart() {
        int mode;
        super.onStart();
        boolean isSmsEnabled = MmsConfig.isSmsEnabled(this);
        if (isSmsEnabled != this.mIsSmsEnabled) {
            this.mIsSmsEnabled = isSmsEnabled;
            invalidateOptionsMenu();
        }
        if (!this.isFromOut) {
            this.mConversation.blockMarkAsRead(true);
            this.mNeedToMarkAsSeen = true;
        }
        if (this.isSendNewMessage) {
            this.mConversation.markAsRead();
            this.mNeedToMarkAsSeen = true;
        }
        initFocus();
        registerReceiver(this.mHttpProgressReceiver, this.mHttpProgressFilter);
        if (DraftCache.getInstance().hasDraft(this.mConversation.getThreadId()) || this.mConversation.getThreadId() <= 0) {
            mode = 16 | 4;
        } else {
            mode = 16 | 2;
        }
        getWindow().setSoftInputMode(mode);
        this.mMessagesAndDraftLoaded = false;
        long threadId = this.mWorkingMessage.getConversation().getThreadId();
        if (MessageUtils.sSameRecipientList.contains(Long.valueOf(threadId))) {
            this.mShouldLoadDraft = false;
        }
        if (!this.mIsSmsEnabled) {
            this.mShouldLoadDraft = false;
        }
        if (!this.mIsDeleteDraftDialogDisp) {
            loadMessagesAndDraft(1);
        }
        this.mWorkingMessage.syncWorkingRecipients();
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                log("update title, mConversation=***");
            } else {
                log("update title, mConversation=" + this.mConversation.toString());
            }
        }
        updateTitle(this.mConversation.getRecipients());
    }

    public void loadMessageContent() {
        Log.d("Mms", "loadMessageContent isFromOut = " + this.isFromOut + "   isSendNewMessage = " + this.isSendNewMessage);
        if (!this.isFromOut && !this.isReplyMessage) {
            this.mConversation.blockMarkAsRead(true);
            this.mConversation.markAsRead();
        }
        startMsgListQuery();
        updateSendFailedNotification();
    }

    private void loadMessagesAndDraft(int debugFlag) {
        if (!this.mSendDiscreetMode && !this.mMessagesAndDraftLoaded) {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "### CMA.loadMessagesAndDraft: flag=" + debugFlag);
            }
            loadMessageContent();
            boolean drawBottomPanel = true;
            if (this.mShouldLoadDraft && loadDraft()) {
                startMsgDispWithDraft();
                drawBottomPanel = false;
            }
            if (drawBottomPanel) {
                drawBottomPanel();
            }
            this.mMessagesAndDraftLoaded = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateSendFailedNotification() {
        final long threadId = this.mConversation.getThreadId();
        if (threadId > 0) {
            new Thread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.27
                @Override // java.lang.Runnable
                public void run() {
                    MessagingNotification.updateSendFailedNotificationForThread(ComposeMessageActivity.this, threadId);
                }
            }, "ComposeMessageActivity.updateSendFailedNotification").start();
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(RECIPIENTS, getRecipients().serialize());
        this.mWorkingMessage.writeStateToBundle(outState);
        if (this.mSendDiscreetMode) {
            outState.putBoolean(KEY_EXIT_ON_SENT, this.mSendDiscreetMode);
        }
        if (this.mForwardMessageMode) {
            outState.putBoolean(KEY_FORWARDED_MESSAGE, this.mForwardMessageMode);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onResume() {
        super.onResume();
        this.mIsForeground = true;
        ConversationList.cancelReceiverDisplay(this);
        if (Log.isLoggable("Mms", 2)) {
            if (FJ_TEL_LOG_ACQ_FLG) {
                log("update title, mConversation=***");
            } else {
                log("update title, mConversation=" + this.mConversation.toString());
            }
        }
        this.mMessageListItemHandler.postDelayed(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.28
            @Override // java.lang.Runnable
            public void run() {
                ContactList recipients;
                if (ComposeMessageActivity.this.isRecipientsEditorVisible()) {
                    recipients = ComposeMessageActivity.this.mRecipientsEditor.constructContactsFromInput(false);
                } else {
                    recipients = ComposeMessageActivity.this.getRecipients();
                }
                ComposeMessageActivity.this.updateTitle(recipients);
            }
        }, 100L);
        this.mIsRunning = true;
        updateThreadIdIfRunning();
        Log.d("Mms", "onResume isFromOut = " + this.isFromOut + "   isSendNewMessage = " + this.isSendNewMessage);
        if (!this.isFromOut) {
            this.mConversation.markAsRead();
        }
        if (!this.mIsSmsEnabled) {
            this.mDialogVisibility = this.mIsSmsEnabled ? false : true;
        }
        getWindow().setSoftInputMode(2);
    }

    protected void onPause() {
        super.onPause();
        this.mIsForeground = false;
        if (this.mMenuHandler != null) {
            this.mMenuHandler.hideAppMenu();
        }
        MessagingNotification.setCurrentlyDisplayedThreadId(-2L);
        removeRecipientsListeners();
        if (this.mAsyncDialog != null) {
            this.mAsyncDialog.clearPendingProgressDialog();
        }
        if (!this.mIsScreenOff) {
            checkPendingNotification();
        }
        this.mSavedScrollPosition = this.mSavedScrollPositionBack;
        this.mItemAdapterId = this.mMsgListView.getItemIdAtPosition(this.mSavedScrollPosition);
        this.mOldSize = this.mMsgListView.getCount();
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "onPause: mSavedScrollPosition=" + this.mSavedScrollPosition);
        }
        if (!this.isFromOut) {
            this.mConversation.markAsRead();
        }
        this.mIsRunning = false;
    }

    public void onHomeKeyEvent() {
        checkPendingNotification();
    }

    protected void onStop() {
        super.onStop();
        this.mBackgroundQueryHandler.cancelOperation(MESSAGE_LIST_QUERY_TOKEN);
        if (!this.isFromOut) {
            this.mConversation.blockMarkAsRead(false);
        }
        if (this.mMsgListAdapter != null) {
            Cursor cursor = this.mMsgListAdapter.getCursor();
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            this.mMsgListAdapter.changeCursor(null);
            this.mMsgListAdapter.cancelBackgroundLoading();
        }
        this.mShouldLoadDraft = false;
        unregisterReceiver(this.mHttpProgressReceiver);
    }

    protected void onDestroy() {
        unregisterReceiver(this.mScreenReceiver);
        if (this.mConversation != null && this.mConversation.getMessageCount() == 0 && !DraftCache.getInstance().hasDraft(this.mConversation.getThreadId())) {
            try {
                deleteThread();
            } catch (Exception e) {
                Log.d("Mms", "他アプリからIntent遷移より(スレッドが生成していない)、メッセージのないスレッド削除でNullPointExceptionが発生するが、無視する");
            }
        }
        super.onDestroy();
        unbindService(mServiceConnection);
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (resetConfiguration(newConfig)) {
            drawTopPanel(isSubjectEditorVisible());
        }
        onKeyboardStateChanged();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private String getTitleBarString(ContactList list) {
        int cnt = list.size();
        switch (cnt) {
            case 0:
                String recipient = null;
                if (this.mRecipientsEditor != null) {
                    recipient = this.mRecipientsEditor.getText().toString();
                }
                if (TextUtils.isEmpty(recipient)) {
                    String title = getString(ModeStringUtil.getModeResFromArray(this, R.array.new_message));
                    return title;
                }
                String title2 = recipient;
                return title2;
            case 1:
                String title3 = list.get(0).getName();
                return title3;
            default:
                String title4 = list.formatNames(", ");
                return title4;
        }
    }

    private boolean resetConfiguration(Configuration config) {
        this.mIsKeyboardOpen = config.keyboardHidden == 1;
        boolean isLandscape = config.orientation == 2;
        if (this.mIsLandscape == isLandscape) {
            return false;
        }
        this.mIsLandscape = isLandscape;
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void onKeyboardStateChanged() {
        this.mTextEditor.setEnabled(this.mIsSmsEnabled);
        if (!this.mIsSmsEnabled) {
            if (this.mRecipientsEditor != null) {
                this.mRecipientsEditor.setFocusableInTouchMode(false);
            }
            if (this.mSubjectTextEditor != null) {
                this.mSubjectTextEditor.setFocusableInTouchMode(false);
            }
            this.mTextEditor.setFocusableInTouchMode(false);
            this.mTextEditor.setHint(ModeStringUtil.getModeResFromArray(this, R.array.sending_disabled_not_default_app));
            return;
        }
        if (this.mIsKeyboardOpen) {
            if (this.mRecipientsEditor != null) {
                this.mRecipientsEditor.setFocusableInTouchMode(true);
            }
            if (this.mSubjectTextEditor != null) {
                this.mSubjectTextEditor.setFocusableInTouchMode(true);
            }
            this.mTextEditor.setFocusableInTouchMode(true);
            this.mTextEditor.setHint(R.string.type_to_compose_text_enter_to_send);
            return;
        }
        if (this.mRecipientsEditor != null) {
            this.mRecipientsEditor.setFocusable(false);
        }
        if (this.mSubjectTextEditor != null) {
            this.mSubjectTextEditor.setFocusable(false);
        }
        this.mTextEditor.setFocusable(false);
        this.mTextEditor.setHint(R.string.open_keyboard_to_compose_message);
    }

    public void onUserInteraction() {
        checkPendingNotification();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.d("Mms", "onKeyDown " + keyCode);
        if (keyCode == 131 && event.getRepeatCount() == 0) {
            MenuItem callNumber = this.mMenu.findItem(R.id.action_phone_call);
            MenuItem addToContacts = this.mMenu.findItem(R.id.action_add_to_contacts);
            MenuItem reply = this.mMenu.findItem(R.id.action_reply);
            MenuItem forward = this.mMenu.findItem(R.id.action_forward_message);
            int recipientCount = getRecipients().size();
            Log.d("Mms", "number length " + recipientCount);
            boolean isName = true;
            for (int i = 0; i < recipientCount; i++) {
                String number = getRecipients().get(i).getNumber();
                Contact cache = Contact.get(number, true);
                if (!cache.isName()) {
                    isName = false;
                    break;
                }
            }
            boolean smsEnabled = FjSettings.Global.getInt(getContentResolver(), "send_message_setting", 1) == 1;
            if (recipientCount > 1) {
                callNumber.setVisible(false);
                addToContacts.setVisible(false);
            } else if (isName) {
                callNumber.setVisible(true);
                addToContacts.setVisible(false);
            } else {
                callNumber.setVisible(false);
                if (ConversationList.isPhoneNumber(getRecipients().get(0).getNumber())) {
                    addToContacts.setVisible(true);
                } else {
                    addToContacts.setVisible(false);
                }
            }
            if (smsEnabled) {
                forward.setVisible(true);
                if (isName) {
                    reply.setVisible(true);
                } else {
                    reply.setVisible(false);
                }
            } else {
                forward.setVisible(false);
                reply.setVisible(false);
            }
            this.mMenuHandler.showAppMenu(this.mSoftkey);
        }
        if (keyCode == 23 && event.getRepeatCount() == 0) {
            event.startTracking();
            return true;
        }
        if (keyCode == 131 && event.getRepeatCount() == 0) {
            event.startTracking();
            return false;
        }
        switch (keyCode) {
            case 4:
                exitComposeMessageActivity(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.29
                    @Override // java.lang.Runnable
                    public void run() {
                        ComposeMessageActivity.this.finish();
                    }
                });
                return true;
            case 6:
                MessageUtils.endCallToHome(this);
                return true;
            case 23:
            case 66:
            case 67:
            default:
                return super.onKeyDown(keyCode, event);
            case 63:
            case 84:
                return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void exitComposeMessageActivity(Runnable exit) {
        if (!this.mWorkingMessage.isWorthSaving()) {
            exit.run();
        } else if (isRecipientsEditorVisible() && !this.mRecipientsEditor.hasValidRecipient(this.mWorkingMessage.requiresMms())) {
            MessageUtils.showDiscardDraftConfirmDialog(this, new DiscardDraftListener());
        } else {
            this.mToastForDraftSave = true;
            exit.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void goToConversationList() {
        finish();
        Intent intent = new Intent((Context) this, (Class<?>) ConversationList.class);
        intent.setFlags(335544320);
        startActivity(intent);
    }

    private void hideRecipientEditor() {
        if (this.mRecipientsEditor != null) {
            this.mRecipientsEditor.removeTextChangedListener(this.mRecipientsWatcher);
            this.mRecipientsEditor.setVisibility(8);
            hideOrShowTopPanel();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isRecipientsEditorVisible() {
        return this.mRecipientsEditor != null && this.mRecipientsEditor.getVisibility() == 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isSubjectEditorVisible() {
        return this.mSubjectTextEditor != null && this.mSubjectTextEditor.getVisibility() == 0;
    }

    @Override // com.android.mms.data.WorkingMessage.MessageStatusListener
    public void onAttachmentChanged() {
        runOnUiThread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.30
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.drawBottomPanel();
                ComposeMessageActivity.this.updateSendButtonState();
                ComposeMessageActivity.this.drawTopPanel(ComposeMessageActivity.this.isSubjectEditorVisible());
            }
        });
    }

    @Override // com.android.mms.data.WorkingMessage.MessageStatusListener
    public void onProtocolChanged(final boolean convertToMms) {
        runOnUiThread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.31
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.showSmsOrMmsSendButton(convertToMms);
                if (convertToMms) {
                    ComposeMessageActivity.this.mTextCounter.setVisibility(8);
                    ComposeMessageActivity.this.showConvertToMmsToast();
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public View showSmsOrMmsSendButton(boolean isMms) {
        View showButton;
        View hideButton;
        if (isMms) {
            showButton = this.mSendButtonMms;
            hideButton = this.mSendButtonSms;
        } else {
            showButton = this.mSendButtonSms;
            hideButton = this.mSendButtonMms;
        }
        hideButton.setVisibility(8);
        return showButton;
    }

    @Override // com.android.mms.data.WorkingMessage.MessageStatusListener
    public void onPreMessageSent() {
        runOnUiThread(this.mResetMessageRunnable);
    }

    @Override // com.android.mms.data.WorkingMessage.MessageStatusListener
    public void onMessageSent() {
        runOnUiThread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.33
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.mStartSendNewMessage = false;
                ComposeMessageActivity.this.startMsgListQuery();
                ComposeMessageActivity.this.updateThreadIdIfRunning();
            }
        });
    }

    @Override // com.android.mms.data.WorkingMessage.MessageStatusListener
    public void onMaxPendingMessagesReached() {
        saveDraft(false);
        runOnUiThread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.34
            @Override // java.lang.Runnable
            public void run() {
                AlertDialogFp toast = new AlertDialogFp.Builder(ComposeMessageActivity.this).setMessage(ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.too_many_unsent_mms)).create();
                toast.setAutoDismiss(true);
                MessageUtils.dialogEndCallToHome(ComposeMessageActivity.this, toast);
                toast.show();
            }
        });
    }

    @Override // com.android.mms.data.WorkingMessage.MessageStatusListener
    public void onAttachmentError(final int error) {
        runOnUiThread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.35
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.handleAddAttachmentError(error, R.string.type_picture);
                ComposeMessageActivity.this.onMessageSent();
            }
        });
    }

    private boolean isRecipientCallable() {
        ContactList recipients = getRecipients();
        return recipients.size() == 1 && !recipients.containsEmail();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dialRecipient() {
        if (isRecipientCallable()) {
            String number = getRecipients().get(0).getNumber();
            String number2 = PhoneNumberUtils.stripSeparators(number);
            Log.i("Mms", "dialRecipient() tel: xxxxxx");
            Intent dialIntent = new Intent("android.intent.action.CALL_PRIVILEGED", Uri.parse("tel:" + number2));
            startActivity(dialIntent);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void buildAddAddressToContactMenuItem(Menu menu) {
        ContactList contacts = getRecipients();
        if (contacts.size() == 1) {
            for (Contact c : getRecipients()) {
                if (!c.existsInDatabase() && canAddToContacts(c)) {
                    Intent intent = ConversationList.createAddContactIntent(c.getNumber());
                    menu.add(0, MENU_ADD_ADDRESS_TO_CONTACTS, 0, ModeStringUtil.getModeResFromArray(this, R.array.menu_add_to_contacts)).setIcon(android.R.drawable.ic_menu_add).setIntent(intent);
                    return;
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case 1:
                myDialog = createAllMessageClearDialog();
                break;
            case 4:
                myDialog = createThreadDeleteDialog();
                break;
            case 5:
                this.mThreadID = this.mConversation.getThreadId();
                myDialog = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.draft_delete)).setPositiveButton(R.string.monaka_yes, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.37
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        DraftCache.getInstance().setDraftState(ComposeMessageActivity.this.mConversation.getThreadId(), false);
                        ComposeMessageActivity.this.deleteDraftSmsMessage(ComposeMessageActivity.this.mConversation.getThreadId());
                        ComposeMessageActivity.this.createNewMessage();
                    }
                }).setNegativeButton(R.string.monaka_no, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.36
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        ComposeMessageActivity.this.mDialogVisibility = false;
                    }
                }).create();
                MessageUtils.dialogEndCallToHome(this, myDialog);
                break;
            case 6:
                myDialog = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.draft_load)).setPositiveButton(ModeStringUtil.getModeResFromArray(this, R.array.draft__load_reopen), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.39
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        if (ComposeMessageActivity.this.loadDraft()) {
                            ComposeMessageActivity.this.startMsgDispWithDraft();
                        } else {
                            Log.d("Mms", "loadDraft fail.");
                        }
                    }
                }).setNegativeButton(ModeStringUtil.getModeResFromArray(this, R.array.monaka_delete_str), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.38
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        DraftCache.getInstance().setDraftState(ComposeMessageActivity.this.mConversation.getThreadId(), false);
                        ComposeMessageActivity.this.deleteDraftSmsMessage(ComposeMessageActivity.this.mConversation.getThreadId());
                        ComposeMessageActivity.this.createNewMessage();
                    }
                }).create();
                MessageUtils.dialogEndCallToHome(this, myDialog);
                break;
        }
        myDialog.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.android.mms.ui.ComposeMessageActivity.40
            @Override // android.content.DialogInterface.OnCancelListener
            public void onCancel(DialogInterface dialog) {
                ComposeMessageActivity.this.mDialogVisibility = false;
            }
        });
        this.mDialogVisibility = true;
        return myDialog;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private Dialog createAllMessageClearDialog() {
        myDialog = new AlertDialogFp.Builder(this).setTitle(LoggingEvents.EXTRA_CALLING_APP_NAME).setMessage(getString(ModeStringUtil.getModeResFromArray(this, R.array.confirm_clear_all_message))).setPositiveButton(R.string.monaka_yes, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.42
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                ComposeMessageActivity.this.clearAllMessage();
                ComposeMessageActivity.this.mDialogVisibility = false;
            }
        }).setNegativeButton(R.string.monaka_no, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.41
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                ComposeMessageActivity.this.mDialogVisibility = false;
            }
        }).create();
        MessageUtils.dialogEndCallToHome(this, myDialog);
        return myDialog;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public Dialog createThreadDeleteDialog() {
        myDialog = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.confirm_delete_thread)).setPositiveButton(R.string.monaka_yes, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.44
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                ComposeMessageActivity.this.deleteThread();
            }
        }).setNegativeButton(R.string.monaka_no, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.43
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                ComposeMessageActivity.this.mDialogVisibility = false;
            }
        }).create();
        MessageUtils.dialogEndCallToHome(this, myDialog);
        myDialog.show();
        myDialog.getButton(-2).requestFocus();
        return myDialog;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private int getRecipientIndexToContact() {
        int index = 0;
        int count = 0;
        ContactList list = getRecipients();
        for (int i = 0; i < list.size(); i++) {
            Contact c = list.get(i);
            if (!c.existsInDatabase() && canAddToContacts(c)) {
                count++;
                index = i;
            }
        }
        if (count == 1) {
            String title = list.get(0).getNumber();
            String titleName = MessageDispActivity.getContactNameByPhoneNumber(this, title);
            if (!TextUtils.isEmpty(titleName)) {
                index = -1;
            }
        }
        if (count != 1) {
            return -1;
        }
        return index;
    }

    private void confirmDeleteThread(long threadId) {
        Conversation.startQueryHaveLockedMessages(this.mBackgroundQueryHandler, threadId, ConversationList.HAVE_LOCKED_MESSAGES_TOKEN);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void addAttachment(int type, boolean replace) {
        int currentSlideSize = 0;
        SlideshowModel slideShow = this.mWorkingMessage.getSlideshow();
        if (replace && slideShow != null) {
            WorkingMessage.removeThumbnailsFromCache(slideShow);
            SlideModel slide = slideShow.get(0);
            currentSlideSize = slide.getSlideSize();
        }
        switch (type) {
            case 0:
                mReadyAttachment = true;
                MessageUtils.selectImage(this, 100);
                break;
            case 1:
                mReadyAttachment = true;
                MessageUtils.capturePicture(this, REQUEST_CODE_TAKE_PICTURE);
                break;
            case 2:
                mReadyAttachment = true;
                MessageUtils.selectVideo(this, REQUEST_CODE_ATTACH_VIDEO);
                break;
            case 3:
                mReadyAttachment = true;
                long sizeLimit = computeAttachmentSizeLimit(slideShow, currentSlideSize);
                if (sizeLimit > 0) {
                    MessageUtils.recordVideo(this, REQUEST_CODE_TAKE_VIDEO, sizeLimit);
                } else {
                    Toast.makeText((Context) this, (CharSequence) getString(R.string.message_too_big_for_video), 0).show();
                }
                break;
            case 4:
                mReadyAttachment = true;
                MessageUtils.selectAudio(this, REQUEST_CODE_ATTACH_SOUND);
                break;
            case 5:
                mReadyAttachment = true;
                MessageUtils.recordSound(this, REQUEST_CODE_RECORD_SOUND, computeAttachmentSizeLimit(slideShow, currentSlideSize));
                break;
            case 6:
                editSlideshow();
                break;
        }
    }

    public static boolean getReadyAttachmentState() {
        return mReadyAttachment;
    }

    public static void setReadyAttachmentState(boolean inFlag) {
        mReadyAttachment = inFlag;
    }

    public static long computeAttachmentSizeLimit(SlideshowModel slideShow, int currentSlideSize) {
        long sizeLimit = MmsConfig.getMaxMessageSize() - 1024;
        if (slideShow != null) {
            return (sizeLimit - ((long) slideShow.getCurrentMessageSize())) + ((long) currentSlideSize);
        }
        return sizeLimit;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showAddAttachmentDialog(final boolean replace) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_dialog_attach);
        builder.setTitle(R.string.add_attachment);
        if (this.mAttachmentTypeSelectorAdapter == null) {
            this.mAttachmentTypeSelectorAdapter = new AttachmentTypeSelectorAdapter(this, 0);
        }
        builder.setAdapter(this.mAttachmentTypeSelectorAdapter, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.45
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                ComposeMessageActivity.this.addAttachment(ComposeMessageActivity.this.mAttachmentTypeSelectorAdapter.buttonToCommand(which), replace);
                dialog.dismiss();
            }
        });
        builder.show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        WorkingMessage newMessage;
        Contact contact;
        this.mWaitingForSubActivity = false;
        this.mShouldLoadDraft = false;
        if (this.mWorkingMessage.isFakeMmsForDraft()) {
            this.mWorkingMessage.removeFakeMmsForDraft();
        }
        if (requestCode == 109) {
            this.mWorkingMessage.asyncDeleteDraftSmsMessage(this.mConversation);
        }
        if (requestCode == 108 && this.mAddContactIntent != null) {
            String address = this.mAddContactIntent.getStringExtra("email");
            if (address == null) {
                address = this.mAddContactIntent.getStringExtra("phone");
            }
            if (address != null && (contact = Contact.get(address, false)) != null) {
                contact.reload();
            }
        }
        if (requestCode == REQUEST_CODE_DO_ADD_CONTACTS) {
            Contact.invalidateCache();
        }
        if (resultCode == -1) {
            switch (requestCode) {
                case 100:
                    if (data != null) {
                        addImageAsync(data.getData(), false);
                    }
                    break;
                case REQUEST_CODE_TAKE_PICTURE /* 101 */:
                    File file = new File(TempFileProvider.getScrapPath(this));
                    Uri uri = Uri.fromFile(file);
                    MmsApp.getApplication().getThumbnailManager().removeThumbnail(uri);
                    addImageAsync(uri, false);
                    break;
                case REQUEST_CODE_ATTACH_VIDEO /* 102 */:
                    if (data != null) {
                        addVideoAsync(data.getData(), false);
                    }
                    break;
                case REQUEST_CODE_TAKE_VIDEO /* 103 */:
                    Uri videoUri = TempFileProvider.renameScrapFile(".3gp", null, this);
                    MmsApp.getApplication().getThumbnailManager().removeThumbnail(videoUri);
                    addVideoAsync(videoUri, false);
                    break;
                case REQUEST_CODE_ATTACH_SOUND /* 104 */:
                    Uri uri2 = (Uri) data.getParcelableExtra("android.intent.extra.ringtone.PICKED_URI");
                    if (uri2 == null) {
                        uri2 = data.getData();
                    } else if (!Settings.System.DEFAULT_RINGTONE_URI.equals(uri2)) {
                    }
                    addAudio(uri2);
                    break;
                case REQUEST_CODE_RECORD_SOUND /* 105 */:
                    if (data != null) {
                        addAudio(data.getData());
                    }
                    break;
                case REQUEST_CODE_CREATE_SLIDESHOW /* 106 */:
                    if (data != null && (newMessage = WorkingMessage.load(this, data.getData())) != null) {
                        setNewMessageSubject(newMessage);
                        this.mWorkingMessage = newMessage;
                        this.mWorkingMessage.setConversation(this.mConversation);
                        updateThreadIdIfRunning();
                        drawTopPanel(false);
                        drawBottomPanel();
                        updateSendButtonState();
                        invalidateOptionsMenu();
                    }
                    break;
                case REQUEST_CODE_ECM_EXIT_DIALOG /* 107 */:
                    boolean outOfEmergencyMode = data.getBooleanExtra(EXIT_ECM_RESULT, false);
                    if (outOfEmergencyMode) {
                        sendMessage(false);
                    }
                    break;
                case REQUEST_CODE_PICK /* 109 */:
                    if (data != null) {
                        processPickResult(data);
                    }
                    break;
                case REQUEST_CODE_FROM_DRAFT /* 1002 */:
                    finish();
                    break;
                case REQUEST_CODE_ADD_TO_CONTACTS /* 1005 */:
                    if (resultCode == -1) {
                        this.mAddressNumber = getRecipients().get(0).getNumber().replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll(" ", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll("\\(", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll("\\)", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll("\\.", LoggingEvents.EXTRA_CALLING_APP_NAME);
                        addToContacts(this.mAddressNumber);
                    }
                    break;
                case REQUEST_CODE_ITEM_ADD_TO_CONTACTS /* 1006 */:
                    if (resultCode == -1 && selectedNumber != null) {
                        addToContacts(selectedNumber.replaceAll("-", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll(" ", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll("\\(", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll("\\)", LoggingEvents.EXTRA_CALLING_APP_NAME).replaceAll("\\.", LoggingEvents.EXTRA_CALLING_APP_NAME));
                    }
                    break;
            }
            if (requestCode == 1000 && resultCode == -1) {
                String message = data.getStringExtra("key_message");
                sendNewMessage(message);
            }
        }
    }

    public static void setSelectedNumber(String number) {
        selectedNumber = number;
    }

    private void addToContacts(String number) {
        Intent intent = new Intent("com.android.contacts.kidsactivity.KidsContactsPeopleEditlistActivity");
        intent.putExtra("kid_contacts_intentvalue", number);
        intent.putExtra("kids_flag", 3);
        startActivityForResult(intent, REQUEST_CODE_DO_ADD_CONTACTS);
    }

    private void setNewMessageSubject(WorkingMessage newWorkingMessage) {
        if (newWorkingMessage != null && this.mWorkingMessage.hasSubject()) {
            newWorkingMessage.setSubject(this.mWorkingMessage.getSubject(), true);
        }
    }

    public void sendNewMessage(String message) {
        this.mWorkingMessage.setText(message);
        removeRecipientsListeners();
        Log.d("Mms", "sendNewMessage   debug recipients = ***");
        this.mWorkingMessage.send(this.mDebugRecipients);
        this.mSentMessage = true;
        this.mSendingMessage = true;
        addRecipientsListeners();
    }

    public void sendFailedMessage(String address, String message, long timeStamp, long failedMsgId) {
        this.mWorkingMessage.changeFailedMessageToDraft(failedMsgId);
        this.mWorkingMessage.setText(message);
        removeRecipientsListeners();
        this.mWorkingMessage.sendFailedMessage(address, timeStamp);
        this.mSentMessage = true;
        this.mSendingMessage = true;
        addRecipientsListeners();
    }

    public boolean isSendingMessage() {
        return this.mSendingMessage;
    }

    public void deleteOneMessage(long msgId, boolean deleteLocked) {
        Uri deleteUri = ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, msgId);
        PduCache.getInstance().purge(deleteUri);
        this.mBackgroundQueryHandler.startDelete(DELETE_MESSAGE_TOKEN, null, deleteUri, deleteLocked ? null : "locked=0", null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void processPickResult(Intent data) {
        final Parcelable[] uris = data.getParcelableArrayExtra("com.android.contacts.extra.PHONE_URIS");
        int recipientCount = uris != null ? uris.length : 0;
        int recipientLimit = MmsConfig.getRecipientLimit();
        if (recipientLimit == Integer.MAX_VALUE || recipientCount <= recipientLimit) {
            final Handler handler = new Handler();
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle(getText(ModeStringUtil.getModeResFromArray(this, R.array.pick_too_many_recipients)));
            progressDialog.setMessage(getText(ModeStringUtil.getModeResFromArray(this, R.array.adding_recipients)));
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            final Runnable showProgress = new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.46
                @Override // java.lang.Runnable
                public void run() {
                    progressDialog.show();
                }
            };
            handler.postDelayed(showProgress, 1000L);
            new Thread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.47
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        final ContactList list = ContactList.blockingGetByUris(uris);
                        handler.removeCallbacks(showProgress);
                        progressDialog.dismiss();
                        Runnable populateWorker = new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.47.1
                            @Override // java.lang.Runnable
                            public void run() {
                                ComposeMessageActivity.this.mRecipientsEditor.populate(list);
                                ComposeMessageActivity.this.updateTitle(list);
                            }
                        };
                        handler.post(populateWorker);
                    } catch (Throwable th) {
                        handler.removeCallbacks(showProgress);
                        progressDialog.dismiss();
                        throw th;
                    }
                }
            }, "ComoseMessageActivity.processPickResult").start();
            return;
        }
        new AlertDialog.Builder(this).setTitle(ModeStringUtil.getModeResFromArray(this, R.array.pick_too_many_recipients)).setIcon(android.R.drawable.ic_dialog_alert).setMessage(getString(ModeStringUtil.getModeResFromArray(this, R.array.too_many_recipients), new Object[]{Integer.valueOf(recipientCount), Integer.valueOf(recipientLimit)})).setPositiveButton(android.R.string.ok, (DialogInterface.OnClickListener) null).create().show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleAddAttachmentError(final int error, final int mediaTypeStringId) {
        if (error != 0) {
            Log.d("Mms", "handleAddAttachmentError: " + error);
            runOnUiThread(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.49
                @Override // java.lang.Runnable
                public void run() {
                    String title;
                    String message;
                    Resources res = ComposeMessageActivity.this.getResources();
                    String mediaType = res.getString(mediaTypeStringId);
                    switch (error) {
                        case WorkingMessage.IMAGE_TOO_LARGE /* -4 */:
                            title = res.getString(R.string.failed_to_resize_image);
                            message = res.getString(R.string.resize_image_error_information);
                            break;
                        case WorkingMessage.UNSUPPORTED_TYPE /* -3 */:
                            title = res.getString(R.string.unsupported_media_format, mediaType);
                            message = res.getString(ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.select_different_media), mediaType);
                            break;
                        case -2:
                            title = res.getString(R.string.exceed_message_size_limitation, mediaType);
                            message = res.getString(R.string.failed_to_add_media, mediaType);
                            break;
                        case -1:
                            String message2 = res.getString(R.string.failed_to_add_media, mediaType);
                            Toast.makeText((Context) ComposeMessageActivity.this, (CharSequence) message2, 0).show();
                            return;
                        default:
                            throw new IllegalArgumentException("unknown error " + error);
                    }
                    MessageUtils.showErrorDialog(ComposeMessageActivity.this, title, message);
                }
            });
        }
    }

    private void addImageAsync(final Uri uri, final boolean append) {
        getAsyncDialog().runAsync(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.50
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.addImage(uri, append);
            }
        }, null, R.string.adding_attachments_title);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void addImage(Uri uri, boolean append) {
        if (Log.isLoggable("Mms", 2)) {
            log("addImage: append=" + append + ", uri=" + uri);
        }
        int result = this.mWorkingMessage.setAttachment(1, uri, append);
        if (result == -4 || result == -2) {
            if (Log.isLoggable("Mms", 2)) {
                log("resize image " + uri);
            }
            MessageUtils.resizeImageAsync(this, uri, this.mAttachmentEditorHandler, this.mResizeImageCallback, append);
            return;
        }
        handleAddAttachmentError(result, R.string.type_picture);
    }

    private void addVideoAsync(final Uri uri, final boolean append) {
        getAsyncDialog().runAsync(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.51
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.addVideo(uri, append);
            }
        }, null, R.string.adding_attachments_title);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void addVideo(Uri uri, boolean append) {
        if (uri != null) {
            int result = this.mWorkingMessage.setAttachment(2, uri, append);
            handleAddAttachmentError(result, R.string.type_video);
        }
    }

    private void addAudio(Uri uri) {
        int result = this.mWorkingMessage.setAttachment(3, uri, false);
        handleAddAttachmentError(result, R.string.type_audio);
    }

    /* JADX WARN: Multi-variable type inference failed */
    AsyncDialog getAsyncDialog() {
        if (this.mAsyncDialog == null) {
            this.mAsyncDialog = new AsyncDialog(this);
        }
        return this.mAsyncDialog;
    }

    private boolean handleForwardedMessage() {
        Intent intent = getIntent();
        if (!this.mForwardMessageMode) {
            if (this.mConversation == null) {
                return false;
            }
            this.mConversation.setHasMmsForward(false);
            return false;
        }
        if (this.mConversation != null) {
            this.mConversation.setHasMmsForward(true);
            String recipientNumber = intent.getStringExtra("msg_recipient");
            this.mConversation.setForwardRecipientNumber(recipientNumber);
        }
        Uri uri = (Uri) intent.getParcelableExtra("msg_uri");
        if (Log.isLoggable("Mms", 3)) {
            log(LoggingEvents.EXTRA_CALLING_APP_NAME + uri);
        }
        if (uri != null) {
            this.mWorkingMessage = WorkingMessage.load(this, uri);
            this.mWorkingMessage.setSubject(intent.getStringExtra("subject"), false);
        } else {
            this.mWorkingMessage.setText(intent.getStringExtra("sms_body"));
        }
        this.mMsgListAdapter.changeCursor(null);
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private boolean handleViewIntent() {
        Uri intentData;
        Intent intent = getIntent();
        String action = intent.getAction();
        if (("android.intent.action.VIEW".equals(action) || "android.intent.action.SENDTO".equals(action)) && (intentData = intent.getData()) != null) {
            String scheme = intentData.getScheme();
            String body = getBody(intentData);
            ArrayList<String[]> senderList = createSenderList();
            Log.d("Mms", "scheme = " + scheme);
            Log.d("Mms", "body = ****");
            if (TextUtils.equals("sms", scheme) || TextUtils.equals("smsto", scheme)) {
                if (!TextUtils.isEmpty(body)) {
                    Intent newIntent = new Intent((Context) this, (Class<?>) MessageDispActivity.class);
                    newIntent.putExtra("key_message", body);
                    newIntent.putExtra("key_sender", senderList);
                    newIntent.putExtra("key_sender_edit", true);
                    newIntent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
                    startActivityForResult(newIntent, 1001);
                    return true;
                }
            } else if (TextUtils.equals("mms", scheme) || TextUtils.equals("mmsto", scheme)) {
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private boolean handleSendIntent() {
        if (handleViewIntent()) {
            return true;
        }
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras == null) {
            return false;
        }
        final String mimeType = intent.getType();
        String action = intent.getAction();
        if ("android.intent.action.SEND".equals(action)) {
            if (extras.containsKey("android.intent.extra.STREAM")) {
                final Uri uri = (Uri) extras.getParcelable("android.intent.extra.STREAM");
                getAsyncDialog().runAsync(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.52
                    @Override // java.lang.Runnable
                    public void run() {
                        ComposeMessageActivity.this.addAttachment(mimeType, uri, false);
                    }
                }, null, R.string.adding_attachments_title);
                return true;
            }
            if (extras.containsKey("android.intent.extra.TEXT")) {
                this.mWorkingMessage.setText(extras.getString("android.intent.extra.TEXT"));
                return true;
            }
        } else if ("android.intent.action.SEND_MULTIPLE".equals(action) && extras.containsKey("android.intent.extra.STREAM")) {
            SlideshowModel slideShow = this.mWorkingMessage.getSlideshow();
            final ArrayList<Parcelable> uris = extras.getParcelableArrayList("android.intent.extra.STREAM");
            int currentSlideCount = slideShow != null ? slideShow.size() : 0;
            int importCount = uris.size();
            if (importCount + currentSlideCount > 10) {
                importCount = Math.min(10 - currentSlideCount, importCount);
                Toast.makeText((Context) this, (CharSequence) getString(R.string.too_many_attachments, new Object[]{10, Integer.valueOf(importCount)}), 1).show();
            }
            final int numberToImport = importCount;
            getAsyncDialog().runAsync(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.53
                @Override // java.lang.Runnable
                public void run() {
                    for (int i = 0; i < numberToImport; i++) {
                        Parcelable uri2 = (Parcelable) uris.get(i);
                        ComposeMessageActivity.this.addAttachment(mimeType, (Uri) uri2, true);
                    }
                }
            }, null, R.string.adding_attachments_title);
            return true;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void addAttachment(String type, Uri uri, boolean append) {
        if (uri != null) {
            boolean wildcard = "*/*".equals(type);
            if (type.startsWith("image/") || (wildcard && uri.toString().startsWith(mImageUri))) {
                addImage(uri, append);
            } else if (type.startsWith("video/") || (wildcard && uri.toString().startsWith(mVideoUri))) {
                addVideo(uri, append);
            }
        }
    }

    private String getResourcesString(int id, String mediaName) {
        Resources r = getResources();
        return r.getString(id, mediaName);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void drawBottomPanel() {
        resetCounter();
        if (this.mWorkingMessage.hasSlideshow()) {
            this.mBottomPanel.setVisibility(8);
            this.mAttachmentEditor.requestFocus();
            return;
        }
        CharSequence text = this.mWorkingMessage.getText();
        if (text != null && this.mIsSmsEnabled) {
            this.mTextEditor.setTextKeepState(text);
            this.mTextEditor.setSelection(this.mTextEditor.length());
        } else {
            this.mTextEditor.setText(LoggingEvents.EXTRA_CALLING_APP_NAME);
        }
        onKeyboardStateChanged();
        requestFocusTextEditor(this.mIsSaveFocusTextEditor);
    }

    private void hideBottomPanel() {
        this.mBottomPanel.setVisibility(4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void drawTopPanel(boolean showSubjectEditor) {
        boolean showingAttachment = this.mAttachmentEditor.update(this.mWorkingMessage);
        this.mAttachmentEditorScrollView.setVisibility(showingAttachment ? 0 : 8);
        showSubjectEditor(showSubjectEditor || this.mWorkingMessage.hasSubject());
        invalidateOptionsMenu();
        onKeyboardStateChanged();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        if ((v == this.mSendButtonSms || v == this.mSendButtonMms) && isPreparedForSending()) {
            confirmSendMessageIfNeeded();
            return;
        }
        if (v == this.mRecipientsPicker) {
            launchMultiplePhonePicker();
        } else if (v == this.mGuidanceButton) {
            showUsersGuide();
        } else if (v == this.mCreateNewMessageButton) {
            createNewMessage();
        }
    }

    private void launchMultiplePhonePicker() {
        Intent intent = new Intent("com.android.contacts.action.GET_MULTIPLE_PHONES");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.setType("vnd.android.cursor.dir/phone_v2");
        ContactList contacts = this.mRecipientsEditor.constructContactsFromInput(true);
        Uri[] uris = new Uri[contacts.size()];
        int urisCount = 0;
        for (Contact contact : contacts) {
            if (1 == contact.getContactMethodType()) {
                uris[urisCount] = contact.getPhoneUri();
                urisCount++;
            }
        }
        if (urisCount > 0) {
            intent.putExtra("com.android.contacts.extra.PHONE_URIS", uris);
        }
        startActivityForResult(intent, REQUEST_CODE_PICK);
    }

    private void showUsersGuide() {
        Intent intent = new Intent();
        intent.setClassName("com.fujitsu.mobile_phone.ud.usersguide", "com.fujitsu.mobile_phone.ud.usersguide.controller.OtherAppEntrance");
        this.mConversation.getMessageCount();
        intent.putExtra("ID", GUIDE_ID_MESSAGE);
        startActivity(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void createNewMessage() {
        ContactList recipients = getRecipients();
        int count = recipients.size();
        if (count >= 0) {
            ArrayList<String[]> senderList = createSenderList();
            Intent intent = new Intent((Context) this, (Class<?>) MessageDispActivity.class);
            intent.putExtra("key_sender", senderList);
            intent.putExtra("key_sender_edit", false);
            intent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
            startActivityForResult(intent, 1000);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void confirmDestination() {
        ContactList recipients = getRecipients();
        int count = recipients.size();
        if (count >= 0) {
            ArrayList<String[]> senderList = createSenderList();
            Intent intent = new Intent((Context) this, (Class<?>) SenderListActivity.class);
            intent.putExtra("key_sender", senderList);
            intent.putExtra("key_sender_edit", false);
            startActivity(intent);
        }
    }

    private ArrayList<String[]> createSenderList() {
        ContactList recipients = getRecipients();
        return createSenderList(recipients);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private ArrayList<String[]> createSenderList(ContactList recipients) {
        int count = recipients.size();
        ArrayList<String[]> senderList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String number = recipients.get(i).getNumber();
            String name = MessageDispActivity.getContactNameByPhoneNumber(this, number);
            if (name.isEmpty()) {
                name = null;
            }
            senderList.add(new String[]{name, null, number});
        }
        return senderList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void clearAllMessage() {
        MessagingNotification.stopOutOfName();
        MessagingNotification.stopRinging();
        MessagingNotification.stopVibrate();
        long threadId = this.mConversation.getThreadId();
        Conversation.startDelete((Conversation.ConversationQueryHandler) this.mBackgroundQueryHandler, DELETE_ALL_MESSAGE_TOKEN, true, threadId);
        DraftCache.getInstance().setDraftState(threadId, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void deleteThread() {
        long threadId = this.mConversation.getThreadId();
        Conversation.startDelete((Conversation.ConversationQueryHandler) this.mBackgroundQueryHandler, ConversationList.DELETE_CONVERSATION_TOKEN, true, threadId);
        DraftCache.getInstance().setDraftState(threadId, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showCompleteDialog(String message) {
        AlertDialogFp mDialog = new AlertDialogFp.Builder(this).setMessage(message).create();
        mDialog.setAutoDismiss(true);
        mDialog.show();
        this.isShowingDialog = true;
        mDialog.getWindow().addPrivateFlags(4096);
        mDialog.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.android.mms.ui.ComposeMessageActivity.55
            @Override // android.content.DialogInterface.OnKeyListener
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode != 6) {
                    return false;
                }
                ActivityManager mActivityManager = (ActivityManager) ComposeMessageActivity.this.getSystemService("activity");
                dialog.dismiss();
                mActivityManager.goHome();
                return true;
            }
        });
        mDialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.android.mms.ui.ComposeMessageActivity.56
            @Override // android.content.DialogInterface.OnDismissListener
            public void onDismiss(DialogInterface dialog) {
                ComposeMessageActivity.this.isShowingDialog = false;
                if (ComposeMessageActivity.this.isDeleteAll) {
                    ComposeMessageActivity.this.isDeleteAll = false;
                    ComposeMessageActivity.this.finish();
                } else if (ComposeMessageActivity.this.isBlockingFinish) {
                    ComposeMessageActivity.this.isBlockingFinish = false;
                    ComposeMessageActivity.this.goToConversationList();
                }
            }
        });
    }

    @Override // android.widget.TextView.OnEditorActionListener
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (event != null) {
            if (!event.isShiftPressed() && event.getAction() == 0) {
                if (!isPreparedForSending()) {
                    return true;
                }
                confirmSendMessageIfNeeded();
                return true;
            }
            return false;
        }
        if (!isPreparedForSending()) {
            return true;
        }
        confirmSendMessageIfNeeded();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void ensureCorrectButtonHeight() {
        int currentTextLines = this.mTextEditor.getLineCount();
        if (currentTextLines <= 2) {
            this.mTextCounter.setVisibility(8);
        } else if (currentTextLines > 2 && this.mTextCounter.getVisibility() == 8) {
            this.mTextCounter.setVisibility(4);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void initMenu() {
        if (this.mMenu == null) {
            PopupMenu tempMenu = new PopupMenu(this, null);
            tempMenu.inflate(R.menu.compose_message_menu_monaka);
            this.mMenu = tempMenu.getMenu();
            MenuItem reply = this.mMenu.findItem(R.id.action_reply);
            MenuItem forwardMessage = this.mMenu.findItem(R.id.action_forward_message);
            MenuItem callNumber = this.mMenu.findItem(R.id.action_phone_call);
            MenuItem addToContacts = this.mMenu.findItem(R.id.action_add_to_contacts);
            MenuItem deleteConversation = this.mMenu.findItem(R.id.action_delete_one_message);
            MenuItem deleteAllConversation = this.mMenu.findItem(R.id.action_delete_all_message);
            reply.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.msg_reply_str));
            forwardMessage.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_forward_str));
            callNumber.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_call_number_str));
            addToContacts.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_add_to_contact_str));
            deleteConversation.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_delete_str));
            deleteAllConversation.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_delete_all_str));
        }
        this.mMenuHandler = new AppMenuHandler(this, this.mMenu);
        this.mMenuHandler.addObserver(new AppMenuObserver() { // from class: com.android.mms.ui.ComposeMessageActivity.59
            public void onOptionsItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_delete_one_message /* 2131689662 */:
                        if (ComposeMessageActivity.this.g_mMsgItem != null) {
                            DeleteMessageListener l = ComposeMessageActivity.this.new DeleteMessageListener(ComposeMessageActivity.this.g_mMsgItem);
                            ComposeMessageActivity.this.confirmDeleteDialog(l, ComposeMessageActivity.this.g_mMsgItem.mLocked);
                        }
                        break;
                    case R.id.action_delete_all_message /* 2131689663 */:
                        ComposeMessageActivity.this.createThreadDeleteDialog();
                        break;
                    case R.id.action_phone_call /* 2131689664 */:
                        ComposeMessageActivity.this.dialRecipient();
                        break;
                    case R.id.action_add_to_contacts /* 2131689665 */:
                        Intent intent = new Intent("com.fujitsu.settings.ACTION_PWD_CHECK");
                        ComposeMessageActivity.this.startActivityForResult(intent, ComposeMessageActivity.REQUEST_CODE_ADD_TO_CONTACTS);
                        break;
                    case R.id.action_reply /* 2131689666 */:
                        if (!DraftCache.getInstance().hasDraft(ComposeMessageActivity.this.mConversation.getThreadId())) {
                            ComposeMessageActivity.this.createNewMessage();
                        } else {
                            ComposeMessageActivity.this.showDialog(6);
                            ComposeMessageActivity.myDialog.getButton(-1).requestFocus();
                        }
                        break;
                    case R.id.action_forward_message /* 2131689667 */:
                        MessageListItem msgItem = (MessageListItem) ComposeMessageActivity.this.mMsgListView.getSelectedView();
                        String body = msgItem.getMessageItem().mBody;
                        int[] params = SmsMessage.calculateLength(body, false);
                        int msgSize = params[1];
                        int msgEncodingType = params[3];
                        Log.i("Mms", "msgSize = " + msgSize + "  msgEncodingType = " + msgEncodingType);
                        if ((msgEncodingType == 1 && msgSize > ComposeMessageActivity.MAX_HALF_SHAPE_TEXT_SIZE) || (msgEncodingType != 1 && msgSize > ComposeMessageActivity.MAX_FULL_SHAPE_TEXT_SIZE)) {
                            AlertDialogFp toast = new AlertDialogFp.Builder(ComposeMessageActivity.this).setMessage(ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.forward_reject_toast)).create();
                            toast.setAutoDismiss(true);
                            MessageUtils.dialogEndCallToHome(ComposeMessageActivity.this, toast);
                            toast.show();
                        } else {
                            Log.d("Mms", "forward message, text = *****");
                            Intent newSmsIntent = new Intent((Context) ComposeMessageActivity.this, (Class<?>) MessageDispActivity.class);
                            newSmsIntent.putExtra("key_message", body);
                            newSmsIntent.putExtra("key_sender_edit", true);
                            newSmsIntent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
                            newSmsIntent.putExtra(MessageDispActivity.extraKey_from_msg_forward, true);
                            newSmsIntent.putExtra(MessageDispActivity.index_message, body.length());
                            ComposeMessageActivity.instance = ComposeMessageActivity.this;
                            newSmsIntent.setFlags(335544320);
                            ComposeMessageActivity.this.startActivity(newSmsIntent);
                        }
                        break;
                }
            }

            public void onMenuVisibilityChanged(boolean isVisible) {
                if (!isVisible) {
                    ComposeMessageActivity.this.mSoftkey.SetLeftSoftkey(R.string.soft_menu);
                } else {
                    ComposeMessageActivity.this.mSoftkey.SetLeftSoftkey(ModeStringUtil.getModeResFromArray(ComposeMessageActivity.this, R.array.menu_left_key_str));
                }
            }
        });
    }

    private void initResourceRefs() {
        this.mMsgListView = (MessageListView) findViewById(R.id.history);
        this.mMsgListView.setPreviewPixels(0);
        this.mMsgListView.setFocusLoopEnabled(false);
        this.mMsgListView.setDivider(null);
        this.mMsgListView.setClipToPadding(false);
        this.mMsgListView.setClipChildren(false);
        this.mEmptyConversation = (TextView) findViewById(R.id.empty_conversation);
        this.mEmptyConversation.setVisibility(8);
        this.mBottomPanel = findViewById(R.id.bottom_panel);
        this.mTextEditor = (MmsEditText) findViewById(R.id.embedded_text_editor);
        this.mTextEditor.setOnEditorActionListener(this);
        this.mTextEditor.addTextChangedListener(this.mTextEditorWatcher);
        this.mTextEditor.setFilters(new InputFilter[]{new MessageFilter()});
        this.mTextEditor.setOnKeyListener(new View.OnKeyListener() { // from class: com.android.mms.ui.ComposeMessageActivity.60
            @Override // android.view.View.OnKeyListener
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == 0) {
                    switch (keyCode) {
                        case 66:
                            return true;
                    }
                }
                return false;
            }
        });
        this.mTextCounter = (TextView) findViewById(R.id.text_counter);
        this.mSendButtonMms = (TextView) findViewById(R.id.send_button_mms);
        if (TelephonyManager.getDefault().isMultiSimEnabled()) {
            this.mSendButtonMms.setText(R.string.mms1);
        }
        this.mSendButtonSms = (ImageButton) findViewById(R.id.send_button_sms);
        this.mSendButtonMms.setOnClickListener(this);
        this.mSendButtonSms.setOnClickListener(this);
        this.mTopPanel = findViewById(R.id.recipients_subject_linear);
        this.mTopPanel.setFocusable(false);
        this.mAttachmentEditor = (AttachmentEditor) findViewById(R.id.attachment_editor);
        this.mAttachmentEditor.setHandler(this.mAttachmentEditorHandler);
        this.mAttachmentEditorScrollView = findViewById(R.id.attachment_editor_scroll_view);
    }

    private void updateFooterView() {
        ContactList recipients = getRecipients();
        if (recipients != null && recipients.size() < 2) {
            keyGuideFlag = 1;
        } else {
            keyGuideFlag = 2;
        }
        if (!this.mIsSmsEnabled) {
            keyGuideFlag = 0;
        }
        if (recipients == null || recipients.size() != 1 || isPhoneNumber(recipients.get(0)) || this.mIsSmsEnabled) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void confirmDeleteDialog(DialogInterface.OnClickListener listener, boolean locked) {
        AlertDialogFp builder = new AlertDialogFp.Builder(this).setCancelable(true).setMessage(locked ? R.string.confirm_delete_locked_message : ModeStringUtil.getModeResFromArray(this, R.array.compose_delete_one_message)).setPositiveButton(R.string.monaka_yes, listener).setNegativeButton(R.string.monaka_no, (DialogInterface.OnClickListener) null).show();
        MessageUtils.dialogEndCallToHome(this, builder);
        builder.getButton(-2).requestFocus();
    }

    /* JADX WARN: Multi-variable type inference failed */
    void undeliveredMessageDialog(long date) {
        String body;
        if (date >= 0) {
            body = getString(R.string.undelivered_msg_dialog_body, new Object[]{MessageUtils.formatTimeStampString(this, date)});
        } else {
            body = getString(R.string.undelivered_sms_dialog_body);
        }
        Toast.makeText((Context) this, (CharSequence) body, 1).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startMsgListQuery() {
        startMsgListQuery(MESSAGE_LIST_QUERY_TOKEN);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void startMsgListQuery(int token) {
        if (!this.mSendDiscreetMode) {
            Uri conversationUri = this.mConversation.getUri();
            if (conversationUri == null) {
                log("##### startMsgListQuery: conversationUri is null, bail!");
                return;
            }
            long threadId = this.mConversation.getThreadId();
            if (Log.isLoggable("Mms", 2)) {
                if (FJ_TEL_LOG_ACQ_FLG) {
                    log("startMsgListQuery for ***, threadId=" + threadId + " token: " + token + " mConversation: ***");
                } else {
                    log("startMsgListQuery for " + conversationUri + ", threadId=" + threadId + " token: " + token + " mConversation: " + this.mConversation);
                }
            }
            this.mBackgroundQueryHandler.cancelOperation(token);
            try {
                this.mBackgroundQueryHandler.startQuery(token, Long.valueOf(threadId), conversationUri, MessageListAdapter.PROJECTION, null, null, SORT_ORDER_DATE_ASC);
            } catch (SQLiteException e) {
                SqliteWrapper.checkSQLiteException(this, e);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initMessageList() {
        if (this.mMsgListAdapter == null) {
            String highlightString = getIntent().getStringExtra("highlight");
            Pattern highlight = highlightString == null ? null : Pattern.compile("\\b" + Pattern.quote(highlightString), 2);
            this.mMsgListAdapter = new MessageListAdapter(this, null, this.mMsgListView, true, highlight);
            this.mMsgListAdapter.setOnDataSetChangedListener(this.mDataSetChangedListener);
            this.mMsgListAdapter.setMsgListItemHandler(this.mMessageListItemHandler);
            this.mMsgListView.setAdapter(this.mMsgListAdapter);
            this.mMsgListView.setItemsCanFocus(true);
            this.mMsgListView.setChoiceMode(2);
            this.mMsgListView.setVisibility(this.mSendDiscreetMode ? 4 : 0);
            this.mMsgListView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.mms.ui.ComposeMessageActivity.61
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (view != null) {
                        ((MessageListItem) view).onMessageListItemClick();
                    }
                }
            });
            this.mMsgListView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: com.android.mms.ui.ComposeMessageActivity.62
                @Override // android.widget.AdapterView.OnItemSelectedListener
                public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    int listCount = ComposeMessageActivity.this.mMsgListView.getCount() - ComposeMessageActivity.this.mMsgListView.getFooterViewsCount();
                    ComposeMessageActivity.this.g_msgList = arg2;
                    if (arg2 >= listCount) {
                        ComposeMessageActivity.this.g_mMsgItem = null;
                        return;
                    }
                    if (arg1 != null) {
                        int firstVisiblePosition = ComposeMessageActivity.this.mMsgListView.getFirstVisiblePosition() + 1;
                        int lastVisiblePosition = ComposeMessageActivity.this.mMsgListView.getLastVisiblePosition() + 1;
                        if (lastVisiblePosition > listCount) {
                        }
                        TextView mBodyTextView = (TextView) arg1.findViewById(R.id.text_view);
                        mBodyTextView.setFocusable(false);
                        ComposeMessageActivity.this.g_mMsgItem = ((MessageListItem) arg1).getMessageItem();
                        URLSpan[] spans = mBodyTextView.getUrls();
                        if (spans.length != 0 || ComposeMessageActivity.this.g_mMsgItem.isFailedMessage()) {
                        }
                        ComposeMessageActivity.this.mSavedScrollPosition = arg2;
                        ComposeMessageActivity.this.mSavedScrollPositionBack = arg2;
                        ComposeMessageActivity.this.mSavedFirstScrollPosition = ComposeMessageActivity.this.mMsgListView.getFirstVisiblePosition();
                        View v = ComposeMessageActivity.this.mMsgListView.getChildAt(ComposeMessageActivity.this.mSavedScrollPosition - ComposeMessageActivity.this.mSavedFirstScrollPosition);
                        ComposeMessageActivity.this.mTop = v != null ? v.getTop() : 0;
                        ComposeMessageActivity.this.invalidateOptionsMenu();
                    }
                }

                @Override // android.widget.AdapterView.OnItemSelectedListener
                public void onNothingSelected(AdapterView<?> arg0) {
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean loadDraft() {
        if (Log.isLoggable("Mms", 2)) {
            log("CMA.loadDraft");
        }
        this.mWorkingMessage = WorkingMessage.loadDraft(this, this.mConversation, new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.63
            @Override // java.lang.Runnable
            public void run() {
                ComposeMessageActivity.this.drawTopPanel(ComposeMessageActivity.this.isSubjectEditorVisible());
                ComposeMessageActivity.this.drawBottomPanel();
                ComposeMessageActivity.this.updateSendButtonState();
                DraftCache.getInstance().setDraftState(ComposeMessageActivity.this.mConversation.getThreadId(), false);
                ComposeMessageActivity.this.deleteDraftSmsMessage(ComposeMessageActivity.this.mConversation.getThreadId());
            }
        });
        this.mWorkingMessage.setConversation(this.mConversation);
        return !this.mWorkingMessage.getText().toString().equals(LoggingEvents.EXTRA_CALLING_APP_NAME);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void saveDraft(boolean isStopping) {
        if (Log.isLoggable("Mms", 2)) {
            LogTag.debug("saveDraft", new Object[0]);
        }
        if (!this.mWorkingMessage.isDiscarded()) {
            if (!this.mWaitingForSubActivity && !this.mWorkingMessage.isWorthSaving() && (!isRecipientsEditorVisible() || recipientCount() == 0)) {
                if (Log.isLoggable("Mms", 2)) {
                    log("not worth saving, discard WorkingMessage and bail");
                }
                this.mWorkingMessage.discard();
                return;
            }
            this.mWorkingMessage.saveDraft(isStopping);
            if (this.mToastForDraftSave) {
                AlertDialogFp toast = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.message_saved_as_draft)).create();
                toast.setAutoDismiss(true);
                MessageUtils.dialogEndCallToHome(this, toast);
                toast.show();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isPreparedForSending() {
        int recipientCount = recipientCount();
        return recipientCount > 0 && recipientCount <= MmsConfig.getRecipientLimit() && this.mIsSmsEnabled && (this.mWorkingMessage.hasAttachment() || this.mWorkingMessage.hasText() || this.mWorkingMessage.hasSubject());
    }

    private int recipientCount() {
        if (isRecipientsEditorVisible()) {
            int recipientCount = this.mRecipientsEditor.getRecipientCount();
            return recipientCount;
        }
        int recipientCount2 = getRecipients().size();
        return recipientCount2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void sendMessage(boolean bCheckEcmMode) {
        if (bCheckEcmMode) {
            String inEcm = SystemProperties.get("ril.cdma.inecmmode");
            if (Boolean.parseBoolean(inEcm)) {
                try {
                    startActivityForResult(new Intent("android.intent.action.ACTION_SHOW_NOTICE_ECM_BLOCK_OTHERS", (Uri) null), REQUEST_CODE_ECM_EXIT_DIALOG);
                    return;
                } catch (ActivityNotFoundException e) {
                    Log.e("Mms", "Cannot find EmergencyCallbackModeExitDialog", e);
                }
            }
        }
        if (!this.mSendingMessage) {
            String sendingRecipients = this.mConversation.getRecipients().serialize();
            if (!sendingRecipients.equals(this.mDebugRecipients)) {
                String workingRecipients = this.mWorkingMessage.getWorkingRecipients();
                if (!this.mDebugRecipients.equals(workingRecipients)) {
                    if (FJ_TEL_LOG_ACQ_FLG) {
                        LogTag.warnPossibleRecipientMismatch("ComposeMessageActivity.sendMessage recipients in window: \"***\" differ from recipients from conv: \"***\" and working recipients: ***", this);
                    } else {
                        LogTag.warnPossibleRecipientMismatch("ComposeMessageActivity.sendMessage recipients in window: \"" + this.mDebugRecipients + "\" differ from recipients from conv: \"" + sendingRecipients + "\" and working recipients: " + workingRecipients, this);
                    }
                }
            }
            sanityCheckConversation();
            removeRecipientsListeners();
            this.mWorkingMessage.send(this.mDebugRecipients);
            MmsApp.smsFlag = true;
            this.mSentMessage = true;
            this.mSendingMessage = true;
            addRecipientsListeners();
            this.mScrollOnSend = true;
        }
        if (this.mSendDiscreetMode) {
            finish();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void resetMessage() {
        if (Log.isLoggable("Mms", 2)) {
            log("resetMessage");
        }
        this.mAttachmentEditor.hideView();
        this.mAttachmentEditorScrollView.setVisibility(8);
        showSubjectEditor(false);
        requestFocusTextEditor(!this.mIsSaveFocusTextEditor);
        this.mTextEditor.removeTextChangedListener(this.mTextEditorWatcher);
        TextKeyListener.clear(this.mTextEditor.getText());
        this.mWorkingMessage.clearConversation(this.mConversation, false, false);
        this.mWorkingMessage = WorkingMessage.createEmpty(this);
        this.mWorkingMessage.setConversation(this.mConversation);
        hideRecipientEditor();
        drawBottomPanel();
        updateSendButtonState();
        this.mTextEditor.addTextChangedListener(this.mTextEditorWatcher);
        if (this.mIsLandscape) {
            hideKeyboard();
        }
        this.mLastRecipientCount = 0;
        this.mSendingMessage = false;
        invalidateOptionsMenu();
    }

    private void hideKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService("input_method");
        inputMethodManager.hideSoftInputFromWindow(this.mTextEditor.getWindowToken(), 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateSendButtonState() {
        boolean enable = false;
        if (isPreparedForSending()) {
            if (!this.mWorkingMessage.hasSlideshow()) {
                enable = true;
            } else {
                this.mAttachmentEditor.setCanSend(true);
            }
        } else if (this.mAttachmentEditor != null) {
            this.mAttachmentEditor.setCanSend(false);
        }
        if (DISP_ORIGINATING_ADDRESS.equals(this.mTitle)) {
            enable = false;
        }
        boolean requiresMms = this.mWorkingMessage.requiresMms();
        View sendButton = showSmsOrMmsSendButton(requiresMms);
        sendButton.setEnabled(enable);
        sendButton.setFocusable(enable);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private long getMessageDate(Uri uri) {
        Cursor cursor;
        if (uri != null && (cursor = SqliteWrapper.query(this, this.mContentResolver, uri, new String[]{"date"}, (String) null, (String[]) null, (String) null)) != null) {
            try {
                if (cursor.getCount() == 1 && cursor.moveToFirst()) {
                    return cursor.getLong(0) * 1000;
                }
            } finally {
                cursor.close();
            }
        }
        return -1L;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initActivityState(Bundle bundle) {
        Intent intent = getIntent();
        if (bundle != null) {
            setIntent(getIntent().setAction("android.intent.action.VIEW"));
            String recipients = bundle.getString(RECIPIENTS);
            this.mConversation = Conversation.get((Context) this, ContactList.getByNumbers(recipients, false, true), false);
            addRecipientsListeners();
            this.mSendDiscreetMode = bundle.getBoolean(KEY_EXIT_ON_SENT, false);
            this.mForwardMessageMode = bundle.getBoolean(KEY_FORWARDED_MESSAGE, false);
            if (this.mSendDiscreetMode) {
                this.mMsgListView.setVisibility(4);
            }
            this.mWorkingMessage.readStateFromBundle(bundle);
            return;
        }
        long threadId = intent.getLongExtra(THREAD_ID, 0L);
        if (threadId > 0) {
            this.mConversation = Conversation.get((Context) this, threadId, false);
        } else {
            Uri intentData = intent.getData();
            if (intentData != null) {
                this.mConversation = Conversation.get((Context) this, intentData, false);
                this.mWorkingMessage.setText(getBody(intentData));
            } else {
                String address = intent.getStringExtra("address");
                if (!TextUtils.isEmpty(address)) {
                    this.mConversation = Conversation.get((Context) this, ContactList.getByNumbers(address, false, true), false);
                } else {
                    this.mConversation = Conversation.createNew(this);
                }
            }
        }
        updateThreadIdIfRunning();
        this.mSendDiscreetMode = intent.getBooleanExtra(KEY_EXIT_ON_SENT, false);
        this.mForwardMessageMode = intent.getBooleanExtra(KEY_FORWARDED_MESSAGE, false);
        if (this.mSendDiscreetMode) {
            this.mMsgListView.setVisibility(4);
        }
        if (intent.hasExtra("sms_body")) {
            this.mWorkingMessage.setText(intent.getStringExtra("sms_body"));
        }
        this.mWorkingMessage.setSubject(intent.getStringExtra("subject"), false);
    }

    private void initFocus() {
        if (this.mIsKeyboardOpen) {
            if (isRecipientsEditorVisible() && TextUtils.isEmpty(this.mRecipientsEditor.getText()) && !this.mTextEditor.isFocused()) {
                this.mRecipientsEditor.requestFocus();
            } else {
                requestFocusTextEditor(!this.mIsSaveFocusTextEditor);
            }
        }
    }

    private void checkPendingNotification() {
        if (this.mPossiblePendingNotification && hasWindowFocus()) {
            MessagingNotification.sUsersAction = true;
            if (!this.isFromOut) {
                this.mConversation.markAsRead();
            }
            this.mPossiblePendingNotification = false;
        }
    }

    private void smoothScrollToEnd(boolean force, int listSizeChange) {
        int lastItemVisible = this.mMsgListView.getLastVisiblePosition();
        int lastItemInList = this.mMsgListAdapter.getCount() - 1;
        if (lastItemVisible < 0 || lastItemInList < 0) {
            if (Log.isLoggable("Mms", 2)) {
                Log.v("Mms", "smoothScrollToEnd: lastItemVisible=" + lastItemVisible + ", lastItemInList=" + lastItemInList + ", mMsgListView not ready");
                return;
            }
            return;
        }
        View lastChildVisible = this.mMsgListView.getChildAt(lastItemVisible - this.mMsgListView.getFirstVisiblePosition());
        int lastVisibleItemBottom = 0;
        int lastVisibleItemHeight = 0;
        if (lastChildVisible != null) {
            lastVisibleItemBottom = lastChildVisible.getBottom();
            lastVisibleItemHeight = lastChildVisible.getHeight();
        }
        if (Log.isLoggable("Mms", 2)) {
            Log.v("Mms", "smoothScrollToEnd newPosition: " + lastItemInList + " mLastSmoothScrollPosition: " + this.mLastSmoothScrollPosition + " first: " + this.mMsgListView.getFirstVisiblePosition() + " lastItemVisible: " + lastItemVisible + " lastVisibleItemBottom: " + lastVisibleItemBottom + " lastVisibleItemBottom + listSizeChange: " + (lastVisibleItemBottom + listSizeChange) + " mMsgListView.getHeight() - mMsgListView.getPaddingBottom(): " + (this.mMsgListView.getHeight() - this.mMsgListView.getPaddingBottom()) + " listSizeChange: " + listSizeChange);
        }
        int listHeight = this.mMsgListView.getHeight();
        boolean lastItemTooTall = lastVisibleItemHeight > listHeight;
        boolean willScroll = force || (!(listSizeChange == 0 && lastItemInList == this.mLastSmoothScrollPosition) && lastVisibleItemBottom + listSizeChange <= listHeight - this.mMsgListView.getPaddingBottom());
        if (willScroll || (lastItemTooTall && lastItemInList == lastItemVisible)) {
            if (Math.abs(listSizeChange) > SMOOTH_SCROLL_THRESHOLD) {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "keyboard state changed. setSelection=" + lastItemInList);
                }
                if (lastItemTooTall) {
                    this.mMsgListView.setSelectionFromTop(lastItemInList, listHeight - lastVisibleItemHeight);
                    return;
                } else {
                    this.mMsgListView.setSelection(lastItemInList);
                    return;
                }
            }
            if (lastItemInList - lastItemVisible > 20) {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "too many to scroll, setSelection=" + lastItemInList);
                }
                this.mMsgListView.setSelection(lastItemInList);
            } else {
                if (Log.isLoggable("Mms", 2)) {
                    Log.v("Mms", "smooth scroll to " + lastItemInList);
                }
                if (lastItemTooTall) {
                    this.mMsgListView.setSelectionFromTop(lastItemInList, listHeight - lastVisibleItemHeight);
                } else {
                    this.mMsgListView.smoothScrollToPosition(lastItemInList);
                }
                this.mLastSmoothScrollPosition = lastItemInList;
            }
        }
    }

    private final class BackgroundQueryHandler extends Conversation.ConversationQueryHandler {
        public BackgroundQueryHandler(ContentResolver contentResolver) {
            super(contentResolver);
        }

        @Override // android.content.AsyncQueryHandler
        protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
            switch (token) {
                case ConversationList.HAVE_LOCKED_MESSAGES_TOKEN /* 1802 */:
                    if (ComposeMessageActivity.this.isFinishing()) {
                        Log.w("Mms", "ComposeMessageActivity is finished, do nothing ");
                        if (cursor != null) {
                            cursor.close();
                        }
                    } else {
                        ArrayList<Long> threadIds = (ArrayList) cookie;
                        ConversationList.confirmDeleteThreadDialog(new ConversationList.DeleteThreadListener(threadIds, ComposeMessageActivity.this.mBackgroundQueryHandler, ComposeMessageActivity.this), threadIds, cursor != null && cursor.getCount() > 0, ComposeMessageActivity.this);
                        if (cursor != null) {
                            cursor.close();
                        }
                    }
                    break;
                case ComposeMessageActivity.MESSAGE_LIST_QUERY_TOKEN /* 9527 */:
                    if (cursor == null || cursor.getCount() == 0) {
                        if (ComposeMessageActivity.this.mDeleteMsg && !ComposeMessageActivity.this.isFromOut) {
                            if (ComposeMessageActivity.this.isShowingDialog) {
                                ComposeMessageActivity.this.isBlockingFinish = true;
                            } else {
                                ComposeMessageActivity.this.goToConversationList();
                            }
                        }
                    } else {
                        if (ComposeMessageActivity.this.mSoftkey.getLeftSoftkey() != null && !ComposeMessageActivity.this.mSoftkey.getLeftSoftkey().isShown()) {
                            ComposeMessageActivity.this.mSoftkey.SetLeftSoftkey(ComposeMessageActivity.this.getString(R.string.soft_menu));
                        }
                        ComposeMessageActivity.this.mSoftkey.SetCenterSoftkey(R.drawable.key_center);
                        ComposeMessageActivity.this.initMenu();
                    }
                    long tid = ((Long) cookie).longValue();
                    if (Log.isLoggable("Mms", 2)) {
                        ComposeMessageActivity.log("##### onQueryComplete: msg history result for threadId " + tid);
                    }
                    if (tid != ComposeMessageActivity.this.mConversation.getThreadId()) {
                        ComposeMessageActivity.log("onQueryComplete: msg history query result is for threadId " + tid + ", but mConversation has threadId " + ComposeMessageActivity.this.mConversation.getThreadId() + " starting a new query");
                        if (cursor != null) {
                            cursor.close();
                        }
                        ComposeMessageActivity.this.startMsgListQuery();
                    } else {
                        ComposeMessageActivity.this.sanityCheckConversation();
                        int newSelectionPos = -1;
                        long targetMsgId = ComposeMessageActivity.this.getIntent().getLongExtra("select_id", -1L);
                        if (targetMsgId == -1) {
                            if (ComposeMessageActivity.this.mSavedScrollPosition != -1) {
                                newSelectionPos = ComposeMessageActivity.this.mSavedScrollPosition;
                                ComposeMessageActivity.this.mSavedScrollPosition = -1;
                            }
                        } else if (cursor != null) {
                            cursor.moveToPosition(-1);
                            while (cursor.moveToNext()) {
                                long msgId = cursor.getLong(1);
                                if (msgId == targetMsgId) {
                                    newSelectionPos = cursor.getPosition();
                                }
                            }
                        }
                        ComposeMessageActivity.this.mMsgListAdapter.changeCursor(cursor);
                        if (newSelectionPos != -1) {
                            ComposeMessageActivity.this.mMsgListView.setSelectionFromTop(newSelectionPos, ComposeMessageActivity.this.mTop);
                            if (ComposeMessageActivity.this.mOldSize != ComposeMessageActivity.this.mMsgListView.getCount()) {
                                boolean setLast = true;
                                if (ComposeMessageActivity.this.mDeleteMsg && ComposeMessageActivity.this.mMsgListView.getCount() > 0) {
                                    setLast = false;
                                }
                                if (setLast) {
                                    ComposeMessageActivity.this.mOldSize = ComposeMessageActivity.this.mMsgListView.getCount();
                                    ComposeMessageActivity.this.mMsgListView.setSelection(ComposeMessageActivity.this.mMsgListView.getCount() - 1);
                                }
                            }
                        } else {
                            int count = ComposeMessageActivity.this.mMsgListAdapter.getCount();
                            long lastMsgId = 0;
                            if (cursor != null && count > 0) {
                                cursor.moveToLast();
                                lastMsgId = cursor.getLong(1);
                            }
                            if (lastMsgId != ComposeMessageActivity.this.mLastMessageId) {
                                ComposeMessageActivity.this.mMsgListView.setSelection(ComposeMessageActivity.this.mMsgListView.getCount() - 1);
                                ComposeMessageActivity.this.mOldSize = ComposeMessageActivity.this.mMsgListView.getCount();
                            }
                            ComposeMessageActivity.this.mLastMessageId = lastMsgId;
                            ComposeMessageActivity.this.mScrollOnSend = false;
                        }
                        ComposeMessageActivity.this.mConversation.setMessageCount(ComposeMessageActivity.this.mMsgListAdapter.getCount());
                        if (ComposeMessageActivity.this.mConversation.getMessageCount() <= 0) {
                            ComposeMessageActivity.this.mEmptyConversation.setVisibility(8);
                            if (!ComposeMessageActivity.this.mStartSendNewMessage && !ComposeMessageActivity.this.isFromOut) {
                                if (ComposeMessageActivity.this.isShowingDialog) {
                                    ComposeMessageActivity.this.isBlockingFinish = true;
                                } else {
                                    ComposeMessageActivity.this.goToConversationList();
                                }
                            }
                        } else {
                            ComposeMessageActivity.this.mEmptyConversation.setVisibility(8);
                        }
                        if (ComposeMessageActivity.this.mIsAllMessageDeleted) {
                            ComposeMessageActivity.this.mIsAllMessageDeleted = false;
                            ContactList contactList = ComposeMessageActivity.this.mConversation.getRecipients();
                            ComposeMessageActivity.this.mConversation.setMessageCount(0);
                            ComposeMessageActivity.this.mWorkingMessage.discard();
                            ComposeMessageActivity.this.mConversation = Conversation.createNew(ComposeMessageActivity.this.getApplicationContext());
                            ComposeMessageActivity.this.mConversation.setRecipients(contactList);
                            ComposeMessageActivity.this.mConversation.ensureThreadId();
                            ComposeMessageActivity.this.mWorkingMessage = WorkingMessage.createEmpty(ComposeMessageActivity.this);
                            ComposeMessageActivity.this.mWorkingMessage.setConversation(ComposeMessageActivity.this.mConversation);
                        }
                        if (cursor.getCount() != 0 || ComposeMessageActivity.this.isRecipientsEditorVisible() || !ComposeMessageActivity.this.mSentMessage) {
                        }
                        if (cursor.getCount() == 0 && ComposeMessageActivity.this.mDeleteMsg) {
                            long threadId = ComposeMessageActivity.this.mConversation.getThreadId();
                            ConversationList.execDeleteThread(threadId, ComposeMessageActivity.this.mBackgroundQueryHandler, ComposeMessageActivity.this);
                            ComposeMessageActivity.this.mDeleteMsg = false;
                        }
                        ComposeMessageActivity.this.requestFocusTextEditor(!ComposeMessageActivity.this.mIsSaveFocusTextEditor);
                        Log.d("Mms", "on query complete block mark as read ");
                        if (!ComposeMessageActivity.this.isReplyMessage) {
                            ComposeMessageActivity.this.mConversation.blockMarkAsRead(false);
                        }
                        ComposeMessageActivity.this.invalidateOptionsMenu();
                        if (!ComposeMessageActivity.this.mIsScreenOff) {
                            ComposeMessageActivity.this.needToMarkAsSeen();
                        }
                    }
                    break;
                case 9528:
                    long tid2 = ((Long) cookie).longValue();
                    if (Log.isLoggable("Mms", 2)) {
                        ComposeMessageActivity.log("##### onQueryComplete (after delete): msg history result for threadId " + tid2);
                    }
                    if (cursor != null) {
                        if (tid2 > 0 && cursor.getCount() == 0) {
                            ComposeMessageActivity.log("##### MESSAGE_LIST_QUERY_AFTER_DELETE_TOKEN clearing thread id: " + tid2);
                            Conversation conv = Conversation.get((Context) ComposeMessageActivity.this, tid2, false);
                            if (conv != null) {
                                conv.clearThreadId();
                                conv.setDraftState(false);
                            }
                            if (!ComposeMessageActivity.this.isFromOut) {
                                if (ComposeMessageActivity.this.isShowingDialog) {
                                    ComposeMessageActivity.this.isBlockingFinish = true;
                                } else {
                                    ComposeMessageActivity.this.exitComposeMessageActivity(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.BackgroundQueryHandler.1
                                        @Override // java.lang.Runnable
                                        public void run() {
                                            ComposeMessageActivity.this.goToConversationList();
                                        }
                                    });
                                }
                            } else {
                                ComposeMessageActivity.this.finish();
                            }
                        }
                        cursor.close();
                    }
                    break;
            }
        }

        @Override // com.android.mms.data.Conversation.ConversationQueryHandler, android.content.AsyncQueryHandler
        protected void onDeleteComplete(int token, Object cookie, int result) {
            super.onDeleteComplete(token, cookie, result);
            switch (token) {
                case ConversationList.DELETE_CONVERSATION_TOKEN /* 1801 */:
                    ComposeMessageActivity.this.mConversation.setMessageCount(0);
                case ComposeMessageActivity.DELETE_MESSAGE_TOKEN /* 9700 */:
                    ComposeMessageActivity.this.mDeleteMsg = true;
                    if ((cookie instanceof Boolean) && ((Boolean) cookie).booleanValue()) {
                        ComposeMessageActivity.this.mLastMessageId = 0L;
                    }
                    MessagingNotification.nonBlockingUpdateNewMessageIndicator(ComposeMessageActivity.this, false, false);
                    ComposeMessageActivity.this.updateSendFailedNotification();
                    break;
                case ComposeMessageActivity.DELETE_ALL_MESSAGE_TOKEN /* 10000 */:
                    ComposeMessageActivity.this.mIsAllMessageDeleted = true;
                    MessagingNotification.nonBlockingUpdateNewMessageIndicator(ComposeMessageActivity.this, false, false);
                    ComposeMessageActivity.this.updateSendFailedNotification();
                    break;
            }
            if (result > 0) {
                ComposeMessageActivity.this.mDeletedHandler.sendEmptyMessage(1);
            }
            if (token == 1801) {
                ContactList recipients = ComposeMessageActivity.this.mConversation.getRecipients();
                ComposeMessageActivity.this.mWorkingMessage.discard();
                if (recipients != null) {
                    for (Contact contact : recipients) {
                        contact.removeFromCache();
                    }
                }
                Conversation.init(ComposeMessageActivity.this);
                ComposeMessageActivity.this.isDeleteAll = true;
            } else if (token == ComposeMessageActivity.DELETE_MESSAGE_TOKEN) {
                ComposeMessageActivity.this.startMsgListQuery(9528);
            }
            MmsWidgetProvider.notifyDatasetChanged(ComposeMessageActivity.this.getApplicationContext());
        }
    }

    @Override // com.android.mms.data.Contact.UpdateListener
    public void onUpdate(final Contact updated) {
        this.mMessageListItemHandler.post(new Runnable() { // from class: com.android.mms.ui.ComposeMessageActivity.65
            @Override // java.lang.Runnable
            public void run() {
                ContactList recipients;
                if (ComposeMessageActivity.this.isRecipientsEditorVisible()) {
                    recipients = ComposeMessageActivity.this.mRecipientsEditor.constructContactsFromInput(false);
                } else {
                    recipients = ComposeMessageActivity.this.getRecipients();
                }
                if (Log.isLoggable("Mms", 2)) {
                    if (ComposeMessageActivity.FJ_TEL_LOG_ACQ_FLG) {
                        ComposeMessageActivity.log("[CMA] onUpdate contact updated: ***");
                        ComposeMessageActivity.log("[CMA] onUpdate recipients: ***");
                    } else {
                        ComposeMessageActivity.log("[CMA] onUpdate contact updated: " + updated);
                        ComposeMessageActivity.log("[CMA] onUpdate recipients: " + recipients);
                    }
                }
                ComposeMessageActivity.this.updateTitle(recipients);
                ComposeMessageActivity.this.mMsgListAdapter.notifyDataSetChanged();
            }
        });
    }

    private void addRecipientsListeners() {
        Contact.addListener(this);
    }

    private void removeRecipientsListeners() {
        Contact.removeListener(this);
    }

    public static Intent createIntent(Context context, long threadId) {
        Intent intent = new Intent(context, (Class<?>) ComposeMessageActivity.class);
        if (threadId > 0) {
            intent.setData(Conversation.getUri(threadId));
        }
        return intent;
    }

    public static Intent createIntentAddFlags(Context context, long threadId, boolean addFlags) {
        Intent intent = new Intent(context, (Class<?>) ComposeMessageActivity.class);
        if (addFlags) {
            intent.setFlags(335544320);
        }
        if (threadId > 0) {
            intent.setData(Conversation.getUri(threadId));
        }
        return intent;
    }

    private String getBody(Uri uri) {
        String strDecode = null;
        if (uri != null) {
            String urlStr = uri.getSchemeSpecificPart();
            if (urlStr.contains("?")) {
                String[] params = urlStr.substring(urlStr.indexOf(63) + 1).split("&");
                for (String p : params) {
                    if (p.startsWith("body=")) {
                        try {
                            strDecode = URLDecoder.decode(p.substring(5), "UTF-8");
                            break;
                        } catch (UnsupportedEncodingException e) {
                        }
                    }
                }
            }
        }
        return strDecode;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateThreadIdIfRunning() {
        if (this.mIsRunning && this.mConversation != null) {
            MessagingNotification.setCurrentlyDisplayedThreadId(this.mConversation.getThreadId());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void needToMarkAsSeen() {
        if (this.mNeedToMarkAsSeen) {
            this.mNeedToMarkAsSeen = false;
            Conversation.markAllConversationsAsSeen(getApplicationContext());
        }
    }

    public class OnScreenReceiver extends BroadcastReceiver {
        public OnScreenReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("android.intent.action.USER_PRESENT".equals(intent.getAction())) {
                ComposeMessageActivity.this.mIsScreenOff = false;
                if (ComposeMessageActivity.this.mIsForeground) {
                    ComposeMessageActivity.this.needToMarkAsSeen();
                    return;
                }
                return;
            }
            if ("android.intent.action.SCREEN_OFF".equals(intent.getAction())) {
                ComposeMessageActivity.this.mIsScreenOff = true;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void editMessage(MessageItem msgItem) {
        ContactList recipients = getRecipients();
        int count = recipients.size();
        if (count < 0) {
            LogUtil.printFormatLog("Debug_Log", 5, "recipient < 0");
            return;
        }
        this.mMessageItem = msgItem;
        ArrayList<String[]> senderList = createSenderList();
        LogUtil.printFormatLog("Debug_Log", 4, "Sender List Size = " + senderList.size());
        LogUtil.printFormatLog("Debug_Log", 4, "Message = ******");
        Intent intent = new Intent((Context) this, (Class<?>) MessageDispActivity.class);
        intent.putExtra("key_message", msgItem.mBody);
        intent.putExtra("key_sender", senderList);
        intent.putExtra("key_sender_edit", false);
        intent.putExtra(MessageDispActivity.extraKey_from_conversation_list, false);
        startActivityForResult(intent, 1000);
    }

    public void sendFailedMessage(MessageItem msgItem) {
        if (msgItem.mType.equals("sms")) {
            this.mWorkingMessage.changeFailedMessageToDraft(msgItem.mMsgId);
            this.mWorkingMessage.setText(msgItem.mBody);
        }
        removeRecipientsListeners();
        this.mWorkingMessage.sendFailedMessage(msgItem.mAddress, msgItem.mDate);
        this.mSentMessage = true;
        this.mSendingMessage = true;
        addRecipientsListeners();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void requestFocusTextEditor(boolean request) {
        if (request) {
            this.mTextEditor.requestFocus();
            this.mIsSaveFocusTextEditor = false;
        }
    }

    private class MessageFilter implements InputFilter {
        private MessageFilter() {
        }

        @Override // android.text.InputFilter
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            if (!TextUtils.isEmpty(source)) {
                String destStr = dest.toString();
                String newValue = destStr.substring(0, dstart) + ((Object) source) + destStr.substring(dend);
                CharSequence newSource = ComposeMessageActivity.this.changeInputeSourceString(newValue, source);
                Log.d("Mms", "newSource: ***");
                return newSource;
            }
            return source;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public CharSequence changeInputeSourceString(CharSequence dest, CharSequence source) {
        int maxlength;
        int[] params = SmsMessage.calculateLength(dest, false);
        int msgcount = params[0];
        int i = params[1];
        int remainingInCurrentMessage = params[2];
        int msgEncodingType = params[3];
        if (msgEncodingType == 1) {
            maxlength = 1530;
            Log.d("Mms", "maxlength: 1530");
        } else {
            maxlength = 670;
            Log.d("Mms", "maxlength: 670");
        }
        if (msgcount > 10) {
            int source_len = source.length();
            if (source_len <= ((maxlength / 10) * (msgcount - 10)) - remainingInCurrentMessage) {
                Log.d("Mms", "GSM7bit to other");
                return LoggingEvents.EXTRA_CALLING_APP_NAME;
            }
            this.mTextCounter.setVisibility(0);
            CharSequence newSourceStr = source.subSequence(0, source_len - (((maxlength / 10) * (msgcount - 10)) - remainingInCurrentMessage));
            Log.d("Mms", "after cut down newSourceStr:" + ((Object) newSourceStr));
            return newSourceStr;
        }
        Log.d("Mms", "normal input");
        return source;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void startMsgDispWithDraft() {
        Intent intent = getIntent();
        Uri intentData = intent.getData();
        if (intentData != null) {
            intentData.getScheme();
        }
        Log.d("Mms", "final mWorkingMessage.getText()******");
        String body = this.mWorkingMessage.getText().toString();
        ArrayList<String[]> senderList = createSenderList();
        Intent newIntent = new Intent((Context) this, (Class<?>) MessageDispActivity.class);
        newIntent.putExtra("key_message", body);
        newIntent.putExtra(MessageDispActivity.index_message, body.length());
        newIntent.putExtra("key_sender", senderList);
        newIntent.putExtra("key_sender_edit", false);
        newIntent.putExtra(MessageDispActivity.extraKey_have_draft, true);
        newIntent.putExtra(MessageDispActivity.extraKey_edited, true);
        newIntent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
        newIntent.putExtra(MessageDispActivity.extraKey_reply_message, true);
        startActivity(newIntent);
        if (this.mShouldLoadDraft) {
            finish();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void deleteDraftSmsMessage(long threadId) {
        SqliteWrapper.delete(this, getContentResolver(), ContentUris.withAppendedId(Telephony.Sms.Conversations.CONTENT_URI, threadId), SMS_DRAFT_WHERE, (String[]) null);
    }
}
