package com.android.mms.ui;

import android.app.AlertDialog;
import android.app.AlertDialogFp;
import android.app.TitleBarActivity;
import android.content.AsyncQueryHandler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SqliteWrapper;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.provider.FjSettings;
import android.provider.Telephony;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.telephony.PhoneNumberUtils;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AppMenuHandler;
import android.widget.AppMenuObserver;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListViewFP;
import android.widget.PopupMenu;
import android.widget.SearchView;
import android.widget.SoftkeyView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.common.speech.LoggingEvents;
import com.android.mms.LogTag;
import com.android.mms.MmsConfig;
import com.android.mms.R;
import com.android.mms.data.Contact;
import com.android.mms.data.ContactList;
import com.android.mms.data.Conversation;
import com.android.mms.transaction.ISmsRingtoneService;
import com.android.mms.transaction.MessagingNotification;
import com.android.mms.transaction.SmsRejectedReceiver;
import com.android.mms.util.DownloadManager;
import com.android.mms.util.DraftCache;
import com.android.mms.util.ModeStringUtil;
import com.android.mms.util.Recycler;
import com.android.mms.widget.MmsWidgetProvider;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class ConversationList extends TitleBarActivity implements View.OnClickListener, DraftCache.OnDraftChangedListener {
    private static final String CHECKED_MESSAGE_LIMITS = "checked_message_limits";
    private static final boolean DEBUG = false;
    private static final boolean DEBUGCLEANUP = true;
    private static final int DELETED_FAILED = 2;
    private static final int DELETED_SUCCESS = 1;
    public static final int DELETE_CONVERSATION_TOKEN = 1801;
    private static final int DELETE_OBSOLETE_THREADS_TOKEN = 1803;
    private static final int DIALOG_ID_ADDRESS_NOT_SAVED = 7;
    static final int DIALOG_ID_DEL = 4;
    static final int DIALOG_ID_DELETE_DRAFT = 6;
    static final int DIALOG_ID_HAVE_DRAFT = 4;
    static final int DIALOG_ID_NOTSMS_SUBMENU = 5;
    static final int DIALOG_ID_NO_PHONE_NUMBER = 3;
    static final int DIALOG_ID_POPUP = 1;
    static final int DIALOG_ID_SUBMENU = 2;
    private static final int GUIDE_ID_LISTDATA = 177;
    private static final int GUIDE_ID_LISTDATA_NONE = 178;
    public static final int HAVE_LOCKED_MESSAGES_TOKEN = 1802;
    private static final String LAST_LIST_OFFSET = "last_list_offset";
    private static final String LAST_LIST_POS = "last_list_pos";
    private static final boolean LOCAL_LOGV = false;
    public static final int MENU_ADD_TO_CONTACTS = 3;
    public static final int MENU_DELETE = 0;
    public static final int MENU_VIEW = 1;
    public static final int MENU_VIEW_CONTACT = 2;
    private static final int RequestCode_AddContacts = 10;
    private static final String SMS_DRAFT_WHERE = "type=3";
    private static final String TAG = "Mms";
    private static final int THREAD_LIST_QUERY_TOKEN = 1701;
    private static final int UNREAD_THREADS_QUERY_TOKEN = 1702;
    private static final int WAITING_TIME_OF_VOICE = 1000;
    private static boolean mExistMessage;
    private static boolean mIsSmsEnabled;
    private static ConversationListAdapter mListAdapter;
    private TextView emptyView;
    private ListViewFP listView;
    private Toast mComposeDisabledToast;
    MenuItem mContactItem;
    private Context mContext;
    MenuItem mDailItem;
    MenuItem mDelitem;
    private boolean mDialogVisibility;
    private boolean mDoOnceAfterFirstQuery;
    private Handler mHandler;
    private Menu mMenu;
    private AppMenuHandler mMenuHandler;
    private int mMessageCount;
    private boolean mNeedToMarkAsSeen;
    private SharedPreferences mPrefs;
    private ThreadListQueryHandler mQueryHandler;
    MenuItem mSIMitem;
    private int mSavedFirstItemOffset;
    SelectedCheckHandler mSelectCheckHandler;
    MenuItem mSetitem;
    private View mSmsPromoBannerView;
    private SoftkeyView mSoftkey;
    private long mThreadID;
    private int mTitle;
    private ImageView sms_default_app_icon;
    private int themeMode;
    static AlertDialogFp myDialog = null;
    private static int keyGuideFlag = 0;
    private static String mPhoneString = LoggingEvents.EXTRA_CALLING_APP_NAME;
    private static ISmsRingtoneService mISmsRingtoneService = null;
    private static ServiceConnection mServiceConnection = new ServiceConnection() { // from class: com.android.mms.ui.ConversationList.1
        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName name, IBinder binder) {
            ISmsRingtoneService unused = ConversationList.mISmsRingtoneService = ISmsRingtoneService.Stub.asInterface(binder);
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName name) {
            ISmsRingtoneService unused = ConversationList.mISmsRingtoneService = null;
        }
    };
    private boolean mIsSimReady = false;
    private View mItemView = null;
    private boolean isSelectMode = false;
    private HashSet<Long> mSelectedIdSet = new HashSet<>();
    private HashSet<Long> mEmptyIdSet = new HashSet<>();
    private boolean mIsSelf = false;
    private int mSavedFirstVisiblePosition = -1;
    private int mPosition = 0;
    private LinearLayout ll_toptitle = null;
    private final ConversationListAdapter.OnContentChangedListener mContentChangedListener = new ConversationListAdapter.OnContentChangedListener() { // from class: com.android.mms.ui.ConversationList.4
        @Override // com.android.mms.ui.ConversationListAdapter.OnContentChangedListener
        public void onContentChanged(ConversationListAdapter adapter) {
            ConversationList.this.startAsyncQuery();
        }
    };
    SearchView.OnQueryTextListener mQueryTextListener = new SearchView.OnQueryTextListener() { // from class: com.android.mms.ui.ConversationList.10
        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        @Override // android.widget.SearchView.OnQueryTextListener
        public boolean onQueryTextSubmit(String query) {
            Intent intent = new Intent();
            intent.setClass(ConversationList.this, SearchActivity.class);
            intent.putExtra("query", query);
            ConversationList.this.startActivity(intent);
            return true;
        }

        @Override // android.widget.SearchView.OnQueryTextListener
        public boolean onQueryTextChange(String newText) {
            return false;
        }
    };
    private ArrayList<String[]> mSenderList = null;
    private final View.OnCreateContextMenuListener mConvListOnCreateContextMenuListener = new View.OnCreateContextMenuListener() { // from class: com.android.mms.ui.ConversationList.28
        @Override // android.view.View.OnCreateContextMenuListener
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            Cursor cursor = ConversationList.mListAdapter.getCursor();
            if (cursor != null && cursor.getPosition() >= 0) {
                ConversationList.this.mPosition = cursor.getPosition();
                Conversation conv = Conversation.from(ConversationList.this, cursor);
                ContactList recipients = conv.getRecipients();
                menu.setHeaderTitle(recipients.formatNames(MessageDispActivity.string_delimiter));
                menu.add(0, 1, 0, ModeStringUtil.getModeResFromArray(ConversationList.this, R.array.menu_view));
                if (recipients.size() == 1) {
                    if (recipients.get(0).existsInDatabase()) {
                        menu.add(0, 2, 0, ModeStringUtil.getModeResFromArray(ConversationList.this, R.array.menu_view_contact));
                    } else {
                        String name = recipients.get(0).getNameAndNumber();
                        if (!ComposeMessageActivity.DISP_ORIGINATING_ADDRESS.equals(name)) {
                            menu.add(0, 3, 0, ModeStringUtil.getModeResFromArray(ConversationList.this, R.array.menu_add_to_contacts));
                        }
                    }
                }
                if (ConversationList.mIsSmsEnabled) {
                    menu.add(0, 0, 0, ModeStringUtil.getModeResFromArray(ConversationList.this, R.array.menu_delete));
                }
            }
        }
    };
    private final View.OnKeyListener mThreadListKeyListener = new View.OnKeyListener() { // from class: com.android.mms.ui.ConversationList.31
        @Override // android.view.View.OnKeyListener
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (event.getAction() == 0) {
                switch (keyCode) {
                    case 67:
                        long id = ConversationList.this.listView.getSelectedItemId();
                        if (id > 0) {
                            ConversationList.confirmDeleteThread(id, ConversationList.this.mQueryHandler);
                        }
                        return true;
                }
            }
            return false;
        }
    };
    private final Runnable mDeleteObsoleteThreadsRunnable = new Runnable() { // from class: com.android.mms.ui.ConversationList.32
        @Override // java.lang.Runnable
        public void run() {
            if (Log.isLoggable("Mms", 2)) {
                LogTag.debug("mDeleteObsoleteThreadsRunnable getSavingDraft(): " + DraftCache.getInstance().getSavingDraft(), new Object[0]);
            }
            if (DraftCache.getInstance().getSavingDraft()) {
                LogTag.debug("mDeleteObsoleteThreadsRunnable saving draft, trying again", new Object[0]);
                ConversationList.this.mHandler.postDelayed(ConversationList.this.mDeleteObsoleteThreadsRunnable, 1000L);
            }
        }
    };
    private Handler mDeletedHandler = new Handler() { // from class: com.android.mms.ui.ConversationList.33
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    String message = ConversationList.this.getString(ModeStringUtil.getModeResFromArray(ConversationList.this, R.array.delete_success_message));
                    MessageUtils.showCompleteDialog(ConversationList.this, message);
                    break;
            }
        }
    };
    private boolean mIsScreenOff = false;
    private boolean mIsForeground = false;
    private OnScreenReceiver mScreenReceiver = new OnScreenReceiver();

    private static void stopNotification() {
        if (mISmsRingtoneService != null) {
            try {
                mISmsRingtoneService.stopToRington();
                mISmsRingtoneService.stopToVibrator();
            } catch (RemoteException e) {
                Log.e("Mms", "[Ringtone][RemoteException]");
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        IntentFilter screenFilter = new IntentFilter();
        screenFilter.addAction("android.intent.action.USER_PRESENT");
        screenFilter.addAction("android.intent.action.SCREEN_OFF");
        registerReceiver(this.mScreenReceiver, screenFilter);
        View view = getLayoutInflater().inflate(R.layout.conversation_list_screen_monaka, (ViewGroup) null);
        Intent intent = new Intent(ISmsRingtoneService.class.getName());
        intent.setPackage(getPackageName());
        bindService(intent, mServiceConnection, 1);
        stopNotification();
        setContentView(view);
        this.themeMode = FjSettings.System.getInt(getContentResolver(), "theme_type", 1);
        int resId = getResources().getThemeResFromArray(R.array.theme_background);
        getWindow().setBackgroundDrawableResource(resId);
        getWindow().addPrivateFlags(4096);
        initView();
        initListener();
        this.mSmsPromoBannerView = findViewById(R.id.banner_sms_promo);
        this.mQueryHandler = new ThreadListQueryHandler(getContentResolver());
        this.listView = findViewById(R.id.list);
        this.listView.setPreviewPixels(0);
        this.emptyView = (TextView) findViewById(R.id.empty);
        if (this.themeMode == 4) {
            this.emptyView.setTextColor(getResources().getColor(R.color.text_normal_simple_color));
        } else {
            this.emptyView.setTextColor(getResources().getColor(R.color.text_normal_color));
        }
        this.listView.setEmptyView(this.emptyView);
        this.listView.setSelection(0);
        this.mSelectCheckHandler = new SelectedCheckHandler();
        initListAdapter();
        setupActionBar();
        this.listView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: com.android.mms.ui.ConversationList.2
            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                String unused = ConversationList.mPhoneString = ((ConversationListItem) arg1).formatConMessage().toString();
                ConversationList.this.mItemView = arg1;
                ConversationList.this.mIsSelf = ((ConversationListItem) arg1).isMySelf();
                ConversationList.this.invalidateOptionsMenu();
                ConversationList.this.mThreadID = ((ConversationListItem) arg1).getConversation().getThreadId();
                ConversationList.mListAdapter.setSelectedIndex(ConversationList.this.listView.getSelectedItemPosition(), ConversationList.this.mThreadID);
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        this.mTitle = ModeStringUtil.getModeResFromArray(this, R.array.conversation_list_title);
        this.mHandler = new Handler();
        this.mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean checkedMessageLimits = this.mPrefs.getBoolean(CHECKED_MESSAGE_LIMITS, false);
        if (!checkedMessageLimits) {
            runOneTimeStorageLimitCheckForLegacyMessages();
        }
        if (savedInstanceState != null) {
            this.mSavedFirstVisiblePosition = savedInstanceState.getInt(LAST_LIST_POS, -1);
            this.mSavedFirstItemOffset = savedInstanceState.getInt(LAST_LIST_OFFSET, 0);
        } else {
            this.mSavedFirstVisiblePosition = -1;
            this.mSavedFirstItemOffset = 0;
        }
        this.mDialogVisibility = false;
        this.mContext = this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v8, types: [com.android.mms.ui.ConversationList$3] */
    protected void onResume() {
        super.onResume();
        boolean isSmsEnabled = MmsConfig.isSmsEnabled(this);
        if (isSmsEnabled != mIsSmsEnabled) {
            mIsSmsEnabled = isSmsEnabled;
            invalidateOptionsMenu();
        }
        cancelReceiverDisplay(this);
        if (mIsSmsEnabled || MmsConfig.isSmsPromoDismissed(this)) {
            this.mSmsPromoBannerView.setVisibility(8);
        } else {
            initSmsPromoBanner();
            this.mSmsPromoBannerView.setVisibility(0);
        }
        mListAdapter.setOnContentChangedListener(this.mContentChangedListener);
        this.mIsForeground = true;
        mListAdapter.initAllUnreadMessageCount();
        Log.d("Mms", "mDialogVisibility:" + this.mDialogVisibility + " isSelectMode:" + this.isSelectMode);
        if (!this.mDialogVisibility && !this.isSelectMode) {
            setNavigationBarMenuButtonVisibility(true);
        }
        if (this.isSelectMode) {
            new Thread() { // from class: com.android.mms.ui.ConversationList.3
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    super.run();
                    while (true) {
                        if ((ConversationList.this.mSelectedIdSet.size() == 0 || ConversationList.this.listView.getChildCount() != 0) && ConversationList.this.listView.getCount() == ConversationList.this.listView.getChildCount()) {
                            break;
                        }
                        try {
                            Thread.sleep(100L);
                        } catch (InterruptedException e) {
                            Log.e("Mms", e.getMessage());
                        }
                    }
                    if (ConversationList.this.mSelectedIdSet.size() != 0 && ConversationList.this.listView.getChildCount() != 0 && ConversationList.this.listView.getCount() == ConversationList.this.listView.getChildCount()) {
                        ConversationList.this.mSelectCheckHandler.sendEmptyMessage(0);
                    }
                }
            }.start();
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(LAST_LIST_POS, this.mSavedFirstVisiblePosition);
        outState.putInt(LAST_LIST_OFFSET, this.mSavedFirstItemOffset);
    }

    public static void cancelReceiverDisplay(Context context) {
        Intent intent = new Intent("com.nextfp.android.util.sublcd.ACTION_SMS_IDLE");
        intent.setPackage("com.nextfp.android.util.sublcd");
        context.sendBroadcast(intent);
    }

    public void onPause() {
        super.onPause();
        if (this.mMenuHandler != null) {
            this.mMenuHandler.hideAppMenu();
        }
        mListAdapter.setOnContentChangedListener(null);
        this.mIsForeground = false;
        setDelConversationMod(false);
    }

    private void setNavigationBarBackButtonType(int backButtonType) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setNavigationBarMenuButtonVisibility(boolean menuButtonVisibility) {
    }

    private void setupActionBar() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initListAdapter() {
        mListAdapter = new ConversationListAdapter(this, null);
        mListAdapter.setOnContentChangedListener(this.mContentChangedListener);
        this.listView.setAdapter(mListAdapter);
        this.listView.setRecyclerListener(mListAdapter);
        this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.mms.ui.ConversationList.5
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (ConversationList.mIsSmsEnabled) {
                    Cursor cursor = (Cursor) ConversationList.this.listView.getItemAtPosition(position);
                    Conversation conv = Conversation.from(ConversationList.this, cursor);
                    long tid = conv.getThreadId();
                    if (ConversationList.this.isSelectMode) {
                        ConversationListItem headerView = (ConversationListItem) view;
                        headerView.selectStatusToggle();
                        boolean checked = headerView.getSelectedStatus();
                        if (checked) {
                            ConversationList.this.mSelectedIdSet.add(Long.valueOf(tid));
                        } else {
                            ConversationList.this.mSelectedIdSet.remove(Long.valueOf(tid));
                        }
                        ConversationList.mListAdapter.setAllSelectedId(ConversationList.this.mSelectedIdSet);
                        return;
                    }
                    int msgCount = conv.getMessageCount();
                    ConversationList.this.openThread(tid, msgCount);
                }
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initSmsPromoBanner() {
        PackageManager packageManager = getPackageManager();
        String smsAppPackage = Telephony.Sms.getDefaultSmsPackage(this);
        Drawable smsAppIcon = null;
        ApplicationInfo smsAppInfo = null;
        try {
            smsAppIcon = packageManager.getApplicationIcon(smsAppPackage);
            smsAppInfo = packageManager.getApplicationInfo(smsAppPackage, 0);
        } catch (PackageManager.NameNotFoundException e) {
        }
        final Intent smsAppIntent = packageManager.getLaunchIntentForPackage(smsAppPackage);
        if (smsAppIcon != null && smsAppInfo != null && smsAppIntent != null) {
            ImageView defaultSmsAppIconImageView = (ImageView) this.mSmsPromoBannerView.findViewById(R.id.banner_sms_default_app_icon);
            defaultSmsAppIconImageView.setImageDrawable(smsAppIcon);
            TextView smsPromoBannerTitle = (TextView) this.mSmsPromoBannerView.findViewById(R.id.banner_sms_promo_title);
            String message = getResources().getString(ModeStringUtil.getModeResFromArray(this, R.array.banner_sms_promo_title_application), smsAppInfo.loadLabel(packageManager));
            smsPromoBannerTitle.setText(message);
            this.mSmsPromoBannerView.setOnClickListener(new View.OnClickListener() { // from class: com.android.mms.ui.ConversationList.6
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ConversationList.this.startActivity(smsAppIntent);
                }
            });
            return;
        }
        this.mSmsPromoBannerView.setOnClickListener(new View.OnClickListener() { // from class: com.android.mms.ui.ConversationList.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Intent settingsIntent = new Intent((Context) ConversationList.this, (Class<?>) MessagingPreferenceActivity.class);
                ConversationList.this.startActivityIfNeeded(settingsIntent, -1);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    public synchronized void runOneTimeStorageLimitCheckForLegacyMessages() {
        if (Recycler.isAutoDeleteEnabled(this)) {
            markCheckedMessageLimit();
        } else {
            new Thread(new Runnable() { // from class: com.android.mms.ui.ConversationList.8
                @Override // java.lang.Runnable
                public void run() {
                    if (Recycler.checkForThreadsOverLimit(ConversationList.this)) {
                        ConversationList.this.mHandler.postDelayed(new Runnable() { // from class: com.android.mms.ui.ConversationList.8.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Intent intent = new Intent((Context) ConversationList.this, (Class<?>) WarnOfStorageLimitsActivity.class);
                                ConversationList.this.startActivity(intent);
                            }
                        }, 2000L);
                    } else {
                        ConversationList.this.runOnUiThread(new Runnable() { // from class: com.android.mms.ui.ConversationList.8.2
                            @Override // java.lang.Runnable
                            public void run() {
                                SharedPreferences.Editor editor = ConversationList.this.mPrefs.edit();
                                editor.putBoolean(MessagingPreferenceActivity.AUTO_DELETE, true);
                                editor.apply();
                            }
                        });
                    }
                    ConversationList.this.runOnUiThread(new Runnable() { // from class: com.android.mms.ui.ConversationList.8.3
                        @Override // java.lang.Runnable
                        public void run() {
                            ConversationList.this.markCheckedMessageLimit();
                        }
                    });
                }
            }, "ConversationList.runOneTimeStorageLimitCheckForLegacyMessages").start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void markCheckedMessageLimit() {
        SharedPreferences.Editor editor = this.mPrefs.edit();
        editor.putBoolean(CHECKED_MESSAGE_LIMITS, true);
        editor.apply();
    }

    protected void onNewIntent(Intent intent) {
        startAsyncQuery();
        this.listView.setSelection(0);
    }

    protected void onStart() {
        super.onStart();
        MessagingNotification.cancelNotification(getApplicationContext(), SmsRejectedReceiver.SMS_REJECTED_NOTIFICATION_ID);
        DraftCache.getInstance().addOnDraftChangedListener(this);
        this.mNeedToMarkAsSeen = true;
        startAsyncQuery();
        if (!Conversation.loadingThreads()) {
            Contact.invalidateCache();
        }
    }

    public void onHomeKeyEvent() {
        MessagingNotification.stopOutOfName();
        MessagingNotification.stopRinging();
        MessagingNotification.stopVibrate();
    }

    protected void onStop() {
        super.onStop();
        stopAsyncQuery();
        unbindListeners(null);
    }

    protected void onDestroy() {
        unregisterReceiver(this.mScreenReceiver);
        super.onDestroy();
        Cursor cursor = mListAdapter.getCursor();
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        unbindService(mServiceConnection);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void unbindListeners(Collection<Long> threadIds) {
        for (int i = 0; i < this.listView.getChildCount(); i++) {
            View view = this.listView.getChildAt(i);
            if (view instanceof ConversationListItem) {
                ConversationListItem item = (ConversationListItem) view;
                if (threadIds == null) {
                    item.unbind();
                } else if (threadIds.contains(Long.valueOf(item.getConversation().getThreadId()))) {
                    item.unbind();
                }
            }
        }
    }

    @Override // com.android.mms.util.DraftCache.OnDraftChangedListener
    public void onDraftChanged(final long threadId, final boolean hasDraft) {
        this.mQueryHandler.post(new Runnable() { // from class: com.android.mms.ui.ConversationList.9
            @Override // java.lang.Runnable
            public void run() {
                if (Log.isLoggable("Mms", 2)) {
                    ConversationList.this.log("onDraftChanged: threadId=" + threadId + ", hasDraft=" + hasDraft, new Object[0]);
                }
                ConversationList.mListAdapter.notifyDataSetChanged();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void startAsyncQuery() {
        try {
            Conversation.startQueryForAll(this.mQueryHandler, THREAD_LIST_QUERY_TOKEN);
            Conversation.startQuery(this.mQueryHandler, UNREAD_THREADS_QUERY_TOKEN, "read=0");
        } catch (SQLiteException e) {
            SqliteWrapper.checkSQLiteException(this, e);
        }
    }

    private void stopAsyncQuery() {
        if (this.mQueryHandler != null) {
            this.mQueryHandler.cancelOperation(THREAD_LIST_QUERY_TOKEN);
            this.mQueryHandler.cancelOperation(UNREAD_THREADS_QUERY_TOKEN);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        return !mPhoneString.equals(LoggingEvents.EXTRA_CALLING_APP_NAME) || mListAdapter.getCount() == 0;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        return false;
    }

    public static boolean isPhoneNumber(String contactPhoneNumber) {
        return Telephony.Mms.isEmailAddress(contactPhoneNumber) || Telephony.Mms.isPhoneNumber(contactPhoneNumber);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void createNewMessage() {
        setNavigationBarMenuButtonVisibility(false);
        Intent intent = new Intent((Context) this, (Class<?>) RecipientSelectActivity.class);
        intent.putExtra("Activity", "ConversationList");
        intent.putExtra(PhoneNumberInputActivity.KEY_MODE, 2);
        startActivity(intent);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.d("Mms", "onKeyDown " + keyCode);
        if (keyCode == 131 && event.getRepeatCount() == 0) {
            MenuItem callNumber = this.mMenu.findItem(R.id.action_call_number);
            MenuItem addToContacts = this.mMenu.findItem(R.id.action_add_to_contacts);
            MenuItem reply = this.mMenu.findItem(R.id.action_reply);
            MenuItem mSIMitem = this.mMenu.findItem(R.id.action_reference_sim_card);
            mSIMitem.setVisible(mIsSmsEnabled);
            mSIMitem.setEnabled(isPhoneUsimState(this.mContext));
            MenuItem deleteConversation = this.mMenu.findItem(R.id.action_delete);
            MenuItem deleteAllConversation = this.mMenu.findItem(R.id.action_delete_all);
            if (!mExistMessage) {
                reply.setVisible(false);
                callNumber.setVisible(false);
                addToContacts.setVisible(false);
                deleteConversation.setVisible(false);
                deleteAllConversation.setVisible(false);
            } else {
                deleteConversation.setVisible(true);
                deleteAllConversation.setVisible(true);
                Boolean isName = Boolean.valueOf(MessageUtils.isAllSaved(mPhoneString));
                Log.d("Mms", "Is Name = " + isName + "  Is one contact = " + isOneContact(mPhoneString) + "  xxxxxx");
                boolean smsEnabled = FjSettings.Global.getInt(getContentResolver(), "send_message_setting", 1) == 1;
                if (isOneContact(mPhoneString)) {
                    if (isName.booleanValue()) {
                        callNumber.setVisible(true);
                        addToContacts.setVisible(false);
                    } else {
                        callNumber.setVisible(false);
                        if (isPhoneNumber(mPhoneString)) {
                            addToContacts.setVisible(true);
                        } else {
                            addToContacts.setVisible(false);
                        }
                    }
                } else {
                    addToContacts.setVisible(false);
                    callNumber.setVisible(false);
                }
                if (smsEnabled && isName.booleanValue()) {
                    reply.setVisible(true);
                } else {
                    reply.setVisible(false);
                }
            }
            this.mMenuHandler.showAppMenu(this.mSoftkey);
        }
        if (this.isSelectMode) {
            if (keyCode != 4) {
                return false;
            }
            if (!this.mDialogVisibility) {
                setDelConversationMod(false);
                return false;
            }
            return super.onKeyDown(keyCode, event);
        }
        if (keyCode == 6 && event.getRepeatCount() == 0) {
            MessageUtils.endCallToHome(this);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showDeleteDialog(final long id) {
        AlertDialogFp mDialog = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.delete_dialog_msg)).setPositiveButton(getString(R.string.monaka_yes), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.12
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                ConversationList.execDeleteThread(id, ConversationList.this.mQueryHandler, ConversationList.this);
            }
        }).setNegativeButton(getString(R.string.monaka_no), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.11
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
            }
        }).create();
        if (id == -1) {
            mDialog.setMessage(getResources().getString(ModeStringUtil.getModeResFromArray(this, R.array.confirm_delete_all_conversations)));
        }
        MessageUtils.dialogEndCallToHome(this, mDialog);
        mDialog.show();
        mDialog.getButton(-2).requestFocus();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showDialogEx(int id) {
        setNavigationBarMenuButtonVisibility(false);
        this.mDialogVisibility = true;
        switch (id) {
            case 1:
                myDialog = new AlertDialogFp.Builder(this).setTitle(LoggingEvents.EXTRA_CALLING_APP_NAME).setMessage(getString(ModeStringUtil.getModeResFromArray(this, R.array.address_selection_detail))).setPositiveButton(ModeStringUtil.getModeResFromArray(this, R.array.address_selection_button1), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.14
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent("android.intent.action.PICK", ContactsContract.Contacts.CONTENT_URI);
                        ConversationList.this.startActivityForResult(intent, 1);
                    }
                }).setNegativeButton(ModeStringUtil.getModeResFromArray(this, R.array.address_selection_button2), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.13
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent((Context) ConversationList.this, (Class<?>) PhoneNumberInputActivity.class);
                        intent.putExtra(PhoneNumberInputActivity.KEY_MODE, 2);
                        ConversationList.this.startActivityForResult(intent, 0);
                    }
                }).create();
                myDialog.show();
                myDialog.getButton(-2).requestFocus();
                break;
            case 3:
                myDialog = new AlertDialogFp.Builder(this).setTitle(LoggingEvents.EXTRA_CALLING_APP_NAME).setMessage(getString(ModeStringUtil.getModeResFromArray(this, R.array.sms_no_phone_number))).setPositiveButton(ModeStringUtil.getModeResFromArray(this, R.array.sms_noinput_dialog_return), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.15
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        ConversationList.this.setNavigationBarMenuButtonVisibility(true);
                    }
                }).create();
                myDialog.show();
                break;
            case 4:
                myDialog = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.draft_load)).setPositiveButton(ModeStringUtil.getModeResFromArray(this, R.array.draft__load_reopen), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.17
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Intent draftIntent = ComposeMessageActivity.createIntent(ConversationList.this.mContext, ConversationList.this.mThreadID);
                        draftIntent.putExtra(ComposeMessageActivity.EXTRA_LOAD_DRAFT, true);
                        ConversationList.this.startActivity(draftIntent);
                        ConversationList.this.overridePendingTransition(0, 0);
                    }
                }).setNegativeButton(ModeStringUtil.getModeResFromArray(this, R.array.monaka_delete_str), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.16
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        DraftCache.getInstance().setDraftState(ConversationList.this.mThreadID, false);
                        ConversationList.this.deleteDraftSmsMessage(ConversationList.this.mThreadID);
                        if (ConversationList.this.mMessageCount != 0) {
                            Intent intent = ComposeMessageActivity.createIntent(ConversationList.this.mContext, ConversationList.this.mThreadID);
                            ConversationList.this.startActivity(intent);
                        }
                        ConversationList.this.overridePendingTransition(0, 0);
                    }
                }).create();
                myDialog.show();
                break;
            case 6:
                myDialog = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.draft_load)).setPositiveButton(ModeStringUtil.getModeResFromArray(this, R.array.draft__load_reopen), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.19
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Intent draftIntent = ComposeMessageActivity.createIntent(ConversationList.this.mContext, ConversationList.this.mThreadID);
                        draftIntent.putExtra(ComposeMessageActivity.EXTRA_LOAD_DRAFT, true);
                        draftIntent.putExtra(MessageDispActivity.extraKey_reply_message, true);
                        ConversationList.this.startActivity(draftIntent);
                    }
                }).setNegativeButton(ModeStringUtil.getModeResFromArray(this, R.array.monaka_delete_str), new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.18
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        DraftCache.getInstance().setDraftState(ConversationList.this.mThreadID, false);
                        ConversationList.this.deleteDraftSmsMessage(ConversationList.this.mThreadID);
                        ConversationList.this.createNewMessageByName(ConversationList.mPhoneString);
                    }
                }).create();
                myDialog.show();
                break;
            case 7:
                myDialog = new AlertDialogFp.Builder(this).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.no_save_address)).setPositiveButton(R.string.monaka_yes, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.21
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        DraftCache.getInstance().setDraftState(ConversationList.this.mThreadID, false);
                        ConversationList.this.deleteDraftSmsMessage(ConversationList.this.mThreadID);
                    }
                }).setNegativeButton(R.string.monaka_no, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.20
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        ConversationList.myDialog.dismiss();
                    }
                }).create();
                myDialog.show();
                myDialog.getButton(-2).requestFocus();
                break;
        }
        myDialog.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.android.mms.ui.ConversationList.22
            @Override // android.content.DialogInterface.OnCancelListener
            public void onCancel(DialogInterface dialog) {
                ConversationList.this.setNavigationBarMenuButtonVisibility(true);
                ConversationList.this.mDialogVisibility = false;
            }
        });
        myDialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.android.mms.ui.ConversationList.23
            @Override // android.content.DialogInterface.OnDismissListener
            public void onDismiss(DialogInterface dialog) {
                ConversationList.this.mDialogVisibility = false;
            }
        });
        myDialog.setOnShowListener(new DialogInterface.OnShowListener() { // from class: com.android.mms.ui.ConversationList.24
            @Override // android.content.DialogInterface.OnShowListener
            public void onShow(DialogInterface dialog) {
                ConversationList.this.setNavigationBarMenuButtonVisibility(false);
                ConversationList.this.mDialogVisibility = true;
                if (ConversationList.this.mDelitem != null) {
                    ConversationList.this.mDelitem.setEnabled(ConversationList.mListAdapter.getCount() != 0);
                }
            }
        });
        MessageUtils.dialogEndCallToHome(this, myDialog);
        this.mDialogVisibility = true;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 0:
                if (data != null && data.getStringExtra("ResultFor").equals("INPUTPHONE")) {
                    returnInputNum(resultCode, data);
                    break;
                } else if (data != null && data.getStringExtra("ResultFor").equals("CONTACTSELECT")) {
                    returnGetPhone(resultCode, data);
                    break;
                }
                break;
            case 1:
                returnGetPhone(resultCode, data);
                break;
            case 2:
                returnSelectNum(resultCode, data);
                break;
            case 10:
                if (resultCode == -1) {
                    addContact2(mPhoneString);
                }
                break;
        }
    }

    private void returnInputNum(int resultCode, Intent data) {
        if (resultCode == -1) {
            ArrayList<String[]> senderList = new ArrayList<>();
            String phone = data.getStringExtra("KeyPhoneNumber");
            senderList.add(new String[]{null, null, phone});
            startMessageDispActivity(senderList);
            return;
        }
        if (resultCode == 0) {
            createNewMessage();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void returnGetPhone(int resultCode, Intent data) {
        if (resultCode == -1) {
            ArrayList<String[]> phoneNumberList = new ArrayList<>();
            ContentResolver resolver = getContentResolver();
            Cursor personCursor = resolver.query(data.getData(), null, null, null, null);
            if (personCursor != null) {
                if (personCursor.moveToFirst()) {
                    String displayName = personCursor.getString(personCursor.getColumnIndex("display_name"));
                    String uniqueId = personCursor.getString(personCursor.getColumnIndex("_id"));
                    Cursor phoneCursor = resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, "contact_id = ? ", new String[]{uniqueId}, null);
                    if (phoneCursor != null) {
                        while (phoneCursor.moveToNext()) {
                            String phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndex("data1"));
                            int type = phoneCursor.getInt(phoneCursor.getColumnIndex("data2"));
                            String label = phoneCursor.getString(phoneCursor.getColumnIndex("data3"));
                            String labelName = ContactsContract.CommonDataKinds.Phone.getTypeLabel(getResources(), type, label).toString();
                            phoneNumberList.add(new String[]{displayName, labelName, Contact.get(phoneNumber, false).getNumber()});
                        }
                        phoneCursor.close();
                    }
                }
                personCursor.close();
            }
            int phoneNumberCount = phoneNumberList.size();
            if (1 == phoneNumberCount) {
                ArrayList<String[]> senderList = new ArrayList<>();
                senderList.add(new String[]{phoneNumberList.get(0)[0], phoneNumberList.get(0)[1], phoneNumberList.get(0)[2]});
                startMessageDispActivity(senderList);
                return;
            } else if (1 < phoneNumberCount) {
                Intent intent = new Intent((Context) this, (Class<?>) PhoneNumberListActivity.class);
                intent.putExtra(PhoneNumberListActivity.extraKey_phoneNumberList, phoneNumberList);
                startActivityForResult(intent, 2);
                return;
            } else {
                this.mDialogVisibility = true;
                Toast.makeText((Context) this, ModeStringUtil.getModeResFromArray(this, R.array.sms_no_phone_number), 1).show();
                new Handler().postDelayed(new Runnable() { // from class: com.android.mms.ui.ConversationList.25
                    @Override // java.lang.Runnable
                    public void run() {
                    }
                }, 1000L);
                return;
            }
        }
        if (resultCode == 0) {
            createNewMessage();
        }
    }

    private void returnSelectNum(int resultCode, Intent data) {
        if (resultCode == -1) {
            String[] phoneNumber = data.getStringArrayExtra(PhoneNumberListActivity.extraKey_selectedPhoneNumber);
            if (phoneNumber != null) {
                ArrayList<String[]> senderList = new ArrayList<>();
                senderList.add(phoneNumber);
                startMessageDispActivity(senderList);
                return;
            }
            return;
        }
        createNewMessage();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void startMessageDispActivity(ArrayList<String[]> senderList) {
        Intent intent = new Intent((Context) this, (Class<?>) RecipientSelectActivity.class);
        intent.putExtra(MessageDispActivity.extraKey_to_msg_disp, true);
        intent.putExtra("Activity", "ConversationList");
        intent.putExtra(PhoneNumberInputActivity.KEY_MODE, 2);
        intent.putExtra("key_sender", senderList);
        intent.putExtra("key_sender_edit", true);
        intent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
        startActivity(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void openThread(long threadId, int messageCount) {
        this.mThreadID = threadId;
        this.mMessageCount = messageCount;
        boolean smsEnabled = FjSettings.Global.getInt(getContentResolver(), "send_message_setting", 1) == 1;
        if (DraftCache.getInstance().hasDraft(threadId) && mIsSmsEnabled && messageCount == 0) {
            if (smsEnabled) {
                if (MessageUtils.isAllSaved(mPhoneString)) {
                    showDialogEx(4);
                    return;
                } else {
                    showDialogEx(7);
                    return;
                }
            }
            showDialogNoEdit();
            return;
        }
        startActivity(ComposeMessageActivity.createIntent(this, threadId));
        overridePendingTransition(0, 0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showDialogNoEdit() {
        myDialog = new AlertDialogFp.Builder(this).setTitle(LoggingEvents.EXTRA_CALLING_APP_NAME).setMessage(ModeStringUtil.getModeResFromArray(this, R.array.edit_email_message_dialog)).setPositiveButton(R.string.monaka_yes, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.27
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                Cursor cursor = ConversationList.mListAdapter.getCursor();
                Conversation conv = Conversation.from(ConversationList.this, cursor);
                int msgCount = conv.getMessageCount();
                DraftCache.getInstance().setDraftState(ConversationList.this.mThreadID, false);
                ConversationList.this.deleteDraftSmsMessage(ConversationList.this.mThreadID);
                if (msgCount != 0) {
                    ConversationList.this.startActivity(ComposeMessageActivity.createIntent(ConversationList.this.mContext, ConversationList.this.mThreadID));
                    ConversationList.this.overridePendingTransition(0, 0);
                }
            }
        }).setNegativeButton(R.string.monaka_no, new DialogInterface.OnClickListener() { // from class: com.android.mms.ui.ConversationList.26
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
            }
        }).create();
        MessageUtils.dialogEndCallToHome(this, myDialog);
        myDialog.show();
        myDialog.getButton(-2).requestFocus();
    }

    public static Intent createAddContactIntent(String address) {
        Intent intent = new Intent("android.intent.action.INSERT_OR_EDIT");
        intent.setType("vnd.android.cursor.item/contact");
        if (Telephony.Mms.isEmailAddress(address)) {
            intent.putExtra("email", address);
        } else {
            intent.putExtra("phone", address);
            intent.putExtra("phone_type", 2);
        }
        intent.setFlags(AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END);
        return intent;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean onContextItemSelected(MenuItem item) {
        Cursor cursor = mListAdapter.getCursor();
        cursor.moveToPosition(this.mPosition);
        if (cursor != null && cursor.getPosition() >= 0) {
            Conversation conv = Conversation.from(this, cursor);
            long threadId = conv.getThreadId();
            int msgCount = conv.getMessageCount();
            switch (item.getItemId()) {
                case 0:
                    confirmDeleteThread(threadId, this.mQueryHandler);
                    break;
                case 1:
                    openThread(threadId, msgCount);
                    break;
                case 2:
                    Contact contact = conv.getRecipients().get(0);
                    Intent intent = new Intent("android.intent.action.VIEW", contact.getUri());
                    intent.setFlags(AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END);
                    startActivity(intent);
                    break;
                case 3:
                    String address = conv.getRecipients().get(0).getNumber();
                    startActivity(createAddContactIntent(address));
                    break;
            }
        }
        return super.onContextItemSelected(item);
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    public static void confirmDeleteThread(long threadId, AsyncQueryHandler handler) {
        ArrayList<Long> threadIds = null;
        if (threadId != -1) {
            threadIds = new ArrayList<>();
            threadIds.add(Long.valueOf(threadId));
        }
        confirmDeleteThreads(threadIds, handler);
    }

    public static void confirmDeleteThreads(Collection<Long> threadIds, AsyncQueryHandler handler) {
        Conversation.startQueryHaveLockedMessages(handler, threadIds, HAVE_LOCKED_MESSAGES_TOKEN);
    }

    public static void confirmDeleteThreadDialog(final DeleteThreadListener listener, Collection<Long> threadIds, boolean hasLockedMessages, Context context) {
        View contents = View.inflate(context, R.layout.delete_thread_dialog_view, null);
        TextView msg = (TextView) contents.findViewById(R.id.message);
        if (threadIds == null) {
            msg.setText(ModeStringUtil.getModeResFromArray(context, R.array.confirm_delete_all_conversations));
        } else {
            int cnt = threadIds.size();
            msg.setText(context.getResources().getQuantityString(R.plurals.confirm_delete_conversation, cnt, Integer.valueOf(cnt)));
        }
        final CheckBox checkbox = (CheckBox) contents.findViewById(R.id.delete_locked);
        if (!hasLockedMessages) {
            checkbox.setVisibility(8);
        } else {
            listener.setDeleteLockedMessage(checkbox.isChecked());
            checkbox.setOnClickListener(new View.OnClickListener() { // from class: com.android.mms.ui.ConversationList.29
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    listener.setDeleteLockedMessage(checkbox.isChecked());
                }
            });
        }
        myDialog = new AlertDialogFp.Builder(context).setMessage(ModeStringUtil.getModeResFromArray(context, R.array.delete_dialog_msg)).setPositiveButton(R.string.monaka_yes, listener).setNegativeButton(R.string.monaka_no, (DialogInterface.OnClickListener) null).create();
        myDialog.show();
        myDialog.getButton(-2).requestFocus();
    }

    public static void setDialogButtonFocus(AlertDialog dialog, int whichButton) {
        Button btn;
        if (dialog != null && (btn = dialog.getButton(whichButton)) != null) {
            btn.setFocusable(true);
            btn.setFocusableInTouchMode(true);
            btn.requestFocus();
        }
    }

    public static void execDeleteThread(final long threadId, final Conversation.ConversationQueryHandler handler, Context context) {
        Log.d("Mms", "+ConversationList : execDeleteThread() threadId=" + threadId + ",handler=" + handler + ",context=" + handler);
        ArrayList<Long> tempThreadIds = null;
        if (threadId != -1) {
            tempThreadIds = new ArrayList<>();
            tempThreadIds.add(Long.valueOf(threadId));
        }
        final Collection<Long> threadIds = tempThreadIds;
        MessageUtils.handleReadReport(context, threadIds, DownloadManager.STATE_DOWNLOADING, new Runnable() { // from class: com.android.mms.ui.ConversationList.30
            @Override // java.lang.Runnable
            public void run() {
                if (threadId == -1) {
                    Conversation.startDeleteAll(handler, ConversationList.DELETE_CONVERSATION_TOKEN, true);
                    return;
                }
                Iterator i$ = threadIds.iterator();
                while (i$.hasNext()) {
                    long threadId2 = ((Long) i$.next()).longValue();
                    Conversation.startDelete(handler, ConversationList.DELETE_CONVERSATION_TOKEN, false, threadId2);
                    DraftCache.getInstance().setDraftState(threadId2, false);
                }
            }
        });
    }

    public static class DeleteThreadListener implements DialogInterface.OnClickListener {
        private final Context mContext;
        private boolean mDeleteLockedMessages;
        private final Conversation.ConversationQueryHandler mHandler;
        private final Collection<Long> mThreadIds;

        public DeleteThreadListener(Collection<Long> threadIds, Conversation.ConversationQueryHandler handler, Context context) {
            this.mThreadIds = threadIds;
            this.mHandler = handler;
            this.mContext = context;
        }

        public void setDeleteLockedMessage(boolean deleteLockedMessages) {
            this.mDeleteLockedMessages = deleteLockedMessages;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int whichButton) {
            MessageUtils.handleReadReport(this.mContext, this.mThreadIds, DownloadManager.STATE_DOWNLOADING, new Runnable() { // from class: com.android.mms.ui.ConversationList.DeleteThreadListener.1
                @Override // java.lang.Runnable
                public void run() {
                    if (DeleteThreadListener.this.mContext instanceof ConversationList) {
                        ((ConversationList) DeleteThreadListener.this.mContext).unbindListeners(DeleteThreadListener.this.mThreadIds);
                    }
                    if (DeleteThreadListener.this.mThreadIds != null) {
                        Iterator i$ = DeleteThreadListener.this.mThreadIds.iterator();
                        while (i$.hasNext()) {
                            long threadId = ((Long) i$.next()).longValue();
                            Conversation.startDelete(DeleteThreadListener.this.mHandler, ConversationList.DELETE_CONVERSATION_TOKEN, DeleteThreadListener.this.mDeleteLockedMessages, threadId);
                            DraftCache.getInstance().setDraftState(threadId, false);
                        }
                        return;
                    }
                    Conversation.startDeleteAll(DeleteThreadListener.this.mHandler, ConversationList.DELETE_CONVERSATION_TOKEN, DeleteThreadListener.this.mDeleteLockedMessages);
                    DraftCache.getInstance().refresh();
                }
            });
            int unused = ConversationList.keyGuideFlag = 0;
            dialog.dismiss();
        }
    }

    public class DeleteDialogListener extends DeleteThreadListener {
        public DeleteDialogListener(Collection<Long> threadIds, Conversation.ConversationQueryHandler handler, Context context) {
            super(threadIds, handler, context);
        }

        @Override // com.android.mms.ui.ConversationList.DeleteThreadListener, android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int whichButton) {
            super.onClick(dialog, whichButton);
            ConversationList.this.setDelConversationMod(false);
        }
    }

    private final class ThreadListQueryHandler extends Conversation.ConversationQueryHandler {
        public ThreadListQueryHandler(ContentResolver contentResolver) {
            super(contentResolver);
        }

        @Override // android.content.AsyncQueryHandler
        protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
            switch (token) {
                case ConversationList.THREAD_LIST_QUERY_TOKEN /* 1701 */:
                    ConversationList.mListAdapter.changeCursor(cursor);
                    if (cursor == null || cursor.getCount() == 0) {
                        boolean unused = ConversationList.mExistMessage = false;
                        ConversationList.this.mSoftkey.SetCenterSoftkey((Bitmap) null);
                    } else {
                        boolean unused2 = ConversationList.mExistMessage = true;
                        ConversationList.this.mSoftkey.SetCenterSoftkey(R.drawable.key_center);
                    }
                    ConversationList.this.initMenu();
                    ConversationList.this.listView.requestFocus();
                    ConversationList.this.setTitle(ConversationList.this.mTitle);
                    ConversationList.this.setProgressBarIndeterminateVisibility(false);
                    if (!ConversationList.this.mIsScreenOff) {
                        ConversationList.this.needToMarkAsSeen();
                    }
                    break;
                case ConversationList.UNREAD_THREADS_QUERY_TOKEN /* 1702 */:
                    break;
                case ConversationList.HAVE_LOCKED_MESSAGES_TOKEN /* 1802 */:
                    if (ConversationList.this.isFinishing()) {
                        Log.w("Mms", "ConversationList is finished, do nothing ");
                        if (cursor != null) {
                            cursor.close();
                            return;
                        }
                        return;
                    }
                    Collection<Long> threadIds = (Collection) cookie;
                    ConversationList.confirmDeleteThreadDialog(ConversationList.this.new DeleteDialogListener(threadIds, ConversationList.this.mQueryHandler, ConversationList.this), threadIds, cursor != null && cursor.getCount() > 0, ConversationList.this);
                    if (cursor != null) {
                        cursor.close();
                    }
                    break;
                    break;
                default:
                    Log.e("Mms", "onQueryComplete called with unknown token " + token);
                    break;
            }
            if (ConversationList.mListAdapter == null || ConversationList.mListAdapter.getCount() == 0) {
                ConversationList.this.mItemView = null;
            } else if (ConversationList.this.mItemView != null) {
                String unused3 = ConversationList.mPhoneString = ((ConversationListItem) ConversationList.this.mItemView).formatConMessage().toString();
            }
            ConversationList.this.invalidateOptionsMenu();
        }

        @Override // com.android.mms.data.Conversation.ConversationQueryHandler, android.content.AsyncQueryHandler
        protected void onDeleteComplete(int token, Object cookie, int result) {
            super.onDeleteComplete(token, cookie, result);
            switch (token) {
                case ConversationList.DELETE_CONVERSATION_TOKEN /* 1801 */:
                    long threadId = cookie != null ? ((Long) cookie).longValue() : -1L;
                    if (threadId == -1) {
                        Contact.unregisterDataBasesObserver(ConversationList.this);
                        Contact.init(ConversationList.this);
                    } else {
                        Conversation conv = Conversation.get((Context) ConversationList.this, threadId, false);
                        if (conv != null) {
                            ContactList recipients = conv.getRecipients();
                            for (Contact contact : recipients) {
                                contact.removeFromCache();
                            }
                        }
                    }
                    Conversation.init(ConversationList.this);
                    MessagingNotification.nonBlockingUpdateNewMessageIndicator(ConversationList.this, false, false);
                    MessagingNotification.updateSendFailedNotification(ConversationList.this);
                    ConversationList.this.startAsyncQuery();
                    MmsWidgetProvider.notifyDatasetChanged(ConversationList.this.getApplicationContext());
                    break;
                case ConversationList.DELETE_OBSOLETE_THREADS_TOKEN /* 1803 */:
                    LogTag.debug("onQueryComplete finished DELETE_OBSOLETE_THREADS_TOKEN", new Object[0]);
                    break;
            }
            if (result > 0) {
                ConversationList.this.mDeletedHandler.sendEmptyMessage(1);
            }
        }
    }

    private class ModeCallback implements AbsListView.MultiChoiceModeListener {
        private View mMultiSelectActionBarView;
        private TextView mSelectedConvCount;
        private HashSet<Long> mSelectedThreadIds;

        private ModeCallback() {
        }

        @Override // android.view.ActionMode.Callback
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = ConversationList.this.getMenuInflater();
            this.mSelectedThreadIds = new HashSet<>();
            inflater.inflate(R.menu.conversation_multi_select_menu, menu);
            if (this.mMultiSelectActionBarView == null) {
                this.mMultiSelectActionBarView = (ViewGroup) LayoutInflater.from(ConversationList.this).inflate(R.layout.conversation_list_multi_select_actionbar, (ViewGroup) null);
                this.mSelectedConvCount = (TextView) this.mMultiSelectActionBarView.findViewById(R.id.selected_conv_count);
            }
            mode.setCustomView(this.mMultiSelectActionBarView);
            ((TextView) this.mMultiSelectActionBarView.findViewById(R.id.title)).setText(ModeStringUtil.getModeResFromArray(ConversationList.this, R.array.select_conversations));
            return true;
        }

        @Override // android.view.ActionMode.Callback
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            if (this.mMultiSelectActionBarView == null) {
                ViewGroup v = (ViewGroup) LayoutInflater.from(ConversationList.this).inflate(R.layout.conversation_list_multi_select_actionbar, (ViewGroup) null);
                mode.setCustomView(v);
                this.mSelectedConvCount = (TextView) v.findViewById(R.id.selected_conv_count);
                return true;
            }
            return true;
        }

        @Override // android.view.ActionMode.Callback
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case R.id.delete /* 2131689674 */:
                    if (this.mSelectedThreadIds.size() > 0) {
                        ConversationList.confirmDeleteThreads(this.mSelectedThreadIds, ConversationList.this.mQueryHandler);
                    }
                    mode.finish();
                    break;
            }
            return true;
        }

        @Override // android.view.ActionMode.Callback
        public void onDestroyActionMode(ActionMode mode) {
            ConversationListAdapter adapter = (ConversationListAdapter) ConversationList.this.listView.getAdapter();
            adapter.uncheckAll();
            this.mSelectedThreadIds = null;
        }

        @Override // android.widget.AbsListView.MultiChoiceModeListener
        public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
            int checkedCount = ConversationList.this.listView.getCheckedItemCount();
            this.mSelectedConvCount.setText(Integer.toString(checkedCount));
            Cursor cursor = (Cursor) ConversationList.this.listView.getItemAtPosition(position);
            Conversation conv = Conversation.from(ConversationList.this, cursor);
            conv.setIsChecked(checked);
            long threadId = conv.getThreadId();
            if (checked) {
                this.mSelectedThreadIds.add(Long.valueOf(threadId));
            } else {
                this.mSelectedThreadIds.remove(Long.valueOf(threadId));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String format, Object... args) {
        String s = String.format(format, args);
        Log.d("Mms", "[" + Thread.currentThread().getId() + "] " + s);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void needToMarkAsSeen() {
        if (this.mNeedToMarkAsSeen) {
            this.mNeedToMarkAsSeen = false;
            Conversation.markAllConversationsAsSeen(getApplicationContext());
            this.mHandler.post(this.mDeleteObsoleteThreadsRunnable);
        }
    }

    public class OnScreenReceiver extends BroadcastReceiver {
        public OnScreenReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("android.intent.action.USER_PRESENT".equals(intent.getAction())) {
                ConversationList.this.mIsScreenOff = false;
                if (ConversationList.this.mIsForeground) {
                    ConversationList.this.needToMarkAsSeen();
                    return;
                }
                return;
            }
            if ("android.intent.action.SCREEN_OFF".equals(intent.getAction())) {
                ConversationList.this.mIsScreenOff = true;
            }
        }
    }

    private void delConversation() {
        if (this.mSelectedIdSet.size() > 0) {
            confirmDeleteThreads(this.mSelectedIdSet, this.mQueryHandler);
        }
    }

    public void setDelConversationMod(boolean delmod) {
        if (delmod) {
            keyGuideFlag = 1;
        } else {
            keyGuideFlag = 0;
        }
        mListAdapter.setSelectMode(delmod);
        mListAdapter.notifyDataSetChanged();
        this.isSelectMode = delmod;
        setNavigationBarMenuButtonVisibility(delmod ? false : true);
        this.mSelectedIdSet.clear();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void setListViewChecked(boolean checked) {
        int count = this.listView.getCount();
        if (checked) {
            for (int i = 0; i < count; i++) {
                Cursor cursor = (Cursor) this.listView.getItemAtPosition(i);
                Conversation conv = Conversation.from(this, cursor);
                long tid = conv.getThreadId();
                this.mSelectedIdSet.add(Long.valueOf(tid));
            }
        } else {
            for (int i2 = 0; i2 < count; i2++) {
                Cursor cursor2 = (Cursor) this.listView.getItemAtPosition(i2);
                Conversation conv2 = Conversation.from(this, cursor2);
                conv2.getThreadId();
            }
            this.mSelectedIdSet.clear();
        }
        mListAdapter.setAllSelectedId(this.mSelectedIdSet);
        mListAdapter.notifyDataSetChanged();
    }

    class SelectedCheckHandler extends Handler {
        public SelectedCheckHandler() {
        }

        public SelectedCheckHandler(Looper L) {
            super(L);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            Log.d("MyHandler", "handleMessage......");
            super.handleMessage(msg);
            Object[] selectIDs = ConversationList.this.mSelectedIdSet.toArray();
            for (Object long1 : selectIDs) {
                Log.d("Mms", "mSelectedIdSet:" + long1.toString());
            }
            int count = ConversationList.this.listView.getCount();
            Log.d("Mms", MainMenuActivity.FOLDER_LIST_DATA_COUNT + count);
            for (int i = 0; i < count; i++) {
                View v = ConversationList.this.listView.getChildAt(i);
                boolean isItem = v instanceof ConversationListItem;
                Log.d("Mms", "isItem:" + isItem);
                if (isItem) {
                    Cursor cursor = (Cursor) ConversationList.this.listView.getItemAtPosition(i);
                    Conversation conv = Conversation.from(ConversationList.this.mContext, cursor);
                    long tid = conv.getThreadId();
                    Log.d("Mms", "tid:" + tid);
                    if (ConversationList.this.mSelectedIdSet.contains(Long.valueOf(tid))) {
                        ConversationListItem headerView = (ConversationListItem) v;
                        headerView.setItemSelected(true);
                    }
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initView() {
        this.ll_toptitle = (LinearLayout) findViewById(R.id.ll_toptitle);
        this.sms_default_app_icon = (ImageView) findViewById(R.id.sms_default_app_icon);
        this.sms_default_app_icon.setVisibility(0);
        this.mSoftkey = findViewById(R.id.soft_key);
        this.mSoftkey.SetLeftSoftkey(getString(R.string.soft_menu));
        this.mSoftkey.SetRightSoftkey(ModeStringUtil.getModeResFromArray(this, R.array.soft_back_text));
        this.mSoftkey.SetCenterSoftkey(R.drawable.key_center);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void initMenu() {
        if (this.mMenu == null) {
            PopupMenu tempMenu = new PopupMenu(this, null);
            tempMenu.inflate(R.menu.conversation_list_menu_monaka);
            this.mMenu = tempMenu.getMenu();
            MenuItem reply = this.mMenu.findItem(R.id.action_reply);
            MenuItem callNumber = this.mMenu.findItem(R.id.action_call_number);
            MenuItem addToContacts = this.mMenu.findItem(R.id.action_add_to_contacts);
            MenuItem deleteConversation = this.mMenu.findItem(R.id.action_delete);
            MenuItem deleteAllConversation = this.mMenu.findItem(R.id.action_delete_all);
            reply.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.msg_reply_str));
            callNumber.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_call_number_str));
            addToContacts.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_add_to_contact_str));
            deleteConversation.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_delete_str));
            deleteAllConversation.setTitle(ModeStringUtil.getModeResFromArray(this, R.array.monaka_delete_all_str));
        }
        this.mMenuHandler = new AppMenuHandler(this, this.mMenu);
        this.mMenuHandler.addObserver(new AppMenuObserver() { // from class: com.android.mms.ui.ConversationList.34
            public void onOptionsItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_add_to_contacts /* 2131689665 */:
                        Intent intent = new Intent("com.fujitsu.settings.ACTION_PWD_CHECK");
                        ConversationList.this.startActivityForResult(intent, 10);
                        break;
                    case R.id.action_reply /* 2131689666 */:
                        if (DraftCache.getInstance().hasDraft(ConversationList.this.mThreadID)) {
                            ConversationList.this.showDialogEx(6);
                        } else {
                            ConversationList.this.createNewMessageByName(ConversationList.mPhoneString);
                        }
                        break;
                    case R.id.action_reference_sim_card /* 2131689670 */:
                        ConversationList.this.startActivity(new Intent((Context) ConversationList.this, (Class<?>) ManageSimMessages.class));
                        break;
                    case R.id.action_call_number /* 2131689671 */:
                        ConversationList.this.dialRecipient(ConversationList.mPhoneString);
                        break;
                    case R.id.action_delete /* 2131689672 */:
                        Cursor cursor = (Cursor) ConversationList.this.listView.getItemAtPosition(ConversationList.this.listView.getSelectedItemPosition());
                        Conversation conv = Conversation.from(ConversationList.this, cursor);
                        long tid = conv.getThreadId();
                        ConversationList.this.mSelectedIdSet.add(Long.valueOf(tid));
                        Log.d("Mms", "onMenuItem click delete thread id " + tid);
                        ConversationList.this.showDeleteDialog(tid);
                        break;
                    case R.id.action_delete_all /* 2131689673 */:
                        ConversationList.this.showDeleteDialog(-1L);
                        break;
                }
            }

            public void onMenuVisibilityChanged(boolean isVisible) {
                if (!isVisible) {
                    ConversationList.this.mSoftkey.SetLeftSoftkey(R.string.soft_menu);
                } else {
                    ConversationList.this.mSoftkey.SetLeftSoftkey(ModeStringUtil.getModeResFromArray(ConversationList.this, R.array.menu_left_key_str));
                }
            }
        });
    }

    private void initListener() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void createNewMessageByName(String phoneNumber) {
        String[] phoneArray = phoneNumber.split(MessageDispActivity.string_delimiter);
        ArrayList<String[]> senderList = new ArrayList<>();
        for (String str : phoneArray) {
            senderList.add(new String[]{null, null, str});
        }
        Intent intent = new Intent((Context) this, (Class<?>) MessageDispActivity.class);
        intent.putExtra("key_sender", senderList);
        intent.putExtra("key_sender_edit", false);
        intent.putExtra(MessageDispActivity.extraKey_from_conversation_list, true);
        startActivityForResult(intent, 1000);
    }

    public void dialRecipient(String phoneString) {
        Intent dialIntent = new Intent("android.intent.action.CALL_PRIVILEGED", Uri.parse("tel:" + PhoneNumberUtils.stripSeparators(phoneString)));
        startActivity(dialIntent);
    }

    public void addContact(String phoneString) {
        Intent intent = new Intent("android.intent.action.INSERT_OR_EDIT");
        intent.setType("vnd.android.cursor.item/contact");
        intent.putExtra("phone", phoneString);
        startActivity(intent);
    }

    public void addContact2(String phoneString) {
        Intent intent = new Intent("com.android.contacts.kidsactivity.KidsContactsPeopleEditlistActivity");
        intent.putExtra("kid_contacts_intentvalue", phoneString.replace(" ", LoggingEvents.EXTRA_CALLING_APP_NAME));
        Log.d("Mms", "add to contacts:number = xxxxxxx");
        intent.putExtra("kids_flag", 3);
        startActivity(intent);
    }

    public boolean isOneContact(String phoneString) {
        return (phoneString.contains(MessageDispActivity.string_delimiter) || TextUtils.isEmpty(phoneString)) ? false : true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public String isOneNotInContact(String phoneString) {
        List<String> phoneList = new ArrayList<>();
        if (phoneString.contains(MessageDispActivity.string_delimiter)) {
            String[] phoneArray = phoneString.split(MessageDispActivity.string_delimiter);
            for (int i = 0; i < phoneArray.length; i++) {
                if (!getAddressFromPhoneNumber(phoneArray[i], this)) {
                    phoneList.add(phoneArray[i]);
                }
            }
        } else if (!getAddressFromPhoneNumber(phoneString, this)) {
            phoneList.add(phoneString);
        }
        return phoneList.size() == 1 ? phoneList.get(0).toString() : LoggingEvents.EXTRA_CALLING_APP_NAME;
    }

    public boolean getAddressFromPhoneNumber(String phoneNumber, Context context) {
        Cursor cursorOriginal = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{"display_name"}, "data1='" + phoneNumber + "'", null, null);
        if (cursorOriginal == null) {
            if (cursorOriginal != null) {
                cursorOriginal.close();
            }
            return false;
        }
        try {
            try {
                if (cursorOriginal.getCount() > 0) {
                    if (cursorOriginal != null) {
                        cursorOriginal.close();
                    }
                    return true;
                }
                if (cursorOriginal != null) {
                    cursorOriginal.close();
                }
                return false;
            } catch (Exception e) {
                Log.e("Mms", "Exception: " + e);
                if (cursorOriginal != null) {
                    cursorOriginal.close();
                }
                return false;
            }
        } catch (Throwable th) {
            if (cursorOriginal != null) {
                cursorOriginal.close();
            }
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void deleteDraftSmsMessage(long threadId) {
        SqliteWrapper.delete(this.mContext, this.mContext.getContentResolver(), ContentUris.withAppendedId(Telephony.Sms.Conversations.CONTENT_URI, threadId), SMS_DRAFT_WHERE, (String[]) null);
    }

    private boolean isPhoneUsimState(Context context) {
        TelephonyManager manager = (TelephonyManager) getSystemService("phone");
        switch (manager.getSimState()) {
            case 1:
            default:
                return false;
            case 5:
                return true;
        }
    }
}
