package com.android.mms.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewStub;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import com.android.mms.R;
import com.android.mms.data.WorkingMessage;
import com.android.mms.model.SlideModel;
import com.android.mms.model.SlideshowModel;

/* JADX INFO: loaded from: classes.dex */
public class AttachmentEditor extends LinearLayout {
    static final int MSG_EDIT_SLIDESHOW = 1;
    static final int MSG_PLAY_AUDIO = 8;
    static final int MSG_PLAY_SLIDESHOW = 3;
    static final int MSG_PLAY_VIDEO = 7;
    static final int MSG_REMOVE_ATTACHMENT = 10;
    static final int MSG_REPLACE_AUDIO = 6;
    static final int MSG_REPLACE_IMAGE = 4;
    static final int MSG_REPLACE_VIDEO = 5;
    static final int MSG_SEND_SLIDESHOW = 2;
    static final int MSG_VIEW_IMAGE = 9;
    private static final String TAG = "Mms";
    private boolean mCanSend;
    private final Context mContext;
    private Handler mHandler;
    private Presenter mPresenter;
    private Button mSendButton;
    private SlideshowModel mSlideshow;
    private SlideViewInterface mView;

    public AttachmentEditor(Context context, AttributeSet attr) {
        super(context, attr);
        this.mContext = context;
    }

    public boolean update(WorkingMessage msg) {
        hideView();
        this.mView = null;
        if (!msg.hasAttachment()) {
            return false;
        }
        this.mSlideshow = msg.getSlideshow();
        this.mView = createView();
        if (this.mPresenter == null || !this.mSlideshow.equals(this.mPresenter.getModel())) {
            this.mPresenter = PresenterFactory.getPresenter("MmsThumbnailPresenter", this.mContext, this.mView, this.mSlideshow);
        } else {
            this.mPresenter.setView(this.mView);
        }
        this.mPresenter.present(null);
        return true;
    }

    public void setHandler(Handler handler) {
        this.mHandler = handler;
    }

    public void setCanSend(boolean enable) {
        if (this.mCanSend != enable) {
            this.mCanSend = enable;
            updateSendButton();
        }
    }

    private void updateSendButton() {
        if (this.mSendButton != null) {
            this.mSendButton.setEnabled(this.mCanSend);
            this.mSendButton.setFocusable(this.mCanSend);
        }
    }

    public void hideView() {
        if (this.mView != null) {
            ((View) this.mView).setVisibility(8);
        }
    }

    private View getStubView(int stubId, int viewId) {
        View view = findViewById(viewId);
        if (view == null) {
            ViewStub stub = (ViewStub) findViewById(stubId);
            return stub.inflate();
        }
        return view;
    }

    private class MessageOnClick implements View.OnClickListener {
        private int mWhat;

        public MessageOnClick(int what) {
            this.mWhat = what;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            Message msg = Message.obtain(AttachmentEditor.this.mHandler, this.mWhat);
            msg.sendToTarget();
        }
    }

    private SlideViewInterface createView() {
        boolean inPortrait = inPortraitMode();
        if (this.mSlideshow.size() > 1) {
            return createSlideshowView(inPortrait);
        }
        SlideModel slide = this.mSlideshow.get(0);
        if (slide.hasImage()) {
            return createMediaView(R.id.image_attachment_view_stub, R.id.image_attachment_view, R.id.view_image_button, R.id.replace_image_button, R.id.remove_image_button, 9, 4, 10);
        }
        if (slide.hasVideo()) {
            return createMediaView(R.id.video_attachment_view_stub, R.id.video_attachment_view, R.id.view_video_button, R.id.replace_video_button, R.id.remove_video_button, 7, 5, 10);
        }
        if (slide.hasAudio()) {
            return createMediaView(R.id.audio_attachment_view_stub, R.id.audio_attachment_view, R.id.play_audio_button, R.id.replace_audio_button, R.id.remove_audio_button, 8, 6, 10);
        }
        throw new IllegalArgumentException();
    }

    private boolean inPortraitMode() {
        Configuration configuration = this.mContext.getResources().getConfiguration();
        return configuration.orientation == 1;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private SlideViewInterface createMediaView(int stub_view_id, int real_view_id, int view_button_id, int replace_button_id, int remove_button_id, int view_message, int replace_message, int remove_message) {
        LinearLayout linearLayout = (LinearLayout) getStubView(stub_view_id, real_view_id);
        linearLayout.setVisibility(0);
        Button viewButton = (Button) linearLayout.findViewById(view_button_id);
        Button replaceButton = (Button) linearLayout.findViewById(replace_button_id);
        Button removeButton = (Button) linearLayout.findViewById(remove_button_id);
        viewButton.setOnClickListener(new MessageOnClick(view_message));
        replaceButton.setOnClickListener(new MessageOnClick(replace_message));
        removeButton.setOnClickListener(new MessageOnClick(remove_message));
        return (SlideViewInterface) linearLayout;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private SlideViewInterface createSlideshowView(boolean inPortrait) {
        LinearLayout linearLayout = (LinearLayout) getStubView(R.id.slideshow_attachment_view_stub, R.id.slideshow_attachment_view);
        linearLayout.setVisibility(0);
        Button editBtn = (Button) linearLayout.findViewById(R.id.edit_slideshow_button);
        this.mSendButton = (Button) linearLayout.findViewById(R.id.send_slideshow_button);
        updateSendButton();
        ImageButton playBtn = (ImageButton) linearLayout.findViewById(R.id.play_slideshow_button);
        editBtn.setOnClickListener(new MessageOnClick(1));
        this.mSendButton.setOnClickListener(new MessageOnClick(2));
        playBtn.setOnClickListener(new MessageOnClick(3));
        Button removeButton = (Button) linearLayout.findViewById(R.id.remove_slideshow_button);
        removeButton.setOnClickListener(new MessageOnClick(10));
        return (SlideViewInterface) linearLayout;
    }
}
