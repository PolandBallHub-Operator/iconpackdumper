package com.android.mms.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.mms.R;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class IconListAdapter extends ArrayAdapter<IconListItem> {
    private static final int mResource = 2130968592;
    protected LayoutInflater mInflater;
    private ViewHolder mViewHolder;

    static class ViewHolder {
        private ImageView mImageView;
        private TextView mTextView;
        private View mView;

        public ViewHolder(View view) {
            this.mView = view;
        }

        public TextView getTextView() {
            if (this.mTextView == null) {
                this.mTextView = (TextView) this.mView.findViewById(R.id.text1);
            }
            return this.mTextView;
        }

        public ImageView getImageView() {
            if (this.mImageView == null) {
                this.mImageView = (ImageView) this.mView.findViewById(R.id.icon);
            }
            return this.mImageView;
        }
    }

    public IconListAdapter(Context context, List<IconListItem> items) {
        super(context, R.layout.icon_list_item, items);
        this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        if (convertView == null) {
            view = this.mInflater.inflate(R.layout.icon_list_item, parent, false);
            this.mViewHolder = new ViewHolder(view);
            view.setTag(this.mViewHolder);
        } else {
            view = convertView;
            this.mViewHolder = (ViewHolder) view.getTag();
        }
        TextView text = this.mViewHolder.getTextView();
        text.setText(getItem(position).getTitle());
        ImageView image = this.mViewHolder.getImageView();
        image.setImageResource(getItem(position).getResource());
        return view;
    }

    public static class IconListItem {
        private final int mResource;
        private final String mTitle;

        public IconListItem(String title, int resource) {
            this.mResource = resource;
            this.mTitle = title;
        }

        public String getTitle() {
            return this.mTitle;
        }

        public int getResource() {
            return this.mResource;
        }
    }
}
