package com.android.mms.ui;

import android.content.Context;
import com.android.mms.MmsConfig;
import com.android.mms.R;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class AttachmentTypeSelectorAdapter extends IconListAdapter {
    public static final int ADD_IMAGE = 0;
    public static final int ADD_SLIDESHOW = 6;
    public static final int ADD_SOUND = 4;
    public static final int ADD_VIDEO = 2;
    public static final int MODE_WITHOUT_SLIDESHOW = 1;
    public static final int MODE_WITH_SLIDESHOW = 0;
    public static final int RECORD_SOUND = 5;
    public static final int RECORD_VIDEO = 3;
    public static final int TAKE_PICTURE = 1;

    public AttachmentTypeSelectorAdapter(Context context, int mode) {
        super(context, getData(mode, context));
    }

    public int buttonToCommand(int whichButton) {
        AttachmentListItem item = (AttachmentListItem) getItem(whichButton);
        return item.getCommand();
    }

    protected static List<IconListAdapter.IconListItem> getData(int mode, Context context) {
        List<IconListAdapter.IconListItem> data = new ArrayList<>(7);
        addItem(data, context.getString(R.string.attach_image), R.drawable.ic_attach_picture_holo_light, 0);
        addItem(data, context.getString(R.string.attach_take_photo), R.drawable.ic_attach_capture_picture_holo_light, 1);
        addItem(data, context.getString(R.string.attach_video), R.drawable.ic_attach_video_holo_light, 2);
        addItem(data, context.getString(R.string.attach_record_video), R.drawable.ic_attach_capture_video_holo_light, 3);
        if (MmsConfig.getAllowAttachAudio()) {
            addItem(data, context.getString(R.string.attach_sound), R.drawable.ic_attach_audio_holo_light, 4);
        }
        addItem(data, context.getString(R.string.attach_record_sound), R.drawable.ic_attach_capture_audio_holo_light, 5);
        if (mode == 0) {
            addItem(data, context.getString(R.string.attach_slideshow), R.drawable.ic_attach_slideshow_holo_light, 6);
        }
        return data;
    }

    protected static void addItem(List<IconListAdapter.IconListItem> data, String title, int resource, int command) {
        AttachmentListItem temp = new AttachmentListItem(title, resource, command);
        data.add(temp);
    }

    public static class AttachmentListItem extends IconListAdapter.IconListItem {
        private int mCommand;

        public AttachmentListItem(String title, int resource, int command) {
            super(title, resource);
            this.mCommand = command;
        }

        public int getCommand() {
            return this.mCommand;
        }
    }
}
