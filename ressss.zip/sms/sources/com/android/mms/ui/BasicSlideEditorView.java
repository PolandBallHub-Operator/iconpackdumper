package com.android.mms.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import com.android.mms.R;
import java.io.IOException;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class BasicSlideEditorView extends LinearLayout implements SlideViewInterface {
    private static final String TAG = "Mms";
    private TextView mAudioNameView;
    private View mAudioView;
    private EditText mEditText;
    private ImageView mImageView;
    private OnTextChangedListener mOnTextChangedListener;
    private boolean mOnTextChangedListenerEnabled;

    public interface OnTextChangedListener {
        void onTextChanged(String str);
    }

    public BasicSlideEditorView(Context context) {
        super(context);
        this.mOnTextChangedListenerEnabled = true;
    }

    public BasicSlideEditorView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mOnTextChangedListenerEnabled = true;
    }

    @Override // android.view.View
    public void onFinishInflate() {
        this.mImageView = (ImageView) findViewById(R.id.image);
        this.mAudioView = findViewById(R.id.audio);
        this.mAudioNameView = (TextView) findViewById(R.id.audio_name);
        this.mEditText = (EditText) findViewById(R.id.text_message);
        this.mEditText.addTextChangedListener(new TextWatcher() { // from class: com.android.mms.ui.BasicSlideEditorView.1
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (BasicSlideEditorView.this.mOnTextChangedListenerEnabled && BasicSlideEditorView.this.mOnTextChangedListener != null) {
                    BasicSlideEditorView.this.mOnTextChangedListener.onTextChanged(s.toString());
                }
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
            }
        });
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void startAudio() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void startVideo() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setAudio(Uri audio, String name, Map<String, ?> extras) {
        this.mAudioView.setVisibility(0);
        this.mAudioNameView.setText(name);
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImage(String name, Bitmap bitmap) {
        if (bitmap == null) {
            try {
                bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_missing_thumbnail_picture);
            } catch (OutOfMemoryError e) {
                Log.e("Mms", "setImage: out of memory: ", e);
                return;
            }
        }
        this.mImageView.setImageBitmap(bitmap);
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImageRegionFit(String fit) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setImageVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setText(String name, String text) {
        this.mOnTextChangedListenerEnabled = false;
        if (text != null && !text.equals(this.mEditText.getText().toString())) {
            this.mEditText.setText(text);
            this.mEditText.setSelection(text.length());
        }
        this.mOnTextChangedListenerEnabled = true;
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setTextVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideo(String name, Uri video) throws IOException {
        try {
            Bitmap bitmap = VideoAttachmentView.createVideoThumbnail(this.mContext, video);
            if (bitmap == null) {
                bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_missing_thumbnail_video);
            }
            this.mImageView.setImageBitmap(bitmap);
        } catch (OutOfMemoryError e) {
            Log.e("Mms", "setVideo: out of memory: ", e);
        }
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideoThumbnail(String name, Bitmap bitmap) {
        this.mImageView.setImageBitmap(bitmap);
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void setVideoVisibility(boolean visible) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void stopAudio() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void stopVideo() {
    }

    @Override // com.android.mms.ui.ViewInterface
    public void reset() {
        this.mImageView.setImageDrawable(null);
        this.mAudioView.setVisibility(8);
        this.mOnTextChangedListenerEnabled = false;
        this.mEditText.setText(LoggingEvents.EXTRA_CALLING_APP_NAME);
        this.mOnTextChangedListenerEnabled = true;
    }

    @Override // com.android.mms.ui.ViewInterface
    public void setVisibility(boolean visible) {
    }

    public void setOnTextChangedListener(OnTextChangedListener l) {
        this.mOnTextChangedListener = l;
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void pauseAudio() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void pauseVideo() {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void seekAudio(int seekTo) {
    }

    @Override // com.android.mms.ui.SlideViewInterface
    public void seekVideo(int seekTo) {
    }
}
