package com.android.mms.ui;

import android.content.Context;
import com.android.ex.chips.BaseRecipientAdapter;

/* JADX INFO: loaded from: classes.dex */
public class ChipsRecipientAdapter extends BaseRecipientAdapter {
    private static final int DEFAULT_PREFERRED_MAX_RESULT_COUNT = 10;

    public ChipsRecipientAdapter(Context context) {
        super(context, 10, 1);
    }
}
