package com.android.mms.ui;

import android.widget.ImageView;
import com.android.common.speech.LoggingEvents;

/* JADX INFO: loaded from: classes.dex */
public interface Divot {
    public static final int BOTTOM_LEFT = 10;
    public static final int BOTTOM_MIDDLE = 11;
    public static final int BOTTOM_RIGHT = 12;
    public static final float CORNER_OFFSET = 12.0f;
    public static final float HEIGHT = 16.0f;
    public static final int LEFT_LOWER = 3;
    public static final int LEFT_MIDDLE = 2;
    public static final int LEFT_UPPER = 1;
    public static final int RIGHT_LOWER = 6;
    public static final int RIGHT_MIDDLE = 5;
    public static final int RIGHT_UPPER = 4;
    public static final int TOP_LEFT = 7;
    public static final int TOP_MIDDLE = 8;
    public static final int TOP_RIGHT = 9;
    public static final float WIDTH = 6.0f;
    public static final String[] sPositionChoices = {LoggingEvents.EXTRA_CALLING_APP_NAME, "left_upper", "left_middle", "left_lower", "right_upper", "right_middle", "right_lower", "top_left", "top_middle", "top_right", "bottom_left", "bottom_middle", "bottom_right"};

    ImageView asImageView();

    void assignContactFromEmail(String str);

    float getCloseOffset();

    float getFarOffset();

    int getPosition();

    void setPosition(int i);
}
